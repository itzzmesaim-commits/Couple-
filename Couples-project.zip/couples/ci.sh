#!/bin/bash
# Runs inside GitHub Actions after the zip is extracted
set -e
cd "$(dirname "$0")"
npm install
mkdir -p ~/.android && cp ci/debug.keystore ~/.android/debug.keystore   # same signing key every build, so new APKs install over old ones
mkdir -p www/vendor
for f in app auth firestore; do cp node_modules/firebase/firebase-$f-compat.js www/vendor/ ; done
npx cap add android
python3 scripts/patch_manifest.py
npx @capacitor/assets generate --android
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug
