/* Couples - core app */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const AVATARS = ['😀', '😎', '🥰', '😈', '🦊', '🐼', '🦁', '🐯', '🐵', '🦄', '🌹', '🔥'];
const DATA = { dares: [], quiz: [], intimacy: { cards: [], male: [], female: [] } };
let auth, db, me = null, unsubs = [], FV;

const listen = u => { unsubs.push(u); return u; };
const clearListeners = () => { unsubs.forEach(u => { try { u(); } catch (e) {} }); unsubs = []; };
const ctx = () => ({ data: DATA });

function modal(html) {
  const m = $('#modal');
  m.innerHTML = `<div class="box">${html}</div>`;
  m.classList.remove('hidden');
  return m;
}
const closeModal = () => $('#modal').classList.add('hidden');
const toast = t => { const m = modal(`<p>${esc(t)}</p><button class="btn full" id="ok">OK</button>`); $('#ok', m).onclick = closeModal; };

/* ---------- boot ---------- */
async function boot() {
  const scr = $('#screen');
  if (!FIREBASE_CONFIG.apiKey || FIREBASE_CONFIG.apiKey === 'PASTE_HERE') {
    $('#nav').style.display = 'none';
    scr.innerHTML = `<div class="card"><h2>Setup baaki hai</h2><p>www/js/firebase-config.js mein apni Firebase keys paste karo. GUIDE.md ka Step 2 dekho.</p></div>`;
    return;
  }
  scr.innerHTML = '<p class="mut">Loading...</p>';
  firebase.initializeApp(FIREBASE_CONFIG);
  auth = firebase.auth(); db = firebase.firestore(); FV = firebase.firestore.FieldValue;
  for (const [k, f] of [['dares', 'dares.json'], ['quiz', 'quiz.json'], ['intimacy', 'intimacy.json']]) {
    try { DATA[k] = await (await fetch('data/' + f)).json(); } catch (e) { console.warn(f, e); }
  }
  $$('#nav button').forEach(b => b.onclick = () => show(b.dataset.s));
  auth.onAuthStateChanged(async u => {
    if (!u) { auth.signInAnonymously().catch(e => toast('Login fail: ' + e.message)); return; }
    const snap = await db.collection('users').doc(u.uid).get();
    if (!snap.exists) return setupProfile(u.uid);
    me = { uid: u.uid, ...snap.data() };
    db.collection('users').doc(u.uid).onSnapshot(s => { if (s.exists) { me = { uid: u.uid, ...s.data() }; $('#pts').textContent = `${me.avatar} ${me.name} · ⭐ ${me.points}`; } });
    show('home');
  });
}

function setupProfile(uid) {
  $('#nav').style.display = 'none';
  let av = AVATARS[0];
  $('#screen').innerHTML = `<h2>Apna profile banao</h2>
    <input id="nm" maxlength="14" placeholder="Apna naam">
    <div class="grid" style="grid-template-columns:repeat(6,1fr)">${AVATARS.map(a => `<button class="tile av" data-a="${a}">${a}</button>`).join('')}</div>
    <button class="btn full" id="go">Shuru karo</button>`;
  $$('[data-a]').forEach(b => b.onclick = () => { av = b.dataset.a; $$('[data-a]').forEach(x => x.classList.remove('adult')); b.classList.add('adult'); });
  $('#go').onclick = async () => {
    const name = $('#nm').value.trim();
    if (name.length < 2) return toast('Naam kam se kam 2 letter ka rakho.');
    await db.collection('users').doc(uid).set({ name, nameLower: name.toLowerCase(), avatar: av, points: 0, created: FV.serverTimestamp() });
    $('#nav').style.display = 'flex';
    location.reload();
  };
}

/* ---------- navigation ---------- */
const screens = { home: homeScreen, live: liveScreen, dm: dmScreen, rank: rankScreen, me: meScreen };
function show(name) {
  clearListeners();
  $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.s === name));
  $('#nav').style.display = 'flex';
  $('#screen').style.padding = '12px 14px';
  screens[name]();
}

/* ---------- age gate ---------- */
const ageOf = d => { const b = new Date(d), n = new Date(); let a = n.getFullYear() - b.getFullYear(); if (n < new Date(n.getFullYear(), b.getMonth(), b.getDate())) a--; return a; };
function requireAdult(cb) {
  const dob = localStorage.getItem('dob');
  if (dob && ageOf(dob) >= 18) {
    const m = modal(`<h2>🔞 18+ Content</h2><p>Is section mein adult content hai. Confirm karo ki aap 18 saal ya usse zyada ke ho.</p>
      <button class="btn full" id="y">Haan, main 18+ hoon</button><button class="btn sec full" id="n">Cancel</button>`);
    $('#y', m).onclick = () => { closeModal(); cb(); };
    $('#n', m).onclick = closeModal;
  } else {
    const m = modal(`<h2>🔞 Age Verification</h2><p>Apni date of birth daalo. 18 se kam age walon ko entry nahi milegi.</p>
      <input type="date" id="d"><button class="btn full" id="y">Verify</button><button class="btn sec full" id="n">Cancel</button>`);
    $('#n', m).onclick = closeModal;
    $('#y', m).onclick = () => {
      const v = $('#d', m).value;
      if (!v) return;
      if (ageOf(v) < 18) { closeModal(); return toast('Sorry, ye section sirf 18+ ke liye hai.'); }
      localStorage.setItem('dob', v); closeModal(); requireAdult(cb);
    };
  }
}

/* ---------- home / games ---------- */
function homeScreen() {
  $('#screen').innerHTML = `<h2>Games</h2><div class="grid">${GAMES.map(g => `<button class="tile ${g.adult ? 'adult' : ''}" data-g="${g.id}"><b>${g.icon}</b>${esc(g.name)}${g.adult ? '<br>🔞 18+' : ''}</button>`).join('')}</div>
    <p class="mut" style="text-align:center;margin-top:16px">Aur games jald aa rahe hain 💕</p>`;
  $$('[data-g]').forEach(b => b.onclick = () => {
    const g = GAMES.find(x => x.id === b.dataset.g);
    g.adult ? requireAdult(() => openGame(g)) : openGame(g);
  });
}

function openGame(g) {
  if (g.solo) {
    const s = $('#screen');
    s.innerHTML = `<button class="back">← Back</button><div id="solo"></div>`;
    $('.back', s).onclick = () => show('home');
    g.solo($('#solo'), ctx());
    return;
  }
  $('#screen').innerHTML = `<button class="back">← Back</button><h2>${g.icon} ${esc(g.name)}</h2><p class="mut">${esc(g.desc || '')}</p>
    <button class="btn full" id="qm">⚡ Quick Match (random partner)</button>
    <button class="btn sec full" id="cr">🔗 Room banao (partner ko code do)</button>
    <div class="row"><input id="code" placeholder="Room code" maxlength="5" style="text-transform:uppercase"><button class="btn" id="jn">Join</button></div>`;
  $('.back').onclick = () => show('home');
  $('#qm').onclick = () => quickMatch(g);
  $('#cr').onclick = async () => enterRoom(await createRoom(g));
  $('#jn').onclick = async () => {
    const c = $('#code').value.trim().toUpperCase();
    if (!c) return;
    (await joinRoom(c, g.id)) ? enterRoom(c) : toast('Room nahi mila, ya full hai.');
  };
}

const me2 = () => ({ uid: me.uid, name: me.name, avatar: me.avatar });
async function createRoom(g) {
  let id;
  do { id = Math.random().toString(36).slice(2, 7).toUpperCase(); } while ((await db.collection('rooms').doc(id).get()).exists);
  await db.collection('rooms').doc(id).set({ game: g.id, status: 'open', players: [me2()], st: JSON.stringify(g.init(ctx())), created: FV.serverTimestamp() });
  return id;
}
async function joinRoom(id, gameId) {
  const ref = db.collection('rooms').doc(id);
  try {
    return await db.runTransaction(async tx => {
      const s = await tx.get(ref);
      if (!s.exists) return false;
      const r = s.data();
      if (gameId && r.game !== gameId) return false;
      if (r.players.some(p => p.uid === me.uid)) return true;
      if (r.status !== 'open' || r.players.length !== 1) return false;
      tx.update(ref, { players: [...r.players, me2()], status: 'playing' });
      return true;
    });
  } catch (e) { return false; }
}
async function quickMatch(g) {
  $('#qm').textContent = 'Dhundh raha hoon...';
  const q = await db.collection('rooms').where('status', '==', 'open').where('game', '==', g.id).limit(8).get();
  for (const d of q.docs) {
    if (d.data().players[0].uid !== me.uid && await joinRoom(d.id, g.id)) return enterRoom(d.id);
  }
  enterRoom(await createRoom(g));
}

function enterRoom(id) {
  clearListeners();
  const ref = db.collection('rooms').doc(id);
  $('#screen').innerHTML = `<button class="back">← Leave</button><div class="scorebar" id="pl"></div><div class="status" id="stt"></div><div id="gm"></div>
    <details open><summary class="mut">💬 Game chat</summary><div id="gc" style="height:230px"></div></details>`;
  let g = null, chatOn = false;
  $('.back').onclick = async () => {
    try { const s = await ref.get(); if (s.exists && s.data().status === 'open' && s.data().players[0].uid === me.uid) await ref.delete(); } catch (e) {}
    show('home');
  };
  listen(ref.onSnapshot(snap => {
    if (!snap.exists) { show('home'); return; }
    const r = snap.data();
    g = GAMES.find(x => x.id === r.game);
    const seat = r.players.findIndex(p => p.uid === me.uid);
    const s = JSON.parse(r.st);
    $('#pl').innerHTML = [0, 1].map(i => { const p = r.players[i]; return `<div>${p ? p.avatar + ' ' + esc(p.name) : '⏳ ...'}${i === seat ? ' (aap)' : ''}<br><span class="p${i}">${g.sym ? g.sym[i] : '●'}</span></div>`; }).join('');
    if (r.status === 'open') {
      $('#stt').innerHTML = `Partner ka wait... Room code: <span style="color:var(--rose);font-size:22px">${id}</span>`;
      $('#gm').innerHTML = '';
    } else {
      let t;
      if (s.winner != null) {
        t = s.winner === 'draw' ? '🤝 Draw!' : (s.winner === seat ? '🎉 Aap jeet gaye!' : '😅 Partner jeet gaya');
      } else t = g.status ? g.status(s, seat) : (s.turn === seat ? '👉 Aapki baari' : '⏳ Partner ki baari');
      $('#stt').textContent = t;
      g.render($('#gm'), s, seat, m => sendMove(id, g, m), ctx());
      if (s.winner != null) {
        const b = document.createElement('button');
        b.className = 'btn full'; b.textContent = '🔄 Rematch';
        b.onclick = () => rematch(id, g);
        $('#gm').appendChild(b);
      }
    }
    if (!chatOn && r.players.length === 2) { chatOn = true; chatPanel($('#gc'), ref.collection('messages'), {}); }
  }));
}

async function sendMove(id, g, m) {
  const ref = db.collection('rooms').doc(id);
  try {
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref);
      const r = snap.data();
      const seat = r.players.findIndex(p => p.uid === me.uid);
      if (seat < 0 || r.status !== 'playing') return;
      const s = JSON.parse(r.st);
      if (s.winner != null) return;
      if (!g.simul && s.turn !== seat) return;
      const ns = g.move(s, m, seat, ctx());
      if (!ns) return;
      const upd = { st: JSON.stringify(ns) };
      if (ns.winner != null) {
        upd.status = 'done';
        r.players.forEach((p, i) => {
          const pts = ns.winner === 'draw' ? 5 : (ns.winner === i ? 10 : 2);
          tx.update(db.collection('users').doc(p.uid), { points: FV.increment(pts) });
        });
      }
      tx.update(ref, upd);
    });
  } catch (e) { console.warn(e); toast('Move fail hua, dobara try karo.'); }
}
async function rematch(id, g) {
  await db.collection('rooms').doc(id).update({ st: JSON.stringify(g.init(ctx())), status: 'playing' });
}

/* ---------- chat ---------- */
function chatPanel(el, col, o = {}) {
  el.innerHTML = `<div class="chatwrap"><div class="msgs"></div><div class="compose">
    ${o.img ? '<label class="btn sec" style="margin:0">📷<input type="file" accept="image/*" hidden></label>' : ''}
    <input placeholder="Message likho..."><button class="btn">➤</button></div></div>`;
  const box = $('.msgs', el), inp = $('input:not([type=file])', el);
  const send = async (extra = {}) => {
    const text = inp.value.trim();
    if (!text && !extra.img) return;
    inp.value = '';
    await col.add({ uid: me.uid, name: me.name, avatar: me.avatar, text, ...extra, t: FV.serverTimestamp() });
    if (o.onSend) o.onSend(extra.img ? '📷 Photo' : text);
  };
  $('.btn:last-child', el).onclick = () => send();
  inp.onkeydown = e => { if (e.key === 'Enter') send(); };
  const f = $('input[type=file]', el);
  if (f) f.onchange = async () => { if (f.files[0]) { try { await send({ img: await shrink(f.files[0]) }); } catch (e) { toast('Photo nahi bhej paaye.'); } f.value = ''; } };
  listen(col.orderBy('t', 'desc').limit(60).onSnapshot(s => {
    const arr = s.docs.map(d => d.data()).reverse();
    box.innerHTML = arr.map(m => `<div class="msg ${m.uid === me.uid ? 'me' : ''}">${o.names !== false && m.uid !== me.uid ? `<small>${m.avatar || ''} ${esc(m.name)}</small>` : ''}${esc(m.text)}${m.img ? `<img src="${m.img}">` : ''}</div>`).join('');
    box.scrollTop = box.scrollHeight;
  }));
}
function shrink(file, max = 720) {
  return new Promise((res, rej) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = img.width * k; c.height = img.height * k;
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      res(c.toDataURL('image/jpeg', 0.6));
    };
    img.onerror = rej; img.src = url;
  });
}

function liveScreen() {
  $('#screen').style.padding = '8px 12px';
  $('#screen').innerHTML = `<h2>💬 Live Chat</h2><div id="lc" style="height:calc(100vh - 230px)"></div>`;
  chatPanel($('#lc'), db.collection('public_chat'), { img: false });
}

/* ---------- private chat ---------- */
const pairId = (a, b) => [a, b].sort().join('_');
function dmScreen() {
  $('#screen').innerHTML = `<h2>✉️ Private Chat</h2><input id="sq" placeholder="Naam se dhundo..."><div id="res"></div><div class="mut" style="margin:10px 0 4px">Aapki chats</div><div id="cl"></div>`;
  const rowHtml = u => `<div class="rank" data-u="${u.uid}" data-n="${esc(u.name)}" data-a="${u.avatar}"><span class="av">${u.avatar}</span><div><b>${esc(u.name)}</b><div class="mut">${esc(u.last || '')}</div></div></div>`;
  const bind = r => $$('[data-u]', r).forEach(d => d.onclick = () => openDM({ uid: d.dataset.u, name: d.dataset.n, avatar: d.dataset.a }));
  listen(db.collection('users').doc(me.uid).collection('contacts').orderBy('lastT', 'desc').limit(40).onSnapshot(s => {
    $('#cl').innerHTML = s.docs.map(d => rowHtml(d.data())).join('') || '<p class="mut">Abhi koi chat nahi.</p>';
    bind($('#cl'));
  }));
  let tm;
  $('#sq').oninput = e => {
    clearTimeout(tm);
    tm = setTimeout(async () => {
      const q = e.target.value.trim().toLowerCase();
      if (!q) { $('#res').innerHTML = ''; return; }
      const s = await db.collection('users').where('nameLower', '>=', q).where('nameLower', '<=', q + '\uf8ff').limit(15).get();
      $('#res').innerHTML = s.docs.filter(d => d.id !== me.uid).map(d => rowHtml({ uid: d.id, ...d.data() })).join('') || '<p class="mut">Koi nahi mila.</p>';
      bind($('#res'));
    }, 300);
  };
}
function openDM(u) {
  clearListeners();
  $('#screen').style.padding = '8px 12px';
  $('#screen').innerHTML = `<button class="back">← Back</button><h2>${u.avatar} ${esc(u.name)}</h2><div id="dc" style="height:calc(100vh - 260px)"></div>`;
  $('.back').onclick = () => show('dm');
  const touch = text => {
    const T = FV.serverTimestamp();
    db.collection('users').doc(me.uid).collection('contacts').doc(u.uid).set({ uid: u.uid, name: u.name, avatar: u.avatar, last: text, lastT: T });
    db.collection('users').doc(u.uid).collection('contacts').doc(me.uid).set({ uid: me.uid, name: me.name, avatar: me.avatar, last: text, lastT: T });
  };
  chatPanel($('#dc'), db.collection('chats').doc(pairId(me.uid, u.uid)).collection('messages'), { img: true, names: false, onSend: touch });
}

/* ---------- leaderboard ---------- */
function rankScreen() {
  $('#screen').innerHTML = `<h2>🏆 Leaderboard</h2><div id="rk"><p class="mut">Loading...</p></div>`;
  listen(db.collection('users').orderBy('points', 'desc').limit(50).onSnapshot(s => {
    $('#rk').innerHTML = s.docs.map((d, i) => { const u = d.data(); return `<div class="rank" style="${d.id === me.uid ? 'outline:2px solid var(--rose)' : ''}"><span class="n">${i < 3 ? ['🥇', '🥈', '🥉'][i] : i + 1}</span><span class="av">${u.avatar}</span><b style="flex:1">${esc(u.name)}</b><span>⭐ ${u.points}</span></div>`; }).join('');
  }));
}

/* ---------- profile ---------- */
function meScreen() {
  const dob = localStorage.getItem('dob');
  $('#screen').innerHTML = `<h2>👤 Profile</h2><div class="card"><div style="font-size:48px;text-align:center">${me.avatar}</div>
    <input id="nm" maxlength="14" value="${esc(me.name)}">
    <div class="grid" style="grid-template-columns:repeat(6,1fr)">${AVATARS.map(a => `<button class="tile av" data-a="${a}">${a}</button>`).join('')}</div>
    <button class="btn full" id="sv">Save</button></div>
    <div class="card">⭐ Points: <b>${me.points}</b><br><span class="mut">Jeet = 10, haar = 2, draw = 5</span></div>
    <div class="card">🔞 Age verification: ${dob && ageOf(dob) >= 18 ? 'Done' : 'Pending'} ${dob ? '<button class="btn sec" id="rv" style="margin-left:8px">Reset</button>' : ''}</div>`;
  let av = me.avatar;
  $$('[data-a]').forEach(b => b.onclick = () => { av = b.dataset.a; $$('[data-a]').forEach(x => x.classList.remove('adult')); b.classList.add('adult'); });
  $('#sv').onclick = async () => {
    const name = $('#nm').value.trim();
    if (name.length < 2) return toast('Naam bahut chhota hai.');
    await db.collection('users').doc(me.uid).update({ name, nameLower: name.toLowerCase(), avatar: av });
    toast('Saved ✅');
  };
  const rv = $('#rv'); if (rv) rv.onclick = () => { localStorage.removeItem('dob'); show('me'); };
}

boot();
