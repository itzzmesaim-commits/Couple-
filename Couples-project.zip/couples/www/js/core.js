/* Playmates core: helpers, age gate, email login, boot */
const AVATARS = ['😀', '😎', '🥰', '😈', '🦊', '🐼', '🦁', '🐯', '🐵', '🦄', '🌹', '🔥'];
const DATA = { dares: [], quiz: [], intimacy: { cards: [], male: [], female: [] } };
let auth, db, FV, me = null, unsubs = [], selfUnsub = null, presenceT = null, pendingJoin = null;

const listen = u => { unsubs.push(u); return u; };
const clearListeners = () => { unsubs.forEach(u => { try { u(); } catch (e) {} }); unsubs = []; };
const ctx = () => ({ data: DATA });
const isAdmin = () => !!(me && me.email && ADMIN_EMAIL && me.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());
const ownerLine = () => `<div class="owner">Owned &amp; managed by <b>${esc(OWNER_NAME)}</b></div>`;
const setNav = on => { $('#nav').style.display = on ? 'flex' : 'none'; };

function modal(html) { const m = $('#modal'); m.innerHTML = `<div class="box">${html}</div>`; m.classList.remove('hidden'); return m; }
const closeModal = () => $('#modal').classList.add('hidden');
const toast = t => { const m = modal(`<p>${esc(t)}</p><button class="btn full" id="ok">OK</button>`); $('#ok', m).onclick = closeModal; };
function confirmBox(t, yes) {
  const m = modal(`<p>${esc(t)}</p><button class="btn full" id="y">Haan</button><button class="btn sec full" id="n">Nahi</button>`);
  $('#n', m).onclick = closeModal; $('#y', m).onclick = () => { closeModal(); yes(); };
}

/* ---------- 18+ age gate ---------- */
const ageOf = d => { const b = new Date(d), n = new Date(); let a = n.getFullYear() - b.getFullYear(); if (n < new Date(n.getFullYear(), b.getMonth(), b.getDate())) a--; return a; };
function requireAdult(cb, cancel) {
  const dob = localStorage.getItem('dob');
  if (dob && ageOf(dob) >= 18) {
    const m = modal(`<h2>🔞 18+ Content</h2><p>Is game mein adult content hai. Confirm karo ki aap 18 saal ya usse zyada ke ho.</p>
      <button class="btn full" id="y">Haan, main 18+ hoon</button><button class="btn sec full" id="n">Cancel</button>`);
    $('#y', m).onclick = () => { closeModal(); cb(); };
    $('#n', m).onclick = () => { closeModal(); if (cancel) cancel(); };
  } else {
    const m = modal(`<h2>🔞 Age Verification</h2><p>Apni date of birth daalo. 18 se kam age walon ko entry nahi milegi.</p>
      <input type="date" id="d"><button class="btn full" id="y">Verify</button><button class="btn sec full" id="n">Cancel</button>`);
    $('#n', m).onclick = () => { closeModal(); if (cancel) cancel(); };
    $('#y', m).onclick = () => {
      const v = $('#d', m).value; if (!v) return;
      if (ageOf(v) < 18) { closeModal(); toast('Sorry, ye game sirf 18+ ke liye hai.'); if (cancel) cancel(); return; }
      localStorage.setItem('dob', v); closeModal(); requireAdult(cb, cancel);
    };
  }
}

/* ---------- login ---------- */
const authErr = e => ({
  'auth/email-already-in-use': 'Ye email pehle se registered hai. Login karo.',
  'auth/invalid-credential': 'Email ya password galat hai.', 'auth/wrong-password': 'Email ya password galat hai.',
  'auth/user-not-found': 'Ye email registered nahi hai.', 'auth/invalid-email': 'Email sahi likho.',
  'auth/weak-password': 'Password kam se kam 6 character ka rakho.', 'auth/too-many-requests': 'Bahut try ho gaye. Thodi der baad karo.',
  'auth/network-request-failed': 'Internet check karo.', 'auth/operation-not-allowed': 'Firebase mein Email/Password login ON nahi hai.'
}[e.code] || ('Error: ' + (e.message || e.code)));

function authScreen(mode = 'login') {
  setNav(false); $('#pts').textContent = '';
  $('#screen').innerHTML = `<div class="authbox"><img class="logo-lg" src="img/logo-lg.png" alt="">
    <div class="tabs"><button class="btn ${mode === 'login' ? '' : 'sec'}" id="t1">Login</button><button class="btn ${mode === 'signup' ? '' : 'sec'}" id="t2">Sign up</button></div>
    <input id="em" type="email" placeholder="Email" autocomplete="email"><input id="pw" type="password" placeholder="Password (6+ character)">
    <button class="btn full" id="go">${mode === 'login' ? 'Login' : 'Account banao'}</button>
    ${mode === 'login' ? '<button class="back" id="fg">Password bhool gaye?</button>' : '<p class="mut">Sign up ke baad email par verification link aayega.</p>'}
    <button class="btn sec full" id="off">🤖 Bot ke saath khelo (offline)</button>${ownerLine()}</div>`;
  $('#t1').onclick = () => authScreen('login'); $('#t2').onclick = () => authScreen('signup');
  $('#off').onclick = offlineHome;
  $('#go').onclick = async () => {
    const email = $('#em').value.trim(), pw = $('#pw').value;
    if (!email || !pw) return toast('Email aur password daalo.');
    try {
      if (mode === 'login') await auth.signInWithEmailAndPassword(email, pw);
      else { const c = await auth.createUserWithEmailAndPassword(email, pw); await c.user.sendEmailVerification(); }
    } catch (e) { toast(authErr(e)); }
  };
  const fg = $('#fg');
  if (fg) fg.onclick = async () => {
    const email = $('#em').value.trim(); if (!email) return toast('Pehle email daalo.');
    try { await auth.sendPasswordResetEmail(email); toast('Password reset link email par bhej diya.'); } catch (e) { toast(authErr(e)); }
  };
}

function verifyScreen(u) {
  setNav(false);
  $('#screen').innerHTML = `<div class="authbox"><img class="logo-lg" src="img/logo-lg.png" alt=""><h2>📧 Email verify karo</h2>
    <p>Humne <b>${esc(u.email)}</b> par verification link bheja hai. Email kholo (Spam bhi dekho), link par click karo, phir niche button dabao.</p>
    <button class="btn full" id="ok">✅ Maine verify kar liya</button><button class="btn sec full" id="rs">📧 Link dobara bhejo</button>
    <button class="back" id="lo">Logout</button>${ownerLine()}</div>`;
  $('#ok').onclick = async () => {
    try { await u.reload(); const cu = auth.currentUser; if (cu && cu.emailVerified) { await cu.getIdToken(true); await afterLogin(cu); } else toast('Abhi verify nahi hua. Email ka link dabao.'); } catch (e) { toast(authErr(e)); }
  };
  $('#rs').onclick = async () => { try { await u.sendEmailVerification(); toast('Link bhej diya.'); } catch (e) { toast(authErr(e)); } };
  $('#lo').onclick = () => auth.signOut();
}

function profileSetup(u) {
  setNav(false); let av = AVATARS[0];
  $('#screen').innerHTML = `<h2>Apna profile banao</h2><input id="nm" maxlength="14" placeholder="Apna naam">
    <div class="grid" style="grid-template-columns:repeat(6,1fr)">${AVATARS.map(a => `<button class="tile av" data-a="${a}">${a}</button>`).join('')}</div>
    <button class="btn full" id="go">Shuru karo</button>`;
  $$('[data-a]').forEach(b => b.onclick = () => { av = b.dataset.a; $$('[data-a]').forEach(x => x.classList.remove('adult')); b.classList.add('adult'); });
  $('#go').onclick = async () => {
    const name = $('#nm').value.trim();
    if (name.length < 2) return toast('Naam kam se kam 2 letter ka rakho.');
    try {
      const b = db.batch(), T = FV.serverTimestamp();
      b.set(db.collection('users').doc(u.uid), { name, nameLower: name.toLowerCase(), avatar: av, points: 0, created: T, lastSeen: T });
      b.set(db.collection('users_private').doc(u.uid), { email: u.email, created: T });
      await b.commit(); await afterLogin(u);
    } catch (e) { toast('Profile nahi bana: ' + (e.message || e)); }
  };
}

function buildNav() {
  const items = [['home', '🎮', 'Games'], ['live', '💬', 'Live'], ['rank', '🏆', 'Ranks'], ['me', '👤', 'Profile']];
  if (isAdmin()) items.push(['admin', '🛡️', 'Owner']);
  $('#nav').innerHTML = items.map(([s, i, n]) => `<button data-s="${s}">${i}<small>${n}</small></button>`).join('');
  $$('#nav button').forEach(b => b.onclick = () => show(b.dataset.s));
}

async function afterLogin(u) {
  const snap = await db.collection('users').doc(u.uid).get();
  if (!snap.exists) return profileSetup(u);
  me = { uid: u.uid, email: u.email, ...snap.data() };
  buildNav();
  if (selfUnsub) selfUnsub();
  selfUnsub = db.collection('users').doc(u.uid).onSnapshot(s => { if (s.exists) { me = { uid: u.uid, email: u.email, ...s.data() }; $('#pts').textContent = `${me.avatar} ${me.name} · ⭐ ${me.points}`; } });
  clearInterval(presenceT);
  const ping = () => { if (me && !document.hidden) db.collection('users').doc(me.uid).update({ lastSeen: FV.serverTimestamp() }).catch(() => {}); };
  ping(); presenceT = setInterval(ping, 60000);
  show('home');
  if (pendingJoin) { const c = pendingJoin; pendingJoin = null; doJoin(c); }
}

function handleLink(url) {
  const m = String(url || '').match(/(?:join[\/=]|room=)([A-Za-z0-9]{5})/);
  if (!m) return;
  const c = m[1].toUpperCase();
  if (me) doJoin(c); else pendingJoin = c;
}

/* ---------- offline (bots only) ---------- */
function offlineHome() {
  clearListeners(); setNav(false);
  $('#screen').innerHTML = `<h2>🤖 Bot ke saath khelo (offline)</h2><div class="grid">${GAMES.filter(g => g.bot && !g.adult).map(gameTile).join('')}</div>
    <button class="btn sec full" id="rt" style="margin-top:14px">🔄 Online login par jao</button>${ownerLine()}`;
  $$('[data-g]').forEach(b => b.onclick = () => playBot(GAMES.find(x => x.id === b.dataset.g)));
  $('#rt').onclick = () => location.reload();
}

/* ---------- boot ---------- */
async function boot() {
  const scr = $('#screen');
  if (!FIREBASE_CONFIG.apiKey || FIREBASE_CONFIG.apiKey === 'PASTE_HERE') { setNav(false); scr.innerHTML = '<div class="card"><h2>Setup baaki hai</h2><p>firebase-config.js mein keys daalo.</p></div>'; return; }
  scr.innerHTML = '<p class="mut">Loading...</p>';
  for (const [k, f] of [['dares', 'dares.json'], ['quiz', 'quiz.json'], ['intimacy', 'intimacy.json']]) {
    try { DATA[k] = await (await fetch('data/' + f)).json(); } catch (e) { console.warn(f, e); }
  }
  const A = window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.App;
  if (A) { try { A.addListener('appUrlOpen', e => handleLink(e.url)); A.getLaunchUrl().then(r => r && handleLink(r.url)).catch(() => {}); } catch (e) {} }
  try { firebase.initializeApp(FIREBASE_CONFIG); auth = firebase.auth(); db = firebase.firestore(); FV = firebase.firestore.FieldValue; } catch (e) { return offlineHome(); }
  auth.onAuthStateChanged(async u => {
    if (!u) { me = null; clearInterval(presenceT); if (selfUnsub) { selfUnsub(); selfUnsub = null; } clearListeners(); authScreen('login'); return; }
    if (!u.email) { auth.signOut(); return; }
    if (!u.emailVerified) { verifyScreen(u); return; }
    try { await afterLogin(u); } catch (e) { console.warn(e); offlineHome(); }
  });
}
