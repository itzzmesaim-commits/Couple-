/* Playmates core: helpers, age gate, email login, boot */
const AVATARS = ['😀', '😎', '🥰', '😈', '🦊', '🐼', '🦁', '🐯', '🐵', '🦄', '🌹', '🔥'];
const DATA = { dares: [], quiz: [], intimacy: { cards: [], male: [], female: [] } };
let auth, db, FV, me = null, unsubs = [], selfUnsub = null, presenceT = null, pendingJoin = null;

const listen = u => { unsubs.push(u); return u; };
const clearListeners = () => { unsubs.forEach(u => { try { u(); } catch (e) {} }); unsubs = []; };
const ctx = () => ({ data: DATA });
const isAdmin = () => !!(me && me.email && ADMIN_EMAIL && me.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());
const ownerLine = () => `<div class="owner">Owned &amp; managed by <b>${esc(OWNER_NAME)}</b></div>`;
const setNav = on => { $('#nav').style.display = on ? 'flex' : 'none'; document.body.classList.remove('authmode'); };
const authMode = () => { setNav(false); document.body.classList.add('authmode'); };

function modal(html) { const m = $('#modal'); m.innerHTML = `<div class="box">${html}</div>`; m.classList.remove('hidden'); return m; }
const closeModal = () => $('#modal').classList.add('hidden');
const toast = t => { const m = modal(`<p>${esc(t)}</p><button class="btn full" id="ok">OK</button>`); $('#ok', m).onclick = closeModal; };
function confirmBox(t, yes) {
  const m = modal(`<p>${esc(t)}</p><button class="btn full" id="y">Haan</button><button class="btn sec full" id="n">Nahi</button>`);
  $('#n', m).onclick = closeModal; $('#y', m).onclick = () => { closeModal(); yes(); };
}

/* ---------- 18+ age gate ---------- */
const ageOf = d => { const b = new Date(d), n = new Date(); let a = n.getFullYear() - b.getFullYear(); if (n < new Date(n.getFullYear(), b.getMonth(), b.getDate())) a--; return a; };
function requireAdult(cb, cancel) {
  const dob = localStorage.getItem('dob');
  if (dob && ageOf(dob) >= 18) {
    const m = modal(`<h2>🔞 18+ Content</h2><p>This game has adult content. Please confirm that you are 18 years or older.</p>
      <button class="btn full" id="y">Haan, main 18+ hoon</button><button class="btn sec full" id="n">Cancel</button>`);
    $('#y', m).onclick = () => { closeModal(); cb(); };
    $('#n', m).onclick = () => { closeModal(); if (cancel) cancel(); };
  } else {
    const m = modal(`<h2>🔞 Age Verification</h2><p>Enter your date of birth. Entry is not allowed under 18.</p>
      <input type="date" id="d"><button class="btn full" id="y">Verify</button><button class="btn sec full" id="n">Cancel</button>`);
    $('#n', m).onclick = () => { closeModal(); if (cancel) cancel(); };
    $('#y', m).onclick = () => {
      const v = $('#d', m).value; if (!v) return;
      if (ageOf(v) < 18) { closeModal(); toast('Sorry, this game is for 18+ only.'); if (cancel) cancel(); return; }
      localStorage.setItem('dob', v); closeModal(); requireAdult(cb, cancel);
    };
  }
}

/* ---------- login ---------- */
const authErr = e => ({
  'auth/email-already-in-use': 'This email is already registered. Please log in.',
  'auth/invalid-credential': 'Wrong email or password.', 'auth/wrong-password': 'Wrong email or password.',
  'auth/user-not-found': 'This email is not registered.', 'auth/invalid-email': 'Please enter a valid email.',
  'auth/weak-password': 'Password must be at least 6 characters.', 'auth/too-many-requests': 'Too many attempts. Please try again later.',
  'auth/network-request-failed': 'Please check your internet.', 'auth/operation-not-allowed': 'Email/Password login is not enabled in Firebase.'
}[e.code] || ('Error: ' + (e.message || e.code)));

const AX_ICON = { user: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>', mail: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 8l9 6 9-6"/></svg>', phone: '<svg viewBox="0 0 24 24"><path d="M6 3h4l2 5-3 2a12 12 0 005 5l2-3 5 2v4a2 2 0 01-2 2A17 17 0 014 5a2 2 0 012-2z"/></svg>', lock: '<svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="3"/><path d="M8 11V8a4 4 0 018 0v3"/></svg>', eye: '<svg viewBox="0 0 24 24"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>' };
const axField = (id, icon, ph, type = 'text', extra = '') => `<label class="ax-f"><i>${AX_ICON[icon]}</i><input id="${id}" type="${type}" placeholder="${ph}" ${extra}>${type === 'password' ? `<b class="ax-eye" data-eye="${id}">${AX_ICON.eye}</b>` : ''}</label>`;
const AX_GOOGLE = '<svg viewBox="0 0 48 48" width="20" height="20"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.4 30.2 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.8 6.1C12.3 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.5-4.1 7-10.2 7-17.6z"/><path fill="#FBBC05" d="M10.4 28.7A14.5 14.5 0 019.5 24c0-1.6.3-3.2.9-4.7l-7.8-6.1A24 24 0 000 24c0 3.9.9 7.5 2.6 10.8l7.8-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.7-4.1-13.6-9.8l-7.8 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
function axBind(root) {
  $$('[data-eye]', root).forEach(b => b.onclick = () => { const i = $('#' + b.dataset.eye, root); i.type = i.type === 'password' ? 'text' : 'password'; });
  const g = $('#gg', root); if (g) g.onclick = () => toast('Google login is coming soon. Please use your email for now.');
  $$('[data-terms]', root).forEach(a => a.onclick = e => { e.preventDefault(); const m = modal(`<h2>${a.dataset.terms === 'p' ? 'Privacy Policy' : 'Terms & Conditions'}</h2><p class="mut" style="text-align:left">${a.dataset.terms === 'p' ? 'We store your name, email, phone number, avatar and game points to run your account. Chat messages are visible to the people in that chat. We do not sell your data. You can ask the owner to delete your account at any time.' : 'Be kind and respectful. No abuse, spam or illegal content. 18+ games are only for adults who play with mutual consent. The owner may remove accounts that break these rules.'}</p><button class="btn full" id="ok">OK</button>`); $('#ok', m).onclick = closeModal; });
}
const AX_TAG = '<div class="ax-tag">Play <i>•</i> Connect <i>•</i> Grow</div>';

function authScreen(mode = 'login') {
  authMode(); $('#pts').textContent = '';
  const login = mode === 'login';
  $('#screen').innerHTML = `<div class="authx"><button class="ax-back" id="bk" aria-label="Back">←</button>
    <img class="ax-logo" src="img/logo-lg.png" alt="Playmates">${AX_TAG}
    <h2>${login ? 'Welcome Back!' : 'Create Your Account'}</h2><p class="ax-sub">${login ? 'Log in to continue your journey with Playmates.' : 'Join Playmates and be part of something amazing.'}</p>
    ${login ? axField('em', 'mail', 'Email or Phone Number', 'text', 'autocomplete="username"') + axField('pw', 'lock', 'Password', 'password', 'autocomplete="current-password"')
      : axField('fn', 'user', 'Full Name', 'text', 'maxlength="14" autocomplete="name"') + axField('em', 'mail', 'Email Address', 'email', 'autocomplete="email"') + axField('ph', 'phone', 'Phone Number', 'tel', 'autocomplete="tel"') + axField('pw', 'lock', 'Password (6+ characters)', 'password', 'autocomplete="new-password"') + axField('pw2', 'lock', 'Confirm Password', 'password', 'autocomplete="new-password"')}
    ${login ? '<div class="ax-row"><label class="ax-chk"><input type="checkbox" id="rm" checked><span></span>Remember me</label><a href="#" id="fg">Forgot Password?</a></div>'
      : '<label class="ax-chk ax-terms"><input type="checkbox" id="ag" checked><span></span><em>I agree to the <a href="#" data-terms="t">Terms &amp; Conditions</a> and <a href="#" data-terms="p">Privacy Policy</a></em></label>'}
    <button class="ax-btn" id="go">${login ? 'Log In' : 'Create Account'} →</button>
    <div class="ax-or"><span>OR</span></div>
    <button class="ax-gbtn" id="gg">${AX_GOOGLE} Continue with Google</button>
    <p class="ax-alt">${login ? "Don't have an account? <a href=\"#\" id=\"sw\">Sign Up</a>" : 'Already have an account? <a href="#" id="sw">Log In</a>'}</p>
    ${login ? '<p class="ax-alt"><a href="#" id="off">🤖 Play with Bot (offline)</a></p>' : ''}${ownerLine()}</div>`;
  const root = $('#screen'); axBind(root);
  $('#bk').onclick = () => { splashScreen(); };
  $('#sw').onclick = e => { e.preventDefault(); authScreen(login ? 'signup' : 'login'); };
  const off = $('#off'); if (off) off.onclick = e => { e.preventDefault(); offlineHome(); };
  $('#go').onclick = async () => {
    const email = $('#em').value.trim(), pw = $('#pw').value;
    try {
      if (login) {
        if (!email || !pw) return toast('Enter your email and password.');
        if (!email.includes('@')) return toast('Phone number login is not available yet. Please log in with your email.');
        try { await auth.setPersistence($('#rm').checked ? firebase.auth.Auth.Persistence.LOCAL : firebase.auth.Auth.Persistence.SESSION); } catch (e) { }
        await auth.signInWithEmailAndPassword(email, pw);
      } else {
        const name = $('#fn').value.trim(), ph = $('#ph').value.replace(/[\s-]/g, '');
        if (name.length < 2) return toast('Please enter your full name.');
        if (!/^\S+@\S+\.\S+$/.test(email)) return toast('Please enter a valid email.');
        if (!/^\+?\d{10,14}$/.test(ph)) return toast('Please enter a valid phone number (10+ digits).');
        if (pw.length < 6) return toast('Password must be at least 6 characters.');
        if (pw !== $('#pw2').value) return toast('The two passwords do not match.');
        if (!$('#ag').checked) return toast('Please accept the Terms & Conditions.');
        try { localStorage.setItem('pm_signup', JSON.stringify({ name, phone: ph, email })); } catch (e) { }
        const c = await auth.createUserWithEmailAndPassword(email, pw); await c.user.sendEmailVerification();
      }
    } catch (e) { toast(authErr(e)); }
  };
  const fg = $('#fg');
  if (fg) fg.onclick = async e => {
    e.preventDefault(); const email = $('#em').value.trim(); if (!email || !email.includes('@')) return toast('Enter your email first.');
    try { await auth.sendPasswordResetEmail(email); toast('Password reset link has been sent to your email.'); } catch (er) { toast(authErr(er)); }
  };
}

function verifyScreen(u) {
  authMode();
  $('#screen').innerHTML = `<div class="authx"><img class="ax-logo" src="img/logo-lg.png" alt="Playmates">${AX_TAG}
    <h2>Verify your email</h2><p class="ax-sub">We sent a verification link to <b>${esc(u.email)}</b>. Open your email (check Spam too), tap the link, then press the button below.</p>
    <button class="ax-btn" id="ok">I have verified →</button><button class="ax-gbtn" id="rs">Resend link</button>
    <p class="ax-alt"><a href="#" id="lo">Logout</a></p>${ownerLine()}</div>`;
  $('#ok').onclick = async () => {
    try { await u.reload(); const cu = auth.currentUser; if (cu && cu.emailVerified) { await cu.getIdToken(true); await afterLogin(cu); } else toast('Not verified yet. Please tap the link in your email.'); } catch (e) { toast(authErr(e)); }
  };
  $('#rs').onclick = async () => { try { await u.sendEmailVerification(); toast('Link bhej diya.'); } catch (e) { toast(authErr(e)); } };
  $('#lo').onclick = e => { e.preventDefault(); auth.signOut(); };
}

function profileSetup(u) {
  setNav(false); let av = AVATARS[0]; let sg = {}; try { sg = JSON.parse(localStorage.getItem('pm_signup') || '{}'); } catch (e) { }
  $('#screen').innerHTML = `<h2>Create your profile</h2><input id="nm" maxlength="14" placeholder="Your name" value="${esc(sg.name || '')}">
    <div class="grid" style="grid-template-columns:repeat(6,1fr)">${AVATARS.map(a => `<button class="tile av" data-a="${a}">${a}</button>`).join('')}</div>
    <button class="btn full" id="go">Get started</button>`;
  $$('[data-a]').forEach(b => b.onclick = () => { av = b.dataset.a; $$('[data-a]').forEach(x => x.classList.remove('adult')); b.classList.add('adult'); });
  $('#go').onclick = async () => {
    const name = $('#nm').value.trim();
    if (name.length < 2) return toast('Name must be at least 2 letters.');
    try {
      const b = db.batch(), T = FV.serverTimestamp();
      b.set(db.collection('users').doc(u.uid), { name, nameLower: name.toLowerCase(), avatar: av, points: 0, created: T, lastSeen: T });
      b.set(db.collection('users_private').doc(u.uid), Object.assign({ email: u.email, created: T }, sg.phone ? { phone: sg.phone } : {}));
      await b.commit(); await afterLogin(u);
    } catch (e) { toast('Could not create profile: ' + (e.message || e)); }
  };
}

function buildNav() {
  const items = [['home', '🏠', 'Home'], ['games', '🎮', 'Games'], ['live', '💬', 'Chat'], ['rank', '🏆', 'Ranks'], ['me', '👤', 'Profile']];
  if (isAdmin()) items.push(['admin', '🛡️', 'Owner']);
  $('#nav').innerHTML = items.map(([s, i, n]) => `<button data-s="${s}">${i}<small>${n}</small></button>`).join('');
  $$('#nav button').forEach(b => b.onclick = () => show(b.dataset.s));
}

async function afterLogin(u) {
  const snap = await db.collection('users').doc(u.uid).get();
  if (!snap.exists) return profileSetup(u);
  me = { uid: u.uid, email: u.email, ...snap.data() };
  buildNav();
  if (selfUnsub) selfUnsub();
  selfUnsub = db.collection('users').doc(u.uid).onSnapshot(s => { if (s.exists) { me = { uid: u.uid, email: u.email, ...s.data() }; $('#pts').textContent = `${me.avatar} ${me.name} · ⭐ ${me.points}`; } });
  clearInterval(presenceT);
  const ping = () => { if (me && !document.hidden) db.collection('users').doc(me.uid).update({ lastSeen: FV.serverTimestamp() }).catch(() => {}); };
  ping(); presenceT = setInterval(ping, 60000);
  show('home');
  if (pendingJoin) { const c = pendingJoin; pendingJoin = null; doJoin(c); }
}

function handleLink(url) {
  const m = String(url || '').match(/(?:join[\/=]|room=)([A-Za-z0-9]{5})/);
  if (!m) return;
  const c = m[1].toUpperCase();
  if (me) doJoin(c); else pendingJoin = c;
}

/* ---------- offline (bots only) ---------- */
function offlineHome() {
  clearListeners(); setNav(false);
  $('#screen').innerHTML = `<h2>🤖 Play with Bot (offline)</h2><div class="grid">${GAMES.filter(g => g.bot && !g.adult && !g.soon).map(gameTile).join('')}</div>
    <button class="btn sec full" id="rt" style="margin-top:14px">🔄 Back to online login</button>${ownerLine()}`;
  $$('[data-g]').forEach(b => b.onclick = () => playBot(GAMES.find(x => x.id === b.dataset.g)));
  $('#rt').onclick = () => location.reload();
}

/* ---------- splash ---------- */
let splashed = false;
function splashScreen() {
  authMode(); $('#pts').textContent = '';
  $('#screen').innerHTML = `<div class="authx ax-splash"><img class="ax-logo big" src="img/logo-lg.png" alt="Playmates">${AX_TAG}
    <p class="ax-sub" style="margin-top:22px">More than just a game…<br><b>It’s a community.</b></p>
    <button class="ax-btn" id="gs">Get Started →</button><p class="ax-alt">Already have an account? <a href="#" id="al">Log In</a></p>${ownerLine()}</div>`;
  $('#gs').onclick = () => authScreen('signup'); $('#al').onclick = e => { e.preventDefault(); authScreen('login'); };
}

/* ---------- boot ---------- */
async function boot() {
  const scr = $('#screen');
  if (!FIREBASE_CONFIG.apiKey || FIREBASE_CONFIG.apiKey === 'PASTE_HERE') { setNav(false); scr.innerHTML = '<div class="card"><h2>Setup incomplete</h2><p>Add your keys in firebase-config.js.</p></div>'; return; }
  scr.innerHTML = '<p class="mut">Loading...</p>';
  for (const [k, f] of [['dares', 'dares.json'], ['quiz', 'quiz.json'], ['intimacy', 'intimacy.json']]) {
    try { DATA[k] = await (await fetch('data/' + f)).json(); } catch (e) { console.warn(f, e); }
  }
  const A = window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.App;
  if (A) { try { A.addListener('appUrlOpen', e => handleLink(e.url)); A.getLaunchUrl().then(r => r && handleLink(r.url)).catch(() => {}); } catch (e) {} }
  try { firebase.initializeApp(FIREBASE_CONFIG); auth = firebase.auth(); db = firebase.firestore(); FV = firebase.firestore.FieldValue; } catch (e) { return offlineHome(); }
  auth.onAuthStateChanged(async u => {
    if (!u) { me = null; clearInterval(presenceT); if (selfUnsub) { selfUnsub(); selfUnsub = null; } clearListeners(); if (!splashed) { splashed = true; splashScreen(); } else authScreen('login'); return; }
    if (!u.email) { auth.signOut(); return; }
    if (!u.emailVerified) { verifyScreen(u); return; }
    try { await afterLogin(u); } catch (e) { console.warn(e); offlineHome(); }
  });
}
