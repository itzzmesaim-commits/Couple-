/* Playmates core: helpers, age gate, email login, boot */
const AVATARS = ['😀', '😎', '🥰', '😈', '🦊', '🐼', '🦁', '🐯', '🐵', '🦄', '🌹', '🔥'];
const DATA = { dares: [], quiz: [], intimacy: { cards: [], male: [], female: [] } };
let auth, db, FV, me = null, unsubs = [], selfUnsub = null, presenceT = null, pendingJoin = null;

const listen = u => { unsubs.push(u); return u; };
const clearListeners = () => { unsubs.forEach(u => { try { u(); } catch (e) {} }); unsubs = []; };
const ctx = () => ({ data: DATA });
const isAdmin = () => !!(me && me.email && ADMIN_EMAIL && me.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());
const ownerLine = () => `<div class="owner">Owned &amp; managed by <b>${esc(OWNER_NAME)}</b></div>`;
const setNav = on => { $('#nav').style.display = on ? 'flex' : 'none'; };

function modal(html) { const m = $('#modal'); m.innerHTML = `<div class="box">${html}</div>`; m.classList.remove('hidden'); return m; }
const closeModal = () => $('#modal').classList.add('hidden');
const toast = t => { const m = modal(`<p>${esc(t)}</p><button class="btn full" id="ok">OK</button>`); $('#ok', m).onclick = closeModal; };
function confirmBox(t, yes) {
  const m = modal(`<p>${esc(t)}</p><button class="btn full" id="y">Haan</button><button class="btn sec full" id="n">Nahi</button>`);
  $('#n', m).onclick = closeModal; $('#y', m).onclick = () => { closeModal(); yes(); };
}

/* ---------- 18+ age gate ---------- */
const ageOf = d => { const b = new Date(d), n = new Date(); let a = n.getFullYear() - b.getFullYear(); if (n < new Date(n.getFullYear(), b.getMonth(), b.getDate())) a--; return a; };
function requireAdult(cb, cancel) {
  const dob = localStorage.getItem('dob');
  if (dob && ageOf(dob) >= 18) {
    const m = modal(`<h2>🔞 18+ Content</h2><p>This game has adult content. Please confirm that you are 18 years or older.</p>
      <button class="btn full" id="y">Haan, main 18+ hoon</button><button class="btn sec full" id="n">Cancel</button>`);
    $('#y', m).onclick = () => { closeModal(); cb(); };
    $('#n', m).onclick = () => { closeModal(); if (cancel) cancel(); };
  } else {
    const m = modal(`<h2>🔞 Age Verification</h2><p>Enter your date of birth. Entry is not allowed under 18.</p>
      <input type="date" id="d"><button class="btn full" id="y">Verify</button><button class="btn sec full" id="n">Cancel</button>`);
    $('#n', m).onclick = () => { closeModal(); if (cancel) cancel(); };
    $('#y', m).onclick = () => {
      const v = $('#d', m).value; if (!v) return;
      if (ageOf(v) < 18) { closeModal(); toast('Sorry, this game is for 18+ only.'); if (cancel) cancel(); return; }
      localStorage.setItem('dob', v); closeModal(); requireAdult(cb, cancel);
    };
  }
}

/* ---------- login ---------- */
const authErr = e => ({
  'auth/email-already-in-use': 'This email is already registered. Please log in.',
  'auth/invalid-credential': 'Wrong email or password.', 'auth/wrong-password': 'Wrong email or password.',
  'auth/user-not-found': 'This email is not registered.', 'auth/invalid-email': 'Please enter a valid email.',
  'auth/weak-password': 'Password must be at least 6 characters.', 'auth/too-many-requests': 'Too many attempts. Please try again later.',
  'auth/network-request-failed': 'Please check your internet.', 'auth/operation-not-allowed': 'Email/Password login is not enabled in Firebase.'
}[e.code] || ('Error: ' + (e.message || e.code)));

function authScreen(mode = 'login') {
  setNav(false); $('#pts').textContent = '';
  $('#screen').innerHTML = `<div class="authbox"><img class="logo-lg" src="img/logo-lg.png" alt=""><h2>Welcome to Playmates</h2><p class="mut">Play your favorite games with friends and people worldwide.</p>
    <div class="tabs"><button class="btn ${mode === 'login' ? '' : 'sec'}" id="t1">Login</button><button class="btn ${mode === 'signup' ? '' : 'sec'}" id="t2">Sign up</button></div>
    <input id="em" type="email" placeholder="Email" autocomplete="email"><input id="pw" type="password" placeholder="Password (6+ character)">
    <button class="btn full" id="go">${mode === 'login' ? 'Login' : 'Create account'}</button>
    ${mode === 'login' ? '<button class="back" id="fg">Forgot password?</button>' : '<p class="mut">After signing up, a verification link will be sent to your email.</p>'}
    <button class="btn sec full" id="off">🤖 Play with Bot (offline)</button>${ownerLine()}</div>`;
  $('#t1').onclick = () => authScreen('login'); $('#t2').onclick = () => authScreen('signup');
  $('#off').onclick = offlineHome;
  $('#go').onclick = async () => {
    const email = $('#em').value.trim(), pw = $('#pw').value;
    if (!email || !pw) return toast('Enter your email and password.');
    try {
      if (mode === 'login') await auth.signInWithEmailAndPassword(email, pw);
      else { const c = await auth.createUserWithEmailAndPassword(email, pw); await c.user.sendEmailVerification(); }
    } catch (e) { toast(authErr(e)); }
  };
  const fg = $('#fg');
  if (fg) fg.onclick = async () => {
    const email = $('#em').value.trim(); if (!email) return toast('Enter your email first.');
    try { await auth.sendPasswordResetEmail(email); toast('Password reset link email par bhej diya.'); } catch (e) { toast(authErr(e)); }
  };
}

function verifyScreen(u) {
  setNav(false);
  $('#screen').innerHTML = `<div class="authbox"><img class="logo-lg" src="img/logo-lg.png" alt=""><h2>📧 Verify your email</h2>
    <p>We sent a verification link to <b>${esc(u.email)}</b>. Open your email (check Spam too), click the link, then tap the button below.</p>
    <button class="btn full" id="ok">✅ I have verified</button><button class="btn sec full" id="rs">📧 Resend link</button>
    <button class="back" id="lo">Logout</button>${ownerLine()}</div>`;
  $('#ok').onclick = async () => {
    try { await u.reload(); const cu = auth.currentUser; if (cu && cu.emailVerified) { await cu.getIdToken(true); await afterLogin(cu); } else toast('Not verified yet. Please tap the link in your email.'); } catch (e) { toast(authErr(e)); }
  };
  $('#rs').onclick = async () => { try { await u.sendEmailVerification(); toast('Link bhej diya.'); } catch (e) { toast(authErr(e)); } };
  $('#lo').onclick = () => auth.signOut();
}

function profileSetup(u) {
  setNav(false); let av = AVATARS[0];
  $('#screen').innerHTML = `<h2>Create your profile</h2><input id="nm" maxlength="14" placeholder="Your name">
    <div class="grid" style="grid-template-columns:repeat(6,1fr)">${AVATARS.map(a => `<button class="tile av" data-a="${a}">${a}</button>`).join('')}</div>
    <button class="btn full" id="go">Get started</button>`;
  $$('[data-a]').forEach(b => b.onclick = () => { av = b.dataset.a; $$('[data-a]').forEach(x => x.classList.remove('adult')); b.classList.add('adult'); });
  $('#go').onclick = async () => {
    const name = $('#nm').value.trim();
    if (name.length < 2) return toast('Name must be at least 2 letters.');
    try {
      const b = db.batch(), T = FV.serverTimestamp();
      b.set(db.collection('users').doc(u.uid), { name, nameLower: name.toLowerCase(), avatar: av, points: 0, created: T, lastSeen: T });
      b.set(db.collection('users_private').doc(u.uid), { email: u.email, created: T });
      await b.commit(); await afterLogin(u);
    } catch (e) { toast('Could not create profile: ' + (e.message || e)); }
  };
}

function buildNav() {
  const items = [['home', '🏠', 'Home'], ['games', '🎮', 'Games'], ['live', '💬', 'Chat'], ['rank', '🏆', 'Ranks'], ['me', '👤', 'Profile']];
  if (isAdmin()) items.push(['admin', '🛡️', 'Owner']);
  $('#nav').innerHTML = items.map(([s, i, n]) => `<button data-s="${s}">${i}<small>${n}</small></button>`).join('');
  $$('#nav button').forEach(b => b.onclick = () => show(b.dataset.s));
}

async function afterLogin(u) {
  const snap = await db.collection('users').doc(u.uid).get();
  if (!snap.exists) return profileSetup(u);
  me = { uid: u.uid, email: u.email, ...snap.data() };
  buildNav();
  if (selfUnsub) selfUnsub();
  selfUnsub = db.collection('users').doc(u.uid).onSnapshot(s => { if (s.exists) { me = { uid: u.uid, email: u.email, ...s.data() }; $('#pts').textContent = `${me.avatar} ${me.name} · ⭐ ${me.points}`; } });
  clearInterval(presenceT);
  const ping = () => { if (me && !document.hidden) db.collection('users').doc(me.uid).update({ lastSeen: FV.serverTimestamp() }).catch(() => {}); };
  ping(); presenceT = setInterval(ping, 60000);
  show('home');
  if (pendingJoin) { const c = pendingJoin; pendingJoin = null; doJoin(c); }
}

function handleLink(url) {
  const m = String(url || '').match(/(?:join[\/=]|room=)([A-Za-z0-9]{5})/);
  if (!m) return;
  const c = m[1].toUpperCase();
  if (me) doJoin(c); else pendingJoin = c;
}

/* ---------- offline (bots only) ---------- */
function offlineHome() {
  clearListeners(); setNav(false);
  $('#screen').innerHTML = `<h2>🤖 Play with Bot (offline)</h2><div class="grid">${GAMES.filter(g => g.bot && !g.adult && !g.soon).map(gameTile).join('')}</div>
    <button class="btn sec full" id="rt" style="margin-top:14px">🔄 Back to online login</button>${ownerLine()}`;
  $$('[data-g]').forEach(b => b.onclick = () => playBot(GAMES.find(x => x.id === b.dataset.g)));
  $('#rt').onclick = () => location.reload();
}

/* ---------- splash ---------- */
let splashed = false;
function splashScreen() {
  setNav(false); $('#pts').textContent = '';
  $('#screen').innerHTML = `<div class="splash"><img class="logo-lg" src="img/logo-lg.png" alt=""><h1>Playmates</h1><p class="mut">Play &nbsp;•&nbsp; Connect &nbsp;•&nbsp; Make Friends</p>
    <button class="btn full" id="gs">Get Started</button><button class="back" id="al">Already have an account? <b>Login</b></button>${ownerLine()}</div>`;
  $('#gs').onclick = () => authScreen('signup'); $('#al').onclick = () => authScreen('login');
}

/* ---------- boot ---------- */
async function boot() {
  const scr = $('#screen');
  if (!FIREBASE_CONFIG.apiKey || FIREBASE_CONFIG.apiKey === 'PASTE_HERE') { setNav(false); scr.innerHTML = '<div class="card"><h2>Setup incomplete</h2><p>Add your keys in firebase-config.js.</p></div>'; return; }
  scr.innerHTML = '<p class="mut">Loading...</p>';
  for (const [k, f] of [['dares', 'dares.json'], ['quiz', 'quiz.json'], ['intimacy', 'intimacy.json']]) {
    try { DATA[k] = await (await fetch('data/' + f)).json(); } catch (e) { console.warn(f, e); }
  }
  const A = window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.App;
  if (A) { try { A.addListener('appUrlOpen', e => handleLink(e.url)); A.getLaunchUrl().then(r => r && handleLink(r.url)).catch(() => {}); } catch (e) {} }
  try { firebase.initializeApp(FIREBASE_CONFIG); auth = firebase.auth(); db = firebase.firestore(); FV = firebase.firestore.FieldValue; } catch (e) { return offlineHome(); }
  auth.onAuthStateChanged(async u => {
    if (!u) { me = null; clearInterval(presenceT); if (selfUnsub) { selfUnsub(); selfUnsub = null; } clearListeners(); if (!splashed) { splashed = true; splashScreen(); } else authScreen('login'); return; }
    if (!u.email) { auth.signOut(); return; }
    if (!u.emailVerified) { verifyScreen(u); return; }
    try { await afterLogin(u); } catch (e) { console.warn(e); offlineHome(); }
  });
}
