/* Playmates - shared helpers: DOM, RNG, canvas, physics, duel + physics game factories */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const clone = o => JSON.parse(JSON.stringify(o));
const newSeed = () => (Math.random() * 4294967296) >>> 0;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const tri = (t, sp) => { const x = (t * sp) % 2; return x < 1 ? x : 2 - x; };
function rng(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

/* ---------- canvas helpers ---------- */
function mkCanvas(box, w, h) {
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h; cv.className = 'cv'; cv.style.touchAction = 'none';
  box.appendChild(cv);
  return cv;
}
function ptr(cv, e) {
  const r = cv.getBoundingClientRect();
  return { x: (e.clientX - r.left) * cv.width / r.width, y: (e.clientY - r.top) * cv.height / r.height };
}
function anim(fn) {
  let id, alive = true, last = performance.now();
  const f = t => { if (!alive) return; const dt = Math.min(0.05, (t - last) / 1000); last = t; try { fn(dt); } catch (e) { console.error(e); } id = requestAnimationFrame(f); };
  id = requestAnimationFrame(f);
  return () => { alive = false; cancelAnimationFrame(id); };
}
/* slingshot: pull back from the ball, release to shoot. */
function sling(cv, getBall, onShoot, maxPull = 80) {
  const st = { aim: null }; let on = false;
  const calc = e => {
    const b = getBall(); if (!b) return null;
    const p = ptr(cv, e), dx = b.x - p.x, dy = b.y - p.y, len = Math.min(Math.hypot(dx, dy), maxPull);
    return { ang: Math.atan2(dy, dx), pow: len / maxPull };
  };
  cv.addEventListener('pointerdown', e => { if (!getBall()) return; on = true; try { cv.setPointerCapture(e.pointerId); } catch (x) {} st.aim = calc(e); e.preventDefault(); });
  cv.addEventListener('pointermove', e => { if (on) st.aim = calc(e); });
  const up = e => {
    if (!on) return; on = false;
    const a = calc(e) || st.aim; st.aim = null;
    if (a && a.pow > 0.12 && getBall()) onShoot(a);
  };
  cv.addEventListener('pointerup', up);
  cv.addEventListener('pointercancel', () => { on = false; st.aim = null; });
  return st;
}

/* ---------- physics (circles on a table) ---------- */
const Phys = {
  step(P, dt) {
    const ev = [], B = P.balls;
    for (const b of B) {
      if (!b.a) continue;
      b.x += b.vx * dt; b.y += b.vy * dt;
      const sp = Math.hypot(b.vx, b.vy);
      if (sp > 0) { const ns = sp - P.fr * dt; if (ns < 3) { b.vx = 0; b.vy = 0; } else { b.vx *= ns / sp; b.vy *= ns / sp; } }
    }
    for (const b of B) {
      if (!b.a) continue;
      if (P.pockets) for (const p of P.pockets) if ((b.x - p.x) ** 2 + (b.y - p.y) ** 2 < p.r * p.r) { b.a = 0; b.vx = 0; b.vy = 0; ev.push(b.id); break; }
      if (!b.a) continue;
      const r = b.r, e = P.rest;
      if (b.x < r) { b.x = r; b.vx = Math.abs(b.vx) * e; } else if (b.x > P.w - r) { b.x = P.w - r; b.vx = -Math.abs(b.vx) * e; }
      if (P.killTop) { if (b.y < -r) { b.a = 0; b.vx = 0; b.vy = 0; } } else if (b.y < r) { b.y = r; b.vy = Math.abs(b.vy) * e; }
      if (b.y > P.h - r) { b.y = P.h - r; b.vy = -Math.abs(b.vy) * e; }
    }
    for (let i = 0; i < B.length; i++) {
      const a = B[i]; if (!a.a) continue;
      for (let j = i + 1; j < B.length; j++) {
        const c = B[j]; if (!c.a) continue;
        let dx = c.x - a.x, dy = c.y - a.y; const rr = a.r + c.r, d2 = dx * dx + dy * dy;
        if (d2 >= rr * rr || d2 === 0) continue;
        const d = Math.sqrt(d2); dx /= d; dy /= d;
        const ov = (rr - d) / 2; a.x -= dx * ov; a.y -= dy * ov; c.x += dx * ov; c.y += dy * ov;
        const rel = (a.vx - c.vx) * dx + (a.vy - c.vy) * dy;
        if (rel > 0) { const k = rel * (1 + P.rest) / 2; a.vx -= k * dx; a.vy -= k * dy; c.vx += k * dx; c.vy += k * dy; }
      }
    }
    return ev;
  },
  moving: P => P.balls.some(b => b.a && (b.vx || b.vy)),
  run(P, max = 2400) { const ev = []; for (let i = 0; i < max; i++) { ev.push(...Phys.step(P, 1 / 120)); if (!Phys.moving(P)) break; } return ev; }
};

/* ---------- duel factory: each player plays alone, scores compared ---------- */
function duel(def) {
  return Object.assign({ type: 'duel', simul: true, sym: ['●', '●'] }, def, {
    init: () => ({ seed: newSeed(), sc: [null, null], turn: 0, winner: null }),
    status: (s, seat) => s.winner != null ? '' : (s.sc[seat] == null ? '🎯 Play!' : '⏳ Partner is playing...'),
    move(s, m, seat) {
      if (m.a !== 'score' || s.sc[seat] != null) return null;
      s.sc[seat] = Math.max(0, Math.round(m.v));
      if (s.sc[0] != null && s.sc[1] != null) s.winner = s.sc[0] === s.sc[1] ? 'draw' : ((def.low ? s.sc[0] < s.sc[1] : s.sc[0] > s.sc[1]) ? 0 : 1);
      return s;
    },
    bot: (s, seat) => s.sc[seat] == null ? { a: 'score', v: def.bot() } : null,
    render(el, s, seat, send) {
      const key = s.gid + '|' + seat;
      if (s.sc[seat] == null) {
        if (el.__run === key) return;
        if (el.__stop) { try { el.__stop(); } catch (e) {} }
        el.__run = key; el.innerHTML = '';
        const box = document.createElement('div'); el.appendChild(box);
        el.__stop = def.play(box, s.seed, v => { el.__stop && el.__stop(); el.__stop = null; send({ a: 'score', v }); }) || null;
        return;
      }
      if (el.__stop) { try { el.__stop(); } catch (e) {} el.__stop = null; }
      el.__run = null;
      const f = v => v == null ? '…' : v;
      el.innerHTML = `<div class="scorebar"><div class="p0">${f(s.sc[0])}</div><div class="mut">${def.low ? 'lower = better' : 'higher = better'}</div><div class="p1">${f(s.sc[1])}</div></div>`;
    }
  });
}

/* ---------- physics turn game factory (pool, carrom, disc slide) ---------- */
function physGame(def) {
  const unpack = b => b.map((q, i) => ({ id: i, x: q[0], y: q[1], vx: q[2], vy: q[3], a: q[4], r: def.r(i) }));
  const pack = P => P.balls.map(b => [+b.x.toFixed(2), +b.y.toFixed(2), 0, 0, b.a]);
  const mkP = b => ({ w: def.w, h: def.h, fr: def.fr, rest: def.rest, pockets: def.pockets, killTop: def.killTop, balls: unpack(b) });
  const g = Object.assign({ type: 'turn', sym: ['🔴', '🔵'] }, def, {
    move(s, m, seat) {
      if (def.valid && !def.valid(s, m, seat)) return null;
      m = def.prep ? def.prep(s, m, seat) : Object.assign({}, m);
      m.by = seat;
      const P = mkP(s.b), before = s.b;
      def.launch(P, m, seat);
      const ev = Phys.run(P);
      P.balls.forEach(b => { b.vx = 0; b.vy = 0; });
      s.prev = before; s.b = pack(P); s.shot = m; s.n = (s.n || 0) + 1;
      def.after(s, ev, seat, before);
      return s;
    },
    candidates: def.cands,
    bot(s, seat, c) {
      let best = null, bs = -1e9;
      for (const m of def.cands(s, seat)) {
        const ns = g.move(clone(s), m, seat, c); if (!ns) continue;
        const sc = def.eval(s, ns, seat) + Math.random() * 0.5;
        if (sc > bs) { bs = sc; best = m; }
      }
      return best;
    },
    render(el, s, seat, send) {
      let R = el.__R;
      if (!R) {
        el.innerHTML = '<div class="hud"></div>';
        const cv = mkCanvas(el, def.cw || def.w, def.ch || def.h);
        const ctl = document.createElement('div'); el.appendChild(ctl);
        R = el.__R = { cv, c: cv.getContext('2d'), queue: [], busy: false, n: -1, sx: 0.5, show: null, P: null, seat };
        if (def.slider) { ctl.innerHTML = '<div class="mut" style="text-align:center">⬅️ move the striker ➡️</div><input type="range" min="0" max="100" value="50">'; $('input', ctl).oninput = e => { R.sx = e.target.value / 100; }; }
        const canShoot = () => R.mine && !R.busy && !R.queue.length && R.s.winner == null;
        R.sling = sling(cv, () => canShoot() ? def.shooter(R.s, R) : null, a => send({ ang: a.ang, pow: a.pow, x: R.sx }), def.pull || 80);
        R.stop = anim(() => {
          if (!R.busy && R.queue.length) {
            const st = R.queue.shift();
            R.cur = st;
            if (st.shot && st.prev && !st.noanim) { R.P = mkP(st.prev); def.launch(R.P, st.shot, st.shot.by); R.busy = true; el.__anim = true; }
            else R.show = unpack(st.b);
          }
          if (R.busy) {
            for (let i = 0; i < 3; i++) { Phys.step(R.P, 1 / 120); if (!Phys.moving(R.P)) { R.busy = false; el.__anim = false; R.P = null; R.show = unpack(R.cur.b); break; } }
          }
          const balls = R.busy ? R.P.balls : R.show;
          if (balls) def.draw(R.c, balls, R, R.s, canShoot());
        });
        el.__stop = R.stop;
      }
      R.s = s; R.mine = s.turn === seat && s.winner == null;
      $('.hud', el).innerHTML = def.hud ? def.hud(s, seat) : '';
      if (s.n !== R.n) { R.n = s.n; R.queue.push(Object.assign({}, s, { noanim: !R.first })); R.first = true; }
    }
  });
  return g;
}
