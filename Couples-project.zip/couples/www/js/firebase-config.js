// Playmates config
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyBMx0DuAF3hJWK0TLFK99--klC2NFuEGnQ",
  authDomain: "couples-ab32f.firebaseapp.com",
  projectId: "couples-ab32f",
  storageBucket: "couples-ab32f.firebasestorage.app",
  messagingSenderId: "991388748844",
  appId: "1:991388748844:web:e8402176421660c9be9589"
};
const ADMIN_EMAIL = "itzzsaimikhan@gmail.com";   // sirf is email wale ko Owner Panel dikhega
const OWNER_NAME = "Sameer Khan";
const INVITE_BASE = "https://itzzmesaim-commits.github.io/Couple-/join.html";
