/* Playmates - per-game sound + animation feedback, wraps every game's render */
(function () {
  const flash = (el, cls) => { el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); setTimeout(() => el.classList.remove(cls), 450); };
  const sig = s => { try { const c = Object.assign({}, s); delete c.gid; return JSON.stringify(c); } catch (e) { return ''; } };
  function react(g, el, o, s, seat) {
    const id = g.id, P = SFX.play;
    if (s.winner != null && o.winner == null) { setTimeout(() => P(s.winner === 'draw' ? 'good' : (s.winner === seat ? 'win' : 'lose')), 250); flash(el, 'fxpulse'); return; }
    if (id === 'monster' && s.ev && s.n !== o.n) { const e = s.ev; if (e.special) P('boom'); else if (e.dmg > 0) P('hit'); if (e.armor) setTimeout(() => P('shield'), 120); if (e.heal) setTimeout(() => P('heal'), 220); if (e.chain > 1) setTimeout(() => P('coin'), 300); if (e.extra) setTimeout(() => P('clear'), 420); if (e.dmg >= 100 || e.special) flash(el, 'fxshake'); else flash(el, 'fxpulse'); return; }
    if (id === 'sea' && s.last && s.cnt !== o.cnt) { P(s.last.hit ? 'boom' : 'splash'); flash(el, s.last.hit ? 'fxshake' : 'fxpulse'); return; }
    if (id === 'sea' && s.ph !== o.ph) { P('clear'); return; }
    if (id === 'dom') { const nb = s.board.length, ob = o.board.length; if (nb !== ob) { P('clack'); const t = $$('.dtile', el); const last = (o.board.length && s.board.length && JSON.stringify(s.board[0]) !== JSON.stringify(o.board[0])) ? t[0] : t[t.length - 1]; if (last) last.classList.add('fxnew'); } else if (s.stock.length !== o.stock.length) P('pop'); else P('tap'); return; }
    if (id === 'bg') { if (JSON.stringify(s.d) !== JSON.stringify(o.d)) P('dice'); else P('clack'); flash(el, 'fxpulse'); return; }
    if (id === 'dice') { if (s.n !== o.n && s.turn !== o.turn) P('good'); else if (JSON.stringify(s.dice) !== JSON.stringify(o.dice)) P('dice'); else P('tap'); return; }
    if (id === 'word' || id === 'brawl' || id === 'bank') return;
    if (id === 'bloko' && s.turn !== seat) { P('place'); flash(el, 'fxpulse'); return; } if (id === 'bloko') return;
    const ST = { c4: 'drop', rv: 'clack', ck: 'clack', db: 'tap', ttt: 'place', ludo: 'dice', golf: 'putt', tsoc: 'kick', carrom: 'strike', pool: 'hit', bowl: 'strike' }; if (ST[id]) { P(ST[id]); flash(el, 'fxpulse'); return; }
    if (id === 'bloko') { P('place'); flash(el, 'fxpulse'); return; }
    if (s.shot || s.b) { P('hit'); flash(el, 'fxpulse'); return; }
    if (s.dice != null || s.die != null) { P('dice'); flash(el, 'fxpulse'); return; }
    P('place'); flash(el, 'fxpulse');
  }
  (window.GAMES || []).forEach(g => {
    if (!g || g.__fx || !g.render) return; g.__fx = 1; const orig = g.render;
    g.render = function (el, s, seat, send, c) {
      window.__curGame = g.id; try { MUSIC.start(g.id); } catch (e) { }
      try {
        const k = sig(s), old = el.__fxs;
        if (old && el.__fxg === s.gid && g.type !== 'duel' && k !== old.k) { try { react(g, el, old.s, s, seat); } catch (e) { } }
        el.__fxs = { k, s: JSON.parse(k || 'null') || s }; el.__fxg = s.gid;
      } catch (e) { }
      return orig.call(this, el, s, seat, send, c);
    };
  });
  /* canvas games: whoosh on release, soft tap on press */
  document.addEventListener('pointerdown', e => { if (e.target && e.target.tagName === 'CANVAS') SFX.play('tap'); }, true);
  const REL = { arch: 'bow', darts: 'throw', hoop: 'swish', bowl: 'roll', skee: 'roll', golf: 'putt', carrom: 'strike', pool: 'cue', tsoc: 'kick', disco: 'drop', plox: 'place', bounce: 'jump', safari: 'shutter', tower: 'stack', candy: 'slide', brawl: 'cannon' };
  document.addEventListener('pointerup', e => { if (e.target && e.target.tagName === 'CANVAS') SFX.play(REL[window.__curGame] || 'whoosh'); }, true);
})();
