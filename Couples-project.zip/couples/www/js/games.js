/* Couples - game engines. Every room game: init(ctx), move(state, move, seat, ctx) -> new state | null, render(el, state, seat, send, ctx) */
const rnd = n => Math.floor(Math.random() * n);
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const SYM2 = ['●', '●'];

/* ---------- Tic Tac Toe ---------- */
const TTT_LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const G_TTT = {
  id: 'ttt', name: 'Tic Tac Toe', icon: '❌', sym: ['❌', '⭕'], desc: 'Get three in a row.',
  init: () => ({ b: Array(9).fill(null), turn: 0, winner: null }),
  move(s, m, seat) {
    if (s.b[m.i] != null) return null;
    s.b[m.i] = seat;
    if (TTT_LINES.some(l => l.every(i => s.b[i] === seat))) s.winner = seat;
    else if (s.b.every(x => x != null)) s.winner = 'draw';
    else s.turn = 1 - seat;
    return s;
  },
  render(el, s, seat, send) {
    el.innerHTML = `<div class="board" style="grid-template-columns:repeat(3,1fr)">${s.b.map((v, i) => `<button class="cell" data-i="${i}">${v == null ? '' : ['❌', '⭕'][v]}</button>`).join('')}</div>`;
    $$('[data-i]', el).forEach(b => b.onclick = () => send({ i: +b.dataset.i }));
  }
};

/* ---------- 4 in a Row ---------- */
function c4win(b, r, c, p) {
  for (const [dr, dc] of [[0, 1], [1, 0], [1, 1], [1, -1]]) {
    let n = 1;
    for (const k of [1, -1]) { let rr = r + dr * k, cc = c + dc * k; while (rr >= 0 && rr < 6 && cc >= 0 && cc < 7 && b[rr * 7 + cc] === p) { n++; rr += dr * k; cc += dc * k; } }
    if (n >= 4) return true;
  }
  return false;
}
const G_C4 = {
  id: 'c4', name: '4 in a Row', icon: '🔴', sym: SYM2, desc: 'Connect four discs in a line.',
  init: () => ({ b: Array(42).fill(null), turn: 0, winner: null }),
  move(s, m, seat) {
    const c = m.c; let r = 5;
    while (r >= 0 && s.b[r * 7 + c] != null) r--;
    if (r < 0) return null;
    s.b[r * 7 + c] = seat;
    if (c4win(s.b, r, c, seat)) s.winner = seat;
    else if (s.b.every(x => x != null)) s.winner = 'draw';
    else s.turn = 1 - seat;
    return s;
  },
  render(el, s, seat, send) {
    el.innerHTML = `<div class="board" style="grid-template-columns:repeat(7,1fr)">${s.b.map((v, i) => `<button class="cell" data-c="${i % 7}">${v == null ? '' : `<span class="disc p${v}"></span>`}</button>`).join('')}</div>`;
    $$('[data-c]', el).forEach(b => b.onclick = () => send({ c: +b.dataset.c }));
  }
};

/* ---------- Reversi ---------- */
const DIRS8 = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]];
function rvFlips(b, r, c, p) {
  if (b[r * 8 + c] != null) return [];
  const out = [];
  for (const [dr, dc] of DIRS8) {
    const line = []; let rr = r + dr, cc = c + dc;
    while (rr >= 0 && rr < 8 && cc >= 0 && cc < 8 && b[rr * 8 + cc] === 1 - p) { line.push(rr * 8 + cc); rr += dr; cc += dc; }
    if (line.length && rr >= 0 && rr < 8 && cc >= 0 && cc < 8 && b[rr * 8 + cc] === p) out.push(...line);
  }
  return out;
}
const rvMoves = (b, p) => { const m = []; for (let i = 0; i < 64; i++) if (rvFlips(b, i >> 3, i & 7, p).length) m.push(i); return m; };
const G_RV = {
  id: 'rv', name: 'Reversi', icon: '⚫', sym: SYM2, desc: 'Flip your partner’s discs and own more discs.',
  init() { const b = Array(64).fill(null); b[27] = 1; b[36] = 1; b[28] = 0; b[35] = 0; return { b, turn: 0, winner: null }; },
  move(s, m, seat) {
    const f = rvFlips(s.b, m.i >> 3, m.i & 7, seat);
    if (!f.length) return null;
    s.b[m.i] = seat; f.forEach(i => s.b[i] = seat);
    if (rvMoves(s.b, 1 - seat).length) s.turn = 1 - seat;
    else if (rvMoves(s.b, seat).length) s.turn = seat;
    else { const a = s.b.filter(x => x === 0).length, c = s.b.filter(x => x === 1).length; s.winner = a === c ? 'draw' : (a > c ? 0 : 1); }
    return s;
  },
  render(el, s, seat, send) {
    const hints = s.turn === seat && s.winner == null ? rvMoves(s.b, seat) : [];
    const a = s.b.filter(x => x === 0).length, c = s.b.filter(x => x === 1).length;
    el.innerHTML = `<div class="scorebar"><div class="p0">${a}</div><div class="p1">${c}</div></div><div class="board" style="grid-template-columns:repeat(8,1fr);gap:2px">${s.b.map((v, i) => `<button class="cell ${hints.includes(i) ? 'opt' : ''}" style="font-size:14px" data-i="${i}">${v == null ? '' : `<span class="disc p${v}"></span>`}</button>`).join('')}</div>`;
    $$('[data-i]', el).forEach(b => b.onclick = () => send({ i: +b.dataset.i }));
  }
};

/* ---------- Checkers ---------- */
const ckOwn = p => p ? (p.toLowerCase() === 'a' ? 0 : 1) : -1;
function ckMoves(s, seat) {
  const caps = [], steps = [];
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const p = s.b[r][c];
    if (ckOwn(p) !== seat) continue;
    if (s.chain && (s.chain[0] !== r || s.chain[1] !== c)) continue;
    const king = p === p.toUpperCase();
    const drs = king ? [-1, 1] : [seat === 0 ? -1 : 1];
    for (const dr of drs) for (const dc of [-1, 1]) {
      const nr = r + dr, nc = c + dc;
      if (nr < 0 || nr > 7 || nc < 0 || nc > 7) continue;
      const q = s.b[nr][nc];
      if (q == null) { if (!s.chain) steps.push({ fr: r, fc: c, tr: nr, tc: nc }); }
      else if (ckOwn(q) !== seat) {
        const jr = r + 2 * dr, jc = c + 2 * dc;
        if (jr >= 0 && jr < 8 && jc >= 0 && jc < 8 && s.b[jr][jc] == null) caps.push({ fr: r, fc: c, tr: jr, tc: jc });
      }
    }
  }
  return caps.length ? caps : steps;
}
let ckSel = null;
const G_CK = {
  id: 'ck', name: 'Checkers', icon: '🏁', sym: SYM2, desc: 'Capture all of your partner’s pieces. Capturing is compulsory.',
  init() {
    const b = Array.from({ length: 8 }, () => Array(8).fill(null));
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) if ((r + c) % 2 === 1) { if (r < 3) b[r][c] = 'b'; else if (r > 4) b[r][c] = 'a'; }
    return { b, turn: 0, chain: null, nc: 0, winner: null };
  },
  move(s, m, seat) {
    const ok = ckMoves(s, seat).find(x => x.fr === m.fr && x.fc === m.fc && x.tr === m.tr && x.tc === m.tc);
    if (!ok) return null;
    let p = s.b[m.fr][m.fc];
    s.b[m.fr][m.fc] = null;
    const jump = Math.abs(m.tr - m.fr) === 2;
    if (jump) s.b[(m.fr + m.tr) / 2][(m.fc + m.tc) / 2] = null;
    let kinged = false;
    if ((seat === 0 && m.tr === 0 && p === 'a') || (seat === 1 && m.tr === 7 && p === 'b')) { p = p.toUpperCase(); kinged = true; }
    s.b[m.tr][m.tc] = p;
    s.chain = null;
    s.nc = jump ? 0 : (s.nc || 0) + 1;
    if (s.nc >= 60) { s.winner = 'draw'; return s; }
    if (jump && !kinged) { s.chain = [m.tr, m.tc]; if (!ckMoves(s, seat).length) s.chain = null; }
    if (!s.chain) {
      s.turn = 1 - seat;
      if (!ckMoves(s, 1 - seat).length) s.winner = seat;
    }
    return s;
  },
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null;
    const mv = mine ? ckMoves(s, seat) : [];
    if (mine && s.chain) ckSel = s.chain.slice();
    else if (!mine || (ckSel && !mv.some(x => x.fr === ckSel[0] && x.fc === ckSel[1]))) ckSel = null;
    const dests = ckSel ? mv.filter(x => x.fr === ckSel[0] && x.fc === ckSel[1]) : [];
    const flipView = seat === 1;
    let html = '';
    for (let rr = 0; rr < 8; rr++) for (let cc = 0; cc < 8; cc++) {
      const r = flipView ? 7 - rr : rr, c = flipView ? 7 - cc : cc;
      const p = s.b[r][c], dark = (r + c) % 2 === 1;
      const isSel = ckSel && ckSel[0] === r && ckSel[1] === c;
      const isDest = dests.some(x => x.tr === r && x.tc === c);
      html += `<button class="cell ${dark ? 'dark' : 'light'} ${isSel ? 'sel' : ''} ${isDest ? 'opt' : ''}" style="font-size:12px" data-r="${r}" data-c="${c}">${p ? `<span class="disc p${ckOwn(p)} ${p === p.toUpperCase() ? 'k' : ''}"></span>` : ''}</button>`;
    }
    el.innerHTML = `<div class="board" style="grid-template-columns:repeat(8,1fr);gap:1px">${html}</div>`;
    $$('[data-r]', el).forEach(b => b.onclick = () => {
      const r = +b.dataset.r, c = +b.dataset.c;
      if (!mine) return;
      const d = dests.find(x => x.tr === r && x.tc === c);
      if (d) { const m = { fr: d.fr, fc: d.fc, tr: r, tc: c }; ckSel = null; send(m); return; }
      if (!s.chain && mv.some(x => x.fr === r && x.fc === c)) { ckSel = [r, c]; G_CK.render(el, s, seat, send); }
    });
  }
};

/* ---------- Dots & Boxes ---------- */
const DB_N = 5;
const dbBoxDone = (s, i, j) => s.h[i][j] != null && s.h[i + 1][j] != null && s.v[i][j] != null && s.v[i][j + 1] != null;
const G_DB = {
  id: 'db', name: 'Dots & Boxes', icon: '🔲', sym: SYM2, desc: 'Draw lines and complete boxes. A box gives you another turn.',
  init: () => ({ h: Array.from({ length: DB_N + 1 }, () => Array(DB_N).fill(null)), v: Array.from({ length: DB_N }, () => Array(DB_N + 1).fill(null)), bx: Array.from({ length: DB_N }, () => Array(DB_N).fill(null)), sc: [0, 0], turn: 0, winner: null }),
  move(s, m, seat) {
    const L = m.t === 'h' ? s.h : s.v;
    if (!L[m.r] || L[m.r][m.c] !== null) return null;
    L[m.r][m.c] = seat;
    const cand = m.t === 'h' ? [[m.r - 1, m.c], [m.r, m.c]] : [[m.r, m.c - 1], [m.r, m.c]];
    let got = 0;
    cand.forEach(([i, j]) => { if (i >= 0 && i < DB_N && j >= 0 && j < DB_N && s.bx[i][j] == null && dbBoxDone(s, i, j)) { s.bx[i][j] = seat; s.sc[seat]++; got++; } });
    if (s.sc[0] + s.sc[1] === DB_N * DB_N) s.winner = s.sc[0] === s.sc[1] ? 'draw' : (s.sc[0] > s.sc[1] ? 0 : 1);
    else if (!got) s.turn = 1 - seat;
    return s;
  },
  render(el, s, seat, send) {
    const T = 2 * DB_N + 1; let html = '';
    for (let r = 0; r < T; r++) for (let c = 0; c < T; c++) {
      if (r % 2 === 0 && c % 2 === 0) html += '<div class="dot"></div>';
      else if (r % 2 === 0) { const v = s.h[r / 2][(c - 1) / 2]; html += `<div class="ln ${v != null ? 'on' + v : ''}" data-t="h" data-r="${r / 2}" data-c="${(c - 1) / 2}"></div>`; }
      else if (c % 2 === 0) { const v = s.v[(r - 1) / 2][c / 2]; html += `<div class="ln ${v != null ? 'on' + v : ''}" data-t="v" data-r="${(r - 1) / 2}" data-c="${c / 2}"></div>`; }
      else { const o = s.bx[(r - 1) / 2][(c - 1) / 2]; html += `<div class="bx p${o}">${o == null ? '' : '■'}</div>`; }
    }
    const tpl = Array.from({ length: T }, (_, i) => i % 2 ? '1fr' : '12px').join(' ');
    el.innerHTML = `<div class="scorebar"><div class="p0">${s.sc[0]}</div><div class="p1">${s.sc[1]}</div></div><div class="dots" style="aspect-ratio:1;grid-template-columns:${tpl};grid-template-rows:${tpl}">${html}</div>`;
    $$('.ln', el).forEach(l => l.onclick = () => send({ t: l.dataset.t, r: +l.dataset.r, c: +l.dataset.c }));
  }
};

/* ---------- Dice Party ---------- */
const PIPS = '⚀⚁⚂⚃⚄⚅';
function diceScore(d) {
  const cnt = {}; d.forEach(x => cnt[x] = (cnt[x] || 0) + 1);
  const mx = Math.max(...Object.values(cnt));
  return d.reduce((a, b) => a + b, 0) + ({ 1: 0, 2: 15, 3: 30, 4: 50, 5: 80 })[mx];
}
let diceHeld = [false, false, false, false, false];
const G_DICE = {
  id: 'dice', name: 'Dice Party', icon: '🎲', sym: SYM2, desc: '5 rounds. 3 rolls per turn. Bonus for pairs and triples!',
  init: () => ({ dice: [0, 0, 0, 0, 0], rolls: 0, sc: [0, 0], done: [0, 0], turn: 0, winner: null }),
  move(s, m, seat) {
    if (m.a === 'roll') {
      if (s.rolls >= 3) return null;
      s.dice = s.dice.map((x, i) => (s.rolls > 0 && m.held && m.held[i]) ? x : 1 + rnd(6));
      s.rolls++; return s;
    }
    if (m.a === 'score') {
      if (s.rolls === 0) return null;
      s.sc[seat] += diceScore(s.dice); s.done[seat]++;
      s.dice = [0, 0, 0, 0, 0]; s.rolls = 0;
      if (s.done[0] >= 5 && s.done[1] >= 5) s.winner = s.sc[0] === s.sc[1] ? 'draw' : (s.sc[0] > s.sc[1] ? 0 : 1);
      else s.turn = 1 - seat;
      return s;
    }
    return null;
  },
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null;
    if (s.rolls === 0) diceHeld = [false, false, false, false, false];
    el.innerHTML = `<div class="scorebar"><div class="p0">${s.sc[0]}<br><small>${s.done[0]}/5</small></div><div class="p1">${s.sc[1]}<br><small>${s.done[1]}/5</small></div></div>
      <div class="dice">${s.dice.map((d, i) => `<button class="die ${diceHeld[i] ? 'held' : ''}" data-d="${i}">${d ? PIPS[d - 1] : '?'}</button>`).join('')}</div>
      ${s.rolls ? `<p class="mut" style="text-align:center">Tap a die to hold it. Turn score: <b>${diceScore(s.dice)}</b></p>` : ''}
      ${mine ? `<button class="btn full" id="rl" ${s.rolls >= 3 ? 'disabled' : ''}>🎲 Roll (${3 - s.rolls} baaki)</button>${s.rolls ? '<button class="btn sec full" id="sc">✅ Score le lo</button>' : ''}` : ''}`;
    if (!mine) return;
    $$('[data-d]', el).forEach(b => b.onclick = () => { if (!s.rolls || s.rolls >= 3) return; diceHeld[+b.dataset.d] = !diceHeld[+b.dataset.d]; b.classList.toggle('held'); });
    $('#rl', el).onclick = () => send({ a: 'roll', held: diceHeld.slice() });
    const sc = $('#sc', el); if (sc) sc.onclick = () => send({ a: 'score' });
  }
};

/* ---------- Ludo (2 player, 4 tokens each, 28-cell ring) ---------- */
const LUDO_START = [0, 14];
const ringPos = (seat, pr) => (LUDO_START[seat] + pr - 1) % 28;
function ludoLegal(s, seat, roll) {
  const out = [];
  s.p[seat].forEach((pr, i) => { if (pr === -1) { if (roll === 6) out.push(i); } else if (pr < 28 && pr + roll <= 28) out.push(i); });
  return out;
}
function ringXY(i) {
  if (i < 8) return [0, i];
  if (i < 15) return [i - 7, 7];
  if (i < 22) return [7, 7 - (i - 14)];
  return [7 - (i - 21), 0];
}
const G_LUDO = {
  id: 'ludo', name: 'Ludo', icon: '🎯', sym: ['🔴', '🔵'], desc: 'Roll a 6 to bring out a token. Get all four tokens home first.',
  init: () => ({ p: [[-1, -1, -1, -1], [-1, -1, -1, -1]], turn: 0, roll: null, last: null, winner: null }),
  status: (s, seat) => s.turn !== seat ? '⏳ Partner’s turn' : (s.roll == null ? '🎲 Roll the dice' : '👉 Choose a token'),
  move(s, m, seat) {
    if (m.a === 'roll') {
      if (s.roll != null) return null;
      const r = 1 + rnd(6); s.last = r;
      if (!ludoLegal(s, seat, r).length) { s.roll = null; s.turn = 1 - seat; } else s.roll = r;
      return s;
    }
    if (m.a === 'tok') {
      if (s.roll == null || !ludoLegal(s, seat, s.roll).includes(m.i)) return null;
      const pr = s.p[seat][m.i], np = pr === -1 ? 1 : pr + s.roll;
      s.p[seat][m.i] = np;
      if (np < 28) { const rp = ringPos(seat, np), o = 1 - seat; s.p[o] = s.p[o].map(q => (q >= 1 && q < 28 && ringPos(o, q) === rp) ? -1 : q); }
      if (s.p[seat].every(x => x === 28)) { s.winner = seat; return s; }
      const six = s.roll === 6; s.roll = null;
      if (!six) s.turn = 1 - seat;
      return s;
    }
    return null;
  },
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null;
    const occ = Array.from({ length: 28 }, () => [0, 0]);
    [0, 1].forEach(o => s.p[o].forEach(q => { if (q >= 1 && q < 28) occ[ringPos(o, q)][o]++; }));
    const cells = Array.from({ length: 64 }, () => '<div></div>');
    for (let i = 0; i < 28; i++) {
      const [r, c] = ringXY(i), st = i === 0 ? 0 : i === 14 ? 1 : -1;
      cells[r * 8 + c] = `<div class="cell" style="font-size:13px;${st >= 0 ? 'outline:2px solid ' + (st ? '#5aa2ff' : '#ff4d8d') : ''}">${occ[i][0] ? `<span class="p0">●${occ[i][0] > 1 ? occ[i][0] : ''}</span>` : ''}${occ[i][1] ? `<span class="p1">●${occ[i][1] > 1 ? occ[i][1] : ''}</span>` : ''}</div>`;
    }
    const grid = cells.map((h, i) => (i >> 3 >= 1 && i >> 3 <= 6 && (i & 7) >= 1 && (i & 7) <= 6) ? '' : h).join('');
    const legal = mine && s.roll != null ? ludoLegal(s, seat, s.roll) : [];
    const lbl = q => q === -1 ? 'Yard' : q === 28 ? 'Home ✅' : 'Step ' + q;
    el.innerHTML = `<div class="board" style="grid-template-columns:repeat(8,1fr);gap:2px;position:relative">${grid}
      <div style="grid-area:2/2/8/8;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:13px;text-align:center" class="mut">
      <div style="font-size:40px;color:#fff">${s.last ? PIPS[s.last - 1] : '🎲'}</div>
      <div class="p0">🔴 Home: ${s.p[0].filter(x => x === 28).length}/4</div><div class="p1">🔵 Home: ${s.p[1].filter(x => x === 28).length}/4</div></div></div>
      ${mine && s.roll == null ? '<button class="btn full" id="rl">🎲 Roll the dice</button>' : ''}
      <div class="grid" style="grid-template-columns:repeat(2,1fr)">${s.p[seat].map((q, i) => `<button class="tile ${legal.includes(i) ? 'adult' : ''}" data-t="${i}" ${legal.includes(i) ? '' : 'disabled'}>Token ${i + 1}<br><span class="mut">${lbl(q)}</span></button>`).join('')}</div>`;
    const rl = $('#rl', el); if (rl) rl.onclick = () => send({ a: 'roll' });
    $$('[data-t]', el).forEach(b => b.onclick = () => send({ a: 'tok', i: +b.dataset.t }));
  }
};

/* ---------- Adult Quiz (18+) ---------- */
const G_QUIZ = {
  id: 'quiz', name: 'Adult Quiz', icon: '🔥', adult: true, simul: true, sym: SYM2, desc: 'Both answer the same question. Score a point on a match or a correct answer!',
  init(c) { const n = Math.min(10, (c.data.quiz || []).length); return { order: shuffle([...Array(c.data.quiz.length).keys()]).slice(0, n), i: 0, ans: [null, null], sc: [0, 0], rev: false, turn: 0, winner: null }; },
  status: (s, seat) => s.rev ? 'See result' : (s.ans[seat] == null ? '👉 Choose an answer' : '⏳ Waiting for partner'),
  move(s, m, seat, c) {
    const q = c.data.quiz[s.order[s.i]];
    if (m.a === 'ans') {
      if (s.rev || s.ans[seat] != null || m.k == null) return null;
      s.ans[seat] = m.k;
      if (s.ans[0] != null && s.ans[1] != null) {
        s.rev = true;
        if (q.a == null) { if (s.ans[0] === s.ans[1]) { s.sc[0]++; s.sc[1]++; } }
        else [0, 1].forEach(i => { if (s.ans[i] === q.a) s.sc[i]++; });
      }
      return s;
    }
    if (m.a === 'next') {
      if (!s.rev) return null;
      s.i++; s.ans = [null, null]; s.rev = false;
      if (s.i >= s.order.length) s.winner = s.sc[0] === s.sc[1] ? 'draw' : (s.sc[0] > s.sc[1] ? 0 : 1);
      return s;
    }
    return null;
  },
  render(el, s, seat, send, c) {
    if (!s.order.length) { el.innerHTML = '<div class="hint">No quiz questions added yet. Add them in data/quiz.json.</div>'; return; }
    if (s.winner != null) { el.innerHTML = `<div class="scorebar"><div class="p0">${s.sc[0]}</div><div class="p1">${s.sc[1]}</div></div>`; return; }
    const q = c.data.quiz[s.order[s.i]];
    el.innerHTML = `<div class="scorebar"><div class="p0">${s.sc[0]}</div><div class="mut">Q ${s.i + 1}/${s.order.length}</div><div class="p1">${s.sc[1]}</div></div>
      <div class="card"><b>${esc(q.q)}</b></div>
      ${q.o.map((o, k) => `<button class="opt-btn ${s.ans[seat] === k ? 'pick' : ''} ${s.rev && q.a === k ? 'right' : ''}" data-k="${k}">${esc(o)}${s.rev ? `<span style="float:right">${s.ans[0] === k ? '<span class=p0>●</span>' : ''}${s.ans[1] === k ? '<span class=p1>●</span>' : ''}</span>` : ''}</button>`).join('')}
      ${s.rev ? '<button class="btn full" id="nx">Aage ➡️</button>' : ''}`;
    $$('[data-k]', el).forEach(b => b.onclick = () => send({ a: 'ans', k: +b.dataset.k }));
    const nx = $('#nx', el); if (nx) nx.onclick = () => send({ a: 'next' });
  }
};

/* ---------- Punishment (18+) ---------- */
const G_PUN = {
  id: 'pun', name: 'Punishment', icon: '😈', adult: true, sym: SYM2, desc: 'Take turns drawing dares for your partner. Play only with mutual consent.',
  init: () => ({ turn: 0, card: null, to: null, used: [], winner: null }),
  status: (s, seat) => s.turn !== seat ? '⏳ Partner’s turn' : (s.card != null ? '😈 Your dare. Complete it, then dare your partner' : '🎲 Draw a dare for your partner'),
  move(s, m, seat, c) {
    const d = c.data.dares || [];
    if (!d.length) return null;
    let pool = d.map((_, i) => i).filter(i => !s.used.includes(i));
    if (!pool.length) { s.used = []; pool = d.map((_, i) => i); }
    const i = pool[rnd(pool.length)];
    s.used.push(i); s.card = i; s.to = 1 - seat; s.turn = 1 - seat;
    return s;
  },
  render(el, s, seat, send, c) {
    const d = c.data.dares || [];
    if (!d.length) { el.innerHTML = '<div class="hint">No dares added yet. Add them in data/dares.json.</div>'; return; }
    el.innerHTML = `<div class="dare">${s.card == null ? '🎴 Draw the first dare' : `<small class="mut">${s.to === seat ? 'For you' : 'For your partner'}</small><br>${esc(d[s.card])}`}</div>
      ${s.turn === seat ? `<button class="btn full" id="dr">${s.card == null ? '🎲 Dare nikalo' : '✅ Dare done — ab partner ko dare do'}</button>` : ''}`;
    const b = $('#dr', el); if (b) b.onclick = () => send({ a: 'draw' });
  }
};

/* ---------- Intimacy Cards (18+, solo) ---------- */
const G_INT = {
  id: 'int', name: 'Intimacy Cards', icon: '💋', adult: true, solo(el, c) {
    const D = c.data.intimacy || {}; let tab = 'cards', idx = 0;
    const draw = () => {
      const list = tab === 'cards' ? (D.cards || []) : (D[tab] || []);
      let body;
      if (!list.length) body = `<div class="hint">${tab === 'cards' ? 'No cards added yet.' : `assets/intimacy/${tab}/ folder and list their names in data/intimacy.json.`}</div>`;
      else {
        const it = list[idx % list.length];
        body = tab === 'cards'
          ? `<div class="dare">${esc(it.text || it)}</div>`
          : `<img class="imgcard" src="assets/intimacy/${tab}/${esc(it)}" alt="">`;
        body += `<div class="row"><button class="btn sec" id="pv" style="flex:1">⬅️</button><span class="mut">${(idx % list.length) + 1}/${list.length}</span><button class="btn" id="nx" style="flex:1">${tab === 'cards' ? '🎴 Next card' : '➡️'}</button></div>`;
      }
      el.innerHTML = `<h2>💋 Intimacy Cards</h2><div class="row" style="margin-bottom:8px">${[['cards', '🎴 Cards'], ['male', '♂️ Male'], ['female', '♀️ Female']].map(([k, n]) => `<button class="btn ${tab === k ? '' : 'sec'}" style="flex:1;padding:10px 4px" data-tab="${k}">${n}</button>`).join('')}</div>${body}`;
      $$('[data-tab]', el).forEach(b => b.onclick = () => { tab = b.dataset.tab; idx = 0; draw(); });
      const nx = $('#nx', el), pv = $('#pv', el);
      if (nx) nx.onclick = () => { idx = tab === 'cards' ? rnd(list.length) : idx + 1; draw(); };
      if (pv) pv.onclick = () => { idx = (idx - 1 + list.length) % list.length; draw(); };
    };
    draw();
  }
};

