/* Playmates - Wave 3.5: Bankroll (property board) + Bloko (clear rebuild) */

/* ================= BANKROLL ================= */
const BR_T = [
  { k: 'start', n: 'START' },
  { k: 'p', n: 'RIO', pr: 100, g: 0 }, { k: 'p', n: 'DELHI', pr: 100, g: 0 }, { k: 'p', n: 'BANGKOK', pr: 130, g: 1 }, { k: 'tr', n: 'HARBOR', pr: 200, ic: '⛵' }, { k: 'p', n: 'CAIRO', pr: 150, g: 1 }, { k: 'p', n: 'MADRID', pr: 150, g: 1 },
  { k: 'chance', n: '?' },
  { k: 'p', n: 'JAKARTA', pr: 170, g: 2 }, { k: 'p', n: 'BERLIN', pr: 180, g: 2 }, { k: 'p', n: 'MOSCOW', pr: 200, g: 3 }, { k: 'tr', n: 'RAILWAY', pr: 200, ic: '🚂' }, { k: 'p', n: 'TORONTO', pr: 200, g: 3 }, { k: 'p', n: 'SEOUL', pr: 200, g: 3 },
  { k: 'jail', n: 'JAIL' },
  { k: 'p', n: 'ZURICH', pr: 250, g: 4 }, { k: 'p', n: 'RIYADH', pr: 250, g: 4 }, { k: 'p', n: 'SYDNEY', pr: 300, g: 5 }, { k: 'ut', n: 'ELECTRICITY', pr: 150, ic: '💡' }, { k: 'p', n: 'BEIJING', pr: 300, g: 5 }, { k: 'p', n: 'DUBAI', pr: 300, g: 5 },
  { k: 'auction', n: 'AUCTION' },
  { k: 'p', n: 'PARIS', pr: 350, g: 6 }, { k: 'p', n: 'HONG KONG', pr: 350, g: 6 }, { k: 'tr', n: 'AIRPORT', pr: 200, ic: '✈️' }, { k: 'p', n: 'LONDON', pr: 420, g: 7 }, { k: 'p', n: 'TOKYO', pr: 420, g: 7 }, { k: 'p', n: 'NEW YORK', pr: 450, g: 7 }
];
const BR_COL = ['#9bcf5f', '#4fb0f0', '#d8457f', '#fdae42', '#3fcfa4', '#d4915f', '#9a63ee', '#f98a72'];
const BR_POS = i => i === 0 ? [7, 0] : i <= 6 ? [7 - i, 0] : i === 7 ? [0, 0] : i <= 13 ? [0, i - 7] : i === 14 ? [0, 7] : i <= 20 ? [i - 14, 7] : i === 21 ? [7, 7] : [7, 28 - i];
const BR_WIN = 3000, BR_ROUNDS = 30, BR_START = 1000, BR_GO = 150;
const brWorth = (s, p) => s.cash[p] + BR_T.reduce((a, t, i) => a + (s.own[i] === p ? t.pr : 0), 0);
const brGroupFull = (s, g, p) => BR_T.every((t, i) => t.g !== g || s.own[i] === p);
function brRent(s, i, die) {
  const t = BR_T[i], o = s.own[i];
  if (t.k === 'p') return Math.round(t.pr * .2) * (brGroupFull(s, t.g, o) ? 2 : 1);
  if (t.k === 'tr') { const n = BR_T.filter((x, j) => x.k === 'tr' && s.own[j] === o).length; return 50 * Math.pow(2, n - 1); }
  return 15 * (die || 1);
}
function brPay(s, from, amt, to) {
  while (s.cash[from] < amt) { let best = -1; BR_T.forEach((t, i) => { if (s.own[i] === from && (best < 0 || t.pr < BR_T[best].pr)) best = i; }); if (best < 0) break; s.own[best] = -1; s.cash[from] += BR_T[best].pr; s.log = BR_T[best].n + ' was sold to pay a debt'; }
  if (s.cash[from] < amt) { if (to != null) s.cash[to] += Math.max(0, s.cash[from]); s.cash[from] = 0; s.winner = 1 - from; s.log = (from === 0 ? 'Player 1' : 'Player 2') + ' went bankrupt!'; return false; }
  s.cash[from] -= amt; if (to != null) s.cash[to] += amt; return true;
}
const BR_CARDS = [
  { t: '🎁 Birthday! Collect $50 from your rival', f: (s, p) => { brPay(s, 1 - p, 50, p); } },
  { t: '💰 Tax refund: +$100', f: (s, p) => { s.cash[p] += 100; } },
  { t: '🔧 Repairs: pay $80', f: (s, p) => { brPay(s, p, 80, null); } },
  { t: '🏁 Advance to START: +$150', f: (s, p) => { s.pos[p] = 0; s.cash[p] += BR_GO; } },
  { t: '⛓ Go straight to JAIL!', f: (s, p) => { s.pos[p] = 14; s.jail[p] = 1; } },
  { t: '🍀 Lottery win: +$120', f: (s, p) => { s.cash[p] += 120; } },
  { t: '🚓 Speeding fine: pay $60', f: (s, p) => { brPay(s, p, 60, null); } },
  { t: '🤝 Donate $40 to your rival', f: (s, p) => { brPay(s, p, 40, 1 - p); } }
];
function brEnd(s, seat) {
  if (s.winner != null) return;
  for (const p of [seat, 1 - seat]) if (brWorth(s, p) >= BR_WIN) { s.winner = p; s.log = (p === 0 ? 'Player 1' : 'Player 2') + ' reached $' + BR_WIN + '!'; return; }
  if (seat === 1) s.round--;
  if (s.round <= 0) { const a = brWorth(s, 0), b = brWorth(s, 1); s.winner = a === b ? 'draw' : (a > b ? 0 : 1); return; }
  s.turn = 1 - seat; s.phase = 'roll'; s.offer = null;
}
function brLand(s, seat) {
  const i = s.pos[seat], t = BR_T[i]; s.ev = null; s.log = '';
  if (t.k === 'p' || t.k === 'tr' || t.k === 'ut') {
    if (s.own[i] < 0) { if (s.cash[seat] >= t.pr) { s.phase = 'buy'; s.offer = { t: i, price: t.pr }; s.log = 'Buy ' + t.n + ' for $' + t.pr + '?'; return; } s.log = 'Not enough cash to buy ' + t.n; }
    else if (s.own[i] !== seat) { const r = brRent(s, i, s.die); s.log = 'Paid $' + r + ' rent for ' + t.n; s.ev = { k: 'rent', v: r }; brPay(s, seat, r, s.own[i]); }
    else s.log = 'Your own property: ' + t.n;
  } else if (t.k === 'chance') { const c = BR_CARDS[Math.floor(rng(s.rs + s.n * 53)() * BR_CARDS.length)]; s.log = c.t; s.ev = { k: 'card' }; c.f(s, seat); if (s.winner != null) return; if (s.jail[seat]) s.log += ' (skip next turn)'; }
  else if (t.k === 'jail') { s.jail[seat] = 1; s.log = '⛓ Jailed! You skip your next turn'; s.ev = { k: 'jail' }; }
  else if (t.k === 'auction') {
    const free = BR_T.map((x, j) => (x.k === 'p' && s.own[j] < 0) ? j : -1).filter(j => j >= 0);
    if (free.length) { const j = free[Math.floor(rng(s.rs + s.n * 71)() * free.length)], pr = Math.round(BR_T[j].pr * .6); if (s.cash[seat] >= pr) { s.phase = 'buy'; s.offer = { t: j, price: pr, auc: 1 }; s.log = '🔨 Auction! ' + BR_T[j].n + ' for only $' + pr + '?'; return; } s.log = '🔨 Auction: no cash for a bargain'; }
    else { s.cash[seat] += 50; s.log = '🔨 Auction: nothing to sell, +$50'; }
  } else if (t.k === 'start') { s.log = 'Resting at START'; }
  if (s.winner == null) brEnd(s, seat);
}
const brDie = n => `<div class="brdie" data-n="${n}">${[[.5, .5]].length ? DOM_PIPS[n].map(([x, y]) => `<i style="left:${x * 100}%;top:${y * 100}%"></i>`).join('') : ''}</div>`;
const BR_SVG = `<svg viewBox="0 0 200 190" class="brbld"><polygon points="20,150 100,190 180,150 100,112" fill="#4a4a52"/><polygon points="40,138 100,168 160,138 100,108" fill="#767684"/><polygon points="52,90 100,114 148,90 100,66" fill="#e6dcc0"/><polygon points="52,90 100,114 100,148 52,124" fill="#cdbf98"/><polygon points="100,114 148,90 148,124 100,148" fill="#b8a97f"/><ellipse cx="100" cy="66" rx="40" ry="14" fill="#6d6a5e"/><path d="M62 64 Q100 -4 138 64Z" fill="#c8bb9a"/><path d="M62 64 Q100 -4 100 -2 L100 64Z" fill="#b5a782"/><circle cx="84" cy="30" r="5" fill="#fff"/><g fill="#7ad3c2"><rect x="60" y="102" width="7" height="12"/><rect x="132" y="100" width="7" height="12"/></g><g stroke="#f1ead3" stroke-width="5"><line x1="62" y1="124" x2="62" y2="150"/><line x1="80" y1="133" x2="80" y2="159"/><line x1="120" y1="133" x2="120" y2="159"/><line x1="138" y1="124" x2="138" y2="150"/></g></svg>`;
const G_BANK2 = {
  id: 'bank', name: 'Bankroll', icon: '🏦', type: 'turn', sym: ['🟡', '🔴'],
  desc: 'Roll the die, buy cities, collect rent and reach $3,000 net worth before 30 rounds end. Owning a full colour set doubles the rent!',
  init() { const rs = newSeed(); return { pos: [0, 0], cash: [BR_START, BR_START], own: Array(28).fill(-1), jail: [0, 0], turn: 0, phase: 'roll', offer: null, die: 1, mv: null, round: BR_ROUNDS, log: 'Roll the die to start!', ev: null, winner: null, rs, n: 0 }; },
  status: (s, seat) => s.winner != null ? '' : (s.turn === seat ? (s.phase === 'buy' ? '🏠 Buy it or skip' : '🎲 Your turn: roll the die') : '⏳ Opponent’s turn'),
  move(s, m, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    if (m.a === 'roll' && s.phase === 'roll') {
      s.n++; s.mv = null;
      if (s.jail[seat]) { s.jail[seat] = 0; s.log = '⛓ Stuck in jail this turn…'; s.mv = { jail: 1 }; brEnd(s, seat); return s; }
      const d = 1 + Math.floor(rng(s.rs + s.n * 13 + seat)() * 6), from = s.pos[seat], np = (from + d) % 28; s.die = d; s.mv = { from, d, by: seat };
      if (from + d >= 28) s.cash[seat] += BR_GO; s.pos[seat] = np; brLand(s, seat); return s;
    }
    if (m.a === 'buy' && s.phase === 'buy' && s.offer) {
      const o = s.offer; s.mv = null;
      if (m.y && s.cash[seat] >= o.price) { s.cash[seat] -= o.price; s.own[o.t] = seat; s.log = 'Bought ' + BR_T[o.t].n + ' for $' + o.price; s.ev = { k: 'buy' }; } else s.log = 'Skipped ' + BR_T[o.t].n;
      s.n++; s.offer = null; brEnd(s, seat); return s;
    }
    return null;
  },
  bot(s, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    if (s.phase === 'roll') return { a: 'roll' };
    if (s.phase === 'buy' && s.offer) { const left = s.cash[seat] - s.offer.price; return { a: 'buy', y: left >= 120 || (s.offer.auc && left >= 0) || Math.random() < .25 && left >= 0 }; }
    return null;
  },
  render(el, s, seat, send) {
    if (el.__gs !== s.gid) { el.__gs = s.gid; el.__disp = s.pos.slice(); el.__n = s.n; el.__busy = false; }
    el.__st = s; el.__seat = seat; el.__send = send;
    const draw = () => {
      const S = el.__st, sd = el.__seat, disp = el.__disp, mine = S.turn === sd && S.winner == null && !el.__busy;
      const cells = BR_T.map((t, i) => {
        const [r, c] = BR_POS(i), o = S.own[i], col = t.g != null ? BR_COL[t.g] : '#cfd8e0', here = [0, 1].filter(p => disp[p] === i);
        const tk = here.map(p => `<span class="brtok p${p} ${el.__hop === p ? 'hop' : ''}" style="${here.length > 1 ? (p ? 'right:3px' : 'left:3px') : 'left:50%;margin-left:-8px'}"></span>`).join('');
        let inner;
        if (t.k === 'p') inner = `<div class="pr" style="background:${shade(col, .25)}">$${t.pr}</div><div class="nm" style="background:${col}">${t.n}</div>`;
        else if (t.k === 'tr' || t.k === 'ut') inner = `<div class="nm tr"><b>${t.n}</b><span>${t.ic}</span></div>`;
        else inner = `<div class="nm co"><span>${{ start: '🏁', chance: '❓', jail: '🏢', auction: '🔨' }[t.k]}</span><b>${t.k === 'chance' ? '' : t.n}</b></div>`;
        return `<div class="bkc ${t.k} ${o >= 0 ? 'own' + o : ''}" style="grid-row:${r + 1};grid-column:${c + 1}">${inner}${o >= 0 ? `<i class="obar o${o}"></i>` : ''}${tk}</div>`;
      }).join('');
      const bar = p => `<div class="brpl ${S.turn === p && S.winner == null ? 'act' : ''}"><div class="brav p${p}">${p === sd ? '🙂' : '🤖'}</div><b>${p === sd ? 'You' : 'Rival'}</b><span>$${S.cash[p].toLocaleString()} <em>($${brWorth(S, p).toLocaleString()})</em></span></div>`;
      const offer = S.phase === 'buy' && S.offer ? S.offer : null;
      el.innerHTML = `<div class="brwrap"><div class="brhead"><b>$${BR_WIN.toLocaleString()}</b> net worth to win. Rounds left: <b>${S.round}</b></div>
        <div class="brboard">${cells}<div class="brcenter"><div class="brlog">${esc(S.log || '')}</div>${BR_SVG}<div class="brdiebox ${el.__rolling ? 'rolling' : ''}">${brDie(el.__rolling ? 1 + Math.floor(Math.random() * 6) : (S.die || 1))}</div></div></div>
        <div class="brplayers">${bar(sd)}${bar(1 - sd)}</div>
        <div class="bract">${el.__busy ? '<div class="mut">…</div>' : (S.winner != null ? '' : mine ? (offer ? `<div class="broffer"><b>${esc(BR_T[offer.t].n)}</b> $${offer.price}${offer.auc ? ' <small>(auction price)</small>' : ''}</div><div class="brbtns"><button class="btn" id="bry">🏠 Buy</button><button class="btn sec" id="brn">Skip</button></div>` : `<button class="btn full" id="brr">🎲 Roll the die</button>`) : '<div class="mut">⏳ Opponent’s turn…</div>')}</div></div>`;
      const ry = $('#brr', el); if (ry) ry.onclick = () => { SFX.play('dice'); el.__send({ a: 'roll' }); };
      const by = $('#bry', el); if (by) by.onclick = () => el.__send({ a: 'buy', y: true });
      const bn = $('#brn', el); if (bn) bn.onclick = () => el.__send({ a: 'buy', y: false });
    };
    const fresh = s.n !== el.__n && s.mv && s.mv.from != null;
    if (fresh && !el.__busy) {
      el.__n = s.n; el.__busy = true; el.__rolling = true; draw(); SFX.play('dice');
      setTimeout(() => {
        el.__rolling = false; const p = s.mv.by; let k = 0; const hop = () => {
          if (!el.isConnected) { el.__busy = false; return; }
          if (k < s.mv.d) { el.__disp[p] = (el.__disp[p] + 1) % 28; el.__hop = p; k++; SFX.play(el.__disp[p] === 0 ? 'good' : 'step'); draw(); setTimeout(hop, 230); }
          else { el.__hop = null; el.__disp = el.__st.pos.slice(); el.__busy = false; const e = el.__st.ev; if (e) SFX.play({ rent: 'cash', card: 'good', jail: 'jail', buy: 'coin' }[e.k] || 'pop'); draw(); }
        }; hop();
      }, 650);
      return;
    }
    if (!el.__busy) { if (s.n !== el.__n) { el.__n = s.n; const e = s.ev; if (e) SFX.play({ rent: 'cash', card: 'good', jail: 'jail', buy: 'coin' }[e.k] || 'pop'); } el.__disp = s.pos.slice(); draw(); }
  }
};

/* ================= BLOKO (clear rebuild) ================= */
function bkWhy(s, seat, ori, r, c) {
  const me = seat + 1, cells = bkCells(ori, r, c), first = !s.placed[seat]; let corner = false, startCov = false;
  for (const [y, x] of cells) {
    if (y < 0 || x < 0 || y >= BK_N || x >= BK_N) return '❌ The piece must stay inside the board';
    if (s.g[y * BK_N + x]) return '❌ Those squares are already taken';
    for (const [dy, dx] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && s.g[yy * BK_N + xx] === me) return '❌ Your own pieces can’t touch side-to-side — only corner-to-corner';
    }
    for (const [dy, dx] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && s.g[yy * BK_N + xx] === me) corner = true; }
    if (y === (seat ? BK_N - 1 : 0) && x === (seat ? BK_N - 1 : 0)) startCov = true;
  }
  if (first) return startCov ? null : '❌ Your FIRST piece must cover the glowing START corner';
  return corner ? null : '❌ The piece must touch one of your pieces at a corner';
}
const G_BLOKO3 = Object.assign({}, G_BLOKO2, {
  desc: 'Fill the board with your coloured pieces. Every new piece must touch your own pieces only at a corner (never side-to-side). The player with the fewest unused squares wins!',
  status: (s, seat) => s.winner != null ? '' : (s.turn === seat ? '👉 Your turn' : '⏳ Opponent’s turn'),
  render(el, s, seat, send) {
    let R = el.__bk3;
    const cs = 25, bx = 5, by = 5, col = o => o ? '#4aa3ff' : '#ff4d8d';
    if (!R || el.__sg !== s.gid) {
      if (el.__stop) try { el.__stop(); } catch (e) { } el.__sg = s.gid;
      el.innerHTML = `<div class="bk3"><div class="bk3rule" id="bkrule"></div><div class="bk3ban" id="bkban"></div><canvas class="cv" id="bkcv" width="${BK_N * cs + 10}" height="${BK_N * cs + 10}" style="touch-action:none"></canvas><div class="bk3sc" id="bksc"></div><div class="bk3shelf" id="bkshelf"></div><div class="bk3btns" id="bkbtns"></div></div>`;
      R = el.__bk3 = { s, seat, sel: -1, ori: 0, at: null, t: 0, hint: !(window.__bkSeen), n: s.n };
      const cv = $('#bkcv', el), c = cv.getContext('2d');
      const ghost = () => { if (R.sel < 0 || !R.at) return null; const o = BK_ORI[R.sel][R.ori], r = clamp(R.at.r - Math.floor(o.length / 2), 0, BK_N - o.length), cc = clamp(R.at.c - Math.floor(o[0].length / 2), 0, BK_N - o[0].length); return { o, r, c: cc, why: bkWhy(R.s, R.seat, o, r, cc) }; };
      const mineT = () => R.s.turn === R.seat && R.s.winner == null;
      const move = e => { if (R.sel < 0 || !mineT()) return; const p = ptr(cv, e); R.at = { r: Math.floor((p.y - by - 38) / cs), c: Math.floor((p.x - bx) / cs) }; R.at.r = clamp(R.at.r, 0, BK_N - 1); R.at.c = clamp(R.at.c, 0, BK_N - 1); ui(); };
      let down = false; cv.addEventListener('pointerdown', e => { down = true; try { cv.setPointerCapture(e.pointerId); } catch (x) { } move(e); e.preventDefault(); }); cv.addEventListener('pointermove', e => { if (down) move(e); }); cv.addEventListener('pointerup', () => { down = false; });
      const rot = () => { if (R.sel < 0) return; const L = BK_ORI[R.sel], q = bkRot(L[R.ori]), k = L.findIndex(x => JSON.stringify(x) === JSON.stringify(q)); R.ori = k < 0 ? 0 : k; SFX.play('slide'); ui(); };
      const flip = () => { if (R.sel < 0) return; const L = BK_ORI[R.sel], q = bkFlip(L[R.ori]), k = L.findIndex(x => JSON.stringify(x) === JSON.stringify(q)); R.ori = k < 0 ? R.ori : k; SFX.play('slide'); ui(); };
      const place = () => { const gh = ghost(); if (!mineT()) return; if (!gh) { SFX.play('bad'); return; } if (gh.why) { SFX.play('bad'); return; } const p = R.sel; R.sel = -1; R.at = null; SFX.play('place'); send({ p, o: R.ori, r: gh.r, c: gh.c }); };
      R.place = place;
      const ui = () => {
        const S = R.s, mine = mineT(), gh = ghost(), me = R.seat;
        const rule = $('#bkrule', el); rule.innerHTML = R.hint ? `<div class="bk3how"><b>How to play</b><ol><li>Pick a piece from the shelf.</li><li>Drag your finger on the board to move it. <b>Green = OK, red = not allowed.</b></li><li>Rule: your pieces may touch each other <b>only at corners</b>, never sides.</li><li>Press <b>PLACE</b>. Fewest unused squares at the end wins!</li></ol><button class="btn sm" id="bkgot">Got it ✔</button></div>` : `<button class="bk3q" id="bkq">❓ Rules</button>`;
        const g1 = $('#bkgot', el); if (g1) g1.onclick = () => { R.hint = false; window.__bkSeen = 1; ui(); }; const q = $('#bkq', el); if (q) q.onclick = () => { R.hint = true; ui(); };
        $('#bkban', el).innerHTML = S.winner != null ? (S.winner === me ? '🏆 You win!' : S.winner === 'draw' ? '🤝 Draw' : '😅 You lose') : !mine ? '⏳ Opponent is thinking…' : R.sel < 0 ? (S.placed[me] ? '① Pick a piece from the shelf below' : '① Pick a piece — your first one must cover the glowing START corner') : !gh ? '' : (gh.why || '✅ Looks good — press PLACE');
        $('#bkban', el).className = 'bk3ban ' + (mine && gh ? (gh.why ? 'bad' : 'ok') : '');
        $('#bksc', el).innerHTML = [me, 1 - me].map(o => `<span class="${S.turn === o && S.winner == null ? 'act' : ''}" style="border-color:${col(o)}"><i style="background:${col(o)}"></i>${o === me ? 'You' : 'Rival'}: <b>${bkLeft(S, o)}</b> squares left</span>`).join('');
        $('#bkshelf', el).innerHTML = BK_PIECES.map((p, i) => S.used[me][i] ? '' : `<button class="bkp2 ${R.sel === i ? 'sel' : ''}" data-p="${i}"><div class="mini" style="grid-template-columns:repeat(${BK_ORI[i][R.sel === i ? R.ori : 0][0].length},10px)">${BK_ORI[i][R.sel === i ? R.ori : 0].map(row => row.map(v => `<i style="background:${v ? col(me) : 'transparent'}"></i>`).join('')).join('')}</div></button>`).reverse().join('');
        bindAll($('#bkshelf', el), '[data-p]', b => { if (!mineT()) return; R.sel = +b.dataset.p; R.ori = 0; R.at = { r: Math.floor(BK_N / 2), c: Math.floor(BK_N / 2) }; SFX.play('pop'); ui(); });
        $('#bkbtns', el).innerHTML = `<button class="btn sec" id="bkr" ${R.sel < 0 ? 'disabled' : ''}>↻ Rotate</button><button class="btn sec" id="bkf" ${R.sel < 0 ? 'disabled' : ''}>⇋ Flip</button><button class="btn" id="bkok" ${mine && gh && !gh.why ? '' : 'disabled'}>✔ PLACE</button>`;
        $('#bkr', el).onclick = rot; $('#bkf', el).onclick = flip; $('#bkok', el).onclick = place;
      };
      R.ui = ui;
      R.stop = anim(dt => {
        R.t += dt; const S = R.s, gh = ghost(), me = R.seat, mine = mineT();
        c.fillStyle = '#0a1230'; c.fillRect(0, 0, cv.width, cv.height);
        for (let r = 0; r < BK_N; r++) for (let q = 0; q < BK_N; q++) { const v = S.g[r * BK_N + q]; if (v) tile(c, bx + q * cs, by + r * cs, cs, col(v - 1)); else { c.fillStyle = (r + q) % 2 ? '#e8eef8' : '#d9e3f3'; c.fillRect(bx + q * cs + .5, by + r * cs + .5, cs - 1, cs - 1); } }
        [[0, 0], [BK_N - 1, BK_N - 1]].forEach(([r, q], o) => { if (!S.placed[o] && !S.g[r * BK_N + q]) { const pu = .5 + .5 * Math.sin(R.t * 5); c.strokeStyle = col(o); c.lineWidth = 3; c.globalAlpha = o === me ? .6 + pu * .4 : .5; c.strokeRect(bx + q * cs + 2, by + r * cs + 2, cs - 4, cs - 4); c.fillStyle = col(o); c.globalAlpha = .25 + .2 * pu; c.fillRect(bx + q * cs + 2, by + r * cs + 2, cs - 4, cs - 4); c.globalAlpha = 1; if (o === me) tx(c, 'START', bx + q * cs + cs / 2 + (o ? -26 : 26), by + r * cs + cs / 2 + (o ? -22 : 22), 11, '#fff', 'center', '#000'); } });
        if (mine && S.placed[me] && R.sel >= 0) { c.fillStyle = col(me); for (let r = 0; r < BK_N; r++) for (let q = 0; q < BK_N; q++) { if (S.g[r * BK_N + q]) continue; let diag = false, side = false; for (const [dy, dx] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { const yy = r + dy, xx = q + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && S.g[yy * BK_N + xx] === me + 1) diag = true; } for (const [dy, dx] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) { const yy = r + dy, xx = q + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && S.g[yy * BK_N + xx] === me + 1) side = true; } if (diag && !side) { c.globalAlpha = .35 + .25 * Math.sin(R.t * 4); c.beginPath(); c.arc(bx + q * cs + cs / 2, by + r * cs + cs / 2, 5, 0, 6.283); c.fill(); c.globalAlpha = 1; } } }
        if (gh && mine) bkCells(gh.o, gh.r, gh.c).forEach(([y, x]) => { c.fillStyle = gh.why ? '#ff4d4dcc' : '#3ddc97cc'; c.fillRect(bx + x * cs, by + y * cs, cs, cs); c.strokeStyle = '#fff'; c.lineWidth = 2; c.strokeRect(bx + x * cs + 1, by + y * cs + 1, cs - 2, cs - 2); });
      });
      el.__stop = R.stop; ui();
    }
    const ch = s.n !== R.s.n || s.turn !== R.s.turn || s.winner !== R.s.winner; R.s = s; R.seat = seat; if (ch) { if (s.n !== R.n) { R.n = s.n; } R.ui(); }
  }
});
