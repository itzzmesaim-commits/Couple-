/* Playmates - Brawlbots: turn-based artillery robots in an ice cave */
const BRW = { W: 360, H: 470, G: 410, R: 16, g: 520 };
const BR_W = [{ n: 'Missile', ic: '🚀', dmg: 38, rad: 42 }, { n: 'Bomb', ic: '💣', dmg: 70, rad: 72 }, { n: 'Shield', ic: '🛡' }, { n: 'Jump', ic: '⤴' }];
const BTH = [
  { s0: '#0b5f86', s1: '#2ac0d8', s2: '#8be9f2', w: '#16547c', e: '#baf4ff', g0: '#3cc7e8', g1: '#0e6f93', ic: '#cffaff', p0: '#d9fbff', p1: '#47c8e6', p2: '#16739a', ic2: '#a8f1ff' },   // ice
  { s0: '#c2571a', s1: '#f5a04a', s2: '#ffe0a0', w: '#7a3a12', e: '#ffe9b0', g0: '#e8b867', g1: '#a8651f', ic: '#f6d28a', p0: '#f7dba0', p1: '#d89a4a', p2: '#8a4e1a', ic2: '#e9b86a' },   // desert
  { s0: '#2a0a0a', s1: '#8a1f0f', s2: '#ff7a2a', w: '#3a1010', e: '#ffb05a', g0: '#ff6a1a', g1: '#7a1200', ic: '#ffd27a', p0: '#6a5a58', p1: '#3a2a2a', p2: '#1a0e0e', ic2: '#ff8a3a' },   // volcano
  { s0: '#1c6b3a', s1: '#5fc27a', s2: '#d6f5b8', w: '#1a4a26', e: '#b6f08a', g0: '#4a9a3a', g1: '#245a1c', ic: '#c8f09a', p0: '#9be070', p1: '#4a9a3a', p2: '#2a5a20', ic2: '#7ac85a' },   // forest
  { s0: '#070722', s1: '#2a1a5a', s2: '#7a3a9a', w: '#14143a', e: '#7af0ff', g0: '#2a3aa0', g1: '#0a0a3a', ic: '#7af0ff', p0: '#7a6aff', p1: '#3a2aa0', p2: '#14104a', ic2: '#ff5ad0' },   // night city
  { s0: '#ff7ab8', s1: '#ffb0d8', s2: '#fff0c8', w: '#a0386a', e: '#fff', g0: '#ff9ad0', g1: '#c0407a', ic: '#fff', p0: '#fff0f8', p1: '#ff8ac0', p2: '#b03a7a', ic2: '#ffd0e8' },   // candy
  { s0: '#ff8a4a', s1: '#ffc27a', s2: '#7ad6e8', w: '#9a4a2a', e: '#ffe8b0', g0: '#2a9ac0', g1: '#0a5a80', ic: '#e8fcff', p0: '#fff2c8', p1: '#e8a860', p2: '#9a5a2a', ic2: '#cdeff7' }    // beach sunset
];
const brwTh = S => BTH[(Math.imul(Math.floor(S.gid || 0) | 0, 2654435761) >>> 11) % BTH.length];
function brwMap(seed) {
  const R = rng(seed), j = () => (R() - .5) * 26;
  const P = [{ x: 18 + j(), y: 310 + j(), w: 66 }, { x: 276 + j(), y: 310 + j(), w: 66 }, { x: 112 + j(), y: 345 + j() / 2, w: 52 }, { x: 196 + j(), y: 345 + j() / 2, w: 52 }, { x: 140 + j(), y: 255 + j(), w: 80 }, { x: 40 + j(), y: 205 + j(), w: 60 }, { x: 260 + j(), y: 205 + j(), w: 60 }, { x: 150, y: 150 + j(), w: 60 }];
  return P.map(p => ({ x: Math.round(p.x), y: Math.round(p.y), w: p.w, h: 14 }));
}
function brwSim(s, seat, w, ang, pow) {
  const me = s.pos[seat], foe = s.pos[1 - seat], pl = brwMap(s.map), isJump = w === 3;
  const v0 = isJump ? 110 + pow * 300 : 130 + pow * 400; let x = me.x, y = me.y - BRW.R, vx = Math.cos(ang) * v0, vy = Math.sin(ang) * v0; const path = [[Math.round(x), Math.round(y)]], dt = 1 / 60;
  for (let i = 1; i < 420; i++) {
    const px = x, py = y; vy += BRW.g * dt; x += vx * dt; y += vy * dt;
    if (isJump) {
      // body (feet = y+R)
      let feet = y + BRW.R, landed = false;
      if (x < 16) { x = 16; vx = 0; } if (x > BRW.W - 16) { x = BRW.W - 16; vx = 0; }
      for (const p of pl) { if (x > p.x - 8 && x < p.x + p.w + 8) { if (vy > 0 && py + BRW.R <= p.y + 2 && feet >= p.y) { y = p.y - BRW.R; landed = true; break; } if (vy < 0 && py - BRW.R >= p.y + p.h - 2 && y - BRW.R <= p.y + p.h) { y = p.y + p.h + BRW.R; vy = 0; } } }
      if (!landed && feet >= BRW.G) { y = BRW.G - BRW.R; landed = true; }
      if (Math.hypot(x - foe.x, y - (foe.y - BRW.R)) < BRW.R * 2 - 4) { x = px; y = py; landed = true; }
      if (i % 3 === 0) path.push([Math.round(x), Math.round(y)]);
      if (landed) return { path, end: { x: Math.round(x), y: Math.round(y + BRW.R) }, jump: 1 };
      continue;
    }
    let hit = null;
    if (x < 4 || x > BRW.W - 4) hit = [Math.max(4, Math.min(BRW.W - 4, x)), y];
    else if (y >= BRW.G) hit = [x, BRW.G];
    else if (y < -200) { return { path, end: null, miss: 1 }; }
    if (!hit) for (const p of pl) if (x > p.x - 2 && x < p.x + p.w + 2 && y > p.y - 2 && y < p.y + p.h + 2) { hit = [px, py]; break; }
    if (!hit && i > 8 && Math.hypot(x - me.x, y - (me.y - BRW.R)) < BRW.R + 2) hit = [x, y];
    if (!hit && Math.hypot(x - foe.x, y - (foe.y - BRW.R)) < BRW.R + 3) hit = [x, y];
    if (i % 3 === 0) path.push([Math.round(x), Math.round(y)]);
    if (hit) { path.push([Math.round(hit[0]), Math.round(hit[1])]); return { path, end: { x: Math.round(hit[0]), y: Math.round(hit[1]) } }; }
  }
  return { path, end: null, miss: 1 };
}
function brwDmg(s, w, ex) { const W = BR_W[w], d = [0, 0]; [0, 1].forEach(p => { const dist = Math.hypot(s.pos[p].x - ex.x, s.pos[p].y - BRW.R - ex.y); if (dist < W.rad + BRW.R) d[p] = Math.max(6, Math.round(W.dmg * (1 - Math.max(0, dist - 8) / (W.rad + BRW.R)))); }); return d; }
const G_BRAWL = {
  id: 'brawl', name: 'Brawlbots', icon: '🤖', type: 'turn', sym: ['🟢', '🟠'],
  desc: 'Drag to aim, then FIRE! Missiles are unlimited, bombs hit hard, shields block one hit and Jump moves your bot. Reduce the rival to 0 HP.',
  init() { const map = newSeed(); return { map, pos: [{ x: 40, y: BRW.G }, { x: 320, y: BRW.G }], hp: [140, 140], sh: [0, 0], ammo: [[999, 2, 2, 999], [999, 2, 2, 999]], turn: 0, winner: null, last: null, n: 0 }; },
  status: (s, seat) => s.winner != null ? '' : (s.turn === seat ? '🎯 Your turn: aim and fire' : '⏳ Opponent is aiming'),
  move(s, m, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    const w = m.w | 0; if (w < 0 || w > 3 || s.ammo[seat][w] <= 0) return null;
    const foe = 1 - seat;
    if (w === 2) { s.sh[seat] = 1; s.ammo[seat][2]--; s.last = { by: seat, w, n: s.n + 1 }; }
    else {
      const ang = Math.max(-Math.PI, Math.min(Math.PI, +m.ang || 0)), pow = Math.max(.12, Math.min(1, +m.pow || .5)), r = brwSim(s, seat, w, ang, pow);
      if (w === 1) s.ammo[seat][1]--;
      if (w === 3) { s.pos[seat] = r.end; s.last = { by: seat, w, path: r.path, n: s.n + 1 }; }
      else {
        const L = { by: seat, w, path: r.path, n: s.n + 1, ex: r.end, d: [0, 0] };
        if (r.end) { const d = brwDmg(s, w, r.end); [0, 1].forEach(p => { if (d[p]) { if (s.sh[p]) { s.sh[p] = 0; L.blk = (L.blk || 0) | (1 << p); d[p] = 0; } else s.hp[p] = Math.max(0, s.hp[p] - d[p]); } }); L.d = d; }
        s.last = L;
      }
    }
    s.n++; if (s.hp[0] <= 0 && s.hp[1] <= 0) s.winner = 'draw'; else if (s.hp[foe] <= 0) s.winner = seat; else if (s.hp[seat] <= 0) s.winner = foe; else if (s.n >= 70) s.winner = s.hp[0] === s.hp[1] ? 'draw' : (s.hp[0] > s.hp[1] ? 0 : 1);
    if (s.winner == null) s.turn = foe; return s;
  },
  bot(s, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    const foe = 1 - seat, face = s.pos[foe].x > s.pos[seat].x ? 1 : -1; let best = null, bs = -1e9;
    if (s.hp[seat] < 55 && !s.sh[seat] && s.ammo[seat][2] > 0 && Math.random() < .65) return { w: 2 };
    for (const w of [0, 1]) { if (s.ammo[seat][w] <= 0) continue; for (let a = 8; a <= 85; a += 4) for (let p = .3; p <= 1.001; p += .07) {
      const ang = face > 0 ? -a * Math.PI / 180 : -Math.PI + a * Math.PI / 180, r = brwSim(s, seat, w, ang, p); if (!r.end) continue;
      const d = brwDmg(s, w, r.end), sc = d[foe] * (w === 1 ? .8 : 1) - d[seat] * 1.6 + Math.random() * 4 - Math.hypot(r.end.x - s.pos[foe].x, r.end.y - s.pos[foe].y) * .02; if (sc > bs) { bs = sc; best = { w, ang: ang + (Math.random() - .5) * .16, pow: Math.max(.15, Math.min(1, p + (Math.random() - .5) * .16)) }; } } }
    if (best && bs > 6) return best;
    // reposition with a jump toward the foe, or a wild missile
    if (Math.random() < .55) { let bj = null, bd = 1e9; for (let k = 0; k < 14; k++) { const a = face > 0 ? -(25 + Math.random() * 50) * Math.PI / 180 : -Math.PI + (25 + Math.random() * 50) * Math.PI / 180, p = .3 + Math.random() * .7, r = brwSim(s, seat, 3, a, p); const d = Math.abs(r.end.x - s.pos[foe].x) + Math.abs(r.end.y - s.pos[foe].y) * .6; if (d < bd) { bd = d; bj = { w: 3, ang: a, pow: p }; } } if (bj) return bj; }
    return best || { w: 0, ang: face > 0 ? -.8 : -Math.PI + .8, pow: .4 + Math.random() * .6 };
  },
  render(el, s, seat, send) {
    let R = el.__brw;
    if (!R || el.__sg !== s.gid) {
      if (el.__stop) try { el.__stop(); } catch (e) { } el.__sg = s.gid;
      el.innerHTML = `<canvas class="cv" id="bwcv" width="${BRW.W}" height="${BRW.H}" style="touch-action:none"></canvas><div class="bwbar" id="bwbar"></div>`;
      const cv = $('#bwcv', el), c = cv.getContext('2d');
      R = el.__brw = { s, seat, w: 0, ang: null, pow: .6, aiming: false, t: 0, n: s.n, view: { pos: clone(s.pos), hp: s.hp.slice(), sh: s.sh.slice() }, an: null, parts: [], pops: popups() };
      const mineT = () => R.s.turn === R.seat && R.s.winner == null && !R.an;
      const aim = e => { if (!mineT() || R.w === 2) return; const p = ptr(cv, e), me = R.view.pos[R.seat], dx = p.x - me.x, dy = p.y - (me.y - BRW.R); const first = R.ang == null; R.ang = Math.atan2(dy, dx); R.pow = clamp(Math.hypot(dx, dy) / 190, .12, 1); if (first && R.ui) R.ui(); };
      cv.addEventListener('pointerdown', e => { R.aiming = true; try { cv.setPointerCapture(e.pointerId); } catch (x) { } aim(e); e.preventDefault(); }); cv.addEventListener('pointermove', e => { if (R.aiming) aim(e); }); cv.addEventListener('pointerup', () => { R.aiming = false; });
      const ui = () => {
        const S = R.s, mine = mineT(), am = S.ammo[R.seat];
        $('#bwbar', el).innerHTML = `<div class="bwweap">${BR_W.map((w, i) => `<button class="bwb ${R.w === i ? 'sel' : ''}" data-w="${i}" ${am[i] <= 0 || !mine ? 'disabled' : ''}><b>${w.ic}</b><small>${w.n}</small>${am[i] < 900 ? `<em>${am[i]}</em>` : '<em>∞</em>'}</button>`).join('')}</div><button class="bwfire" id="bwfire" ${mine && (R.w === 2 || R.ang != null) ? '' : 'disabled'}>🎯 FIRE</button>`;
        bindAll($('#bwbar', el), '[data-w]', b => { R.w = +b.dataset.w; SFX.play('pop'); ui(); });
        $('#bwfire', el).onclick = () => { if (!mineT()) return; const w = R.w; if (w === 2) { SFX.play('shield'); send({ w }); } else { SFX.play(w === 3 ? 'jump' : w === 1 ? 'cannon' : 'missile'); send({ w, ang: R.ang, pow: R.pow }); } R.ang = null; };
      };
      R.ui = ui;
      const start = L => {
        R.an = { L, t: 0, ph: 0 }; if (L.w === 2) { R.an.ph = 2; R.view.sh[L.by] = 1; }
      };
      R.start = start;
      const robot = (p, x, y, face, hp, sh, aimAng, t) => {
        c.save(); c.translate(x, y); c.scale(face, 1);
        if (p === 0) { // tank
          c.fillStyle = '#1b1b1b'; [[-13, -2], [0, -2], [13, -2]].forEach(([wx, wy]) => { c.beginPath(); c.arc(wx, wy - 3, 5.5, 0, 6.283); c.fill(); c.fillStyle = '#d33'; c.beginPath(); c.arc(wx, wy - 3, 2.4, 0, 6.283); c.fill(); c.fillStyle = '#1b1b1b'; });
          const g = c.createLinearGradient(0, -22, 0, -6); g.addColorStop(0, '#9be26a'); g.addColorStop(1, '#4a8f2a'); c.fillStyle = g; rr(c, -18, -20, 36, 14, 5); c.fill(); c.fillStyle = '#ffd54a'; rr(c, -9, -29, 18, 11, 5); c.fill(); c.fillStyle = '#2b2b3a'; c.beginPath(); c.arc(-1, -24, 3.5, 0, 6.283); c.fill();
          c.save(); c.translate(0, -24); c.rotate(aimAng == null ? -.5 : (face > 0 ? aimAng : Math.PI - aimAng)); c.fillStyle = '#555'; rr(c, 0, -3, 22, 6, 2); c.fill(); c.fillStyle = '#d33'; c.fillRect(18, -3.5, 5, 7); c.restore();
        } else { // spider bot
          c.strokeStyle = '#e8e8f0'; c.lineWidth = 3; [[-12, 0, -6], [12, 0, 6]].forEach(([lx, ly, kx]) => { c.beginPath(); c.moveTo(lx * .5, -12); c.lineTo(lx + kx, -3 + Math.sin(t * 3) * .5); c.lineTo(lx + kx * 1.3, 0); c.stroke(); }); c.strokeStyle = '#f2862a'; c.lineWidth = 3; [[-5, 0], [5, 0]].forEach(([lx]) => { c.beginPath(); c.moveTo(lx, -12); c.lineTo(lx * 2.6, -2); c.stroke(); });
          const g = c.createRadialGradient(0, -22, 2, 0, -20, 16); g.addColorStop(0, '#fff'); g.addColorStop(1, '#f2862a'); c.fillStyle = g; c.beginPath(); c.arc(0, -20, 14, 0, 6.283); c.fill(); c.fillStyle = '#1f2a3a'; c.beginPath(); c.arc(0, -21, 8, 0, 6.283); c.fill(); c.fillStyle = '#7fe0ff'; c.beginPath(); c.arc(-2, -23, 2.5, 0, 6.283); c.fill();
          c.save(); c.translate(0, -20); c.rotate(aimAng == null ? -.5 : (face > 0 ? aimAng : Math.PI - aimAng)); c.fillStyle = '#d33'; rr(c, 8, -3, 16, 6, 3); c.fill(); c.restore();
        }
        c.restore();
        if (sh) { c.strokeStyle = '#6fd2ff'; c.lineWidth = 3; c.globalAlpha = .6 + .3 * Math.sin(t * 6); c.beginPath(); c.arc(x, y - 17, 25, 0, 6.283); c.stroke(); c.fillStyle = '#6fd2ff'; c.globalAlpha = .15; c.fill(); c.globalAlpha = 1; }
        c.fillStyle = '#12182a'; rr(c, x - 26, y - 62, 52, 14, 7); c.fill(); c.fillStyle = '#1e2a44'; rr(c, x - 24, y - 60, 48, 10, 5); c.fill(); c.fillStyle = hp > 50 ? (p ? '#ff5a3a' : '#3ab5ff') : '#ff3b3b'; rr(c, x - 24, y - 60, Math.max(4, 48 * hp / 140), 10, 5); c.fill(); tx(c, String(Math.max(0, Math.round(hp))), x, y - 54.5, 10, '#fff', 'center', '#000');
      };
      R.stop = anim(dt => {
        R.t += dt; const S = R.s, V = R.view, T = brwTh(S);
        const bg = c.createLinearGradient(0, 0, 0, BRW.H); bg.addColorStop(0, T.s0); bg.addColorStop(.55, T.s1); bg.addColorStop(1, T.s2); c.fillStyle = bg; c.fillRect(0, 0, BRW.W, BRW.H);
        c.fillStyle = '#ffffff22'; for (let i = 0; i < 6; i++) { c.beginPath(); c.moveTo(i * 70 - 20, 0); c.lineTo(i * 70 + 20, 0); c.lineTo(i * 70 + 4 + Math.sin(i) * 20, 120 + (i % 3) * 30); c.closePath(); c.fill(); }
        c.fillStyle = '#ffffff1c'; c.beginPath(); c.moveTo(0, 330); c.lineTo(90, 200); c.lineTo(170, 300); c.lineTo(250, 170); c.lineTo(360, 310); c.lineTo(360, 410); c.lineTo(0, 410); c.fill();
        c.fillStyle = T.w; c.fillRect(0, 0, 8, BRW.H); c.fillRect(BRW.W - 8, 0, 8, BRW.H);
        c.fillStyle = T.e; c.fillRect(0, BRW.G, BRW.W, 8); const gg = c.createLinearGradient(0, BRW.G + 8, 0, BRW.H); gg.addColorStop(0, T.g0); gg.addColorStop(1, T.g1); c.fillStyle = gg; c.fillRect(0, BRW.G + 8, BRW.W, BRW.H); c.fillStyle = T.ic; for (let i = 0; i < 18; i++) { c.beginPath(); c.moveTo(i * 20 + 2, BRW.G + 8); c.lineTo(i * 20 + 12, BRW.G + 8); c.lineTo(i * 20 + 7, BRW.G + 22 + (i % 3) * 6); c.fill(); }
        brwMap(S.map).forEach(p => { const g = c.createLinearGradient(0, p.y, 0, p.y + p.h); g.addColorStop(0, T.p0); g.addColorStop(.35, T.p1); g.addColorStop(1, T.p2); c.fillStyle = g; rr(c, p.x, p.y, p.w, p.h, 4); c.fill(); c.fillStyle = '#fff'; c.fillRect(p.x + 2, p.y, p.w - 4, 3); c.fillStyle = T.ic2; for (let k = 0; k < p.w / 12; k++) { c.beginPath(); c.moveTo(p.x + 4 + k * 12, p.y + p.h); c.lineTo(p.x + 10 + k * 12, p.y + p.h); c.lineTo(p.x + 7 + k * 12, p.y + p.h + 7 + (k % 2) * 3); c.fill(); } });
        // animation state
        const A = R.an; let proj = null;
        if (A) {
          A.t += dt; const L = A.L;
          if (A.ph === 0) { const idx = A.t * 22; if (L.path && idx < L.path.length - 1) { const i = Math.floor(idx), f = idx - i, a = L.path[i], b = L.path[i + 1]; proj = { x: a[0] + (b[0] - a[0]) * f, y: a[1] + (b[1] - a[1]) * f }; if (L.w === 3) V.pos[L.by] = { x: proj.x, y: proj.y + BRW.R }; }
            else { A.ph = 1; A.t = 0; if (L.w === 3) { V.pos[L.by] = clone(R.s.pos[L.by]); A.ph = 3; A.t = 0; SFX.play('step'); } else if (L.ex) { SFX.play(L.w === 1 ? 'explode' : 'boom'); for (let k = 0; k < 26; k++) R.parts.push({ x: L.ex.x, y: L.ex.y, vx: (Math.random() - .5) * 260, vy: -Math.random() * 220, a: 0, c: k % 3 ? '#ffb02e' : '#fff3a0' }); [0, 1].forEach(p => { if (L.d[p]) R.pops.add('-' + L.d[p], V.pos[p].x, V.pos[p].y - 70, '#ff5252'); else if (L.blk && (L.blk >> p & 1)) R.pops.add('BLOCKED', V.pos[p].x, V.pos[p].y - 70, '#6fd2ff'); }); V.hp = R.s.hp.slice(); V.sh = R.s.sh.slice(); } else { R.pops.add('MISS', 180, 120, '#fff'); A.ph = 3; } } }
          if (A.ph === 1) { const k = A.t / .45; if (L.ex) { c.globalAlpha = Math.max(0, 1 - k); const rad = BR_W[L.w].rad * Math.min(1, k * 2.2); const rg = c.createRadialGradient(L.ex.x, L.ex.y, 2, L.ex.x, L.ex.y, Math.max(3, rad)); rg.addColorStop(0, '#fff'); rg.addColorStop(.4, '#ffb02e'); rg.addColorStop(1, '#ff3b0000'); c.fillStyle = rg; c.beginPath(); c.arc(L.ex.x, L.ex.y, Math.max(3, rad), 0, 6.283); c.fill(); c.globalAlpha = 1; } if (A.t > .7) { A.ph = 3; A.t = 0; } }
          if (A.ph === 2 && A.t > .5) { A.ph = 3; A.t = 0; SFX.play('shield'); }
          if (A.ph === 3 && A.t > .25) { R.an = null; V.pos = clone(R.s.pos); V.hp = R.s.hp.slice(); V.sh = R.s.sh.slice(); if (R.s.winner != null) { } R.ui(); }
        }
        R.parts = R.parts.filter(q => (q.a += dt) < .8); R.parts.forEach(q => { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 500 * dt; c.globalAlpha = 1 - q.a / .8; c.fillStyle = q.c; c.fillRect(q.x, q.y, 4, 4); c.globalAlpha = 1; });
        // preview
        const mine = S.turn === R.seat && S.winner == null && !R.an;
        let myAng = null;
        if (mine && R.ang != null && R.w !== 2) { myAng = R.ang; const r = brwSim({ ...S, pos: V.pos }, R.seat, R.w, R.ang, R.pow); c.fillStyle = '#fff'; r.path.slice(0, 22).forEach((q, i) => { c.globalAlpha = 1 - i / 24; c.beginPath(); c.arc(q[0], q[1], 3.2, 0, 6.283); c.fill(); }); c.globalAlpha = 1; if (r.end && R.w !== 3) { c.strokeStyle = '#ff6b6b88'; c.lineWidth = 2; c.beginPath(); c.arc(r.end.x, r.end.y, 6, 0, 6.283); c.stroke(); } }
        [0, 1].forEach(p => { const ps = V.pos[p], face = V.pos[1 - p].x >= ps.x ? 1 : -1; robot(p, ps.x, ps.y, face, V.hp[p], V.sh[p], p === R.seat ? myAng : (A && A.L.by === p && A.L.w < 2 ? (A.L.path && A.L.path.length > 1 ? Math.atan2(A.L.path[1][1] - A.L.path[0][1], A.L.path[1][0] - A.L.path[0][0]) : null) : null), R.t); });
        tx(c, p0name(R, S), 70, 24, 12, '#fff', 'center', '#000'); tx(c, S.winner != null ? (S.winner === R.seat ? '🏆 VICTORY' : S.winner === 'draw' ? 'DRAW' : '💀 DEFEAT') : (S.turn === R.seat ? 'YOUR TURN' : 'ENEMY TURN'), 180, 24, 16, S.turn === R.seat ? '#7dff9a' : '#ffd54a', 'center', '#000'); tx(c, 'Turn ' + (S.n + 1), 300, 24, 12, '#fff', 'center', '#000');
        if (proj) { c.fillStyle = R.an.L.w === 1 ? '#222' : '#e04040'; c.beginPath(); c.arc(proj.x, proj.y, R.an.L.w === 1 ? 6 : 4.5, 0, 6.283); c.fill(); c.fillStyle = '#ffb02e88'; c.beginPath(); c.arc(proj.x - 3, proj.y + 2, 3, 0, 6.283); c.fill(); }
        R.pops.draw(c, dt);
      });
      el.__stop = R.stop; ui();
    }
    const old = R.s; R.s = s; R.seat = seat;
    if (s.n !== old.n && s.last) { R.start(s.last); } else if (!R.an) R.view = { pos: clone(s.pos), hp: s.hp.slice(), sh: s.sh.slice() };
    R.ui();
  }
};
const p0name = (R, S) => R.seat === 0 ? 'YOU' : 'RIVAL';
