/* Playmates - Dare Duel (18+): a hard steady-hand duel; the loser draws a punishment */
const DD_F = [
  // spicy-but-sweet (10)
  'Give your partner a long, deep kiss for 30 seconds.', 'Take off one piece of clothing of your choice.', 'Kiss your partner softly on the neck, 10 times.',
  'Send your partner a flirty selfie in your best pose.', 'Sit on your partner’s lap and whisper what you love about them.', 'Give your partner a slow, sensual 2-minute massage.',
  'Whisper your dream romantic night idea in your partner’s ear.', 'Let your partner choose where you kiss them: cheek, hand or neck.', 'Slow dance very close with your partner for 1 minute, no talking.',
  'Look into your partner’s eyes and say what you find most attractive about them.',
  // romantic (5)
  'Write “I love you” on your partner’s hand with a kiss.', 'Say 3 things you adore about your partner.', 'Hug your partner for 30 seconds without letting go.', 'Sing one romantic line to your partner.', 'Give your partner a kiss on the forehead and say “mine”.',
  // funny (5)
  'Do your best catwalk across the room.', 'Talk like a robot for the next 2 minutes.', 'Do 10 funny faces in a row.', 'Dance like nobody is watching for 30 seconds.', 'Say “I lost, and I’m your servant” in a dramatic voice.',
  // normal (5)
  'Tell your partner your happiest memory together.', 'Share one secret you never told your partner.', 'Say what you want to do together this year.', 'Give your partner a genuine compliment.', 'Pick the movie for the next movie night.'
];
const DD_M = [
  // spicy-but-sweet (10)
  'Give your partner a slow 30 second kiss.', 'Take off your shirt and flex for 10 seconds.', 'Kiss your partner softly on the neck, 10 times.', 'Send your partner a flirty selfie with your best look.',
  'Hold your partner close and whisper something naughty but sweet.', 'Give your partner a 2-minute massage.', 'Kiss your partner’s hand, then the cheek, then the lips.', 'Tell your partner your favourite thing about their body, politely.',
  'Pull your partner close and slow dance for 1 minute.', 'Whisper your dream romantic date idea in your partner’s ear.',
  // romantic (5)
  'Say “I love you” in 3 different styles.', 'Hug your partner from behind for 30 seconds.', 'Write a 2-line love poem right now.', 'Hold your partner’s hand and say what you promise them.', 'Kiss your partner’s forehead and say “you are my everything”.',
  // caring (5)
  'Make your partner a cup of tea or coffee.', 'Ask your partner how their day really was and listen fully.', 'Give your partner a 1-minute head massage.', 'Tell your partner one thing you will do to make their week easier.', 'Bring your partner a glass of water and a hug.',
  // dares (5)
  'Do 15 push-ups right now.', 'Do a filmy hero entry with a dialogue.', 'Imitate your partner for 1 minute.', 'Call your partner by a funny nickname for the whole night.', 'Hold a plank for 30 seconds.'
];
DD_F.push('Kiss your partner in a deep lip lock.', 'Take off half of your outfit (one or two pieces).', 'Tell your partner what helps you relax and de-stress the most.', 'Tell your partner your favourite way to be romanced.',
  'Write a short love note for your partner and read it aloud.', 'Plan a surprise romantic date and tell your partner the details.', 'Feed your partner a bite of food with your hands, romantically.', 'Dance a slow song with your partner, cheek to cheek.', 'Whisper “I choose you” and give a long hug.',
  'Do 10 jumping jacks while singing a love song.', 'Stand like a statue for 1 minute while your partner tries to make you laugh.', 'Do 10 squats while saying your partner’s name each time.', 'Hold a plank for 1 minute.', 'Do 10 sit-ups with your partner counting out loud.',
  'Tell your partner your favourite childhood memory.', 'Say what you are most grateful for today.', 'Tell your partner your biggest dream.', 'Name 3 things you would do on a perfect holiday together.', 'Say what made you fall for your partner.', 'Share the funniest thing you remember about your partner.');
DD_M.push('Tell your partner your “magic word” — the sweet thing that makes them smile.', 'Kiss your partner for 30 seconds without stopping.', 'Tell your partner which spot on you is the most ticklish or sensitive, and let them kiss it.',
  'Ask your partner how they are feeling and just listen for 2 minutes.', 'Massage your partner’s feet for 2 minutes.', 'Tell your partner one worry of theirs you will help with this week.', 'Make your partner their favourite snack.', 'Give your partner a long forehead kiss and a hug.',
  'Do 10 push-ups while saying “I love you”.', 'Walk like a model across the room.', 'Do a funny dance for 30 seconds.', 'Hold a wall-sit for 1 minute.', 'Do your best movie villain laugh 3 times.',
  'Write your partner a 4-line romantic shayari.', 'Whisper 3 reasons you chose your partner.', 'Hold your partner close, forehead to forehead, for 1 minute.', 'Slow dance in the dark with your partner.', 'Tell your partner your favourite memory of the two of you.');
DD_F.push('Do 10 squats non-stop, then freeze like a statue for 1 minute.',
  'Hold a wall sit for 1 minute while your partner counts.',
  'Hold your breath for 20 seconds while your partner tickles you.',
  'Do 10 jumping jacks, then give your partner a kiss.',
  'Stay completely still for 1 minute while your partner whispers to you.',
  'Tell your partner which kind of kiss you like the most, then show it.',
  'What is your favourite way to relax with your partner?',
  'What is one place you want to travel to together?',
  'What is your favourite memory of the two of you?',
  'What do you want your partner to do more often?',
  'Which of your partner’s habits do you love the most?',
  'Describe your perfect lazy day together.');
DD_M.push('Do 10 push-ups non-stop, then give your partner a kiss.',
  'Hold a plank for 1 minute while your partner counts.',
  'Stay frozen like a statue for 1 minute.',
  'Dance in a funny way for 30 seconds.',
  'Do your best animal imitation for 20 seconds.',
  'Tell your partner which kiss you like the most and show it.',
  'Whisper to your partner what you find most attractive about them.',
  'Let your partner choose where to be kissed: hand, cheek or neck.',
  'Ask your partner what they need from you today and promise to do it.',
  'Tell your partner one worry you have, and ask about theirs.',
  'Plan tomorrow’s dinner together and cook for your partner.',
  'Give your partner a 1 minute foot or hand massage.',
  'Tell your partner what makes you feel most loved by them.');
DD_F.push('Take off half of your outfit, only if you are comfortable (your choice).',
  'Give your partner a long, slow kiss wherever they choose: cheek, hand, neck or lips.',
  'Do a slow, flirty dance for your partner for 1 minute, with your choice of song.',
  'Tell your partner honestly: a passionate night or a cosy cuddle, which do you prefer tonight?',
  'Show your partner your most flirty look and pose for 1 minute.',
  'Stand in your favourite outfit and let your partner admire you for 1 minute.');
DD_M.push('Send your partner a flirty shirtless selfie, only if you choose to.',
  'Whisper your “magic word” in your partner’s ear, the one that makes them blush.',
  'Give your partner a slow 30 second kiss on the neck, your choice of spot.',
  'Give your partner a slow 1 minute back or shoulder massage, your choice of spot.',
  'Tell your partner which part of you is most sensitive or ticklish, and let them kiss it if you choose.',
  'Send your partner a flirty pic in their favourite outfit, only if you choose to.');
const DD_CF = [], DD_CM = [];
const ddList = g => g === 'f' ? (DD_CF.length ? DD_CF : DD_F) : (DD_CM.length ? DD_CM : DD_M);   // your own cards (data/dd_custom) replace the built-in ones when present
const ddHeart = (c, x, y, s, col, rot) => { c.save(); c.translate(x, y); c.rotate(rot || 0); c.fillStyle = col; c.beginPath(); c.moveTo(0, s * .9); c.bezierCurveTo(-s * 1.5, -s * .1, -s * .7, -s * 1.1, 0, -s * .35); c.bezierCurveTo(s * .7, -s * 1.1, s * 1.5, -s * .1, 0, s * .9); c.fill(); c.fillStyle = 'rgba(255,255,255,.4)'; c.beginPath(); c.ellipse(-s * .42, -s * .3, s * .22, s * .13, -.6, 0, 6.283); c.fill(); c.restore(); };
const G_DARE = (() => {
  const g = duel({
    id: 'dareduel', name: 'Punishment', icon: '💞', adult: true, low: false,
    desc: 'Heart Catch! Slide the basket to catch falling hearts, avoid the broken 💔 ones. The winner is safe, the loser draws a punishment (2 skips allowed). Play only with mutual consent.',
    bot: () => 250 + Math.floor(Math.random() * 450),
    play(box, seed, done) {
      const { cv, c } = arena(box, 360, 540), pops = popups(), R = rng(seed + 31);
      let bx = 180, tx0 = 180, lives = 3, score = 0, combo = 0, T = 0, over = false, started = false, items = [], spawn = .6, sparks = [], t = 0, shake = 0;
      const TOT = 45, BW = 46;
      const end = msg => { if (over) return; over = true; SFX.play(lives > 0 ? 'win' : 'buzz'); setTimeout(() => { stop(); fin(box, score, done, msg + ' · ' + score + ' pts'); }, 900); };
      const mv = e => { e.preventDefault(); started = true; tx0 = Math.max(BW / 2, Math.min(360 - BW / 2, ptr(cv, e).x)); };
      cv.addEventListener('pointerdown', e => { try { cv.setPointerCapture(e.pointerId); } catch (x) { } mv(e); });
      cv.addEventListener('pointermove', e => { if (e.buttons || e.pointerType === 'touch') mv(e); });
      const stop = anim(dt => {
        if (!box.isConnected) { stop(); return; }
        t += dt;
        if (started && !over) {
          T += dt; spawn -= dt; const ramp = 1 + T / TOT * 1.1;
          if (spawn <= 0) { const r = R(), k = r < .2 ? 'bad' : r < .3 ? 'gold' : 'heart'; items.push({ k, x: 24 + R() * 312, y: -20, v: (110 + R() * 70) * ramp, rot: R() * 2 - 1, ph: R() * 6 }); spawn = (.55 + R() * .35) / (1 + T / TOT * .8); }
          bx += (tx0 - bx) * Math.min(1, dt * 18);
          items.forEach(o => { o.y += o.v * dt; o.rot += dt * .8; });
          items = items.filter(o => {
            const hit = o.y > 470 && o.y < 505 && Math.abs(o.x - bx) < BW / 2 + 8;
            if (hit) {
              if (o.k === 'bad') { lives--; combo = 0; shake = .35; SFX.play('buzz'); pops.add('💔', o.x, 470, '#ff4a6a'); }
              else { combo++; const p = (o.k === 'gold' ? 30 : 10) * (1 + Math.min(4, Math.floor(combo / 5))); score += p; SFX.play('pop'); for (let i = 0; i < 6; i++) sparks.push({ x: o.x, y: 480, vx: (Math.random() - .5) * 160, vy: -Math.random() * 140, l: .5, c: o.k === 'gold' ? '#ffd54a' : '#ff6aa8' }); pops.add('+' + p, o.x, 460, o.k === 'gold' ? '#ffd54a' : '#fff'); }
              return false;
            }
            if (o.y > 560) { if (o.k !== 'bad') combo = 0; return false; }
            return true;
          });
          if (lives <= 0) end('Out of lives'); else if (T >= TOT) end('Time up');
        }
        shake = Math.max(0, shake - dt);
        c.save(); if (shake > 0) c.translate((Math.random() - .5) * 8, (Math.random() - .5) * 8);
        const bg = c.createLinearGradient(0, 0, 0, 540); bg.addColorStop(0, '#5a1246'); bg.addColorStop(.6, '#2a0b36'); bg.addColorStop(1, '#12061a'); c.fillStyle = bg; c.fillRect(0, 0, 360, 540);
        for (let i = 0; i < 18; i++) { const sx = (i * 67 + 13) % 360, sy = (i * 131 + t * 12 * (1 + i % 3)) % 540; c.globalAlpha = .18 + (i % 4) * .05; ddHeart(c, sx, sy, 4 + i % 4, '#ff7ab8', Math.sin(t + i) * .3); } c.globalAlpha = 1;
        items.forEach(o => { if (o.k === 'bad') { ddHeart(c, o.x, o.y, 15, '#7a3a9a', Math.sin(o.ph + o.rot) * .3); c.strokeStyle = '#ffffff'; c.lineWidth = 2; c.beginPath(); c.moveTo(o.x - 3, o.y - 12); c.lineTo(o.x + 4, o.y - 2); c.lineTo(o.x - 4, o.y + 4); c.lineTo(o.x + 3, o.y + 14); c.stroke(); } else ddHeart(c, o.x, o.y, o.k === 'gold' ? 15 : 14, o.k === 'gold' ? '#ffc933' : '#ff3d7f', Math.sin(o.ph + o.rot) * .3); });
        sparks.forEach(p => { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 300 * dt; p.l -= dt; c.globalAlpha = Math.max(0, p.l * 2); c.fillStyle = p.c; c.beginPath(); c.arc(p.x, p.y, 3, 0, 6.283); c.fill(); }); c.globalAlpha = 1; sparks = sparks.filter(p => p.l > 0);
        const by = 492; c.fillStyle = '#c8873a'; c.beginPath(); c.moveTo(bx - BW / 2 - 6, by - 14); c.lineTo(bx + BW / 2 + 6, by - 14); c.lineTo(bx + BW / 2 - 4, by + 18); c.lineTo(bx - BW / 2 + 4, by + 18); c.closePath(); c.fill(); c.strokeStyle = '#7a4a1a'; c.lineWidth = 2; for (let i = -2; i <= 2; i++) { c.beginPath(); c.moveTo(bx + i * 9, by - 12); c.lineTo(bx + i * 8, by + 16); c.stroke(); } c.fillStyle = '#e6a652'; c.fillRect(bx - BW / 2 - 8, by - 18, BW + 16, 7);
        for (let i = 0; i < 3; i++) ddHeart(c, 24 + i * 26, 24, 9, i < lives ? '#ff3d7f' : '#4a2a4a');
        tx(c, String(score), 180, 30, 22, '#fff', 'center', '#000'); tx(c, '⏱ ' + Math.ceil(Math.max(0, TOT - T)) + 's', 320, 28, 14, '#fff');
        if (combo >= 5) tx(c, 'x' + (1 + Math.min(4, Math.floor(combo / 5))) + ' combo', 180, 54, 12, '#ffd54a');
        if (!started) tx(c, 'Touch and drag to move the basket', 180, 270, 15, '#fff', 'center', '#000');
        pops.draw(c, dt); c.restore();
      });
      return () => { over = true; stop(); };
    }
  });
  const base = g.render, bmove = g.move;
  g.move = function (s, m, seat) {
    if (m.a === 'pun') {
      if (s.winner == null || s.winner === 'draw' || s.pun || seat === s.winner) return null;
      const gg = m.g === 'f' ? 'f' : 'm', n = ddList(gg).length, i = (m.i | 0) < 0 ? -1 : Math.min(n - 1, m.i | 0);
      s.pun = { g: gg, i, n: 1 }; return s;
    }
    if (m.a === 'skip') {   // loser may swap the card twice; the 3rd card must be done, and it is never "lucky"
      if (!s.pun || s.winner == null || s.winner === 'draw' || seat === s.winner || s.pun.i < 0 || s.pun.n >= 3) return null;
      const n = ddList(s.pun.g).length; let i = Math.min(n - 1, Math.max(0, m.i | 0));
      if (n > 1 && i === s.pun.i) i = (i + 1) % n;
      s.pun = { g: s.pun.g, i, n: s.pun.n + 1 }; return s;
    }
    return bmove.call(this, s, m, seat);
  };
  g.render = function (el, s, seat, send) {
    base.call(this, el, s, seat, send);
    if (s.winner == null) return;
    const loser = s.winner === 'draw' ? -1 : 1 - s.winner, div = document.createElement('div'); div.className = 'ddbox';
    if (s.winner === 'draw') div.innerHTML = '<h3>🤝 Draw!</h3><p class="mut">Nobody is punished. Play again!</p>';
    else if (s.pun) {
      const lst = ddList(s.pun.g), left = 3 - s.pun.n, mine = seat === loser;
      if (s.pun.i < 0) div.innerHTML = '<h3>🍀 You are Lucky!</h3><p class="ddc lucky">No punishment this time</p>';
      else div.innerHTML = `<h3>😈 Punishment${mine ? ' for you' : ''}</h3><p class="ddc">${esc(lst[s.pun.i])}</p>` + (mine ? (left > 0 ? `<button class="btn sec full" id="ddsk">⏭ Skip to another punishment (${left} left)</button>` : '<p class="mut">No more skips. You must complete this one! 😈</p>') : '');
    }
    else if (seat === loser) { div.innerHTML = '<h3>😅 You lost!</h3><button class="btn full" id="ddt">🎴 Tap for punishment</button>'; }
    else div.innerHTML = '<h3>🏆 You won!</h3><p class="mut">Waiting for your partner to draw the punishment…</p>';
    el.appendChild(div);
    const sk = $('#ddsk', div); if (sk) sk.onclick = () => { SFX.play('pop'); const n = ddList(s.pun.g).length; send({ a: 'skip', i: Math.floor(Math.random() * n) }); };
    const t = $('#ddt', div); if (t) t.onclick = () => {
      div.innerHTML = '<h3>Choose</h3><button class="btn full" id="ddf">👩 Female</button><button class="btn sec full" id="ddm">👨 Male</button>';
      const pick = gg => { SFX.play('pop'); const lucky = Math.random() < .15; send({ a: 'pun', g: gg, i: lucky ? -1 : Math.floor(Math.random() * ddList(gg).length) }); };
      $('#ddf', div).onclick = () => pick('f'); $('#ddm', div).onclick = () => pick('m');
    };
  };
  return g;
})();
/* Your own extra cards. Put them in data/dd_custom.txt (or dd_custom.json). Easy format: one card per line, starting with "F:" (female) or "M:" (male). JSON {"f":[...],"m":[...]} also works; curly quotes are fixed automatically. */
function ddParse(t) {
  t = String(t || '');
  const add = j => { (j.f || []).forEach(x => { if (typeof x === 'string' && x.trim()) DD_CF.push(x); }); (j.m || []).forEach(x => { if (typeof x === 'string' && x.trim()) DD_CM.push(x); }); };
  try { add(JSON.parse(t)); return; } catch (e) { }   // valid JSON: cards are used exactly as written
  t = t.replace(/[\u201C\u201D]/g, '"').replace(/[\u2018\u2019]/g, "'");
  try { const j = JSON.parse(t.replace(/,(\s*[\]}])/g, '$1')); (j.f || []).forEach(x => { if (typeof x === 'string' && x.trim()) DD_CF.push(x.trim()); }); (j.m || []).forEach(x => { if (typeof x === 'string' && x.trim()) DD_CM.push(x.trim()); }); return; } catch (e) { }
  t.split(/\r?\n/).forEach(l => { l = l.trim(); const m = /(?:^|[\[\s,])([fFmM])\s*[:\-]\s*(.+)$/.exec(l); if (m && !/^["']?[fFmM]["']?\s*:\s*\[?\s*\]?,?$/.test(l)) { const x = m[2].replace(/^["']+|["']*,?\s*$/g, '').trim(); if (x) (m[1].toLowerCase() === 'f' ? DD_CF : DD_CM).push(x); } });
}
['data/dd_custom.txt', 'data/dd_custom.json'].forEach(u => { try { fetch(u).then(r => r.ok ? r.text() : '').then(ddParse).catch(() => { }); } catch (e) { } });
