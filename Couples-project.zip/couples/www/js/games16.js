/* Playmates - Runup 3D: pseudo-3D endless runner level player (replacement for runPlay in games13.js).
   Exports: runPlay3(stage, L, i, finish) -> stop(). Uses RU_LEVELS fields: kind, v, dens, spd, goal, n. */

const RU3 = { W: 360, H: 520, HZ: 176, GY: 452, D: 7.5, LW: 92, FAR: 96, INNER: 184, DEP: 170, SLOT: 16, FH: 32 };
const RU3_FLOORS = [5, 7, 9, 13, 18, 25];

/* ---------- themes (one per level, cycles) ---------- */
const RU3_TH = [
  { sky: ['#3f8fe8', '#7ec3f5', '#cfeeff'], fog: '#cfe6f5', ground: '#464952', road: '#3b3e47', road2: '#42454f', walk: '#bcbfc9', walk2: '#aeb1bc', curb: ['#e8e8ee', '#d9433a'], b: ['#e8836a', '#c9ced9', '#8fa7d6', '#e0b765', '#78b394', '#d98aa6', '#9d8be0', '#d9d2c3'], glass: ['#6fa9d6', '#a9d6f0'], lit: .1, night: 0, sun: [.72, 1, '#fff6c8', '#ffe27a'], cloud: 1 },
  { sky: ['#5f9cf5', '#ffc7a3', '#ffe8cf'], fog: '#ffe1c8', ground: '#4b4a52', road: '#3d3e47', road2: '#45464f', walk: '#c8c0bd', walk2: '#b9b1b0', curb: ['#f2ece8', '#e0553c'], b: ['#f0907a', '#d9cfc8', '#9fb2d8', '#e8c27a', '#86bba0', '#e29ab0', '#a898e4', '#d8c9b4'], glass: ['#86b4d8', '#f3d3b8'], lit: .2, night: 0, sun: [.25, .98, '#fff0c8', '#ffb86a'], cloud: 1 },
  { sky: ['#2b3a8f', '#e8687a', '#ffb36b'], fog: '#ffb893', ground: '#3d3a46', road: '#34353f', road2: '#3b3c47', walk: '#a8a0aa', walk2: '#9b939e', curb: ['#e6dfe6', '#c9453a'], b: ['#c4627a', '#8d86b8', '#d49a6a', '#6f8fb4', '#a8708f', '#c98b5a', '#7a73a8', '#b88a8a'], glass: ['#8a7fb0', '#ffb08a'], lit: .45, night: 0, sun: [.5, 1.0, '#fff2c0', '#ff9a4a'], cloud: 1 },
  { sky: ['#2a9fd6', '#6fd3e8', '#d5f6f2'], fog: '#d0f2ee', ground: '#454a50', road: '#3a3f46', road2: '#41464e', walk: '#c2c8c6', walk2: '#b3b9b7', curb: ['#eef2f0', '#2f9d84'], b: ['#58b9a0', '#d8e0e4', '#7fa0d8', '#e8c46a', '#e08a7a', '#8cc9b0', '#b09ae0', '#cfd8c0'], glass: ['#78b8d4', '#b8e8f0'], lit: .1, night: 0, sun: [.3, .93, '#ffffe0', '#fff0a0'], cloud: 1 },
  { sky: ['#1d2260', '#7a4aa8', '#f08aa0'], fog: '#d89ab4', ground: '#35323f', road: '#2f303b', road2: '#363745', walk: '#928c9e', walk2: '#867f93', curb: ['#d8d0e0', '#b83a5a'], b: ['#8a5a9a', '#5f6ea8', '#b86a8a', '#4a7aa0', '#9a6a7a', '#6a5aa0', '#a86a50', '#7a8aa8'], glass: ['#6a6aa8', '#e898b0'], lit: .55, night: 0, sun: [.78, 1.0, '#ffd6e0', '#ff7aa0'], cloud: 1 },
  { sky: ['#3a2a7a', '#ff6f91', '#ffc27a'], fog: '#f0a898', ground: '#3b3744', road: '#33333e', road2: '#3a3a46', walk: '#a39aa0', walk2: '#968d93', curb: ['#ece4e4', '#d24848'], b: ['#d4627a', '#9a8cc4', '#e0a070', '#7a96c0', '#b8708a', '#d49a5a', '#8478b8', '#c49a98'], glass: ['#9a88b8', '#ffc08a'], lit: .4, night: 0, sun: [.3, 1.0, '#fff4cc', '#ff8a50'], cloud: 1 },
  { sky: ['#050a24', '#10205a', '#24408a'], fog: '#1d2f66', ground: '#262935', road: '#262833', road2: '#2c2f3b', walk: '#6e7284', walk2: '#656979', curb: ['#b0b6c8', '#8a3a4a'], b: ['#3a4a7a', '#4a3a78', '#2f5a7a', '#5a4a6a', '#35508a', '#6a3a5a', '#2f4a6a', '#454f80'], glass: ['#1a2a50', '#3a5a90'], lit: .7, night: 1, sun: [.78, .22, '#ffffff', '#cfe0ff'], cloud: 0 },
  { sky: ['#0b0620', '#35106b', '#c0348f'], fog: '#5a2a7a', ground: '#201a30', road: '#211c32', road2: '#292340', walk: '#5f5680', walk2: '#564e76', curb: ['#a090d0', '#ff4fa8'], b: ['#40206a', '#2a3a7a', '#6a2a7a', '#1f4a7a', '#7a2a5a', '#2a2a6a', '#503a8a', '#2a4a8a'], glass: ['#201650', '#5a3a9a'], lit: .75, night: 1, sun: [.3, .26, '#ffe0ff', '#ff9adf'], cloud: 0 }
];

/* ---------- small helpers ---------- */
function ru3Hash(n) { n = (n ^ 61) ^ (n >>> 16); n = (n + (n << 3)) | 0; n ^= n >>> 4; n = Math.imul(n, 0x27d4eb2d); n ^= n >>> 15; return (n >>> 0) / 4294967296; }
function ru3Off(w, h, K, fn) { const cv = document.createElement('canvas'); cv.width = Math.ceil(w * K); cv.height = Math.ceil(h * K); const g = cv.getContext('2d'); g.scale(K, K); fn(g, w, h); return { cv, w, h }; }
function ru3Mix(a, b, t) { const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16), f = (x, y) => Math.round(x + (y - x) * t); return 'rgb(' + f(pa >> 16, pb >> 16) + ',' + f((pa >> 8) & 255, (pb >> 8) & 255) + ',' + f(pa & 255, pb & 255) + ')'; }
function ru3Heart(c, x, y, s, col) { c.fillStyle = col; c.beginPath(); c.moveTo(x, y + s * .9); c.bezierCurveTo(x - s * 1.5, y - s * .1, x - s * .7, y - s * 1.1, x, y - s * .35); c.bezierCurveTo(x + s * .7, y - s * 1.1, x + s * 1.5, y - s * .1, x, y + s * .9); c.fill(); }

/* ---------- building textures ---------- */
function ru3Tex(K, w, floors, th, seed, kind) {
  const r = rng(seed * 977 + 13), FH = RU3.FH, h = floors * FH, style = Math.floor(r() * 4), col = th.b[Math.floor(r() * th.b.length)], night = th.night;
  const awn = ['#e0453a', '#2f8fe0', '#f2b42a', '#2fae6a', '#a84ae0'][Math.floor(r() * 5)], sign = ['#ff4fa8', '#4fe0ff', '#ffe04f', '#7dff7a', '#ff8a3a'][Math.floor(r() * 5)];
  return ru3Off(w, h, K, g => {
    const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, shade(col, .14)); gr.addColorStop(1, shade(col, -.22 - (night ? .2 : 0))); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    if (style === 3) { g.strokeStyle = 'rgba(0,0,0,.13)'; g.lineWidth = 1; for (let y = 0; y < h; y += 8) { g.beginPath(); g.moveTo(0, y + .5); g.lineTo(w, y + .5); g.stroke(); } }
    const cols = Math.max(2, Math.floor(w / 31)), cw = w / cols;
    for (let f = 0; f < floors; f++) {
      const y0 = h - (f + 1) * FH; // floor band, f=0 is ground
      g.fillStyle = 'rgba(0,0,0,.16)'; g.fillRect(0, y0 + FH - 2, w, 2); g.fillStyle = 'rgba(255,255,255,.07)'; g.fillRect(0, y0, w, 2);
      if (f === 0) { // shopfront
        g.fillStyle = night ? '#10142a' : '#2a2f3c'; g.fillRect(0, y0 + 6, w, FH - 6);
        for (let k = 0; k < cols; k++) { const x0 = k * cw + 4; const lit = r() < .85; const gg = g.createLinearGradient(0, y0 + 9, 0, y0 + FH - 2); gg.addColorStop(0, lit ? '#ffe9a8' : th.glass[1]); gg.addColorStop(1, lit ? '#ffb85a' : th.glass[0]); g.fillStyle = gg; g.fillRect(x0, y0 + 10, cw - 8, FH - 13); g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(x0 + 2, y0 + 10, 3, FH - 13); }
        for (let k = 0; k < cols * 2; k++) { g.fillStyle = k % 2 ? '#fff' : awn; g.fillRect(k * cw / 2, y0 + 2, cw / 2, 8); } g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(0, y0 + 10, w, 2);
        continue;
      }
      if (style === 1 && f % 2 === 1) { // ribbon glass
        const gg = g.createLinearGradient(0, y0 + 6, w, y0 + FH - 6); gg.addColorStop(0, th.glass[0]); gg.addColorStop(.5, th.glass[1]); gg.addColorStop(1, th.glass[0]); g.fillStyle = gg; g.fillRect(3, y0 + 7, w - 6, FH - 14);
        if (night || r() < th.lit) { g.fillStyle = 'rgba(255,214,120,.8)'; for (let k = 0; k < cols; k++) if (r() < (night ? .65 : .3)) g.fillRect(3 + k * cw, y0 + 7, cw - 2, FH - 14); }
        g.fillStyle = 'rgba(255,255,255,.2)'; g.fillRect(3, y0 + 7, w - 6, 3); continue;
      }
      for (let k = 0; k < cols; k++) {
        const x0 = k * cw + (cw - 17) / 2, y1 = y0 + 6, lit = r() < th.lit + (night ? .15 : 0), gg = g.createLinearGradient(0, y1, 0, y1 + 20);
        if (lit) { gg.addColorStop(0, '#ffe7a0'); gg.addColorStop(1, '#ffb450'); } else { gg.addColorStop(0, th.glass[1]); gg.addColorStop(1, th.glass[0]); }
        g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(x0 - 1.5, y1 - 1.5, 20, 23); g.fillStyle = gg; g.fillRect(x0, y1, 17, 20);
        if (!lit) { g.fillStyle = 'rgba(255,255,255,.28)'; g.beginPath(); g.moveTo(x0, y1 + 12); g.lineTo(x0 + 11, y1); g.lineTo(x0 + 17, y1); g.lineTo(x0 + 3, y1 + 20); g.lineTo(x0, y1 + 20); g.fill(); }
        else if (r() < .4) { g.fillStyle = 'rgba(60,30,10,.35)'; g.fillRect(x0 + 5, y1 + 7, 7, 13); }
        g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(x0 + 8, y1, 1.2, 20); g.fillRect(x0, y1 + 9, 17, 1.2);
        g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(x0 - 2, y1 + 21, 21, 2);
        if (style === 2 && f % 2 === 0) { g.fillStyle = 'rgba(30,30,40,.7)'; g.fillRect(x0 - 3, y1 + 14, 23, 2); for (let q = 0; q < 6; q++) g.fillRect(x0 - 3 + q * 4.4, y1 + 14, 1.2, 8); }
      }
    }
    // cornice/parapet
    g.fillStyle = shade(col, .3); g.fillRect(0, 0, w, 5); g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(0, 5, w, 2);
    if (kind === 'fac') { g.fillStyle = 'rgba(0,0,0,.22)'; g.fillRect(0, 0, w, h); }
    if (r() < .55) { const sy = h - FH - 26 - Math.floor(r() * 3) * FH * 2; if (sy > 20) { g.fillStyle = '#111'; g.fillRect(w * .5 - 18, sy, 36, 14); g.fillStyle = sign; g.shadowColor = sign; g.shadowBlur = night ? 8 : 0; g.fillRect(w * .5 - 16, sy + 2, 32, 10); g.shadowBlur = 0; g.fillStyle = 'rgba(255,255,255,.7)'; g.fillRect(w * .5 - 12, sy + 6, 24, 2); } }
  });
}

/* ---------- sprites (built once per run) ---------- */
function ru3Sprites(K, th) {
  const S = {};
  S.gem = []; for (let k = 0; k < 10; k++) S.gem.push(ru3Off(30, 34, K, g => {
    const th_ = k / 10 * Math.PI * 2, cx = 15, cy = 17, R = 12, ring = (a, rad, y) => [cx + Math.sin(a) * rad, y + Math.cos(a) * 2.4];
    g.shadowColor = '#5fe6ff'; g.shadowBlur = 7;
    const faces = []; for (let j = 0; j < 6; j++) { const a = th_ + j * Math.PI / 3, b = a + Math.PI / 3, m = (a + b) / 2; if (Math.cos(m) < -0.05) continue; faces.push({ a, b, m }); }
    faces.sort((p, q) => Math.cos(p.m) - Math.cos(q.m));
    faces.forEach(f => { const lt = .5 + .5 * Math.cos(f.m - .9); const tA = ring(f.a, 6.5, cy - 9), tB = ring(f.b, 6.5, cy - 9), gA = ring(f.a, R, cy - 2), gB = ring(f.b, R, cy - 2);
      g.fillStyle = ru3Mix('#0a6a9a', '#c8fbff', Math.min(1, lt * 1.1)); g.beginPath(); g.moveTo(tA[0], tA[1]); g.lineTo(tB[0], tB[1]); g.lineTo(gB[0], gB[1]); g.lineTo(gA[0], gA[1]); g.closePath(); g.fill();
      g.fillStyle = ru3Mix('#0a4a8a', '#7fe6ff', Math.min(1, lt * .9)); g.beginPath(); g.moveTo(gA[0], gA[1]); g.lineTo(gB[0], gB[1]); g.lineTo(cx, cy + 14); g.closePath(); g.fill(); g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = .7; g.stroke(); });
    g.shadowBlur = 0; g.fillStyle = 'rgba(255,255,255,.75)'; g.beginPath(); g.moveTo(cx - 3, cy - 12); for (let j = 0; j < 6; j++) { const a = th_ + j * Math.PI / 3, p = ring(a, 6.5, cy - 9); g.lineTo(p[0], p[1]); } g.closePath(); g.globalAlpha = .55; g.fill(); g.globalAlpha = 1;
    if (k % 5 === 0) { g.fillStyle = '#fff'; g.beginPath(); g.moveTo(cx - 6, cy - 6); g.lineTo(cx - 4.5, cy - 4); g.lineTo(cx - 2, cy - 6); g.lineTo(cx - 4.5, cy - 8); g.fill(); }
  }));
  S.cone = ru3Off(34, 44, K, g => { g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(17, 40, 15, 4, 0, 0, 6.283); g.fill(); g.fillStyle = '#2b2b32'; rr(g, 3, 34, 28, 7, 2); g.fill(); const gr = g.createLinearGradient(7, 0, 27, 0); gr.addColorStop(0, '#ff9a4a'); gr.addColorStop(.45, '#ff6a1a'); gr.addColorStop(1, '#c84a0a'); g.fillStyle = gr; g.beginPath(); g.moveTo(17, 3); g.lineTo(28, 35); g.lineTo(6, 35); g.closePath(); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.moveTo(13, 14); g.lineTo(21, 14); g.lineTo(23, 21); g.lineTo(11, 21); g.fill(); g.beginPath(); g.moveTo(9.5, 26); g.lineTo(24.5, 26); g.lineTo(26, 31); g.lineTo(8, 31); g.fill(); g.fillStyle = 'rgba(255,255,255,.35)'; g.fillRect(14, 5, 2, 8); });
  S.lamp = ru3Off(70, 150, K, g => { g.fillStyle = '#2c3038'; g.fillRect(8, 140, 12, 6); g.fillStyle = '#4a505c'; g.fillRect(11, 38, 6, 104); g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(11, 38, 1.8, 104); g.strokeStyle = '#4a505c'; g.lineWidth = 5; g.lineCap = 'round'; g.beginPath(); g.moveTo(14, 40); g.quadraticCurveTo(14, 12, 40, 12); g.stroke(); g.fillStyle = '#2c3038'; rr(g, 34, 8, 24, 9, 4); g.fill(); g.fillStyle = th.night || th.lit > .35 ? '#fff4c0' : '#e8ecf0'; rr(g, 38, 15, 17, 4, 2); g.fill(); });
  S.tree = []; for (let v = 0; v < 3; v++) S.tree.push(ru3Off(90, 140, K, g => { g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.ellipse(45, 134, 20, 5, 0, 0, 6.283); g.fill(); g.fillStyle = '#5a3d28'; g.fillRect(41, 70, 8, 64); g.fillStyle = '#3d2918'; g.fillRect(45, 70, 4, 64); const cols = th.night ? ['#17402f', '#1e5a40', '#2a7050'] : v === 2 ? ['#c9543a', '#e07a3a', '#f0a84a'] : ['#2f8a4a', '#3fae5a', '#6ad07a']; [[45, 42, 34], [26, 58, 24], [64, 58, 24], [45, 24, 24], [33, 38, 20], [58, 36, 20]].forEach(([x, y, r], q) => { g.fillStyle = cols[q % 3]; g.beginPath(); g.arc(x, y, r, 0, 6.283); g.fill(); }); g.fillStyle = 'rgba(255,255,255,.18)'; g.beginPath(); g.arc(38, 30, 14, 0, 6.283); g.fill(); }));
  S.tank = ru3Off(46, 60, K, g => { g.fillStyle = '#5a5f6c'; g.fillRect(8, 36, 3, 24); g.fillRect(35, 36, 3, 24); g.fillStyle = '#8a6a4a'; rr(g, 6, 12, 34, 28, 4); g.fill(); g.fillStyle = '#6a4a30'; g.beginPath(); g.moveTo(4, 14); g.lineTo(23, 2); g.lineTo(42, 14); g.fill(); g.fillStyle = 'rgba(0,0,0,.2)'; g.fillRect(6, 24, 34, 2); });
  S.ant = ru3Off(30, 80, K, g => { g.strokeStyle = '#555b68'; g.lineWidth = 2; g.beginPath(); g.moveTo(15, 80); g.lineTo(15, 4); g.moveTo(6, 20); g.lineTo(24, 20); g.moveTo(8, 34); g.lineTo(22, 34); g.moveTo(10, 48); g.lineTo(20, 48); g.stroke(); g.fillStyle = '#ff3a3a'; g.shadowColor = '#ff3a3a'; g.shadowBlur = 6; g.beginPath(); g.arc(15, 4, 3, 0, 6.283); g.fill(); });
  S.bill = ru3Off(80, 70, K, g => { g.fillStyle = '#44474f'; g.fillRect(14, 40, 4, 30); g.fillRect(62, 40, 4, 30); const gr = g.createLinearGradient(0, 4, 0, 42); gr.addColorStop(0, '#ff6aa8'); gr.addColorStop(1, '#ffb04a'); g.fillStyle = '#222'; g.fillRect(4, 2, 72, 42); g.fillStyle = gr; g.fillRect(7, 5, 66, 36); tx(g, 'RUN!', 40, 24, 20, '#fff', 'center', '#00000066'); });
  S.shadow = ru3Off(100, 30, K, g => { const gr = g.createRadialGradient(50, 15, 2, 50, 15, 50); gr.addColorStop(0, 'rgba(0,0,0,.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.save(); g.scale(1, .3); g.fillStyle = gr; g.beginPath(); g.arc(50, 50, 50, 0, 6.283); g.fill(); g.restore(); });
  S.glow = ru3Off(64, 64, K, g => { const gr = g.createRadialGradient(32, 32, 1, 32, 32, 32); gr.addColorStop(0, 'rgba(255,240,190,.9)'); gr.addColorStop(.4, 'rgba(255,220,140,.3)'); gr.addColorStop(1, 'rgba(255,200,100,0)'); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); });
  S.mag = ru3Off(40, 40, K, g => { const gr = g.createRadialGradient(20, 20, 3, 20, 20, 19); gr.addColorStop(0, '#fff7c0'); gr.addColorStop(1, 'rgba(255,200,60,.0)'); g.fillStyle = gr; g.fillRect(0, 0, 40, 40); g.strokeStyle = '#d8dbe4'; g.lineWidth = 9; g.lineCap = 'butt'; g.beginPath(); g.arc(20, 21, 9, Math.PI, 0); g.lineTo(29, 30); g.moveTo(11, 21); g.lineTo(11, 30); g.stroke(); g.fillStyle = '#e8283a'; g.fillRect(6.5, 27, 9, 7); g.fillRect(24.5, 27, 9, 7); g.fillStyle = '#fff'; g.fillRect(6.5, 33, 9, 3); g.fillRect(24.5, 33, 9, 3); });
  S.shield = ru3Off(40, 40, K, g => { const gr = g.createRadialGradient(20, 20, 3, 20, 20, 19); gr.addColorStop(0, '#c0f0ff'); gr.addColorStop(1, 'rgba(80,200,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, 40, 40); g.fillStyle = '#2d8cf0'; g.strokeStyle = '#fff'; g.lineWidth = 2; g.beginPath(); g.moveTo(20, 6); g.lineTo(32, 11); g.quadraticCurveTo(32, 27, 20, 35); g.quadraticCurveTo(8, 27, 8, 11); g.closePath(); g.fill(); g.stroke(); g.fillStyle = 'rgba(255,255,255,.45)'; g.beginPath(); g.moveTo(20, 9); g.lineTo(20, 31); g.quadraticCurveTo(11, 25, 11, 13); g.closePath(); g.fill(); });
  S.cloud = ru3Off(120, 44, K, g => { g.fillStyle = 'rgba(255,255,255,.92)'; [[30, 28, 16], [52, 20, 20], [78, 24, 17], [96, 30, 12], [60, 32, 18]].forEach(([x, y, r]) => { g.beginPath(); g.arc(x, y, r, 0, 6.283); g.fill(); }); g.fillStyle = 'rgba(150,170,210,.25)'; g.fillRect(14, 36, 92, 8); });
  return S;
}

/* static sky layer: gradient + sun/moon + stars */
function ru3Sky(K, th) {
  return ru3Off(RU3.W, RU3.HZ + 40, K, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, RU3.HZ + 10); gr.addColorStop(0, th.sky[0]); gr.addColorStop(.55, th.sky[1]); gr.addColorStop(1, th.sky[2]); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    if (th.night) { const r = rng(7); g.fillStyle = '#fff'; for (let i = 0; i < 60; i++) { g.globalAlpha = .3 + r() * .7; g.fillRect(r() * w, r() * (RU3.HZ - 40), 1.4, 1.4); } g.globalAlpha = 1; }
    const sx = 40 + th.sun[0] * 280, sy = RU3.HZ - 20 - th.sun[1] * 130, rg = g.createRadialGradient(sx, sy, 4, sx, sy, 110); rg.addColorStop(0, th.night ? 'rgba(200,220,255,.5)' : 'rgba(255,240,200,.85)'); rg.addColorStop(1, 'rgba(255,240,200,0)'); g.fillStyle = rg; g.fillRect(0, 0, w, h);
    const sg = g.createRadialGradient(sx - 6, sy - 6, 2, sx, sy, th.night ? 17 : 26); sg.addColorStop(0, th.sun[2]); sg.addColorStop(1, th.sun[3]); g.fillStyle = sg; g.beginPath(); g.arc(sx, sy, th.night ? 17 : 26, 0, 6.283); g.fill();
    if (th.night) { g.fillStyle = 'rgba(30,50,110,.35)'; g.beginPath(); g.arc(sx + 6, sy - 3, 15, 0, 6.283); g.fill(); }
  });
}
/* distant skyline strip (wraps horizontally, W=720) */
function ru3Skyline(K, th, layer) {
  const W = 720, H = 120 - layer * 20, r = rng(31 + layer * 17);
  return ru3Off(W, H, K, g => {
    const col = ru3Mix(th.fog, th.night ? '#0a1030' : th.b[2 + layer], layer ? .38 : .18);
    let x = -20; while (x < W) {
      const w = 26 + r() * 40, h = 30 + r() * (H - 36), draw = xx => { g.fillStyle = col; g.fillRect(xx, H - h, w, h); if (r() < .5) g.fillRect(xx + w * .3, H - h - 10, 4, 10); g.fillStyle = th.night ? 'rgba(255,214,120,.55)' : 'rgba(255,255,255,.18)'; for (let yy = H - h + 6; yy < H - 6; yy += 9) for (let xx2 = xx + 4; xx2 < xx + w - 5; xx2 += 8) if (r() < (th.night ? .35 : .22)) g.fillRect(xx2, yy, 3, 4); };
      const st = r(); draw(x); if (x + w > W) draw(x - W); x += w + 2 + r() * 8; void st;
    }
  });
}
function ru3Vig(K) { return ru3Off(RU3.W, RU3.H, K, (g, w, h) => { const gr = g.createRadialGradient(w / 2, h * .52, h * .38, w / 2, h * .52, h * .78); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,12,.38)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); }); }

/* ---------- the runner character (rear view) ---------- */
function ru3Runner(c, x, y, o) {
  // o: ph (run phase), air (0..1), crouch (0..1), lean (rad), alpha, t, dead(0..1)
  const ph = o.ph, air = o.air, cr = o.crouch, bob = air > .5 ? 0 : -Math.abs(Math.sin(ph)) * 3.2 * (1 - cr);
  c.save(); c.translate(x, y); if (o.dead) { c.rotate(o.dead * 1.35); c.translate(0, o.dead * 8); } c.translate(0, -48); c.rotate(o.lean); c.translate(0, 48); c.globalAlpha *= o.alpha;
  const hipY = -46 + cr * 22 + bob, shY = -82 + cr * 34 + bob, headY = -97 + cr * 40 + bob + (air > .5 ? -1 : 0);
  const pants = '#2a3a6e', pantsD = '#1d2850', hood = '#ffc21a', hoodD = '#e39a0c', hoodL = '#ffe27a', skin = '#f2b08a';
  // legs
  const leg = (sg) => {
    const p = ph + (sg > 0 ? 0 : Math.PI), sw = Math.sin(p), lift = Math.max(0, sw), fwd = Math.max(0, -sw);
    let fx = sg * 9, fy = -lift * 22 * (1 - cr) + fwd * 0, kx = sg * (10 + lift * 2), ky = (hipY + fy) / 2 - lift * 3;
    if (air > 0) { const afy = sg > 0 ? -30 : -17, afx = sg * 10; fx += (afx - fx) * air; fy += (afy - fy) * air; kx += (sg * 13 - kx) * air; ky += ((hipY + afy) / 2 - 3 - ky) * air; }
    if (cr > 0) { fx += (sg * 11 - fx) * cr; fy += (-3 - fy) * cr; kx += (sg * 16 - kx) * cr; ky += (hipY + (-3 - hipY) * .45 - ky) * cr; }
    c.lineCap = 'round'; c.lineJoin = 'round';
    c.strokeStyle = sg > 0 ? pants : pantsD; c.lineWidth = 11; c.beginPath(); c.moveTo(sg * 8, hipY); c.lineTo(kx, ky); c.stroke(); c.lineWidth = 9.5; c.beginPath(); c.moveTo(kx, ky); c.lineTo(fx, fy - 5); c.stroke();
    // shoe (sole visible when lifted)
    const soleVis = Math.max(lift, air * .6 * (sg > 0 ? 1 : .5)) * (1 - cr);
    c.save(); c.translate(fx, fy); c.fillStyle = '#f4f4f8'; rr(c, -7.5, -6, 15, 10 - soleVis * 2, 4); c.fill(); c.fillStyle = soleVis > .3 ? '#e8283a' : '#c8c8d4'; rr(c, -8, soleVis > .3 ? -7 : 1.5, 16, soleVis > .3 ? 6 : 3, 2.5); c.fill(); c.restore();
  };
  leg(-1); leg(1);
  // torso (hoodie) with backpack
  const sx = Math.sin(ph) * 1.4 * (1 - cr);
  c.save(); c.translate(sx, 0);
  c.fillStyle = hoodD; rr(c, -17, hipY - 12, 34, 14, 6); c.fill();
  const tg = c.createLinearGradient(-20, 0, 20, 0); tg.addColorStop(0, hoodD); tg.addColorStop(.35, hood); tg.addColorStop(.7, hood); tg.addColorStop(1, hoodD); c.fillStyle = tg; c.beginPath(); c.moveTo(-14, hipY - 2); c.quadraticCurveTo(-19, (hipY + shY) / 2, -19, shY + 6); c.quadraticCurveTo(-18, shY - 2, -10, shY - 1); c.lineTo(10, shY - 1); c.quadraticCurveTo(18, shY - 2, 19, shY + 6); c.quadraticCurveTo(19, (hipY + shY) / 2, 14, hipY - 2); c.closePath(); c.fill();
  c.fillStyle = hoodL; c.globalAlpha *= .5; c.beginPath(); c.ellipse(-9, (hipY + shY) / 2 - 2, 3, (hipY - shY) / 2.6, 0, 0, 6.283); c.fill(); c.globalAlpha = o.alpha;
  // hood bump
  c.fillStyle = hoodD; c.beginPath(); c.ellipse(0, shY - 1, 12, 6, 0, 0, 6.283); c.fill(); c.fillStyle = '#c47c08'; c.beginPath(); c.ellipse(0, shY - 1, 7, 3, 0, 0, 6.283); c.fill();
  // backpack
  const bpH = 26 - cr * 4, bpY = shY + 4;
  c.fillStyle = '#e8453a'; rr(c, -11, bpY, 22, bpH, 6); c.fill(); c.fillStyle = '#b8281e'; rr(c, -11, bpY + bpH * .55, 22, bpH * .45, 5); c.fill(); c.fillStyle = '#ff8a7a'; rr(c, -8, bpY + 2, 6, bpH * .5, 3); c.fill(); c.fillStyle = '#ffd04a'; rr(c, -5, bpY + bpH * .6, 10, 3, 1.5); c.fill(); c.strokeStyle = '#7a1a12'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(-11, bpY + 7); c.lineTo(11, bpY + 7); c.stroke();
  c.restore();
  // arms
  const arm = (sg) => {
    const p = ph + (sg > 0 ? Math.PI : 0), a = Math.sin(p);
    let hx = sg * (25 + a * 3), hy = shY + 22 + a * 11, ex = sg * 27, ey = shY + 12 + a * 3;
    if (air > 0) { hx += (sg * 28 - hx) * air; hy += (shY - 10 - hy) * air; ex += (sg * 26 - ex) * air; ey += (shY + 2 - ey) * air; }
    if (cr > 0) { hx += (sg * 20 - hx) * cr; hy += (shY + 16 - hy) * cr; ex += (sg * 25 - ex) * cr; ey += (shY + 10 - ey) * cr; }
    c.lineCap = 'round'; c.strokeStyle = hoodD; c.lineWidth = 10; c.beginPath(); c.moveTo(sg * 17, shY + 4); c.lineTo(ex + sx, ey); c.lineTo(hx + sx, hy); c.stroke(); c.strokeStyle = hood; c.lineWidth = 7; c.beginPath(); c.moveTo(sg * 17, shY + 4); c.lineTo(ex + sx, ey); c.lineTo(hx + sx, hy - 2); c.stroke(); c.fillStyle = skin; c.beginPath(); c.arc(hx + sx, hy + 3, 4.6, 0, 6.283); c.fill();
  };
  arm(-1); arm(1);
  // head
  const hxo = sx * .6; c.fillStyle = skin; rr(c, hxo - 4, headY + 6, 8, 8, 3); c.fill();
  c.fillStyle = '#4a2d1c'; c.beginPath(); c.ellipse(hxo, headY + 2, 11.5, 12, 0, 0, 6.283); c.fill(); c.fillStyle = '#6a4228'; c.beginPath(); c.ellipse(hxo - 3, headY - 1, 6, 7, -.4, 0, 6.283); c.fill();
  c.fillStyle = skin; c.beginPath(); c.arc(hxo - 11.5, headY + 4, 2.6, 0, 6.283); c.arc(hxo + 11.5, headY + 4, 2.6, 0, 6.283); c.fill();
  // cap (worn backwards)
  c.fillStyle = '#2d7be5'; c.beginPath(); c.ellipse(hxo, headY - 3, 12.5, 10, 0, Math.PI, 0); c.lineTo(hxo + 12.5, headY - 2); c.quadraticCurveTo(hxo, headY + 3, hxo - 12.5, headY - 2); c.closePath(); c.fill(); c.fillStyle = '#5aa2ff'; c.beginPath(); c.ellipse(hxo - 3, headY - 8, 5, 2.6, -.3, 0, 6.283); c.fill();
  c.fillStyle = '#1f5cb8'; rr(c, hxo - 6, headY - 2.5, 12, 4, 2); c.fill(); c.fillStyle = '#ffd04a'; c.fillRect(hxo - 1.5, headY - 2, 3, 2.5);
  c.fillStyle = '#2d7be5'; c.beginPath(); c.arc(hxo, headY - 12.5, 2, 0, 6.283); c.fill();
  c.restore();
}

/* ============================================================== */
function runPlay3(stage, L, lv, finish) {
  const W = RU3.W, H = RU3.H, HZ = RU3.HZ, GY = RU3.GY, D = RU3.D, LW = RU3.LW, FAR = RU3.FAR, INNER = RU3.INNER, DEP = RU3.DEP, SLOT = RU3.SLOT;
  const K = Math.max(1, Math.min(2, window.devicePixelRatio || 1)), th = RU3_TH[(lv || 0) % RU3_TH.length], R = rng(newSeed());
  stage.innerHTML = '';
  const cv = document.createElement('canvas'); cv.width = Math.round(W * K); cv.height = Math.round(H * K); cv.className = 'cv'; cv.style.touchAction = 'none'; cv.style.margin = '0 auto'; stage.appendChild(cv);
  const c = cv.getContext('2d'); c.scale(K, K);
  const hint = document.createElement('div'); hint.className = 'mut'; hint.style.cssText = 'text-align:center;font-size:12px;margin-top:4px'; hint.textContent = '👆 Swipe ← → to change lane · ↑ jump · ↓ slide'; stage.appendChild(hint);

  /* assets */
  const SP = ru3Sprites(K, th), SKY = ru3Sky(K, th), SK1 = ru3Skyline(K, th, 0), SK2 = ru3Skyline(K, th, 1), VIG = ru3Vig(K);
  const WT = [], FT = []; RU3_FLOORS.forEach((fl, i) => { for (let v = 0; v < 2; v++) { WT.push(ru3Tex(K, 160, fl, th, i * 5 + v + (lv || 0) * 31, 'wall')); FT.push(ru3Tex(K, DEP, fl, th, i * 5 + v + (lv || 0) * 31, 'fac')); } });
  const haze = c.createLinearGradient(0, HZ - 60, 0, HZ + 62); const fogC = th.fog; haze.addColorStop(0, fogC + '00'); haze.addColorStop(.45, fogC + 'dd'); haze.addColorStop(.62, fogC + 'cc'); haze.addColorStop(1, fogC + '00');
  const CARC = ['#d93a2e', '#2f6fe0', '#f2c230', '#e9ecf2', '#2e9d5b', '#2a2d36', '#ff8a2a', '#8a4ae0'];

  /* state */
  let lane = 0, lx = 0, jy = 0, vy = 0, slideT = 0, slideQ = false, jbuf = 0, crouch = 0, airK = 0, dist = 0, speed = 0, hearts = 3, gems = 0, jumps = 0, slides = 0, score = 0, inv = 0, t = 0, ph = 0;
  let st = 'run', over = false, stopped = false, finished = false, objs = [], genZ = 36, lastPat = '', powerAt = 230, shake = 0, flashR = 0, slowK = 0, magT = 0, shieldOn = 0, endT = 0, winT = 0, deadK = 0, lastLane = 0, dustT = 0, banner = null, pops = [], parts = [], itemsA = [], clouds = [];
  for (let i = 0; i < 4; i++) clouds.push({ x: R() * 480 - 60, y: 22 + R() * 70, s: .6 + R() * .7, v: 3 + R() * 5 });
  let camX = 0, cs1 = 0, cs2 = 0, ch1 = 0, ch2 = 0, PS = 1, PX = 180, PY = GY;
  const curvK = .55 + .07 * Math.min(7, lv || 0);

  /* camera / projection (fills PS, PX, PY for relative depth z) */
  const frameBase = () => { cs1 = Math.sin(dist * .0155); cs2 = Math.sin(dist * .0071 + 1.3); ch1 = Math.sin(dist * .0123 + .7); ch2 = Math.sin(dist * .0051 + 2.1); };
  const proj = z => { if (z < -D + 1.5) z = -D + 1.5; const s = D / (D + z), a = dist + z; PS = s; const cu = curvK * (330 * (Math.sin(a * .0155) - cs1) + 160 * (Math.sin(a * .0071 + 1.3) - cs2)); const hl = 150 * (Math.sin(a * .0123 + .7) - ch1) + 90 * (Math.sin(a * .0051 + 2.1) - ch2); PX = 180 + (cu - camX) * s; PY = HZ + (GY - HZ) * s - hl * s * .8; };
  const fogA = z => z > FAR - 28 ? Math.max(0, (FAR - z) / 28) : 1;

  /* ---------- level generation ---------- */
  const kind = L.kind, dens = L.dens || 1, idx = lv || 0;
  const add = (k, ln, z, extra) => { const o = Object.assign({ k, lane: ln, z }, extra || {}); objs.push(o); return o; };
  const gemLine = (ln, z0, n, gy, sp) => { for (let i = 0; i < n; i++) add('gem', ln, z0 + i * (sp || 2.3), { y: gy || 0, ph: R() * 8 }); };
  const gemArc = (ln, zc, n, hmax) => { for (let i = 0; i < n; i++) { const u = n > 1 ? i / (n - 1) : .5; add('gem', ln, zc + (u - .5) * (n - 1) * 1.7, { y: Math.sin(u * Math.PI) * hmax, ph: R() * 8 }); } };
  const pickLanes = n => { const a = [-1, 0, 1]; for (let i = 2; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a.slice(0, n); };
  const carSpec = () => { const van = R() < .28; return { col: CARC[Math.floor(R() * CARC.length)], van, len: van ? 5.4 : 4.3, h: van ? 70 : 58 }; };
  const patterns = () => {
    const w = [['gems', (kind === 'gems' || kind === 'coins') ? 6 : 3], ['hurdle', kind === 'jump' ? 8 : 3], ['beam', kind === 'slide' ? 8 : 2], ['cone', 2], ['car', 2.4 * Math.min(1.5, dens)], ['arc', (kind === 'gems' || kind === 'coins') ? 2.5 : 1.2], ['combo', idx >= 2 ? 2 : 0], ['train', idx >= 4 ? 2.6 : 0], ['wave', 1.5]];
    let tot = 0; w.forEach(p => { if (p[0] === lastPat && p[0] !== 'gems') p[1] *= .15; tot += p[1]; }); let r = R() * tot; for (const p of w) { if ((r -= p[1]) <= 0) return p[0]; } return 'gems';
  };
  const genSeg = () => {
    const z = genZ, p = patterns(); lastPat = p; let len = 8;
    if (p === 'gems') { const ln = Math.floor(Math.random() * 3) - 1, n = 7 + Math.floor(R() * 5); gemLine(ln, z, n, R() < .15 ? 0 : 0); len = n * 2.3; }
    else if (p === 'wave') { let ln = Math.floor(Math.random() * 3) - 1, zz = z; for (let k = 0; k < 3; k++) { gemLine(ln, zz, 4, 0, 2.2); zz += 4 * 2.2 + 1; const nl = ln + (R() < .5 ? -1 : 1); ln = Math.max(-1, Math.min(1, nl === ln ? ln - 1 : nl)); } len = zz - z; }
    else if (p === 'hurdle') { const n = 1 + Math.floor(R() * (dens > 1.2 ? 3 : 2)), ls = pickLanes(n); ls.forEach(l => add('hurdle', l, z + 6, { len: 1.4, h: 44 })); const free = [-1, 0, 1].filter(l => !ls.includes(l)); if (free.length) gemLine(free[0], z + 1, 6, 0); gemArc(ls[0], z + 6, 5, 78); len = 12; }
    else if (p === 'arc') { const ln = Math.floor(Math.random() * 3) - 1; const h = add('hurdle', ln, z + 7, { len: 1.4, h: 44 }); void h; gemArc(ln, z + 7, 7, 82); len = 14; }
    else if (p === 'beam') { add('beam', 9, z + 6, { len: 1.3 }); gemLine(Math.floor(Math.random() * 3) - 1, z + 3, 5, 0, 1.6); len = 12; }
    else if (p === 'cone') { const n = R() < .5 ? 1 : 2, ls = pickLanes(n); ls.forEach(l => { add('cone', l, z + 5, { len: .8, h: 34 }); if (R() < .6) add('cone', l, z + 7.2, { len: .8, h: 34 }); }); const fr = [-1, 0, 1].filter(l => !ls.includes(l)); gemLine(fr[0], z, 6, 0); len = 11; }
    else if (p === 'car') { const n = R() < .3 ? 2 : 1, ls = pickLanes(n); ls.forEach(l => { const s = carSpec(); add('car', l, z + 6, s); }); const fr = [-1, 0, 1].filter(l => !ls.includes(l)); gemLine(fr[Math.floor(R() * fr.length)], z + 1, 7, 0); len = 14; }
    else if (p === 'combo') { const cl = Math.floor(Math.random() * 3) - 1; add('car', cl, z + 6, carSpec()); [-1, 0, 1].filter(l => l !== cl).forEach(l => add('hurdle', l, z + 7, { len: 1.4, h: 44 })); gemArc(cl === 0 ? -1 : 0, z + 7, 5, 78); len = 13; }
    else if (p === 'train') { const tl = Math.floor(Math.random() * 3) - 1; add('train', tl, z + 38, { len: 18, h: 128, vz: 5.5, col: ['#d9433a', '#2f78d8', '#e8a31e', '#2e9d6a'][Math.floor(R() * 4)] }); [-1, 0, 1].filter(l => l !== tl).forEach((l, q) => gemLine(l, z + 12 + q * 4, 6, 0, 2.4)); len = 40; }
    const spE = L.spd * .62 + Math.min(3, genZ / 400), rest = Math.max(7, (spE * .62 + 3) / Math.pow(dens, .5));
    genZ += len + rest;
    if (genZ > powerAt) { powerAt = genZ + 220 + R() * 120; add(R() < .5 ? 'mag' : 'shield', Math.floor(Math.random() * 3) - 1, genZ, { y: 30 }); genZ += 8; }
  };

  /* ---------- fx helpers ---------- */
  const pop = (txt, x, y, col, big) => pops.push({ t: txt, x, y, col: col || '#ffd54a', age: 0, big });
  const burst = (x, y, n, cols, sp, g) => { for (let i = 0; i < n && parts.length < 140; i++) { const a = R() * 6.283, v = (.3 + R() * .7) * sp; parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - sp * .3, life: 0, max: .4 + R() * .4, col: cols[i % cols.length], r: 1.5 + R() * 2.4, g: g == null ? 300 : g }); } };

  /* ---------- actions ---------- */
  const goalNow = () => (kind === 'gems' || kind === 'coins') ? gems >= L.v : kind === 'dist' ? dist >= L.v : kind === 'time' ? t >= L.v : kind === 'jump' ? jumps >= L.v : slides >= L.v;
  const prog = () => (kind === 'gems' || kind === 'coins') ? gems : kind === 'dist' ? Math.floor(dist) : kind === 'time' ? Math.floor(t) : kind === 'jump' ? jumps : slides;
  const doJump = () => { jy = .01; vy = 590; slideT = 0; slideQ = false; jbuf = 0; try { SFX.play('jump'); } catch (e) { } burst(180 + (lx * LW - camX), GY, 6, ['#d8d8e0', '#aaa'], 80, 100); };
  const act = k => {
    if (st !== 'run') return;
    if (k === 'l') { if (lane > -1) { lastLane = lane; lane--; try { SFX.play('slide'); } catch (e) { } } }
    else if (k === 'r') { if (lane < 1) { lastLane = lane; lane++; try { SFX.play('slide'); } catch (e) { } } }
    else if (k === 'u') { if (jy <= 0.5 && vy <= 0) doJump(); else jbuf = .16; }
    else if (k === 'd') { if (jy > 0.5) { vy = Math.min(vy, -1000); slideQ = true; } else { slideT = .8; try { SFX.play('whoosh'); } catch (e) { } } }
  };
  // swipe: fires as soon as the finger moves far enough (not only on release)
  let sp0 = null, spId = -1;
  cv.addEventListener('pointerdown', e => { sp0 = ptr(cv, e); spId = e.pointerId; try { cv.setPointerCapture(e.pointerId); } catch (x) { } e.preventDefault(); });
  cv.addEventListener('pointermove', e => { if (!sp0 || e.pointerId !== spId) return; const p = ptr(cv, e), dx = p.x - sp0.x, dy = p.y - sp0.y; if (Math.hypot(dx, dy) > 26) { if (Math.abs(dx) > Math.abs(dy)) act(dx > 0 ? 'r' : 'l'); else act(dy < 0 ? 'u' : 'd'); sp0 = null; } e.preventDefault(); });
  const up = e => { if (e.pointerId === spId) sp0 = null; }; cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  const KM = { ArrowLeft: 'l', ArrowRight: 'r', ArrowUp: 'u', ArrowDown: 'd', a: 'l', A: 'l', d: 'r', D: 'r', w: 'u', W: 'u', s: 'd', S: 'd', ' ': 'u' };
  const keyf = e => { const m = KM[e.key]; if (m) { act(m); if (e.key.startsWith('Arrow') || e.key === ' ') e.preventDefault(); } }; document.addEventListener('keydown', keyf);
  const cleanup = () => { document.removeEventListener('keydown', keyf); };

  const finishNow = (win, msg) => {
    if (finished || stopped) return; finished = true; cleanup();
    const stars = hearts >= 3 ? 3 : hearts === 2 ? 2 : 1; setTimeout(() => { try { stop(); } catch (e) { } }, 0);
    finish({ win, stars: win ? stars : 0, score: score + gems * 10 + Math.floor(dist), msg, info: Math.floor(dist) + ' m · ' + gems + ' gems' });
  };

  const hurt = (o, px) => {
    if (inv > 0) return;
    if (shieldOn > 0) { shieldOn = 0; inv = 1; shake = .2; try { SFX.play('shield'); } catch (e) { } pop('BLOCKED!', px, GY - 130, '#7fe0ff'); burst(px, GY - 50, 18, ['#7fe0ff', '#fff'], 220); return; }
    hearts--; inv = 1.7; shake = .5; flashR = .38; slowK = 1; try { SFX.play('hit'); SFX.play('buzz'); } catch (e) { }
    pop('OUCH!', px, GY - 130, '#ff5252', 1); burst(px, GY - 50, 16, ['#ff8a3a', '#ffd04a', '#ff5252'], 240);
    if (hearts <= 0) { st = 'dead'; endT = 0; }
  };

  /* ---------- update ---------- */
  const update = dt => {
    t += dt; inv = Math.max(0, inv - dt); flashR = Math.max(0, flashR - dt); shake = Math.max(0, shake - dt); slowK = Math.max(0, slowK - dt * .85); jbuf = Math.max(0, jbuf - dt); magT = Math.max(0, magT - dt); shieldOn = Math.max(0, shieldOn - dt);
    const tgt = L.spd * .62 + Math.min(3, dist / 400), ramp = Math.min(1, .3 + t / 1.2);
    let want = tgt * ramp * (1 - .38 * slowK); if (st === 'win') want = Math.max(0, speed - 16 * dt); if (st === 'dead') want = Math.max(0, speed - 40 * dt);
    speed += (want - speed) * Math.min(1, dt * (st === 'run' ? 4 : 6)); if (st !== 'run' && speed < .3) speed = 0;
    dist += speed * dt; ph += dt * speed * .68 * (st === 'dead' ? 0 : 1);
    // lane tween
    lx += (lane - lx) * Math.min(1, dt * 14); if (Math.abs(lane - lx) < .002) lx = lane; camX += (lx * LW * .42 - camX) * Math.min(1, dt * 7);
    // jump / slide
    if (jy > 0 || vy > 0) { vy -= 1900 * dt; jy += vy * dt; if (jy <= 0) { jy = 0; vy = 0; burst(180 + (lx * LW - camX), GY, 8, ['#d0d0d8', '#9a9aa4'], 110, 140); if (slideQ) { slideQ = false; slideT = .8; try { SFX.play('whoosh'); } catch (e) { } } else if (jbuf > 0 && st === 'run') doJump(); } }
    if (slideT > 0) slideT -= dt;
    crouch += ((slideT > 0 ? 1 : 0) - crouch) * Math.min(1, dt * 20); airK += ((jy > 0.5 ? 1 : 0) - airK) * Math.min(1, dt * 16);
    if (jy <= 0.5 && airK < .3 && speed > 4 && st === 'run') { dustT -= dt; if (dustT < 0) { dustT = .09; parts.push({ x: 180 + (lx * LW - camX) + (R() - .5) * 14, y: GY - 2, vx: (R() - .5) * 30, vy: -20 - R() * 20, life: 0, max: .35, col: th.night ? '#4a4e66' : '#bdbdc8', r: 2 + R() * 2, g: -20 }); } }
    while (genZ < dist + FAR + 6) genSeg();
    // move trains
    for (const o of objs) if (o.vz) o.z -= o.vz * dt;
    // magnet
    const px = 180 + (lx * LW - camX);
    for (const o of objs) {
      const zr = o.z - dist;
      if (o.k === 'gem') {
        if (o.got) continue;
        if (magT > 0 && zr < 15 && zr > -1 && st === 'run') { o.lane += (lx - o.lane) * Math.min(1, dt * 9); o.z -= (4 + (15 - zr) * .5) * dt * 1.4; o.y += (40 - o.y) * Math.min(1, dt * 6); }
        if (st === 'run' && zr < 1 && zr > -.9 && Math.abs(o.lane - lx) < .6) { const body = crouch > .5 ? 44 : 104; if (o.y >= jy - 14 && o.y <= jy + body) { o.got = 1; gems++; score += 0; try { SFX.play('coin'); } catch (e) { } burst(px + (o.lane - lx) * LW, GY - 20 - o.y, 8, ['#7fe8ff', '#fff', '#35d4ff'], 150, 220); if (gems % 10 === 0) pop('+' + gems, px, GY - 125, '#7ef0ff'); } }
        continue;
      }
      if (o.k === 'mag' || o.k === 'shield') { if (!o.got && st === 'run' && zr < 1 && zr > -.9 && Math.abs(o.lane - lx) < .65) { o.got = 1; if (o.k === 'mag') { magT = 8; pop('MAGNET!', px, GY - 130, '#ff7a7a', 1); try { SFX.play('good'); } catch (e) { } } else { shieldOn = 12; pop('SHIELD!', px, GY - 130, '#7fe0ff', 1); try { SFX.play('heal'); } catch (e) { } } burst(px, GY - 50, 14, ['#ffd04a', '#fff'], 200); } continue; }
      if (o.done) continue;
      const len = o.len || 1, zFront = zr, zBack = zr + len, solid = o.k === 'car' || o.k === 'train';
      if (zBack < -.4) { if (o.ok && !o.hit) { o.done = 1; if (o.k === 'hurdle') { jumps++; pop('JUMP!', px, GY - 140, '#ffd54a'); } else if (o.k === 'beam') { slides++; pop('SLIDE!', px, GY - 140, '#ffd54a'); } } else o.done = 1; continue; }
      if (zFront > .45 || st !== 'run') continue;
      const lat = o.k === 'beam' || Math.abs(o.lane - lx) < .62; if (!lat) { o.ov = 0; continue; }
      let clear = false;
      if (o.k === 'hurdle' || o.k === 'cone') clear = jy > o.h - 10; else if (o.k === 'beam') clear = crouch > .45 && jy < 10;
      if (clear) { o.ok = 1; continue; }
      if (solid && zFront < -.25 && !o.ov) { // sideswipe: bump back to the previous lane, no damage
        if (lane !== lastLane) { lane = lastLane; } else lane = Math.max(-1, Math.min(1, lane + (lane > o.lane ? 1 : -1))); shake = Math.max(shake, .22); try { SFX.play('buzz'); } catch (e) { } pop('BUMP!', px, GY - 130, '#ffb86a'); burst(px, GY - 40, 6, ['#ffd04a'], 120); o.ov = 1; setTimeout(() => { o.ov = 0; }, 260); continue;
      }
      if (o.ov) continue; o.hit = 1; o.done = 1; hurt(o, px);
    }
    if (objs.length > 200 || (objs.length && objs[0].z < dist - 12)) objs = objs.filter(o => o.z > dist - 12);
    // goal / end states
    if (st === 'run' && goalNow()) { st = 'win'; winT = 0; inv = 99; try { SFX.play('clear'); } catch (e) { } banner = { t: 'LEVEL COMPLETE!', a: 0 }; burst(180, 250, 40, ['#ffd04a', '#7fe8ff', '#ff7aa8', '#7dff7a'], 320, 260); }
    if (st === 'win') { winT += dt; if (winT > 1.25) finishNow(true); }
    if (st === 'dead') { endT += dt; deadK = Math.min(1, endT * 2.2); if (endT > 1.05) finishNow(false, 'You crashed!'); }
    for (const p of pops) p.age += dt; pops = pops.filter(p => p.age < 1.1);
    for (const p of parts) { p.life += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += p.g * dt; } parts = parts.filter(p => p.life < p.max);
    for (const cl of clouds) { cl.x += cl.v * dt; if (cl.x > W + 130) cl.x = -130; }
    if (banner) banner.a += dt;
  };

  /* ---------- drawing primitives ---------- */
  // quad from 4 points
  const quad = (a, b, c2, d) => { c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.lineTo(c2[0], c2[1]); c.lineTo(d[0], d[1]); c.closePath(); };
  let FX = 0, FY = 0, FW = 0, FHh = 0, FS = 1;
  // 3D box: lateral centre xw, half width hw, from height hb to ht, depth z0..z1 (relative), colours front/top/side; leaves front-face rect in FX,FY,FW,FHh
  const box3 = (xw, hw, hb, ht, z0, z1, cf, ct, cs) => {
    if (z1 < -1.8) return false; const za = Math.max(z0, -1.8); proj(za); const s0 = PS, X0 = PX, Y0 = PY; proj(z1); const s1 = PS, X1 = PX, Y1 = PY;
    const xl0 = X0 + (xw - hw) * s0, xr0 = X0 + (xw + hw) * s0, xl1 = X1 + (xw - hw) * s1, xr1 = X1 + (xw + hw) * s1, yb0 = Y0 - hb * s0, yt0 = Y0 - ht * s0, yb1 = Y1 - hb * s1, yt1 = Y1 - ht * s1;
    if (yt0 > HZ + 2 || true) { c.fillStyle = ct; quad([xl0, yt0], [xr0, yt0], [xr1, yt1], [xl1, yt1]); c.fill(); } // top
    if (xl0 > 182) { c.fillStyle = cs; quad([xl0, yt0], [xl1, yt1], [xl1, yb1], [xl0, yb0]); c.fill(); } else if (xr0 < 178) { c.fillStyle = cs; quad([xr0, yt0], [xr1, yt1], [xr1, yb1], [xr0, yb0]); c.fill(); }
    FX = xl0; FY = yt0; FW = xr0 - xl0; FHh = yb0 - yt0; FS = s0; if (z0 >= -1.8) { c.fillStyle = cf; c.fillRect(FX, FY, FW, FHh); }
    return z0 >= -1.8;
  };
  const shadowAt = (xw, hw, z0, z1) => { proj(Math.max(z0, -1.8)); const a = PS, ya = PY, xa = PX; proj(z1); const b = PS, yb = PY; c.globalAlpha *= .5; c.fillStyle = '#000'; quad([xa + (xw - hw) * a, ya], [xa + (xw + hw) * a, ya], [PX + (xw + hw) * b, yb], [PX + (xw - hw) * b, yb]); c.fill(); c.globalAlpha /= .5; };

  /* ---------- object renderers ---------- */
  const drawCar = o => {
    const zr = o.z - dist, hw = o.van ? 38 : 35, xw = o.lane * LW, col = o.col, len = o.len; shadowAt(xw, hw + 3, zr, zr + len);
    const bh = o.van ? 46 : 30; // body height
    if (!o.van) { box3(xw, hw - 6, bh, o.h, zr + 1.1, zr + 3.4, shade(col, -.1), shade(col, .25), shade(col, -.35)); if (FW > 0) { c.fillStyle = th.night ? '#0e1830' : '#1c2a44'; c.fillRect(FX + FW * .08, FY + FHh * .12, FW * .84, FHh * .62); c.fillStyle = 'rgba(180,220,255,.32)'; c.beginPath(); c.moveTo(FX + FW * .1, FY + FHh * .6); c.lineTo(FX + FW * .45, FY + FHh * .12); c.lineTo(FX + FW * .65, FY + FHh * .12); c.lineTo(FX + FW * .3, FY + FHh * .72); c.fill(); } }
    const full = box3(xw, hw, 3, o.van ? o.h : bh, zr, zr + len, col, shade(col, .3), shade(col, -.3)); const s = FS;
    if (full) {
      const x = FX, y = FY, w = FW, h = FHh;
      if (o.van) { c.fillStyle = th.night ? '#0e1830' : '#1c2a44'; c.fillRect(x + w * .1, y + h * .1, w * .8, h * .34); c.fillStyle = 'rgba(180,220,255,.3)'; c.beginPath(); c.moveTo(x + w * .12, y + h * .4); c.lineTo(x + w * .42, y + h * .1); c.lineTo(x + w * .6, y + h * .1); c.lineTo(x + w * .3, y + h * .44); c.fill(); c.fillStyle = 'rgba(0,0,0,.18)'; c.fillRect(x + w * .49, y + h * .5, 1.2 * s, h * .4); }
      c.fillStyle = 'rgba(0,0,0,.22)'; c.fillRect(x, y + h * .8, w, h * .2); // bumper
      c.fillStyle = '#ff2a2a'; if (th.night) { c.shadowColor = '#ff2a2a'; c.shadowBlur = 8 * s; } c.fillRect(x + w * .04, y + h * (o.van ? .5 : .32), w * .2, h * .18); c.fillRect(x + w * .76, y + h * (o.van ? .5 : .32), w * .2, h * .18); c.shadowBlur = 0; c.fillStyle = '#ffd0d0'; c.fillRect(x + w * .06, y + h * (o.van ? .5 : .32), w * .06, h * .05);
      c.fillStyle = '#f2f2f2'; c.fillRect(x + w * .36, y + h * (o.van ? .58 : .42), w * .28, h * .15); c.fillStyle = '#333'; c.fillRect(x + w * .39, y + h * (o.van ? .62 : .46), w * .22, h * .05);
      c.fillStyle = '#15151a'; c.fillRect(x + w * .02, y + h, w * .17, 5 * s); c.fillRect(x + w * .81, y + h, w * .17, 5 * s);
    }
  };
  const drawBarrier = o => {
    const zr = o.z - dist, xw = o.lane * LW, hw = 38; shadowAt(xw, hw + 2, zr, zr + o.len);
    const ok = box3(xw, hw, 0, 44, zr, zr + o.len, '#cfd2d8', '#e6e8ee', '#9a9ea8');
    if (ok) { const x = FX, y = FY, w = FW, h = FHh; c.fillStyle = '#9ea2ac'; c.fillRect(x, y + h * .78, w, h * .22); c.save(); c.beginPath(); c.rect(x, y + h * .06, w, h * .46); c.clip(); c.fillStyle = '#ff7a1a'; c.fillRect(x, y, w, h); c.fillStyle = '#fff'; const sw = w / 7; for (let i = -1; i < 9; i += 2) { c.beginPath(); c.moveTo(x + i * sw, y + h * .52); c.lineTo(x + (i + 1) * sw, y + h * .52); c.lineTo(x + (i + 1) * sw + h * .46, y + h * .06); c.lineTo(x + i * sw + h * .46, y + h * .06); c.fill(); } c.restore(); c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(x, y, w, 2 * FS); c.fillStyle = 'rgba(0,0,0,.18)'; c.fillRect(x, y + h * .52, w, 2 * FS); }
  };
  const drawBeam = o => {
    const zr = o.z - dist; if (zr + 1.3 < -1.6) return; proj(Math.max(zr, -1.6)); const s = PS, cx = PX, y = PY, xl = cx - 150 * s, xr = cx + 150 * s;
    c.globalAlpha *= .5; c.fillStyle = '#000'; c.fillRect(xl, y - 1 * s, xr - xl, 5 * s); c.globalAlpha /= .5;
    const pole = (x) => { c.fillStyle = '#6a707c'; c.fillRect(x - 6 * s, y - 175 * s, 12 * s, 175 * s); c.fillStyle = '#9aa0ac'; c.fillRect(x - 6 * s, y - 175 * s, 4 * s, 175 * s); c.fillStyle = '#3a3e48'; c.fillRect(x - 10 * s, y - 6 * s, 20 * s, 6 * s); };
    pole(xl); pole(xr);
    // sign board (above) + hazard bar (the low part you slide under)
    c.fillStyle = '#1f6a3a'; c.fillRect(xl, y - 168 * s, xr - xl, 56 * s); c.strokeStyle = '#fff'; c.lineWidth = Math.max(1, 2.5 * s); c.strokeRect(xl + 4 * s, y - 164 * s, xr - xl - 8 * s, 48 * s);
    if (s > .16) { tx(c, '▼ SLIDE ▼', cx, y - 140 * s, Math.max(6, 22 * s), '#fff'); }
    c.fillStyle = '#ffc21a'; c.fillRect(xl, y - 108 * s, xr - xl, 40 * s); c.fillStyle = '#222'; const nS = 14, bw = (xr - xl) / nS; for (let i = 0; i < nS; i += 2) { c.beginPath(); c.moveTo(xl + i * bw, y - 68 * s); c.lineTo(xl + (i + 1) * bw, y - 68 * s); c.lineTo(xl + (i + 1) * bw + 14 * s, y - 108 * s); c.lineTo(xl + i * bw + 14 * s, y - 108 * s); c.fill(); }
    c.save(); c.beginPath(); c.rect(xl, y - 108 * s, xr - xl, 40 * s); c.restore(); c.fillStyle = 'rgba(0,0,0,.28)'; c.fillRect(xl, y - 72 * s, xr - xl, 4 * s);
    if (th.lit > .3) { c.fillStyle = '#ff3a3a'; c.shadowColor = '#ff3a3a'; c.shadowBlur = 6 * s; [.25, .5, .75].forEach(f => { c.beginPath(); c.arc(xl + (xr - xl) * f, y - 62 * s, 3 * s, 0, 6.283); c.fill(); }); c.shadowBlur = 0; }
  };
  const drawCone = o => { const zr = o.z - dist; proj(zr); const s = PS, x = PX + o.lane * LW * s; c.drawImage(SP.cone.cv, x - 17 * s * 1.1, PY - 41 * s * 1.1, 34 * s * 1.1, 44 * s * 1.1); };
  const drawTrain = o => {
    const zr = o.z - dist, xw = o.lane * LW, hw = 42, len = o.len, col = o.col; shadowAt(xw, hw + 4, zr, zr + len);
    // chassis skirt
    const ok = box3(xw, hw, 8, o.h, zr, zr + len, shade(col, -.05), shade(col, .35), shade(col, -.3)); const s = FS;
    // side windows + stripe (side face visible for outer lanes)
    const side = o.lane === 0 ? 0 : -Math.sign(o.lane);
    if (side) { for (let k = 0; k < 8; k++) { const za = zr + 1 + k * 2.1, zb = za + 1.3; if (zb < -1.8) continue; proj(Math.max(za, -1.8)); const sa = PS, xa = PX + (xw + side * hw) * sa, ya = PY; proj(zb); const sb = PS, xb = PX + (xw + side * hw) * sb, yb = PY; c.fillStyle = th.night ? '#ffe9a8' : '#bfe3f5'; quad([xa, ya - 100 * sa], [xb, yb - 100 * sb], [xb, yb - 66 * sb], [xa, ya - 66 * sa]); c.fill(); } }
    if (ok) {
      const x = FX, y = FY, w = FW, h = FHh; c.fillStyle = '#fff'; c.fillRect(x, y + h * .5, w, h * .06); c.fillStyle = th.night ? '#16213f' : '#25344e'; rr(c, x + w * .1, y + h * .14, w * .8, h * .3, 5 * s); c.fill(); c.fillStyle = 'rgba(190,225,255,.3)'; c.beginPath(); c.moveTo(x + w * .13, y + h * .4); c.lineTo(x + w * .4, y + h * .15); c.lineTo(x + w * .55, y + h * .15); c.lineTo(x + w * .28, y + h * .42); c.fill();
      c.fillStyle = '#ffd04a'; c.shadowColor = '#fff2a0'; c.shadowBlur = 12 * s; c.beginPath(); c.arc(x + w * .17, y + h * .72, 7 * s, 0, 6.283); c.arc(x + w * .83, y + h * .72, 7 * s, 0, 6.283); c.fill(); c.shadowBlur = 0; c.fillStyle = '#222'; c.fillRect(x + w * .3, y + h * .8, w * .4, h * .1); c.fillStyle = '#ff4a4a'; c.fillRect(x + w * .46, y + h * .02, w * .08, h * .05);
    }
  };
  const drawItem = o => { // power-up
    const zr = o.z - dist; proj(zr); const s = PS, x = PX + o.lane * LW * s, y = PY - (30 + Math.sin(t * 4 + o.z) * 5) * s, im = o.k === 'mag' ? SP.mag : SP.shield, sz = 48 * s; c.drawImage(im.cv, x - sz / 2, y - sz / 2, sz, sz);
  };
  const drawGem = o => { const zr = o.z - dist; proj(zr); const s = PS, x = PX + o.lane * LW * s, y = PY - (22 + o.y) * s, f = SP.gem[Math.floor((t * 9 + o.ph) % 10)], w = 30 * s * 1.05, h = 34 * s * 1.05; c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(x, PY - 1 * s, 9 * s * (1 - o.y / 220), 2.6 * s, 0, 0, 6.283); c.fill(); c.drawImage(f.cv, x - w / 2, y - h / 2, w, h); };

  /* buildings */
  const drawBuilding = (side, n) => {
    const h1 = ru3Hash(n * 2 + (side > 0 ? 1 : 0) + (lv || 0) * 977), v = Math.floor(h1 * WT.length), wt = WT[v], ft = FT[v], hpx = wt.h, wz0 = n * SLOT, zr0 = wz0 - dist, len = 14;
    const zs = Math.max(zr0, -1.6), ze = zr0 + len; if (ze <= zs || zr0 > FAR) return;
    const xi = side * INNER, xo = side * (INNER + DEP), a = fogA(zr0 + 4); if (a <= 0) return; c.globalAlpha = a;
    let z = zs, guard = 0; const tw = wt.w * K, thh = wt.h * K;
    proj(z); let sa = PS, xa = PX + xi * sa, ya = PY;
    while (z < ze - 1e-4 && guard++ < 80) {
      let dz = Math.max(.05, Math.min(2.4, 2.6 * (D + z) * (D + z) / (INNER * D))); const zn = Math.min(ze, z + dz); proj(zn); const sb = PS, xb = PX + xi * sb, yb = PY;
      const u0 = side < 0 ? (z - zr0) / len : (ze - zn) / len, u1 = side < 0 ? (zn - zr0) / len : (ze - z) / len, x0 = Math.min(xa, xb), w = Math.abs(xb - xa) + .8, hm = hpx * (sa + sb) / 2, ym = (ya + yb) / 2;
      if (x0 + w > -2 && x0 < W + 2) c.drawImage(wt.cv, u0 * tw, 0, Math.max(1, (u1 - u0) * tw), thh, x0, ym - hm, w, hm);
      z = zn; sa = sb; xa = xb; ya = yb;
    }
    // roof (visible on low buildings), props
    proj(zs); const s0 = PS, X0 = PX, Y0 = PY; proj(ze); const s1 = PS, X1 = PX, Y1 = PY, ty0 = Y0 - hpx * s0, ty1 = Y1 - hpx * s1;
    if (ty0 > HZ - 4) { c.fillStyle = shade(th.b[v % th.b.length], .1); quad([X0 + xi * s0, ty0], [X0 + xo * s0, ty0], [X1 + xo * s1, ty1], [X1 + xi * s1, ty1]); c.fill(); c.fillStyle = 'rgba(0,0,0,.15)'; quad([X0 + xi * s0, ty0], [X0 + (xi + side * 8) * s0, ty0], [X1 + (xi + side * 8) * s1, ty1], [X1 + xi * s1, ty1]); c.fill(); }
    const pv = Math.floor(ru3Hash(n * 7 + side * 3 + 5) * 5);
    if (pv < 3 && zr0 + 7 > -1) { proj(zr0 + 7); const sp = PS, ps = pv === 0 ? SP.tank : pv === 1 ? SP.ant : SP.bill, bx = PX + (xi + side * 40) * sp, by = PY - hpx * sp; c.drawImage(ps.cv, bx - ps.w * sp / 2 * 1.3, by - ps.h * sp * 1.3 + 3 * sp, ps.w * sp * 1.3, ps.h * sp * 1.3); }
    if (zr0 > -1.4) { proj(zr0); const s = PS, x1 = PX + xi * s, x2 = PX + xo * s; c.drawImage(ft.cv, Math.min(x1, x2), PY - hpx * s, Math.abs(x2 - x1), hpx * s); }
    c.globalAlpha = 1;
  };
  const drawProp = (side, n, isTree) => {
    const zr = n * 24 + (isTree ? 12 : 0) - dist; if (zr < -2 || zr > FAR) return; const a = fogA(zr); if (a <= 0) return; proj(zr); const s = PS; c.globalAlpha = a;
    if (isTree) { const tv = Math.floor(ru3Hash(n * 13 + side + (lv || 0)) * 3), im = SP.tree[tv], sz = 1.0; c.drawImage(im.cv, PX + side * 160 * s - im.w * s * sz / 2, PY - im.h * s * sz + 4 * s, im.w * s * sz, im.h * s * sz); }
    else { const im = SP.lamp, x = PX + side * 150 * s; c.save(); if (side > 0) { c.translate(x, 0); c.scale(-1, 1); c.translate(-x, 0); } c.drawImage(im.cv, x - 14 * s, PY - 146 * s, 70 * s, 150 * s); c.restore(); if (th.lit > .3) { c.globalCompositeOperation = 'lighter'; const gx = x + side * 26 * s, g2 = 70 * s; c.globalAlpha = a * .8; c.drawImage(SP.glow.cv, gx - g2 / 2 + (side > 0 ? 0 : 0), PY - 130 * s - g2 / 2, g2, g2); c.globalCompositeOperation = 'source-over'; } }
    c.globalAlpha = 1;
  };

  /* road */
  const SEGL = 2;
  const drawRoad = () => {
    const mMin = Math.floor((dist - 3) / SEGL), mMax = Math.ceil((dist + FAR + 4) / SEGL), N = mMax - mMin + 1, zs = [], xs = [], ys = [], ss = [];
    for (let k = 0; k <= N; k++) { const z = (mMin + k) * SEGL - dist; proj(z); zs.push(z); xs.push(PX); ys.push(PY); ss.push(PS); }
    const P = {}; const path = (name) => { if (!P[name]) P[name] = new Path2D(); return P[name]; };
    for (let k = N - 1; k >= 0; k--) {
      const m = mMin + k, xa = xs[k], xb = xs[k + 1], ya = ys[k], yb = ys[k + 1], sa = ss[k], sb = ss[k + 1], even = m & 1;
      if (yb > H + 5 && ya > H + 5) continue;
      let p = path(even ? 'r1' : 'r2'); p.moveTo(xa - 138 * sa, ya); p.lineTo(xa + 138 * sa, ya); p.lineTo(xb + 138 * sb, yb); p.lineTo(xb - 138 * sb, yb); p.closePath();
      p = path(even ? 'w1' : 'w2'); p.moveTo(xa - 184 * sa, ya); p.lineTo(xa - 146 * sa, ya); p.lineTo(xb - 146 * sb, yb); p.lineTo(xb - 184 * sb, yb); p.closePath(); p.moveTo(xa + 146 * sa, ya); p.lineTo(xa + 184 * sa, ya); p.lineTo(xb + 184 * sb, yb); p.lineTo(xb + 146 * sb, yb); p.closePath();
      p = path((m >> 1) & 1 ? 'c1' : 'c2'); p.moveTo(xa - 146 * sa, ya); p.lineTo(xa - 138 * sa, ya); p.lineTo(xb - 138 * sb, yb); p.lineTo(xb - 146 * sb, yb); p.closePath(); p.moveTo(xa + 138 * sa, ya); p.lineTo(xa + 146 * sa, ya); p.lineTo(xb + 146 * sb, yb); p.lineTo(xb + 138 * sb, yb); p.closePath();
      p = path('ln'); // edge lines (solid) and lane dashes
      [-130, 130].forEach(e => { p.moveTo(xa + (e - 2.5) * sa, ya); p.lineTo(xa + (e + 2.5) * sa, ya); p.lineTo(xb + (e + 2.5) * sb, yb); p.lineTo(xb + (e - 2.5) * sb, yb); p.closePath(); });
      if (m % 3 === 0) [-46, 46].forEach(e => { p.moveTo(xa + (e - 2.2) * sa, ya); p.lineTo(xa + (e + 2.2) * sa, ya); p.lineTo(xb + (e + 2.2) * sb, yb); p.lineTo(xb + (e - 2.2) * sb, yb); p.closePath(); });
      if (m % 90 < 2) { p = path('zb'); for (let q = -5; q <= 5; q++) { const e = q * 24; p.moveTo(xa + (e - 8) * sa, ya); p.lineTo(xa + (e + 8) * sa, ya); p.lineTo(xb + (e + 8) * sb, yb); p.lineTo(xb + (e - 8) * sb, yb); p.closePath(); } }
    }
    c.fillStyle = th.walk; c.fill(P.w1); c.fillStyle = th.walk2; c.fill(P.w2); c.fillStyle = th.road; c.fill(P.r1); c.fillStyle = th.road2; c.fill(P.r2);
    c.fillStyle = th.curb[0]; c.fill(P.c1); c.fillStyle = th.curb[1]; c.fill(P.c2); c.fillStyle = 'rgba(255,255,255,.82)'; c.fill(P.ln); if (P.zb) { c.fillStyle = 'rgba(255,255,255,.75)'; c.fill(P.zb); }
  };

  const drawLights = () => { // soft light pools at night
    if (!th.night && th.lit < .5) return; c.save(); c.globalCompositeOperation = 'lighter'; c.globalAlpha = th.night ? .16 : .08; c.fillStyle = '#ffd890'; const g = SP.glow; c.drawImage(g.cv, 90, GY - 60, 180, 120); c.restore();
  };

  /* ---------- render ---------- */
  const render = dt => {
    frameBase(); const px = 180 + (lx * LW - camX);
    c.save(); c.clearRect(0, 0, W, H);
    const sh = shake > 0 ? shake * 14 : 0; if (sh) c.translate((R() - .5) * sh, (R() - .5) * sh * .7);
    const tilt = (lane - lx) * .012; c.translate(180, 330); c.rotate(tilt); c.translate(-180, -330);
    // sky
    c.drawImage(SKY.cv, 0, 0, W, SKY.h); proj(FAR); const farShift = PX - 180;
    for (const cl of clouds) { const w = 120 * cl.s, x = cl.x + farShift * .5; if (th.cloud) { c.globalAlpha = .9; c.drawImage(SP.cloud.cv, x, cl.y, w, 44 * cl.s); c.globalAlpha = 1; } }
    [[SK1, .45, 14], [SK2, .85, 0]].forEach(([sk, par, oy]) => { const ox = (((farShift * par + dist * .5 * par * .3) % 720) + 720) % 720; c.drawImage(sk.cv, ox - 720, HZ - sk.h + 6 + oy, 720, sk.h); c.drawImage(sk.cv, ox, HZ - sk.h + 6 + oy, 720, sk.h); });
    c.fillStyle = th.ground; c.fillRect(-10, HZ + 5, W + 20, H - HZ);
    c.fillStyle = th.fog; c.globalAlpha = .55; c.fillRect(-10, HZ + 5, W + 20, 10); c.globalAlpha = 1;
    drawRoad();
    // item list (far -> near)
    const it = itemsA; it.length = 0;
    const nMin = Math.floor((dist - 16) / SLOT), nMax = Math.floor((dist + FAR) / SLOT);
    for (let n = nMin; n <= nMax; n++) { const zr = n * SLOT - dist + 4; it.push([zr, 1, -1, n], [zr, 1, 1, n]); }
    const lMin = Math.floor((dist - 4) / 24), lMax = Math.floor((dist + FAR) / 24); for (let n = lMin; n <= lMax; n++) { it.push([n * 24 - dist, 2, -1, n], [n * 24 - dist, 2, 1, n], [n * 24 + 12 - dist, 3, -1, n]); if (n % 2) it.push([n * 24 + 12 - dist, 3, 1, n]); }
    for (const o of objs) { const zr = o.z - dist + (o.len || 0) * .5; if (zr > -4 && zr - (o.len || 0) * .5 < FAR) it.push([zr + (o.len ? o.len * .5 : 0), 4, 0, o]); }
    it.push([0.2, 5, 0, 0], [46, 6, 0, 0]);
    it.sort((a, b) => b[0] - a[0]);
    const plyDraw = () => {
      const x = px, y = GY - jy; c.save(); const a = 1 - Math.min(.55, jy / 260); c.globalAlpha = a; const sw = 100 * (1 - Math.min(.55, jy / 200)); c.drawImage(SP.shadow.cv, x - sw / 2, GY - 9, sw, 30); c.globalAlpha = 1;
      const blink = inv > 0 && inv < 90 && Math.floor(t * 16) % 2 && st === 'run';
      if (shieldOn > 0) { c.save(); c.globalCompositeOperation = 'lighter'; const r = 62 + Math.sin(t * 8) * 2; const g = c.createRadialGradient(x, y - 52, r * .5, x, y - 52, r); g.addColorStop(0, 'rgba(120,210,255,0)'); g.addColorStop(.8, 'rgba(120,210,255,.25)'); g.addColorStop(1, 'rgba(180,240,255,.7)'); c.fillStyle = g; c.beginPath(); c.arc(x, y - 52, r, 0, 6.283); c.fill(); c.restore(); }
      ru3Runner(c, x, y, { ph, air: airK, crouch, lean: (lx - lane) * -.5 + (lane - lx) * 0, alpha: blink ? .3 : 1, t, dead: st === 'dead' ? deadK : 0 }); c.restore();
    };
    for (const e of it) {
      const k = e[1];
      if (k === 1) drawBuilding(e[2], e[3]); else if (k === 2) drawProp(e[2], e[3], false); else if (k === 3) drawProp(e[2], e[3], true);
      else if (k === 5) plyDraw();
      else if (k === 6) { c.fillStyle = haze; c.fillRect(0, HZ - 62, W, 130); }
      else if (k === 4) { const o = e[3], a = fogA(o.z - dist); if (a <= 0 || o.got) continue; c.globalAlpha = a; if (o.k === 'gem') drawGem(o); else if (o.k === 'car') drawCar(o); else if (o.k === 'hurdle') drawBarrier(o); else if (o.k === 'beam') drawBeam(o); else if (o.k === 'cone') drawCone(o); else if (o.k === 'train') drawTrain(o); else drawItem(o); c.globalAlpha = 1; }
    }
    drawLights();
    // speed lines
    const spK = Math.max(0, Math.min(1, (speed - L.spd * .8) / (L.spd * .7))); if (spK > .05) { c.strokeStyle = th.night ? 'rgba(200,220,255,' : 'rgba(255,255,255,'; c.lineCap = 'round'; for (let i = 0; i < 14; i++) { const ang = i * 2.399 + .3, f = (t * 1.9 + i * .37) % 1, r0 = 70 + f * f * 330, r1 = r0 + 14 + f * 46, cx0 = 180, cy0 = HZ + 36; c.lineWidth = 1 + f * 1.6; c.strokeStyle = (th.night ? 'rgba(200,220,255,' : 'rgba(255,255,255,') + (.26 * spK * (1 - f * .4)).toFixed(3) + ')'; c.beginPath(); c.moveTo(cx0 + Math.cos(ang) * r0, cy0 + Math.sin(ang) * r0 * .9); c.lineTo(cx0 + Math.cos(ang) * r1, cy0 + Math.sin(ang) * r1 * .9); c.stroke(); } }
    // particles
    for (const p of parts) { c.globalAlpha = 1 - p.life / p.max; c.fillStyle = p.col; c.beginPath(); c.arc(p.x, p.y, p.r, 0, 6.283); c.fill(); } c.globalAlpha = 1;
    c.drawImage(VIG.cv, 0, 0, W, H);
    c.restore();
    if (flashR > 0) { c.fillStyle = 'rgba(255,40,40,' + (flashR * 1.1).toFixed(3) + ')'; c.fillRect(0, 0, W, H); }
    drawHud();
    // pop texts
    for (const p of pops) { const k = Math.min(1, p.age * 6); c.globalAlpha = 1 - Math.max(0, p.age - .7) / .4; tx(c, p.t, p.x, p.y - p.age * 46, (p.big ? 24 : 20) * (.7 + .3 * Math.sin(k * Math.PI / 2)), p.col, 'center', '#000'); c.globalAlpha = 1; }
    if (banner) { const k = Math.min(1, banner.a * 4); c.globalAlpha = k; tx(c, banner.t, 180, 236, 30 * (.6 + .4 * k), '#ffd54a', 'center', '#7a3a00'); c.globalAlpha = 1; }
    if (t < 1.1 && st === 'run') { const lbl = t < .7 ? 'GET READY' : 'GO!'; c.globalAlpha = Math.min(1, (1.1 - t) * 3); tx(c, lbl, 180, 240, t < .7 ? 26 : 38, '#fff', 'center', '#1a3a6a'); c.globalAlpha = 1; }
    void dt;
  };

  /* HUD */
  const drawHud = () => {
    c.fillStyle = 'rgba(8,14,40,.45)'; rr(c, 6, 6, 90, 30, 15); c.fill(); for (let i = 0; i < 3; i++) ru3Heart(c, 25 + i * 26, 20, 9, i < hearts ? '#ff4d6d' : 'rgba(255,255,255,.22)'); for (let i = 0; i < hearts; i++) { c.fillStyle = 'rgba(255,255,255,.45)'; c.beginPath(); c.arc(21 + i * 26, 16, 2.2, 0, 6.283); c.fill(); }
    c.fillStyle = 'rgba(8,14,40,.45)'; rr(c, 112, 6, 136, 30, 15); c.fill(); tx(c, String(score + gems * 10 + Math.floor(dist)), 180, 22, 20, '#fff', 'center', '#1a3a6a');
    c.fillStyle = 'rgba(8,14,40,.45)'; rr(c, 264, 6, 90, 30, 15); c.fill(); c.drawImage(SP.gem[0].cv, 268, 5, 26, 30); tx(c, String(gems), 326, 22, 18, '#9af0ff', 'center', '#0a3a5a');
    const bx = 60, bw = 240, by = 58, f = Math.min(1, prog() / L.v);
    tx(c, L.goal.replace(/[💎♥]/gu, '').replace(/\s+/g, ' ').trim(), 180, 46, 11, '#fff', 'center', '#000');
    c.fillStyle = 'rgba(8,14,40,.55)'; rr(c, bx, by, bw, 14, 7); c.fill(); if (f > 0) { const g = c.createLinearGradient(bx, 0, bx + bw, 0); g.addColorStop(0, '#ffb02a'); g.addColorStop(1, '#ffe85a'); c.fillStyle = g; rr(c, bx + 1.5, by + 1.5, Math.max(11, (bw - 3) * f), 11, 5.5); c.fill(); c.fillStyle = 'rgba(255,255,255,.4)'; rr(c, bx + 3, by + 2.5, Math.max(8, (bw - 6) * f), 3.5, 2); c.fill(); }
    tx(c, prog() + ' / ' + L.v + (kind === 'time' ? ' s' : kind === 'dist' ? ' m' : ''), 180, by + 7.5, 9.5, '#fff', 'center', 'rgba(0,0,0,.6)');
    let yy = 82; if (magT > 0) { c.drawImage(SP.mag.cv, 8, yy - 6, 30, 30); c.fillStyle = 'rgba(8,14,40,.5)'; rr(c, 38, yy + 5, 50, 8, 4); c.fill(); c.fillStyle = '#ff7a7a'; rr(c, 38, yy + 5, 50 * magT / 8, 8, 4); c.fill(); yy += 32; }
    if (shieldOn > 0) { c.drawImage(SP.shield.cv, 8, yy - 6, 30, 30); c.fillStyle = 'rgba(8,14,40,.5)'; rr(c, 38, yy + 5, 50, 8, 4); c.fill(); c.fillStyle = '#7fe0ff'; rr(c, 38, yy + 5, 50 * shieldOn / 12, 8, 4); c.fill(); }
  };

  /* ---------- loop ---------- */
  genZ = 36; frameBase();
  const stop = anim(dt => {
    if (stopped) return; if (!stage.isConnected) { stopped = true; stop(); cleanup(); return; }
    if (!(st === 'win' && finished)) update(dt); render(dt);
  });
  stage.__dbg = () => ({ gems, hearts, dist, lane, jump: jy, objs, speed, state: st, jumps, slides, shield: shieldOn, magnet: magT, inv, lx });
  return () => { stopped = true; stop(); cleanup(); };
}

/* ---------- friend mode for challenge games: both play the same random level, higher score wins ---------- */
function chFriend(g) {
  const d = duel({
    id: g.id, name: g.name, icon: g.icon, desc: g.desc,
    play(box, seed, done) {
      const i = seed % g.levels.length, L = g.levels[i], stage = document.createElement('div'); stage.className = 'chstage'; box.appendChild(stage);
      const hd = document.createElement('div'); hd.className = 'chbar'; hd.innerHTML = '<span><b>' + esc(L.n) + '</b> · ' + esc(L.goal || '') + '</span>'; box.insertBefore(hd, stage);
      return g.play(stage, L, i, res => done((res.win ? 100000 : 0) + (res.score || 0)));
    },
    bot: () => 100000 + Math.floor(Math.random() * 1500)
  });
  g.init = d.init; g.move = d.move; g.render = d.render; g.status = d.status; g.bot = d.bot; g.simul = true; g.sym = d.sym;
  return g;
}
[G_CANDY2, G_TOWER2, G_RUNUP].forEach(chFriend);
