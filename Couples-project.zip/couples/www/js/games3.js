/* Playmates - skill games (timing meter) + final game list. Each player plays alone at the same time, scores compared. */
function meterGame(o) {
  const play = (box, seed, done) => {
    let n = 0, total = 0, msg = '', raf = 0, alive = true, tp = [];
    const t0 = performance.now();
    const draw = () => {
      box.innerHTML = `<div class="card center">Shot <b>${Math.min(n + 1, o.throws)}</b>/${o.throws} · Score <b>${total}</b></div>
        <div class="card center" style="min-height:46px">${msg || 'Stop the marker in the middle!'}</div>
        <div class="meter"><div class="zone" style="width:${o.zone}%"></div><div class="mk" id="mk"></div></div>
        <button class="btn full" id="th">${o.icon} Throw!</button>`;
    };
    const loop = () => {
      if (!alive) return;
      const mk = $('#mk', box);
      if (mk) { const x = ((performance.now() - t0) / o.period) % 2, p = x < 1 ? x : 2 - x; mk.style.left = (p * 100) + '%'; mk.dataset.p = p; }
      raf = requestAnimationFrame(loop);
    };
    draw(); loop();
    box.addEventListener('click', e => {
      if (!alive || e.target.id !== 'th') return;
      const mk = $('#mk', box); if (!mk) return;
      const acc = 1 - Math.abs(parseFloat(mk.dataset.p) - 0.5) * 2;
      const pts = o.score(acc, n, tp);
      tp.push(pts); total += pts; n++; msg = o.label(pts);
      if (n >= o.throws) { alive = false; cancelAnimationFrame(raf); box.innerHTML = `<div class="card center">${msg}<br>Total: <b>${total}</b></div>`; done(total); }
      else draw();
    });
    return () => { alive = false; cancelAnimationFrame(raf); };
  };
  const bot = () => {
    let tot = 0; const tp = [];
    for (let n = 0; n < o.throws; n++) { const p = 0.5 + (Math.random() + Math.random() - 1) * 0.42; const pts = o.score(1 - Math.abs(p - 0.5) * 2, n, tp); tp.push(pts); tot += pts; }
    return tot;
  };
  return duel({ id: o.id, name: o.name, icon: o.icon, desc: o.desc, play, bot });
}

const G_DARTS = meterGame({
  id: 'darts', name: 'Darts', icon: '🎯', desc: '9 darts. Stop the marker in the middle, bullseye = 50!', throws: 9, period: 1100, zone: 10,
  score: a => a >= 0.95 ? 50 : a >= 0.85 ? 40 : a >= 0.7 ? 30 : a >= 0.5 ? 20 : a >= 0.3 ? 10 : 0,
  label: p => p === 50 ? '🎯 Bullseye! 50' : p ? p + ' points' : 'Miss ❌'
});
const G_BOWL = meterGame({
  id: 'bowl', name: 'Bowling', icon: '🎳', desc: '5 frames, 2 rolls each. A strike resets the rack!', throws: 10, period: 1200, zone: 10,
  score: (a, n, tp) => n % 2 === 0 ? (a >= 0.9 ? 10 : Math.round(a * 9)) : Math.round(a * (tp[n - 1] === 10 ? 10 : 10 - tp[n - 1])),
  label: p => p === 10 ? '🎳 Strike! 10' : p + ' pins'
});
const G_ARCH = meterGame({
  id: 'arch', name: 'Archery', icon: '🏹', desc: '9 arrows. The closer to the middle, the more points (max 10).', throws: 9, period: 1000, zone: 8,
  score: a => Math.round(a * 10),
  label: p => p >= 10 ? '🏹 Bullseye! 10' : p + ' / 10'
});
const G_HOOP = meterGame({
  id: 'hoop', name: 'Basketball', icon: '🏀', desc: '10 shots. Perfect timing = 3 points!', throws: 10, period: 850, zone: 10,
  score: a => a >= 0.9 ? 3 : a >= 0.6 ? 2 : 0,
  label: p => p === 3 ? '🏀 Swish! +3' : p ? '🏀 Basket +2' : 'Miss ❌'
});
const G_SKEE = meterGame({
  id: 'skee', name: 'Skee Ball', icon: '🎱', desc: '9 balls. The middle ring gives the most points.', throws: 9, period: 1000, zone: 10,
  score: a => a >= 0.9 ? 50 : a >= 0.75 ? 40 : a >= 0.55 ? 30 : a >= 0.35 ? 20 : 10,
  label: p => p + ' points'
});

G_LUDO.icon = '🏠';

