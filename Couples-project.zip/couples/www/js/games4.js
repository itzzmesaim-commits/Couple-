/* Playmates - batch 3: Pool, Carrom, Disc-o (physics turn games), Mini Golf, Bounce, Match Monster, Plox (skill duels), Bloko (turn game) */

/* ================= POOL (8-ball: solids vs stripes) ================= */
const PL = { w: 360, h: 620, r: 10, m: 18 };
const PL_POCK = [[0, 0], [360, 0], [0, 310], [360, 310], [0, 620], [360, 620]].map(([x, y]) => ({ x, y, r: 21 }));
const PL_OWN = seat => seat === 0 ? [1, 2, 3, 4, 5, 6, 7] : [9, 10, 11, 12, 13, 14, 15];
const PL_COL = ['#fff', '#f5c400', '#1e4fd6', '#d62020', '#6a2fa8', '#f07a14', '#14803a', '#7a1f1f', '#111'];
function plRack() {
  const b = [[180, 480, 0, 0, 1]], rows = [[1], [9, 2], [10, 8, 3], [11, 4, 12, 5], [6, 13, 7, 14, 15]];
  rows.forEach((row, i) => row.forEach((id, k) => { b[id] = [+(180 + (k - i / 2) * 20.8).toFixed(2), 170 + i * 18.2, 0, 0, 1]; }));
  return b;
}
function plPlaceCue(b) {
  for (const [x, y] of [[180, 480], [150, 480], [210, 480], [180, 520], [120, 500], [240, 500]])
    if (!b.some((q, i) => i > 0 && q[4] && Math.hypot(q[0] - x, q[1] - y) < 22)) { b[0] = [x, y, 0, 0, 1]; return; }
  b[0] = [180, 560, 0, 0, 1];
}
function plBall(c, x, y, id) {
  const r = PL.r, col = PL_COL[id === 0 ? 0 : id > 8 ? id - 8 : id], stripe = id > 8;
  c.save(); c.translate(x, y);
  c.fillStyle = '#0005'; c.beginPath(); c.arc(2, 3, r, 0, 6.283); c.fill();
  c.beginPath(); c.arc(0, 0, r, 0, 6.283); c.clip();
  c.fillStyle = stripe || id === 0 ? '#f4f4f4' : col; c.fillRect(-r, -r, 2 * r, 2 * r);
  if (stripe) { c.fillStyle = col; c.fillRect(-r, -5.5, 2 * r, 11); }
  c.restore(); c.save(); c.translate(x, y);
  if (id) { c.fillStyle = '#fff'; c.beginPath(); c.arc(0, 0, 5, 0, 6.283); c.fill(); c.fillStyle = '#111'; c.font = 'bold 7px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(id, 0, 0.5); }
  const g = c.createRadialGradient(-3, -4, 1, 0, 0, r); g.addColorStop(0, '#ffffff99'); g.addColorStop(0.5, '#ffffff00'); g.addColorStop(1, '#00000044');
  c.fillStyle = g; c.beginPath(); c.arc(0, 0, r, 0, 6.283); c.fill(); c.restore();
}
const G_POOL = physGame({
  id: 'pool', name: 'Pool', icon: '🎱', desc: 'Pot all your balls, then the black 8. Solids vs Stripes.', sym: ['🔴', '🔵'],
  w: PL.w, h: PL.h, cw: PL.w + 2 * PL.m, ch: PL.h + 2 * PL.m, fr: 230, rest: 0.93, pockets: PL_POCK, r: () => PL.r, pull: 90,
  init: () => ({ b: plRack(), turn: 0, winner: null, n: 0, msg: '' }),
  launch(P, m) { const c = P.balls[0]; c.a = 1; const v = 120 + 820 * clamp(m.pow, 0, 1); c.vx = Math.cos(m.ang) * v; c.vy = Math.sin(m.ang) * v; },
  prep: (s, m) => ({ ang: +m.ang, pow: clamp(+m.pow || 0, 0, 1) }),
  valid: (s, m, seat) => s.winner == null && s.turn === seat && isFinite(m.ang) && isFinite(m.pow),
  after(s, ev, seat, before) {
    const act = i => s.b[i][4] === 1, own = PL_OWN(seat);
    const cueIn = ev.includes(0), blackIn = ev.includes(8);
    const mine = ev.filter(i => own.includes(i)).length;
    s.msg = '';
    if (blackIn) { const legal = own.every(i => !before[i][4]) && !cueIn; s.winner = legal ? seat : 1 - seat; s.msg = legal ? '' : 'Black potted too early'; return; }
    if (cueIn) { plPlaceCue(s.b); s.turn = 1 - seat; s.msg = 'Foul: cue ball potted'; }
    else if (mine > 0) s.turn = seat; else s.turn = 1 - seat;
    if (s.n >= 90) { const l0 = PL_OWN(0).filter(act).length, l1 = PL_OWN(1).filter(act).length; s.winner = l0 === l1 ? 'draw' : (l0 < l1 ? 0 : 1); }
  },
  shooter: s => s.b[0][4] ? { x: s.b[0][0] + PL.m, y: s.b[0][1] + PL.m } : null,
  hud: (s, seat) => {
    const row = o => PL_OWN(o).map(i => `<i class="pb" style="background:${PL_COL[i > 8 ? i - 8 : i]};${i > 8 ? 'box-shadow:inset 0 0 0 3px #fff,inset 0 0 0 5px ' + PL_COL[i - 8] : ''};opacity:${s.b[i][4] ? 1 : .25}"></i>`).join('');
    return `<div class="poolbar ${s.turn === 0 && s.winner == null ? 'on' : ''}"><b>${seat === 0 ? 'You' : 'Opponent'} · Solids</b><div>${row(0)}</div></div>
      <div class="poolbar ${s.turn === 1 && s.winner == null ? 'on' : ''}"><b>${seat === 1 ? 'You' : 'Opponent'} · Stripes</b><div>${row(1)}</div></div><div class="ldmsg">${esc(s.msg || '')}</div>`;
  },
  cands(s, seat) {
    const own = PL_OWN(seat).filter(i => s.b[i][4]), tg = own.length ? own : [8], cue = s.b[0], out = [];
    for (const t of tg) for (const p of PL_POCK) {
      const tb = s.b[t], dx = p.x - tb[0], dy = p.y - tb[1], d = Math.hypot(dx, dy) || 1;
      const gx = tb[0] - dx / d * 2 * PL.r, gy = tb[1] - dy / d * 2 * PL.r, cd = Math.hypot(gx - cue[0], gy - cue[1]) || 1;
      if (((gx - cue[0]) / cd) * (dx / d) + ((gy - cue[1]) / cd) * (dy / d) < 0.25) continue;
      const ang = Math.atan2(gy - cue[1], gx - cue[0]);
      for (const pw of [0.4, 0.65, 0.9]) out.push({ ang, pow: pw });
    }
    for (let k = 0; k < 6; k++) out.push({ ang: Math.random() * 6.283, pow: 0.5 + Math.random() * 0.5 });
    return out.sort(() => Math.random() - 0.5).slice(0, 44);
  },
  eval(s, ns, seat) {
    if (ns.winner === seat) return 1000; if (ns.winner != null) return -1000;
    const cnt = (st, ids) => ids.filter(i => st.b[i][4]).length, o = PL_OWN(seat), q = PL_OWN(1 - seat);
    return (cnt(s, o) - cnt(ns, o)) * 10 - (cnt(s, q) - cnt(ns, q)) * 6 - (ns.msg === 'Foul: cue ball potted' ? 25 : 0) + (ns.turn === seat ? 4 : 0);
  },
  draw(c, balls, R, s, can) {
    const M = PL.m, W = PL.w, H = PL.h;
    c.save(); c.fillStyle = '#6b1a26'; c.fillRect(0, 0, W + 2 * M, H + 2 * M);
    c.fillStyle = '#e8c27a'; for (let k = 1; k < 8; k++) { c.beginPath(); c.arc(M / 2, M + k * H / 8, 2, 0, 6.283); c.arc(W + 1.5 * M, M + k * H / 8, 2, 0, 6.283); c.fill(); }
    for (let k = 1; k < 4; k++) { c.beginPath(); c.arc(M + k * W / 4, M / 2, 2, 0, 6.283); c.arc(M + k * W / 4, H + 1.5 * M, 2, 0, 6.283); c.fill(); }
    c.translate(M, M);
    const g = c.createRadialGradient(W / 2, H / 2, 30, W / 2, H / 2, H * 0.62); g.addColorStop(0, '#34b4e6'); g.addColorStop(1, '#1670a6');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    c.strokeStyle = '#ffffff30'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(0, 470); c.lineTo(W, 470); c.stroke();
    c.fillStyle = '#05070c'; for (const p of PL_POCK) { c.beginPath(); c.arc(p.x, p.y, p.r, 0, 6.283); c.fill(); c.strokeStyle = '#b9a56a'; c.lineWidth = 2; c.stroke(); }
    const cue = balls[0], a = R.sling && R.sling.aim;
    if (can && a && cue && cue.a) {
      const dx = Math.cos(a.ang), dy = Math.sin(a.ang);
      let hit = null, ht = 600;
      for (const b of balls) {
        if (!b.a || b.id === 0) continue;
        const rx = b.x - cue.x, ry = b.y - cue.y, t = rx * dx + ry * dy; if (t <= 0) continue;
        const d2 = rx * rx + ry * ry - t * t; if (d2 >= 4 * PL.r * PL.r) continue;
        const th = t - Math.sqrt(4 * PL.r * PL.r - d2); if (th > 0 && th < ht) { ht = th; hit = b; }
      }
      const ex = cue.x + dx * ht, ey = cue.y + dy * ht;
      c.strokeStyle = '#ffffffcc'; c.lineWidth = 2; c.setLineDash([7, 5]); c.beginPath(); c.moveTo(cue.x, cue.y); c.lineTo(ex, ey); c.stroke(); c.setLineDash([]);
      if (hit) {
        c.beginPath(); c.arc(ex, ey, PL.r, 0, 6.283); c.stroke();
        const nx = hit.x - ex, ny = hit.y - ey, nl = Math.hypot(nx, ny) || 1;
        c.strokeStyle = '#ffd54a'; c.lineWidth = 3; c.beginPath(); c.moveTo(hit.x, hit.y); c.lineTo(hit.x + nx / nl * 55, hit.y + ny / nl * 55); c.stroke();
      }
      const pull = a.pow * 70, sx = cue.x - dx * (PL.r + 6 + pull), sy = cue.y - dy * (PL.r + 6 + pull);
      const ex2 = sx - dx * 230, ey2 = sy - dy * 230, gr = c.createLinearGradient(sx, sy, ex2, ey2); gr.addColorStop(0, '#e9d3a0'); gr.addColorStop(1, '#6b3d14');
      c.lineCap = 'round'; c.strokeStyle = gr; c.lineWidth = 6; c.beginPath(); c.moveTo(sx, sy); c.lineTo(ex2, ey2); c.stroke();
      c.strokeStyle = '#3aa0ff'; c.lineWidth = 6; c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx - dx * 5, sy - dy * 5); c.stroke(); c.lineCap = 'butt';
    }
    for (const b of balls) if (b.a) plBall(c, b.x, b.y, b.id);
    c.restore();
  }
});

/* ================= CARROM ================= */
const CR = { w: 400, h: 400, rs: 15, rc: 10 };
const CR_POCK = [[0, 0], [400, 0], [0, 400], [400, 400]].map(([x, y]) => ({ x, y, r: 27 }));
const CR_OWN = seat => seat === 0 ? [2, 3, 4, 5, 6, 7] : [8, 9, 10, 11, 12, 13];
function crInit() {
  const b = [[200, 348, 0, 0, 0], [200, 200, 0, 0, 1]]; let w = 2, k = 8;
  for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3, id = i % 2 ? k++ : w++; b[id] = [+(200 + Math.cos(a) * 22).toFixed(2), +(200 + Math.sin(a) * 22).toFixed(2), 0, 0, 1]; }
  for (let i = 0; i < 6; i++) { const a = Math.PI / 6 + i * Math.PI / 3, id = i % 2 ? w++ : k++; b[id] = [+(200 + Math.cos(a) * 45).toFixed(2), +(200 + Math.sin(a) * 45).toFixed(2), 0, 0, 1]; }
  return b;
}
const crSx = (R, s) => 70 + (R ? R.sx : 0.5) * (CR.w - 140), crSy = seat => seat === 0 ? CR.h - 54 : 54;
const G_CARROM = physGame({
  id: 'carrom', name: 'Carrom', icon: '🪙', desc: 'Pocket all your coins first. Slide the striker, pull back and flick!', sym: ['⚪', '⚫'],
  w: CR.w, h: CR.h, fr: 150, rest: 0.86, pockets: CR_POCK, r: i => i === 0 ? CR.rs : CR.rc, pull: 80, slider: true,
  init: () => ({ b: crInit(), turn: 0, winner: null, n: 0, msg: '' }),
  prep: (s, m) => ({ ang: +m.ang, pow: clamp(+m.pow || 0, 0, 1), x: clamp(+m.x, 0, 1) }),
  valid: (s, m, seat) => s.winner == null && s.turn === seat && isFinite(m.ang) && isFinite(m.pow),
  launch(P, m, seat) { const st = P.balls[0]; st.a = 1; st.x = 70 + m.x * (CR.w - 140); st.y = crSy(seat); const v = 160 + 780 * m.pow; st.vx = Math.cos(m.ang) * v; st.vy = Math.sin(m.ang) * v; },
  after(s, ev, seat) {
    s.b[0][4] = 0; s.msg = '';
    const own = CR_OWN(seat), mine = ev.filter(i => own.includes(i)).length, queen = ev.includes(1), foul = ev.includes(0);
    const left = st => CR_OWN(st).filter(i => s.b[i][4]).length;
    if (left(seat) === 0) { s.winner = seat; return; }
    if (left(1 - seat) === 0) { s.winner = 1 - seat; return; }
    if (foul) { s.turn = 1 - seat; s.msg = 'Foul: striker pocketed'; }
    else s.turn = (mine > 0 || queen) ? seat : 1 - seat;
    if (s.n >= 70) s.winner = left(0) === left(1) ? 'draw' : (left(0) < left(1) ? 0 : 1);
  },
  shooter: (s, R) => (s.winner == null ? { x: crSx(R), y: crSy(R.seat) } : null),
  hud: s => `<div class="scorebar"><div class="p0">⚪ ${CR_OWN(0).filter(i => s.b[i][4]).length} left</div><div class="mut">${esc(s.msg || '')}</div><div class="p1">⚫ ${CR_OWN(1).filter(i => s.b[i][4]).length} left</div></div>`,
  cands(s, seat) {
    const own = CR_OWN(seat).filter(i => s.b[i][4]), out = [];
    for (const x of [0.15, 0.5, 0.85]) {
      const sx = 70 + x * (CR.w - 140), sy = crSy(seat);
      for (const t of own) for (const p of CR_POCK) {
        const tb = s.b[t], dx = p.x - tb[0], dy = p.y - tb[1], d = Math.hypot(dx, dy) || 1;
        const gx = tb[0] - dx / d * (CR.rs + CR.rc), gy = tb[1] - dy / d * (CR.rs + CR.rc);
        const ang = Math.atan2(gy - sy, gx - sx);
        if ((seat === 0 && Math.sin(ang) > -0.1) || (seat === 1 && Math.sin(ang) < 0.1)) continue;
        for (const pw of [0.5, 0.8]) out.push({ ang, pow: pw, x });
      }
    }
    for (let k = 0; k < 5; k++) out.push({ ang: (seat === 0 ? -1 : 1) * (0.6 + Math.random() * 1.9), pow: 0.5 + Math.random() * 0.5, x: Math.random() });
    return out.sort(() => Math.random() - 0.5).slice(0, 40);
  },
  eval(s, ns, seat) {
    if (ns.winner === seat) return 1000; if (ns.winner != null) return -1000;
    const cnt = (st, ids) => ids.filter(i => st.b[i][4]).length, o = CR_OWN(seat), q = CR_OWN(1 - seat);
    return (cnt(s, o) - cnt(ns, o)) * 10 - (cnt(s, q) - cnt(ns, q)) * 7 - (ns.msg ? 20 : 0) + (ns.b[1][4] ? 0 : 5);
  },
  draw(c, balls, R, s, can) {
    c.fillStyle = '#d9a35c'; c.fillRect(0, 0, CR.w, CR.h);
    c.strokeStyle = '#6b3d14'; c.lineWidth = 12; c.strokeRect(0, 0, CR.w, CR.h);
    c.strokeStyle = '#7a4a1c'; c.lineWidth = 2; c.beginPath(); c.arc(200, 200, 60, 0, 6.283); c.stroke(); c.beginPath(); c.arc(200, 200, 8, 0, 6.283); c.stroke();
    c.strokeRect(70, 54, 260, 292);
    c.fillStyle = '#1a0d05'; for (const p of CR_POCK) { c.beginPath(); c.arc(p.x, p.y, p.r, 0, 6.283); c.fill(); }
    for (const b of balls) {
      if (!b.a || b.id === 0) continue;
      c.fillStyle = b.id === 1 ? '#e0245e' : b.id < 8 ? '#fff4dc' : '#2b2b2b'; c.beginPath(); c.arc(b.x, b.y, CR.rc, 0, 6.283); c.fill();
      c.strokeStyle = '#00000055'; c.lineWidth = 1.5; c.stroke();
    }
    const st = balls[0];
    if (st && st.a) { c.fillStyle = '#4aa3ff'; c.beginPath(); c.arc(st.x, st.y, CR.rs, 0, 6.283); c.fill(); }
    else if (can) { const x = crSx(R), y = crSy(R.seat); c.fillStyle = '#4aa3ffcc'; c.beginPath(); c.arc(x, y, CR.rs, 0, 6.283); c.fill(); const a = R.sling && R.sling.aim; if (a) { c.strokeStyle = '#fff'; c.setLineDash([6, 6]); c.lineWidth = 2; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a.ang) * (60 + a.pow * 200), y + Math.sin(a.ang) * (60 + a.pow * 200)); c.stroke(); c.setLineDash([]); } }
  }
});

/* ================= DISC-O (disc shuffle) ================= */
const DO = { w: 300, h: 520, r: 16, cx: 150, cy: 120 };
const doPts = b => { const d = Math.hypot(b[0] - DO.cx, b[1] - DO.cy); return d < 26 ? 5 : d < 54 ? 3 : d < 84 ? 1 : 0; };
const doScore = s => { const t = [0, 0]; s.b.forEach((b, i) => { if (b[4]) t[i % 2] += doPts(b); }); return t; };
const G_DISCO = physGame({
  id: 'disco', name: 'Disc-o', icon: '🥏', desc: '5 discs each. Slide them onto the target, knock the rival discs away!', sym: ['🔴', '🔵'],
  w: DO.w, h: DO.h, fr: 190, rest: 0.9, killTop: true, r: () => DO.r, pull: 80, slider: true,
  init: () => ({ b: Array.from({ length: 10 }, () => [0, 0, 0, 0, 0]), turn: 0, winner: null, n: 0 }),
  prep: (s, m) => ({ ang: +m.ang, pow: clamp(+m.pow || 0, 0, 1), x: clamp(+m.x, 0, 1), k: s.n }),
  valid: (s, m, seat) => s.winner == null && s.turn === seat && s.n < 10 && isFinite(m.ang) && isFinite(m.pow),
  launch(P, m) { const d = P.balls[m.k]; d.a = 1; d.x = 40 + m.x * (DO.w - 80); d.y = DO.h - 36; const v = 130 + 640 * m.pow; d.vx = Math.cos(m.ang) * v; d.vy = Math.sin(m.ang) * v; },
  after(s, ev, seat) {
    s.turn = s.n % 2;
    if (s.n >= 10) { const t = doScore(s); s.winner = t[0] === t[1] ? 'draw' : (t[0] > t[1] ? 0 : 1); }
  },
  shooter: (s, R) => (s.n < 10 && s.winner == null ? { x: 40 + R.sx * (DO.w - 80), y: DO.h - 36 } : null),
  hud: s => { const t = doScore(s); return `<div class="scorebar"><div class="p0">🔴 ${t[0]}</div><div class="mut">Disc ${Math.min(s.n + 1, 10)}/10</div><div class="p1">🔵 ${t[1]}</div></div>`; },
  cands(s, seat) {
    const out = [];
    for (const x of [0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.9]) for (const pw of [0.35, 0.45, 0.55, 0.65, 0.75]) for (const da of [-0.12, 0, 0.12]) out.push({ ang: -Math.PI / 2 + da * (0.5 - x) * 2 + da, pow: pw, x });
    return out;
  },
  eval(s, ns, seat) { const a = doScore(s), b = doScore(ns); return (b[seat] - b[1 - seat]) - (a[seat] - a[1 - seat]) + Math.random(); },
  draw(c, balls, R, s, can) {
    c.fillStyle = '#16335c'; c.fillRect(0, 0, DO.w, DO.h);
    c.strokeStyle = '#6fa8ff55'; c.lineWidth = 3; c.strokeRect(1, 1, DO.w - 2, DO.h - 2);
    [[84, '#27518f', 1], [54, '#2f69b8', 3], [26, '#ffd54a', 5]].forEach(([r, col, p]) => { c.fillStyle = col; c.beginPath(); c.arc(DO.cx, DO.cy, r, 0, 6.283); c.fill(); c.fillStyle = '#fff'; c.font = 'bold 11px sans-serif'; c.textAlign = 'center'; c.fillText(p, DO.cx, DO.cy - r + 12); });
    for (const b of balls) { if (!b.a) continue; c.fillStyle = b.id % 2 ? '#4aa3ff' : '#ff4d8d'; c.beginPath(); c.arc(b.x, b.y, DO.r, 0, 6.283); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 2; c.stroke(); c.strokeStyle = '#00000033'; c.beginPath(); c.arc(b.x, b.y, DO.r - 6, 0, 6.283); c.stroke(); }
    if (can) {
      const x = 40 + R.sx * (DO.w - 80), y = DO.h - 36, seat = s.n % 2; c.fillStyle = seat ? '#4aa3ffcc' : '#ff4d8dcc'; c.beginPath(); c.arc(x, y, DO.r, 0, 6.283); c.fill();
      const a = R.sling && R.sling.aim; if (a) { c.strokeStyle = '#fff'; c.setLineDash([6, 6]); c.lineWidth = 2; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a.ang) * (60 + a.pow * 260), y + Math.sin(a.ang) * (60 + a.pow * 260)); c.stroke(); c.setLineDash([]); }
    }
  }
});
/* ================= helpers for block games ================= */
const PCS = [[[1]], [[1, 1]], [[1], [1]], [[1, 1, 1]], [[1], [1], [1]], [[1, 1, 1, 1]], [[1], [1], [1], [1]], [[1, 1], [1, 1]], [[1, 1, 1], [1, 1, 1], [1, 1, 1]],
  [[1, 0], [1, 1]], [[0, 1], [1, 1]], [[1, 1], [1, 0]], [[1, 1], [0, 1]], [[1, 0, 0], [1, 0, 0], [1, 1, 1]], [[1, 1, 1], [0, 1, 0]], [[1, 1, 1, 1, 1]]];
const PCOL = ['#ff4d8d', '#4aa3ff', '#ffd54a', '#3ddc97', '#9b5cff', '#ff8a3d'];
const pFits = (g, N, p, r, c) => { for (let i = 0; i < p.length; i++) for (let j = 0; j < p[0].length; j++) if (p[i][j]) { const rr = r + i, cc = c + j; if (rr < 0 || cc < 0 || rr >= N || cc >= N || g[rr * N + cc]) return false; } return true; };
const pAnyFit = (g, N, p) => { for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (pFits(g, N, p, r, c)) return true; return false; };
const pCells = p => p.reduce((a, row) => a + row.reduce((x, y) => x + y, 0), 0);
function pClear(g, N) {
  const rows = [], cols = [];
  for (let r = 0; r < N; r++) if (Array.from({ length: N }, (_, c) => g[r * N + c]).every(Boolean)) rows.push(r);
  for (let c = 0; c < N; c++) if (Array.from({ length: N }, (_, r) => g[r * N + c]).every(Boolean)) cols.push(c);
  rows.forEach(r => { for (let c = 0; c < N; c++) g[r * N + c] = 0; });
  cols.forEach(c => { for (let r = 0; r < N; r++) g[r * N + c] = 0; });
  return rows.length + cols.length;
}
const pMini = (p, col, on) => `<div class="mini" style="grid-template-columns:repeat(${p[0].length},1fr)">${p.map(row => row.map(v => `<i style="background:${v ? col : 'transparent'}"></i>`).join('')).join('')}</div>`;

/* ================= PLOX (place blocks wisely, 1010-style duel) ================= */
const G_PLOX = duel({
  id: 'plox', name: 'Plox', icon: '🧱', desc: 'Place blocks, clear full rows and columns. Highest score wins!',
  bot: () => 140 + Math.floor(Math.random() * 280),
  play(box, seed, done) {
    const R = rng(seed), N = 8; let g = new Array(N * N).fill(0), score = 0, tray = [], sel = 0, over = false;
    const nt = () => { tray = [0, 1, 2].map(() => { const k = Math.floor(R() * PCS.length); return { k, col: PCOL[k % PCOL.length] }; }); };
    nt();
    const end = () => { if (over) return; over = true; box.innerHTML = `<div class="card center">Game over<br>Score: <b>${score}</b></div>`; done(score); };
    const draw = () => {
      box.innerHTML = `<div class="card center">Score <b>${score}</b> · pick a block, then tap the board</div>
        <div class="board" style="grid-template-columns:repeat(${N},1fr);max-width:320px">${g.map((v, i) => `<button class="cell pcell" data-i="${i}" style="${v ? 'background:' + v : ''}"></button>`).join('')}</div>
        <div class="tray">${tray.map((t, i) => t ? `<button class="trayp ${i === sel ? 'sel' : ''}" data-t="${i}">${pMini(PCS[t.k], t.col)}</button>` : '<span class="trayp"></span>').join('')}</div>
        <button class="btn sec full" data-end="1">🏁 Finish now</button>`;
    };
    box.addEventListener('click', e => {
      if (over) return;
      const t = e.target.closest('[data-t]'), cell = e.target.closest('[data-i]');
      if (e.target.closest('[data-end]')) return end();
      if (t) { sel = +t.dataset.t; return draw(); }
      if (cell && tray[sel]) {
        const p = PCS[tray[sel].k], i = +cell.dataset.i, r = Math.floor(i / N) - Math.floor(p.length / 2), c = (i % N) - Math.floor(p[0].length / 2);
        if (!pFits(g, N, p, r, c)) return;
        p.forEach((row, a) => row.forEach((v, b) => { if (v) g[(r + a) * N + c + b] = tray[sel].col; }));
        score += pCells(p); const lines = pClear(g, N); if (lines) score += lines * 10 + (lines - 1) * 10;
        tray[sel] = null; if (tray.every(x => !x)) nt();
        sel = tray.findIndex(x => x); if (sel < 0) sel = 0;
        if (!tray.some(x => x && pAnyFit(g, N, PCS[x.k]))) { draw(); return end(); }
        draw();
      }
    });
    draw();
    return () => { over = true; };
  }
});

/* ================= BLOKO (turn-based, shared board, clear rows/columns) ================= */
const G_BLOKO = {
  id: 'bloko', name: 'Bloko', icon: '🟦', type: 'turn', sym: ['🟥', '🟦'], desc: 'Take turns placing blocks on a shared board. Clear rows and columns to score!',
  init() {
    const s = { g: new Array(64).fill(0), sc: [0, 0], turn: 0, winner: null, rs: newSeed(), n: 0, tray: [] };
    for (let i = 0; i < 3; i++) s.tray.push(Math.floor(rng(s.rs + i * 977)() * PCS.length));
    return s;
  },
  move(s, m, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    const i = m.i | 0, r = m.r | 0, c = m.c | 0, k = s.tray[i];
    if (k == null) return null; const p = PCS[k];
    if (!pFits(s.g, 8, p, r, c)) return null;
    p.forEach((row, a) => row.forEach((v, b) => { if (v) s.g[(r + a) * 8 + c + b] = seat + 1; }));
    s.sc[seat] += pCells(p);
    const lines = pClear(s.g, 8); if (lines) s.sc[seat] += lines * 10 + (lines - 1) * 10;
    s.n++; s.tray[i] = Math.floor(rng(s.rs + s.n * 131)() * PCS.length);
    s.turn = 1 - seat;
    if (!s.tray.some(t => pAnyFit(s.g, 8, PCS[t]))) s.winner = s.sc[0] === s.sc[1] ? 'draw' : (s.sc[0] > s.sc[1] ? 0 : 1);
    return s;
  },
  bot(s, seat) {
    let best = null, bs = -1e9;
    s.tray.forEach((k, i) => { const p = PCS[k]; for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) if (pFits(s.g, 8, p, r, c)) {
      const g2 = s.g.slice(); p.forEach((row, a) => row.forEach((v, b) => { if (v) g2[(r + a) * 8 + c + b] = 1; }));
      const lines = pClear(g2, 8), free = g2.filter(v => !v).length;
      const sc = lines * 14 + pCells(p) + free * 0.15 + Math.random() * 2; if (sc > bs) { bs = sc; best = { i, r, c }; } } });
    return best;
  },
  status: (s, seat) => s.winner != null ? '' : (s.turn === seat ? '👉 Pick a block, then tap the board' : '⏳ Partner’s turn'),
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null; if (el.__sg !== s.gid) { el.__sg = s.gid; el.__sel = 0; }
    el.innerHTML = `<div class="scorebar"><div class="p0">🟥 ${s.sc[0]}</div><div class="mut">Clear a line = +10</div><div class="p1">🟦 ${s.sc[1]}</div></div>
      <div class="board" style="grid-template-columns:repeat(8,1fr);max-width:320px">${s.g.map((v, i) => `<button class="cell pcell" data-i="${i}" style="${v ? 'background:' + (v === 1 ? '#ff4d8d' : '#4aa3ff') : ''}"></button>`).join('')}</div>
      <div class="tray">${s.tray.map((k, i) => `<button class="trayp ${i === el.__sel ? 'sel' : ''}" data-t="${i}">${pMini(PCS[k], PCOL[k % PCOL.length])}</button>`).join('')}</div>`;
    $$('[data-t]', el).forEach(b => b.onclick = () => { el.__sel = +b.dataset.t; G_BLOKO.render(el, s, seat, send); });
    $$('[data-i]', el).forEach(b => b.onclick = () => {
      if (!mine) return; const p = PCS[s.tray[el.__sel]], i = +b.dataset.i;
      const r = Math.floor(i / 8) - Math.floor(p.length / 2), c = (i % 8) - Math.floor(p[0].length / 2);
      if (pFits(s.g, 8, p, r, c)) send({ i: el.__sel, r, c });
    });
  }
};

/* ================= MATCH MONSTER (match-3 duel) ================= */
const G_MONSTER = duel({
  id: 'monster', name: 'Match Monster', icon: '👾', desc: '20 moves. Swap monsters to match 3 or more. Highest score wins!',
  bot: () => 300 + Math.floor(Math.random() * 300),
  play(box, seed, done) {
    const R = rng(seed), N = 7, T = ['👾', '👹', '👻', '🐸', '🦊', '🐙'], rnd = () => Math.floor(R() * T.length);
    let g = [], moves = 20, score = 0, sel = -1, over = false;
    const matches = () => {
      const m = new Set();
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const v = g[r * N + c]; if (v < 0) continue;
        if (c < N - 2 && g[r * N + c + 1] === v && g[r * N + c + 2] === v) { m.add(r * N + c); m.add(r * N + c + 1); m.add(r * N + c + 2); }
        if (r < N - 2 && g[(r + 1) * N + c] === v && g[(r + 2) * N + c] === v) { m.add(r * N + c); m.add((r + 1) * N + c); m.add((r + 2) * N + c); }
      }
      return m;
    };
    const swap = (a, b) => { const t = g[a]; g[a] = g[b]; g[b] = t; };
    const hasMove = () => { for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) for (const [dr, dc] of [[0, 1], [1, 0]]) { if (r + dr >= N || c + dc >= N) continue; const a = r * N + c, b = (r + dr) * N + c + dc; swap(a, b); const ok = matches().size > 0; swap(a, b); if (ok) return true; } return false; };
    const fresh = () => { let t = 0; do { g = Array.from({ length: N * N }, rnd); t++; } while ((matches().size || !hasMove()) && t < 200); };
    const resolve = () => {
      let chain = 0; for (; ;) {
        const m = matches(); if (!m.size) break; chain++; score += m.size * 10 * chain; m.forEach(i => { g[i] = -1; });
        for (let c = 0; c < N; c++) { const col = []; for (let r = N - 1; r >= 0; r--) if (g[r * N + c] >= 0) col.push(g[r * N + c]); while (col.length < N) col.push(rnd()); for (let r = N - 1, k = 0; r >= 0; r--, k++) g[r * N + c] = col[k]; }
      }
    };
    const end = () => { if (over) return; over = true; box.innerHTML = `<div class="card center">Time's up!<br>Score: <b>${score}</b></div>`; done(score); };
    const draw = () => {
      box.innerHTML = `<div class="card center">Moves left <b>${moves}</b> · Score <b>${score}</b></div>
        <div class="board" style="grid-template-columns:repeat(${N},1fr);max-width:340px">${g.map((v, i) => `<button class="cell ${i === sel ? 'sel' : ''}" data-i="${i}" style="font-size:22px">${T[v]}</button>`).join('')}</div>
        <button class="btn sec full" data-end="1">🏁 Finish now</button>`;
    };
    box.addEventListener('click', e => {
      if (over) return;
      if (e.target.closest('[data-end]')) return end();
      const cell = e.target.closest('[data-i]'); if (!cell) return; const i = +cell.dataset.i;
      if (sel < 0) { sel = i; return draw(); }
      const adj = Math.abs(Math.floor(sel / N) - Math.floor(i / N)) + Math.abs((sel % N) - (i % N)) === 1;
      if (!adj) { sel = i; return draw(); }
      swap(sel, i);
      if (matches().size) { moves--; resolve(); if (!hasMove()) fresh(); sel = -1; draw(); if (moves <= 0) end(); }
      else { swap(sel, i); sel = -1; draw(); }
    });
    fresh(); draw();
    return () => { over = true; };
  }
});

/* ================= MINI GOLF (fewest strokes wins) ================= */
const G_GOLF = duel({
  id: 'golf', name: 'Mini Golf', icon: '⛳', low: true, desc: '3 holes. Pull back and release to putt. Fewest strokes wins!',
  bot: () => 8 + Math.floor(Math.random() * 8),
  play(box, seed, done) {
    const R = rng(seed), W = 300, H = 460, holes = [];
    for (let h = 0; h < 3; h++) {
      const obs = [], n = 1 + h;
      for (let i = 0; i < n; i++) { const w = 70 + R() * 60; obs.push({ x: 20 + R() * (W - 40 - w), y: 160 + i * (140 / n) + R() * 25, w, h: 16 }); }
      holes.push({ cup: { x: 50 + R() * 200, y: 55 + R() * 35 }, obs });
    }
    let hi = 0, strokes = 0, total = 0, over = false, moving = false, ball = { x: W / 2, y: 410, vx: 0, vy: 0 };
    box.innerHTML = '<div class="card center" id="gh"></div>';
    const hud = $('#gh', box), cv = mkCanvas(box, W, H), c = cv.getContext('2d');
    const sl = sling(cv, () => (moving || over ? null : ball), a => { strokes++; const v = 90 + 560 * a.pow; ball.vx = Math.cos(a.ang) * v; ball.vy = Math.sin(a.ang) * v; moving = true; }, 90);
    const nextHole = () => { total += strokes; strokes = 0; hi++; if (hi >= 3) { over = true; stop(); box.innerHTML = `<div class="card center">Course complete!<br>Total strokes: <b>${total}</b></div>`; done(total); return; } ball = { x: W / 2, y: 410, vx: 0, vy: 0 }; moving = false; };
    const step = dt => {
      const hole = holes[hi], b = ball; b.x += b.vx * dt; b.y += b.vy * dt;
      const sp = Math.hypot(b.vx, b.vy);
      if (sp > 0) { const ns = sp - 150 * dt; if (ns < 8) { b.vx = 0; b.vy = 0; } else { b.vx *= ns / sp; b.vy *= ns / sp; } }
      if (b.x < 8) { b.x = 8; b.vx = Math.abs(b.vx) * 0.8; } if (b.x > W - 8) { b.x = W - 8; b.vx = -Math.abs(b.vx) * 0.8; }
      if (b.y < 8) { b.y = 8; b.vy = Math.abs(b.vy) * 0.8; } if (b.y > H - 8) { b.y = H - 8; b.vy = -Math.abs(b.vy) * 0.8; }
      for (const o of hole.obs) {
        const cx = clamp(b.x, o.x, o.x + o.w), cy = clamp(b.y, o.y, o.y + o.h); let dx = b.x - cx, dy = b.y - cy; const d = Math.hypot(dx, dy);
        if (d < 8) { if (d === 0) { dx = 0; dy = -1; } else { dx /= d; dy /= d; } b.x = cx + dx * 8.1; b.y = cy + dy * 8.1; const dot = b.vx * dx + b.vy * dy; if (dot < 0) { b.vx -= 1.8 * dot * dx; b.vy -= 1.8 * dot * dy; } }
      }
      if (Math.hypot(b.x - hole.cup.x, b.y - hole.cup.y) < 11 && sp < 340) { nextHole(); return; }
      if (moving && !b.vx && !b.vy) { moving = false; if (strokes >= 6) nextHole(); }
    };
    const stop = anim(dt => {
      if (over) return;
      if (moving) for (let i = 0; i < 4 && !over; i++) step(dt / 4);
      if (over) return;
      const hole = holes[hi];
      hud.innerHTML = `Hole <b>${hi + 1}</b>/3 · Strokes <b>${strokes}</b> (max 6) · Total <b>${total + strokes}</b>`;
      c.fillStyle = '#2e8b3e'; c.fillRect(0, 0, W, H); c.strokeStyle = '#1b5a26'; c.lineWidth = 8; c.strokeRect(0, 0, W, H);
      c.fillStyle = '#7a4a1c'; hole.obs.forEach(o => c.fillRect(o.x, o.y, o.w, o.h));
      c.fillStyle = '#000'; c.beginPath(); c.arc(hole.cup.x, hole.cup.y, 10, 0, 6.283); c.fill();
      c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.moveTo(hole.cup.x, hole.cup.y); c.lineTo(hole.cup.x, hole.cup.y - 28); c.stroke(); c.fillStyle = '#ff4d8d'; c.fillRect(hole.cup.x, hole.cup.y - 28, 14, 9);
      c.fillStyle = '#fff'; c.beginPath(); c.arc(ball.x, ball.y, 7, 0, 6.283); c.fill();
      if (!moving && sl.aim) { c.strokeStyle = '#ffd54a'; c.lineWidth = 3; c.setLineDash([5, 5]); c.beginPath(); c.moveTo(ball.x, ball.y); c.lineTo(ball.x + Math.cos(sl.aim.ang) * (30 + sl.aim.pow * 170), ball.y + Math.sin(sl.aim.ang) * (30 + sl.aim.pow * 170)); c.stroke(); c.setLineDash([]); }
    });
    return () => { over = true; stop(); };
  }
});

/* ================= BOUNCE (brick breaker) ================= */
const G_BOUNCE = duel({
  id: 'bounce', name: 'Bounce', icon: '🏐', desc: '45 seconds. Move the paddle, bounce the ball and break bricks!',
  bot: () => 160 + Math.floor(Math.random() * 190),
  play(box, seed, done) {
    const R = rng(seed), W = 300, H = 440, cols = ['#ff4d8d', '#ff8a3d', '#ffd54a', '#3ddc97', '#4aa3ff'], bricks = [];
    for (let r = 0; r < 5; r++) for (let c = 0; c < 6; c++) if (R() > 0.1) bricks.push({ x: c * 50 + 3, y: 40 + r * 22, w: 44, h: 16, col: cols[r] });
    let pad = { x: W / 2, w: 70, y: H - 30 }, ball = { x: W / 2, y: H - 46, vx: 0, vy: 0, on: true, t: 0 }, lives = 3, time = 45, score = 0, over = false;
    box.innerHTML = '<div class="card center" id="gh"></div>';
    const hud = $('#gh', box), cv = mkCanvas(box, W, H), c = cv.getContext('2d');
    const move = e => { pad.x = clamp(ptr(cv, e).x, pad.w / 2, W - pad.w / 2); };
    cv.addEventListener('pointerdown', e => { try { cv.setPointerCapture(e.pointerId); } catch (x) {} move(e); e.preventDefault(); });
    cv.addEventListener('pointermove', move);
    const finish = () => { if (over) return; over = true; stop(); const bonus = bricks.length ? 0 : Math.round(time) * 5; box.innerHTML = `<div class="card center">Round over!<br>Score: <b>${score + bonus}</b></div>`; done(score + bonus); };
    const stop = anim(dt => {
      if (over) return;
      time -= dt; if (time <= 0) return finish();
      if (ball.on) { ball.x = pad.x; ball.y = pad.y - 16; ball.t += dt; if (ball.t > 0.7) { ball.on = false; ball.vx = (R() - 0.5) * 200; ball.vy = -270; } }
      else for (let k = 0; k < 3; k++) {
        const d = dt / 3; ball.x += ball.vx * d; ball.y += ball.vy * d;
        if (ball.x < 6) { ball.x = 6; ball.vx = Math.abs(ball.vx); } if (ball.x > W - 6) { ball.x = W - 6; ball.vx = -Math.abs(ball.vx); } if (ball.y < 6) { ball.y = 6; ball.vy = Math.abs(ball.vy); }
        if (ball.vy > 0 && ball.y + 6 >= pad.y && ball.y - 6 <= pad.y + 10 && Math.abs(ball.x - pad.x) < pad.w / 2 + 6) { const sp = Math.min(470, Math.hypot(ball.vx, ball.vy) * 1.02); const f = clamp((ball.x - pad.x) / (pad.w / 2), -1, 1); ball.vx = f * sp * 0.8; ball.vy = -Math.sqrt(Math.max(sp * sp - ball.vx * ball.vx, 90000)); ball.y = pad.y - 6; }
        for (const b of bricks) if (ball.x + 6 > b.x && ball.x - 6 < b.x + b.w && ball.y + 6 > b.y && ball.y - 6 < b.y + b.h) {
          const ox = Math.min(ball.x + 6 - b.x, b.x + b.w - (ball.x - 6)), oy = Math.min(ball.y + 6 - b.y, b.y + b.h - (ball.y - 6));
          if (ox < oy) ball.vx = -ball.vx; else ball.vy = -ball.vy;
          bricks.splice(bricks.indexOf(b), 1); score += 10; break;
        }
        if (!bricks.length) return finish();
        if (ball.y > H + 10) { lives--; if (lives <= 0) return finish(); ball = { x: pad.x, y: pad.y - 16, vx: 0, vy: 0, on: true, t: 0 }; break; }
      }
      hud.innerHTML = `Time <b>${Math.ceil(time)}</b> · Lives <b>${'❤️'.repeat(lives)}</b> · Score <b>${score}</b>`;
      c.fillStyle = '#10102a'; c.fillRect(0, 0, W, H);
      bricks.forEach(b => { c.fillStyle = b.col; c.fillRect(b.x, b.y, b.w, b.h); });
      c.fillStyle = '#fff'; c.fillRect(pad.x - pad.w / 2, pad.y, pad.w, 10);
      c.fillStyle = '#ffd54a'; c.beginPath(); c.arc(ball.x, ball.y, 6, 0, 6.283); c.fill();
    });
    return () => { over = true; stop(); };
  }
});

/* ================= FINAL LIST (same order as the Playmates design sheet; 18+ always last) ================= */
G_BOT.name = 'Brawlbots'; G_BANK.name = 'Bankroll'; G_BG.name = 'Backgammon'; G_RV.name = 'Reversi';
const META = {
  pool: ['sports', '2 Players'], bowl: ['sports', '2 Players'], monster: ['puzzle', '2 Players'], bots: ['arcade', '2 Players'], bounce: ['arcade', '2 Players'],
  dice: ['arcade', '2 Players'], golf: ['sports', '2 Players'], tsoc: ['sports', '2 Players'], darts: ['sports', '2 Players'], carrom: ['board', '2 Players'],
  word: ['puzzle', '2 Players'], plox: ['puzzle', '2 Players'], disco: ['arcade', '2 Players'], arch: ['sports', '2 Players'], skee: ['arcade', '2 Players'],
  c4: ['board', '2 Players'], dom: ['board', '2 Players'], bg: ['board', '2 Players'], sea: ['board', '2 Players'], bloko: ['puzzle', '2 Players'],
  db: ['board', '2 Players'], hoop: ['sports', '2 Players'], ck: ['board', '2 Players'], rv: ['board', '2 Players'], ttt: ['board', '2 Players'],
  mem: ['puzzle', '2 Players'], ludo: ['board', '2 Players'], bank: ['arcade', '2 Players'],
  quiz: ['adult', '2 Players'], pun: ['adult', '2 Players'], int: ['adult', '2 Players']
};
const ALL_GAMES = [G_POOL, G_BOWL2, G_MEM, G_BOT, G_BOUNCE, G_DICE, G_GOLF, G_TSOC2, G_DART2, G_CARROM, G_WORD, G_PLOX, G_DISCO, G_ARCH2, G_SKEE2, G_C4, G_DOM, G_BG, G_SEA, G_BLOKO, G_DB, G_HOOP2, G_CK, G_RV, G_TTT, G_LUDO, G_BANK, G_QUIZ, G_PUN, G_INT];
ALL_GAMES.forEach(g => { const m = META[g.id]; g.cat = m[0]; g.players = m[1]; });
const READY = ['ludo', 'pool', 'ttt', 'monster', 'bowl', 'darts', 'carrom', 'golf', 'tsoc', 'hoop', 'arch', 'skee', 'ck', 'c4', 'rv', 'db'];   // fully finished games; the rest stay "Coming soon" until they are improved
ALL_GAMES.forEach(g => { g.soon = !g.adult && !READY.includes(g.id); });
const GAMES = [...READY.map(i => ALL_GAMES.find(g => g.id === i)), ...ALL_GAMES.filter(g => g.soon), ...ALL_GAMES.filter(g => g.adult)];
