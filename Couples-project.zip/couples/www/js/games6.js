/* Playmates - Wave 2: Archery, Darts, Basketball, Skee Ball, Bowling, Table Soccer (+ Match Monster rename). Mini Golf and Carrom are upgraded in games4.js */

const cvStart = (box, W, H) => { box.innerHTML = '<div class="card center" id="gh"></div>'; const hud = $('#gh', box), cv = mkCanvas(box, W, H); return { hud, cv, c: cv.getContext('2d') }; };
const cvEnd = (box, msg, score, done) => { box.innerHTML = `<div class="card center">${msg}<br>Score: <b>${score}</b></div>`; done(score); };
const rot = n => ((n % 1) + 1) % 1;

/* ================= ARCHERY ================= */
const G_ARCH2 = duel({
  id: 'arch', name: 'Archery', icon: '🏹', desc: '3 rounds, 3 arrows each. Tap to shoot and watch the wind!',
  bot: () => 42 + Math.floor(Math.random() * 28),
  play(box, seed, done) {
    const R = rng(seed), W = 300, H = 430, TX = 150, TY = 175, { hud, cv, c } = cvStart(box, W, H);
    let n = 0, total = 0, t = 0, over = false, hits = [], msg = 'Tap to shoot!', wind = (R() - 0.5) * 70, last = 0;
    const ret = () => ({ x: TX + Math.sin(t * 1.9) * 62 + Math.sin(t * 3.1) * 20, y: TY + 25 + Math.cos(t * 1.4) * 55 + Math.sin(t * 2.6) * 18 });
    cv.addEventListener('pointerdown', e => {
      e.preventDefault(); if (over || performance.now() - last < 350) return; last = performance.now();
      const r = ret(), x = r.x + wind * 0.55, y = r.y + 14, d = Math.hypot(x - TX, y - TY), pts = d > 140 ? 0 : Math.max(1, 10 - Math.floor(d / 14));
      hits.push({ x, y }); total += pts; n++; msg = pts >= 10 ? '🎯 Bullseye! 10' : pts ? pts + ' points' : 'Missed!';
      if (n % 3 === 0) wind = (R() - 0.5) * 70;
      if (n >= 9) { over = true; stop(); cvEnd(box, msg, total, done); }
    });
    const stop = anim(dt => {
      if (over) return; t += dt; const r = ret();
      hud.innerHTML = `Round <b>${Math.min(3, Math.floor(n / 3) + 1)}</b>/3 · Arrow <b>${n % 3 + 1}</b>/3 · Score <b>${total}</b><br><span class="mut">${msg}</span>`;
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#8fd3ff'); g.addColorStop(0.45, '#bfe8a5'); g.addColorStop(1, '#4c9a3a'); c.fillStyle = g; c.fillRect(0, 0, W, H);
      ['#fff', '#222', '#2a7de1', '#e03a3a', '#f5c400'].forEach((col, i) => { c.fillStyle = col; c.beginPath(); c.arc(TX, TY, 140 - i * 28 - (i > 0 ? 0 : 0), 0, 6.283); c.fill(); });
      c.strokeStyle = '#0003'; c.lineWidth = 1; for (let k = 1; k <= 10; k++) { c.beginPath(); c.arc(TX, TY, k * 14, 0, 6.283); c.stroke(); }
      hits.forEach(h => { c.strokeStyle = '#3b2412'; c.lineWidth = 3; c.beginPath(); c.moveTo(h.x, h.y); c.lineTo(h.x - 14, h.y + 22); c.stroke(); c.fillStyle = '#e03a3a'; c.beginPath(); c.arc(h.x, h.y, 3, 0, 6.283); c.fill(); });
      c.strokeStyle = '#fff'; c.lineWidth = 2.5; c.beginPath(); c.arc(r.x, r.y, 15, 0, 6.283); c.moveTo(r.x - 22, r.y); c.lineTo(r.x + 22, r.y); c.moveTo(r.x, r.y - 22); c.lineTo(r.x, r.y + 22); c.stroke();
      c.fillStyle = '#0008'; c.fillRect(10, H - 40, 140, 28); c.fillStyle = '#fff'; c.font = 'bold 14px sans-serif'; c.textAlign = 'left'; c.fillText((wind > 0 ? '→ ' : '← ') + 'Wind ' + Math.abs(Math.round(wind / 7)) + ' mph', 18, H - 21);
    });
    return () => { over = true; stop(); };
  }
});

/* ================= DARTS (real dartboard scoring) ================= */
const DB_ORDER = [20, 1, 18, 4, 13, 6, 10, 15, 2, 17, 3, 19, 7, 16, 8, 11, 14, 9, 12, 5];
function dartScore(dx, dy, R) {
  const r = Math.hypot(dx, dy) / R;
  if (r < 0.04) return 50; if (r < 0.095) return 25; if (r > 1) return 0;
  const a = Math.atan2(dx, -dy), idx = Math.floor(((a + 6.283185 + Math.PI / 20) % 6.283185) / (Math.PI / 10)), v = DB_ORDER[idx];
  return r > 0.93 ? v * 2 : (r > 0.58 && r < 0.67) ? v * 3 : v;
}
const G_DART2 = duel({
  id: 'darts', name: 'Darts', icon: '🎯', desc: '9 darts. Tap to throw. Triples, doubles and the bullseye score big!',
  bot: () => 110 + Math.floor(Math.random() * 100),
  play(box, seed, done) {
    const W = 300, H = 420, CX = 150, CY = 190, BR = 135, { hud, cv, c } = cvStart(box, W, H);
    let n = 0, total = 0, t = 0, over = false, darts = [], msg = 'Tap to throw!', last = 0;
    const ret = () => ({ x: CX + Math.sin(t * 2.3) * 70 + Math.cos(t * 3.7) * 28, y: CY + Math.cos(t * 1.9) * 70 + Math.sin(t * 3.3) * 25 });
    cv.addEventListener('pointerdown', e => {
      e.preventDefault(); if (over || performance.now() - last < 300) return; last = performance.now();
      const r = ret(), x = r.x + (Math.random() - 0.5) * 16, y = r.y + 10 + (Math.random() - 0.5) * 16, s = dartScore(x - CX, y - CY, BR);
      darts.push({ x, y }); total += s; n++; msg = s === 50 ? '🎯 BULLSEYE! 50' : s ? s + ' points' : 'Missed the board';
      if (n >= 9) { over = true; stop(); cvEnd(box, msg, total, done); }
    });
    const stop = anim(dt => {
      if (over) return; t += dt; const r = ret();
      hud.innerHTML = `Dart <b>${n + 1}</b>/9 · Total <b>${total}</b><br><span class="mut">${msg}</span>`;
      c.fillStyle = '#6b3d22'; c.fillRect(0, 0, W, H); c.strokeStyle = '#00000025'; c.lineWidth = 2; for (let y = 0; y < H; y += 26) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
      c.fillStyle = '#111'; c.beginPath(); c.arc(CX, CY, BR + 14, 0, 6.283); c.fill();
      for (let i = 0; i < 20; i++) {
        const a0 = -Math.PI / 2 - Math.PI / 20 + i * Math.PI / 10, a1 = a0 + Math.PI / 10, dark = i % 2 === 0;
        const ring = (r0, r1, col) => { c.fillStyle = col; c.beginPath(); c.arc(CX, CY, BR * r1, a0, a1); c.arc(CX, CY, BR * r0, a1, a0, true); c.closePath(); c.fill(); };
        ring(0.095, 0.58, dark ? '#16110d' : '#f1e3bc'); ring(0.58, 0.67, dark ? '#c4252b' : '#1f8a47'); ring(0.67, 0.93, dark ? '#16110d' : '#f1e3bc'); ring(0.93, 1, dark ? '#c4252b' : '#1f8a47');
        c.fillStyle = '#fff'; c.font = 'bold 12px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; const am = (a0 + a1) / 2; c.fillText(DB_ORDER[i], CX + Math.cos(am) * (BR + 8), CY + Math.sin(am) * (BR + 8));
      }
      c.fillStyle = '#1f8a47'; c.beginPath(); c.arc(CX, CY, BR * 0.095, 0, 6.283); c.fill(); c.fillStyle = '#c4252b'; c.beginPath(); c.arc(CX, CY, BR * 0.04, 0, 6.283); c.fill();
      darts.forEach(d => { c.strokeStyle = '#ddd'; c.lineWidth = 2; c.beginPath(); c.moveTo(d.x, d.y); c.lineTo(d.x + 8, d.y + 22); c.stroke(); c.fillStyle = '#ffd54a'; c.fillRect(d.x + 3, d.y + 16, 10, 8); c.fillStyle = '#fff'; c.beginPath(); c.arc(d.x, d.y, 2.5, 0, 6.283); c.fill(); });
      c.strokeStyle = '#ffd54a'; c.lineWidth = 2.5; c.beginPath(); c.arc(r.x, r.y, 12, 0, 6.283); c.moveTo(r.x - 18, r.y); c.lineTo(r.x - 6, r.y); c.moveTo(r.x + 6, r.y); c.lineTo(r.x + 18, r.y); c.moveTo(r.x, r.y - 18); c.lineTo(r.x, r.y - 6); c.moveTo(r.x, r.y + 6); c.lineTo(r.x, r.y + 18); c.stroke();
    });
    return () => { over = true; stop(); };
  }
});

/* ================= BASKETBALL ================= */
const G_HOOP2 = duel({
  id: 'hoop', name: 'Basketball', icon: '🏀', desc: '10 shots. Pull back and release to shoot. The hoop starts moving!',
  bot: () => 12 + Math.floor(Math.random() * 12),
  play(box, seed, done) {
    const W = 300, H = 470, BX = 150, BY = 410, G = 950, { hud, cv, c } = cvStart(box, W, H);
    let shots = 0, score = 0, t = 0, over = false, ball = null, hx = 150, msg = 'Pull back and release!', swish = true, scored = false;
    const hoopX = () => shots < 3 ? 150 : 150 + Math.sin(t * (shots < 6 ? 0.9 : 1.6)) * 72;
    const vel = a => { const v = 380 + 560 * a.pow; return { vx: Math.cos(a.ang) * v, vy: Math.sin(a.ang) * v }; };
    const sl = sling(cv, () => ball ? null : { x: BX, y: BY }, a => { const v = vel(a); ball = { x: BX, y: BY, vx: v.vx, vy: v.vy, py: BY }; swish = true; scored = false; }, 90);
    const next = () => { ball = null; shots++; if (shots >= 10) { over = true; stop(); cvEnd(box, msg, score, done); } };
    const stepBall = dt => {
      const b = ball; b.py = b.y; b.x += b.vx * dt; b.y += b.vy * dt; b.vy += G * dt;
      if (b.x < 10 || b.x > W - 10) b.vx *= -0.6, b.x = clamp(b.x, 10, W - 10);
      if (b.vy < 0 && b.y < 88 && b.y > 62 && Math.abs(b.x - hx) < 44) { b.vy = Math.abs(b.vy) * 0.35; b.y = 89; swish = false; }
      for (const px of [hx - 28, hx + 28]) { const dx = b.x - px, dy = b.y - 126, d = Math.hypot(dx, dy); if (d < 15 && d > 0) { const nx = dx / d, ny = dy / d, dot = b.vx * nx + b.vy * ny; if (dot < 0) { b.vx -= 1.55 * dot * nx; b.vy -= 1.55 * dot * ny; } b.x = px + nx * 15.1; b.y = 126 + ny * 15.1; swish = false; } }
      if (!scored && b.py < 126 && b.y >= 126 && b.vy > 0 && Math.abs(b.x - hx) < 22) { scored = true; const p = swish ? 3 : 2; score += p; msg = swish ? '🏀 Swish! +3' : '🏀 Basket! +2'; }
      if (b.y > H + 30 || (b.y > 440 && Math.abs(b.vy) < 40)) { if (!scored) msg = 'Missed!'; next(); }
    };
    const stop = anim(dt => {
      if (over) return; t += dt; hx = hoopX();
      if (ball) for (let i = 0; i < 4 && ball; i++) stepBall(dt / 4);
      if (over) return;
      hud.innerHTML = `Shot <b>${Math.min(shots + 1, 10)}</b>/10 · Score <b>${score}</b><br><span class="mut">${msg}</span>`;
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#3b2a6b'); g.addColorStop(1, '#7a4a2a'); c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.fillStyle = '#b98a54'; c.fillRect(0, 430, W, 40);
      c.fillStyle = '#e8eaf0'; c.fillRect(hx - 42, 52, 84, 46); c.strokeStyle = '#d33'; c.lineWidth = 3; c.strokeRect(hx - 17, 72, 34, 24);
      c.strokeStyle = '#ff6a2a'; c.lineWidth = 5; c.beginPath(); c.moveTo(hx - 28, 126); c.lineTo(hx + 28, 126); c.stroke();
      c.strokeStyle = '#ffffffaa'; c.lineWidth = 1.5; for (let k = 0; k < 5; k++) { c.beginPath(); c.moveTo(hx - 26 + k * 13, 128); c.lineTo(hx - 16 + k * 8, 160); c.stroke(); }
      if (!ball && sl.aim) { const v = vel(sl.aim); let x = BX, y = BY, vx = v.vx, vy = v.vy; c.fillStyle = '#fff'; for (let k = 0; k < 14; k++) { x += vx * 0.045; y += vy * 0.045; vy += G * 0.045; c.globalAlpha = 1 - k / 16; c.beginPath(); c.arc(x, y, 3, 0, 6.283); c.fill(); } c.globalAlpha = 1; }
      const bb = ball || { x: BX, y: BY }; c.fillStyle = '#f08a2a'; c.beginPath(); c.arc(bb.x, bb.y, 15, 0, 6.283); c.fill(); c.strokeStyle = '#6b2e0a'; c.lineWidth = 2; c.stroke();
      c.beginPath(); c.moveTo(bb.x - 15, bb.y); c.lineTo(bb.x + 15, bb.y); c.moveTo(bb.x, bb.y - 15); c.lineTo(bb.x, bb.y + 15); c.stroke();
      if (ball) { c.strokeStyle = '#ff6a2a'; c.lineWidth = 3; c.beginPath(); c.moveTo(hx - 28, 126); c.lineTo(hx + 28, 126); c.stroke(); }
    });
    return () => { over = true; stop(); };
  }
});

/* ================= SKEE BALL ================= */
const SK_RINGS = [{ x: 150, y: 60, r: 15, v: 50 }, { x: 78, y: 80, r: 17, v: 40 }, { x: 222, y: 80, r: 17, v: 40 }, { x: 150, y: 108, r: 21, v: 30 }, { x: 70, y: 135, r: 22, v: 20 }, { x: 230, y: 135, r: 22, v: 20 }, { x: 150, y: 160, r: 26, v: 10 }];
const G_SKEE2 = duel({
  id: 'skee', name: 'Skee Ball', icon: '🎱', desc: '9 balls. Pull back and release. Roll up the ramp into the high rings!',
  bot: () => 90 + Math.floor(Math.random() * 120),
  play(box, seed, done) {
    const W = 300, H = 470, BX = 150, BY = 430, EDGE = 230, { hud, cv, c } = cvStart(box, W, H);
    let n = 0, score = 0, over = false, ball = null, msg = 'Pull back and release!', land = null;
    const sl = sling(cv, () => ball ? null : { x: BX, y: BY }, a => { const v = 150 + 330 * a.pow; ball = { x: BX, y: BY, vx: Math.cos(a.ang) * v, vy: Math.sin(a.ang) * v, hop: null }; land = null; }, 90);
    const finish = (pts, text) => { score += pts; msg = text; n++; ball = null; if (n >= 9) { over = true; stop(); cvEnd(box, text, score, done); } };
    const step = dt => {
      const b = ball;
      if (b.hop) { b.hop.t += dt; const k = Math.min(1, b.hop.t / 0.45); b.x = b.hop.x0 + (b.hop.x1 - b.hop.x0) * k; b.y = b.hop.y0 + (b.hop.y1 - b.hop.y0) * k; b.z = Math.sin(Math.PI * k) * 40; if (k >= 1) { const r = SK_RINGS.find(q => Math.hypot(b.x - q.x, b.y - q.y) < q.r + 2); finish(r ? r.v : 0, r ? '+' + r.v + ' points!' : 'Missed the rings'); } return; }
      b.x += b.vx * dt; b.y += b.vy * dt; const sp = Math.hypot(b.vx, b.vy), ns = sp - 85 * dt;
      if (ns < 12) { finish(0, 'Too weak. Roll harder!'); return; } b.vx *= ns / sp; b.vy *= ns / sp;
      if (b.x < 46) { b.x = 46; b.vx = Math.abs(b.vx) * 0.6; } if (b.x > W - 46) { b.x = W - 46; b.vx = -Math.abs(b.vx) * 0.6; }
      if (b.y <= EDGE) { const k = ns; b.hop = { t: 0, x0: b.x, y0: b.y, x1: clamp(b.x + b.vx / sp * k * 0.0 + (b.vx / (sp || 1)) * k * 0.15, 20, W - 20), y1: EDGE - k * 0.62 }; }
    };
    const stop = anim(dt => {
      if (over) return;
      if (ball) step(dt);
      if (over) return;
      hud.innerHTML = `Ball <b>${Math.min(n + 1, 9)}</b>/9 · Score <b>${score}</b><br><span class="mut">${msg}</span>`;
      c.fillStyle = '#3a1f12'; c.fillRect(0, 0, W, H);
      c.fillStyle = '#7a2a1a'; c.fillRect(0, 0, W, 190);
      SK_RINGS.forEach(q => { c.fillStyle = '#e8c27a'; c.beginPath(); c.arc(q.x, q.y, q.r + 4, 0, 6.283); c.fill(); c.fillStyle = '#1a0d08'; c.beginPath(); c.arc(q.x, q.y, q.r - 1, 0, 6.283); c.fill(); c.fillStyle = '#fff'; c.font = 'bold 13px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(q.v, q.x, q.y); });
      c.fillStyle = '#c99a5b'; c.beginPath(); c.moveTo(52, EDGE); c.lineTo(W - 52, EDGE); c.lineTo(W - 18, H); c.lineTo(18, H); c.closePath(); c.fill();
      c.strokeStyle = '#8a5a2b'; c.lineWidth = 2; for (let k = 1; k < 6; k++) { c.beginPath(); c.moveTo(52 + k * (W - 104) / 6, EDGE); c.lineTo(18 + k * (W - 36) / 6, H); c.stroke(); }
      c.fillStyle = '#d33'; c.fillRect(46, EDGE - 4, W - 92, 5);
      if (!ball && sl.aim) { c.strokeStyle = '#fff'; c.setLineDash([6, 6]); c.lineWidth = 2; c.beginPath(); c.moveTo(BX, BY); c.lineTo(BX + Math.cos(sl.aim.ang) * (50 + sl.aim.pow * 200), BY + Math.sin(sl.aim.ang) * (50 + sl.aim.pow * 200)); c.stroke(); c.setLineDash([]); }
      const bb = ball || { x: BX, y: BY, z: 0 }, z = bb.z || 0; c.fillStyle = '#0004'; c.beginPath(); c.arc(bb.x + 3, bb.y + 4, 11, 0, 6.283); c.fill();
      const g = c.createRadialGradient(bb.x - 4, bb.y - z - 4, 2, bb.x, bb.y - z, 12); g.addColorStop(0, '#ff8a7a'); g.addColorStop(1, '#a01818'); c.fillStyle = g; c.beginPath(); c.arc(bb.x, bb.y - z, 12, 0, 6.283); c.fill();
    });
    return () => { over = true; stop(); };
  }
});

/* ================= BOWLING (top-down lane, real pin physics) ================= */
const BW = { w: 240, h: 520, bx: 120, by: 470, rb: 11, rp: 6.5 };
const bwPins = () => [[0, 0], [-1, 1], [1, 1], [-2, 2], [0, 2], [2, 2], [-3, 3], [-1, 3], [1, 3], [3, 3]].map(([c, r]) => ({ x: 120 + c * 10.5, y: 126 - r * 18, ox: 120 + c * 10.5, oy: 126 - r * 18 }));
const bwScore = rolls => {
  let tot = 0, i = 0; for (let f = 0; f < 5; f++) {
    const a = rolls[i]; if (a == null) break;
    if (a === 10) { tot += 10 + (rolls[i + 1] || 0) + (rolls[i + 2] || 0); i += 1; }
    else { const b = rolls[i + 1] || 0; tot += a + b + (a + b === 10 ? (rolls[i + 2] || 0) : 0); i += 2; }
  } return tot;
};
const G_BOWL2 = duel({
  id: 'bowl', name: 'Bowling', icon: '🎳', desc: '5 frames, 2 rolls each. Slide to place, pull back and release to bowl. Strikes and spares give bonuses!',
  bot: () => 62 + Math.floor(Math.random() * 50),
  play(box, seed, done) {
    const { hud, cv, c } = cvStart(box, BW.w, BW.h);
    const sld = document.createElement('input'); sld.type = 'range'; sld.min = 0; sld.max = 100; sld.value = 50; box.appendChild(sld);
    let frame = 0, roll = 0, rolls = [], pins = bwPins(), P = null, over = false, msg = 'Slide to place the ball, then pull back and release!', pinsDown = 0, down = [];
    const bx = () => 46 + sld.value / 100 * (BW.w - 92);
    const sl = sling(cv, () => P ? null : { x: bx(), y: BW.by }, a => {
      const v = 260 + 560 * a.pow, balls = [{ id: 0, x: bx(), y: BW.by, vx: Math.cos(a.ang) * v, vy: Math.sin(a.ang) * v, a: 1, r: BW.rb, m: 4 }];
      pins.forEach((p, i) => { if (!p.gone) balls.push({ id: i + 1, x: p.x, y: p.y, vx: 0, vy: 0, a: 1, r: BW.rp, m: 1 }); else balls.push({ id: i + 1, x: p.x, y: p.y, vx: 0, vy: 0, a: 0, r: BW.rp, m: 1 }); });
      P = { w: BW.w, h: BW.h, fr: 18, rest: 0.55, killTop: true, balls };
    }, 90);
    const settle = () => {
      let knocked = 0; P.balls.forEach(b => { if (b.id === 0) return; const p = pins[b.id - 1]; if (p.gone) return; if (!b.a || Math.hypot(b.x - p.ox, b.y - p.oy) > 8) { p.gone = true; knocked++; } else { p.x = b.x; p.y = b.y; } });
      P = null; rolls.push(knocked); const left = pins.filter(p => !p.gone).length;
      msg = knocked === 10 && roll === 0 ? '🎳 STRIKE!' : (left === 0 && roll === 1) ? '🎳 Spare!' : knocked + ' pins down';
      if (roll === 0 && knocked < 10) roll = 1; else { frame++; roll = 0; pins = bwPins(); if (roll === 0 && rolls[rolls.length - 1] === 10 && false) {} }
      if (frame >= 5) { over = true; stop(); const sc = bwScore(rolls); cvEnd(box, msg, sc, done); }
    };
    const stop = anim(dt => {
      if (over) return;
      if (P) { const n = Math.ceil(dt * 150); for (let i = 0; i < n; i++) { Phys.step(P, 1 / 150); } if (!Phys.moving(P)) settle(); }
      if (over) return;
      hud.innerHTML = `Frame <b>${Math.min(frame + 1, 5)}</b>/5 · Roll <b>${roll + 1}</b> · Score <b>${bwScore(rolls)}</b><br><span class="mut">${msg}</span>`;
      const c2 = c; c2.fillStyle = '#2a1608'; c2.fillRect(0, 0, BW.w, BW.h);
      c2.fillStyle = '#4a4a55'; c2.fillRect(16, 0, 18, BW.h); c2.fillRect(BW.w - 34, 0, 18, BW.h);
      const g = c2.createLinearGradient(34, 0, BW.w - 34, 0); g.addColorStop(0, '#d9a45a'); g.addColorStop(0.5, '#efc27a'); g.addColorStop(1, '#d9a45a'); c2.fillStyle = g; c2.fillRect(34, 0, BW.w - 68, BW.h);
      c2.strokeStyle = '#a8742f55'; c2.lineWidth = 1; for (let x = 44; x < BW.w - 34; x += 14) { c2.beginPath(); c2.moveTo(x, 0); c2.lineTo(x, BW.h); c2.stroke(); }
      c2.fillStyle = '#b5532a'; for (let k = 0; k < 7; k++) { c2.beginPath(); c2.moveTo(bx() - 70 + k * 23 + 120 - 120, 400); c2.lineTo(120 - 69 + k * 23 - 4, 405); c2.lineTo(120 - 69 + k * 23 + 4, 405); c2.fill(); }
      const drawPin = (x, y) => { c2.fillStyle = '#0003'; c2.beginPath(); c2.arc(x + 2, y + 2, BW.rp, 0, 6.283); c2.fill(); c2.fillStyle = '#fff'; c2.beginPath(); c2.arc(x, y, BW.rp, 0, 6.283); c2.fill(); c2.fillStyle = '#d33'; c2.beginPath(); c2.arc(x, y, 3, 0, 6.283); c2.fill(); };
      if (P) P.balls.forEach(b => { if (b.id && b.a) drawPin(b.x, b.y); }); else pins.forEach(p => { if (!p.gone) drawPin(p.x, p.y); });
      const bb = P ? P.balls[0] : { x: bx(), y: BW.by, a: 1 };
      if (bb.a) { const gb = c2.createRadialGradient(bb.x - 3, bb.y - 3, 1, bb.x, bb.y, BW.rb); gb.addColorStop(0, '#ff6a6a'); gb.addColorStop(1, '#8a0f0f'); c2.fillStyle = gb; c2.beginPath(); c2.arc(bb.x, bb.y, BW.rb, 0, 6.283); c2.fill(); }
      if (!P && sl.aim) { c2.strokeStyle = '#fff'; c2.setLineDash([6, 6]); c2.lineWidth = 2; c2.beginPath(); c2.moveTo(bx(), BW.by); c2.lineTo(bx() + Math.cos(sl.aim.ang) * 330, BW.by + Math.sin(sl.aim.ang) * 330); c2.stroke(); c2.setLineDash([]); }
    });
    return () => { over = true; stop(); };
  }
});

/* ================= TABLE SOCCER (flick caps, turn-based) ================= */
const TS = { w: 300, h: 460 };
const tsForm = () => [[150, 230], [70, 370], [230, 370], [150, 410], [70, 90], [230, 90], [150, 50]].map(([x, y]) => [x, y, 0, 0, 1]);
const tsOwn = seat => seat === 0 ? [1, 2, 3] : [4, 5, 6];
const tsGoals = [{ x: 150, y: 0, r: 30 }, { x: 150, y: 460, r: 30 }];
const G_TSOC2 = physGame({
  id: 'tsoc', name: 'Table Soccer', icon: '⚽', desc: 'Flick your caps to hit the ball into the goal. First to 3 goals wins!', sym: ['🔴', '🔵'],
  w: TS.w, h: TS.h, fr: 170, rest: 0.9, pockets: tsGoals, r: i => i === 0 ? 8 : 14, pull: 80, pickCap: (s, R, p) => {
    let best = null, bd = 30; tsOwn(R.seat).forEach(i => { const q = s.b[i], d = Math.hypot(q[0] - p.x, q[1] - p.y); if (d < bd) { bd = d; best = i; } }); return best;
  },
  init: () => ({ b: tsForm(), sc: [0, 0], turn: 0, winner: null, n: 0, msg: '' }),
  prep: (s, m, seat) => ({ ang: +m.ang, pow: clamp(+m.pow || 0, 0, 1), k: tsOwn(seat).includes(m.k) ? m.k : tsOwn(seat)[0] }),
  valid: (s, m, seat) => s.winner == null && s.turn === seat && isFinite(m.ang) && isFinite(m.pow),
  launch(P, m) { const q = P.balls[m.k]; const v = 120 + 720 * m.pow; q.vx = Math.cos(m.ang) * v; q.vy = Math.sin(m.ang) * v; },
  after(s, ev, seat) {
    s.msg = '';
    const scored = ev.includes(0) ? (s.b[0][1] < TS.h / 2 ? 0 : 1) : -1;
    if (scored >= 0) {
      s.sc[scored]++; s.msg = '⚽ GOAL!'; s.b = tsForm();
      if (s.sc[scored] >= 3) { s.winner = scored; return; }
      s.turn = 1 - scored; return;
    }
    ev.forEach(i => { if (i > 0) { const orig = tsForm()[i]; s.b[i] = [orig[0], orig[1], 0, 0, 1]; } });
    s.turn = 1 - seat;
    if (s.n >= 36) s.winner = s.sc[0] === s.sc[1] ? 'draw' : (s.sc[0] > s.sc[1] ? 0 : 1);
  },
  shooter: (s, R) => { if (s.winner != null) return null; const own = tsOwn(R.seat); if (R.sel == null || !own.includes(R.sel)) R.sel = own[0]; const q = s.b[R.sel]; return { x: q[0], y: q[1] }; },
  hud: (s, seat) => `<div class="scorebar"><div class="p0">🔴 ${s.sc[0]}</div><div class="mut">${esc(s.msg || (s.turn === seat ? 'Tap a cap, pull back, release' : 'Opponent’s shot'))}</div><div class="p1">🔵 ${s.sc[1]}</div></div>`,
  cands(s, seat) {
    const out = [], ball = s.b[0], gy = seat === 0 ? 0 : TS.h;
    for (const k of tsOwn(seat)) {
      const q = s.b[k];
      for (const pw of [0.5, 0.75, 1]) { out.push({ k, ang: Math.atan2(ball[1] - q[1], ball[0] - q[0]), pow: pw }); out.push({ k, ang: Math.atan2(gy - q[1], 150 - q[0]), pow: pw }); }
      for (let r = 0; r < 2; r++) out.push({ k, ang: Math.random() * 6.283, pow: 0.6 + Math.random() * 0.4 });
    }
    return out;
  },
  eval(s, ns, seat) {
    if (ns.winner === seat) return 1000; if (ns.winner != null) return -1000;
    const gdiff = ns.sc[seat] - s.sc[seat] - (ns.sc[1 - seat] - s.sc[1 - seat]);
    return gdiff * 200 + (seat === 0 ? (230 - ns.b[0][1]) : (ns.b[0][1] - 230)) * 0.5 + Math.random() * 3;
  },
  draw(c, balls, R, s, can) {
    const W = TS.w, H = TS.h;
    for (let i = 0; i < 8; i++) { c.fillStyle = i % 2 ? '#2f9e44' : '#37b24d'; c.fillRect(0, i * H / 8, W, H / 8 + 1); }
    c.strokeStyle = '#ffffffcc'; c.lineWidth = 3; c.strokeRect(6, 6, W - 12, H - 12); c.beginPath(); c.moveTo(6, H / 2); c.lineTo(W - 6, H / 2); c.stroke(); c.beginPath(); c.arc(W / 2, H / 2, 40, 0, 6.283); c.stroke();
    c.strokeRect(75, 6, 150, 70); c.strokeRect(75, H - 76, 150, 70);
    c.fillStyle = '#111'; tsGoals.forEach(p => { c.beginPath(); c.arc(p.x, p.y, 30, 0, 6.283); c.fill(); });
    c.fillStyle = '#ffffff22'; c.fillRect(120, 0, 60, 8); c.fillRect(120, H - 8, 60, 8);
    for (const b of balls) {
      if (!b.a) continue;
      if (b.id === 0) { c.fillStyle = '#fff'; c.beginPath(); c.arc(b.x, b.y, 8, 0, 6.283); c.fill(); c.strokeStyle = '#222'; c.lineWidth = 1.5; c.stroke(); c.fillStyle = '#222'; c.beginPath(); c.arc(b.x, b.y, 3, 0, 6.283); c.fill(); continue; }
      const mine = tsOwn(R.seat).includes(b.id), col = b.id < 4 ? '#e03a5c' : '#3a8cf0';
      c.fillStyle = '#0004'; c.beginPath(); c.arc(b.x + 2, b.y + 3, 14, 0, 6.283); c.fill();
      c.fillStyle = col; c.beginPath(); c.arc(b.x, b.y, 14, 0, 6.283); c.fill(); c.strokeStyle = (can && mine && R.sel === b.id) ? '#ffd54a' : '#fff'; c.lineWidth = (can && mine && R.sel === b.id) ? 4 : 2; c.stroke();
      c.fillStyle = '#ffffff55'; c.beginPath(); c.arc(b.x - 3, b.y - 4, 5, 0, 6.283); c.fill();
    }
    const a = R.sling && R.sling.aim, q = can && R.sel != null ? balls[R.sel] : null;
    if (a && q && q.a) { c.strokeStyle = '#fff'; c.setLineDash([6, 6]); c.lineWidth = 2; c.beginPath(); c.moveTo(q.x, q.y); c.lineTo(q.x + Math.cos(a.ang) * (60 + a.pow * 220), q.y + Math.sin(a.ang) * (60 + a.pow * 220)); c.stroke(); c.setLineDash([]); }
  }
});

/* ================= MATCH MONSTER (the former Match It gem battle, now with monsters) ================= */
const MON = ['🐲', '🦅', '🐙', '👹'];
Object.assign(G_MEM, {
  id: 'monster', name: 'Match Monster', icon: '👾', desc: 'Swap gems to match 3 or more. Your monster attacks the rival monster. Drop its HP to zero!',
  render(el, s, seat, send) {
    if (el.__gs !== s.gid) { el.__gs = s.gid; el.__sel = -1; el.__n = s.n; }
    const mine = s.turn === seat && s.winner == null, sel = el.__sel, hurt = s.ev && s.n !== el.__n ? 1 - s.ev.by : -1;
    el.__n = s.n;
    const bar = o => `<div class="gembar ${s.turn === o && s.winner == null ? 'on' : ''}"><span class="mon ${hurt === o ? 'hit' : ''} ${s.hp[o] <= 0 ? 'ko' : ''}">${MON[o]}</span><div style="flex:1"><b>${o === seat ? 'You' : 'Opponent'}</b><div class="hp"><div style="width:${s.hp[o]}%"></div></div></div><span>${s.hp[o]}</span></div>`;
    const ev = s.ev ? `${s.ev.by === seat ? 'Your monster' : 'Rival monster'}: ${s.ev.total} gems${s.ev.chain > 1 ? ' · x' + s.ev.chain + ' chain' : ''} · ${s.ev.dmg} damage!` : 'Match 3 or more gems to attack!';
    el.innerHTML = `${bar(1 - seat)}<div class="gemboard">${s.g.map((v, i) => `<button class="gem g${v} ${i === sel ? 'sel' : ''}" data-i="${i}"></button>`).join('')}</div>${bar(seat)}<div class="ldmsg">${ev}</div>`;
    $$('[data-i]', el).forEach(b => b.onclick = () => {
      if (!mine) return; const i = +b.dataset.i;
      if (el.__sel < 0) { el.__sel = i; return G_MEM.render(el, s, seat, send); }
      const j = el.__sel, adj = Math.abs(Math.floor(i / GN) - Math.floor(j / GN)) + Math.abs((i % GN) - (j % GN)) === 1;
      if (adj) {
        const t = s.g.slice(); [t[i], t[j]] = [t[j], t[i]];
        if (!gemMatches(t).size) { el.__sel = -1; toast('That swap makes no match'); return G_MEM.render(el, s, seat, send); }
        el.__sel = -1; send({ a: 'swap', i: j, j: i });
      } else { el.__sel = i; G_MEM.render(el, s, seat, send); }
    });
  }
});
