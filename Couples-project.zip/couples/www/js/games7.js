/* Playmates - Wave 2 (part 2) + final game list */
/* ================= BOWLING (3D-look lane, real pin physics) ================= */
const BW = { w: 240, h: 520, bx: 120, by: 478, rb: 11, rp: 6.5 };
const bwPins = () => [[0, 0], [-1, 1], [1, 1], [-2, 2], [0, 2], [2, 2], [-3, 3], [-1, 3], [1, 3], [3, 3]].map(([c, r]) => ({ x: 120 + c * 11.5, y: 96 - r * 19, ox: 120 + c * 11.5, oy: 96 - r * 19 }));
const bwScore = rolls => {
  let tot = 0, i = 0; for (let f = 0; f < 5; f++) {
    const a = rolls[i]; if (a == null) break;
    if (a === 10) { tot += 10 + (rolls[i + 1] || 0) + (rolls[i + 2] || 0); i += 1; }
    else { const b = rolls[i + 1] || 0; tot += a + b + (a + b === 10 ? (rolls[i + 2] || 0) : 0); i += 2; }
  } return tot;
};
const bwS = y => { const f = y / BW.h, z = 1 - f, s = 1 / (1 + 1.75 * z); return { s, sy: 585 - (585 - 150) * (1 - s) / (1 - 1 / 2.75), sx: x => 180 + (x - 120) * s * 1.28 }; };
const G_BOWL2 = duel({
  id: 'bowl', name: 'Bowling', icon: '🎳', desc: '5 frames, 2 rolls each. Drag the ball sideways to place it, then swipe up to bowl. Strikes and spares give bonus points!',
  bot: () => 60 + Math.floor(Math.random() * 55),
  play(box, seed, done) {
    const { cv, c } = arena(box, W2, H2);
    const bg = off(W2, H2, (g, w, h) => {
      g.fillStyle = '#1a0d08'; g.fillRect(0, 0, w, h);
      const wl = g.createLinearGradient(0, 0, 0, 160); wl.addColorStop(0, '#3a1d10'); wl.addColorStop(1, '#6b3a1e'); g.fillStyle = wl; g.fillRect(0, 0, w, 160);
      // pinsetter arch
      g.fillStyle = '#26262e'; g.beginPath(); g.moveTo(70, 150); g.lineTo(70, 70); g.quadraticCurveTo(180, 20, 290, 70); g.lineTo(290, 150); g.closePath(); g.fill();
      g.fillStyle = '#d9a84a'; g.beginPath(); g.moveTo(66, 150); g.lineTo(66, 68); g.quadraticCurveTo(180, 12, 294, 68); g.lineTo(294, 76); g.quadraticCurveTo(180, 22, 74, 76); g.lineTo(74, 150); g.fill();
      const dk = g.createLinearGradient(0, 100, 0, 160); dk.addColorStop(0, '#0c0c10'); dk.addColorStop(1, '#2a2a34'); g.fillStyle = dk; g.fillRect(84, 90, 192, 60);
      // lane
      const bs = bwS(0), bn = bwS(BW.h);
      const ln = g.createLinearGradient(0, 150, 0, 585); ln.addColorStop(0, '#b97a3a'); ln.addColorStop(1, '#f0c47c'); g.fillStyle = ln;
      g.beginPath(); g.moveTo(bs.sx(0), bs.sy); g.lineTo(bs.sx(240), bs.sy); g.lineTo(bn.sx(240), 585); g.lineTo(bn.sx(0), 585); g.fill();
      g.strokeStyle = '#8a4e1c55'; g.lineWidth = 1.2; for (let i = 1; i < 20; i++) { const x = i * 12; g.beginPath(); g.moveTo(bs.sx(x), bs.sy); g.lineTo(bn.sx(x), 585); g.stroke(); }
      // gutters
      const gut = (x0, x1) => { g.fillStyle = '#1b1b22'; g.beginPath(); g.moveTo(bs.sx(x0), bs.sy); g.lineTo(bs.sx(x1), bs.sy); g.lineTo(bn.sx(x1), 585); g.lineTo(bn.sx(x0), 585); g.fill(); };
      gut(-26, 0); gut(240, 266);
      // side walls
      g.fillStyle = '#2b1609'; g.beginPath(); g.moveTo(0, 150); g.lineTo(bs.sx(-26), 150); g.lineTo(bn.sx(-26), 600); g.lineTo(0, 600); g.fill(); g.beginPath(); g.moveTo(w, 150); g.lineTo(bs.sx(266), 150); g.lineTo(bn.sx(266), 600); g.lineTo(w, 600); g.fill();
      g.strokeStyle = '#d9a84a'; g.lineWidth = 3; g.beginPath(); g.moveTo(bs.sx(-26), 150); g.lineTo(bn.sx(-26), 600); g.moveTo(bs.sx(266), 150); g.lineTo(bn.sx(266), 600); g.stroke();
      // arrows
      g.fillStyle = '#7a2a12'; for (let i = -3; i <= 3; i++) { const y = 330, p = bwS(y), x = 120 + i * 24, w2 = 5 * p.s * 1.3; g.beginPath(); g.moveTo(p.sx(x), p.sy - 14 * p.s); g.lineTo(p.sx(x) - w2, p.sy + 6 * p.s); g.lineTo(p.sx(x) + w2, p.sy + 6 * p.s); g.fill(); }
      for (let i = 0; i < 7; i++) { const p = bwS(420); g.fillStyle = '#7a2a1255'; g.beginPath(); g.arc(p.sx(120 + (i - 3) * 20), p.sy, 2.6 * p.s * 1.3, 0, 6.283); g.fill(); }
      g.strokeStyle = '#7a2a12'; g.lineWidth = 2; const fl = bwS(470); g.beginPath(); g.moveTo(fl.sx(0), fl.sy); g.lineTo(fl.sx(240), fl.sy); g.stroke();
    });
    let frame = 0, roll = 0, rolls = [], pins = bwPins(), P = null, over = false, msg = 'Drag sideways to place, swipe up to bowl!', bx = 120, down = null, hist = [], t = 0, big = null;
    const pops = popups();
    cv.addEventListener('pointerdown', e => { e.preventDefault(); if (P || over) return; try { cv.setPointerCapture(e.pointerId); } catch (x) {} down = true; hist = []; const p = ptr(cv, e); bx = clamp(120 + (p.x - 180) / (bwS(BW.by).s * 1.28), 20, 220); hist.push({ x: p.x, y: p.y, t: performance.now() }); });
    cv.addEventListener('pointermove', e => { if (!down) return; const p = ptr(cv, e); hist.push({ x: p.x, y: p.y, t: performance.now() }); if (hist.length > 8) hist.shift(); bx = clamp(120 + (p.x - 180) / (bwS(BW.by).s * 1.28), 20, 220); });
    cv.addEventListener('pointerup', e => {
      if (!down) return; down = false; if (P || over) return;
      const p = ptr(cv, e); hist.push({ x: p.x, y: p.y, t: performance.now() }); const a = hist[Math.max(0, hist.length - 5)], b = hist[hist.length - 1], dt = Math.max(30, b.t - a.t), vx = (b.x - a.x) / dt, vy = (b.y - a.y) / dt;
      if (-vy < .35) { return; }
      const sp = clamp(Math.hypot(vx, vy), .5, 2.4), v = 430 + 330 * (sp - .5) / 1.9, ang = Math.atan2(vy, vx * .55);
      const balls = [{ id: 0, x: bx, y: BW.by, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v, a: 1, r: BW.rb, m: 5 }];
      pins.forEach((p, i) => balls.push({ id: i + 1, x: p.x, y: p.y, vx: 0, vy: 0, a: p.gone ? 0 : 1, r: BW.rp, m: 1 }));
      P = { w: BW.w, h: BW.h, fr: 110, rest: .6, killTop: true, balls }; msg = '';
    });
    const settle = () => {
      let knocked = 0; P.balls.forEach(b => { if (b.id === 0) return; const p = pins[b.id - 1]; if (p.gone) return; if (!b.a || Math.hypot(b.x - p.ox, b.y - p.oy) > 9) { p.gone = true; knocked++; } else { p.x = b.x; p.y = b.y; } });
      P = null; rolls.push(knocked); const left = pins.filter(p => !p.gone).length;
      const strike = knocked === 10 && roll === 0, spare = left === 0 && roll === 1;
      msg = strike ? 'STRIKE!' : spare ? 'SPARE!' : knocked + (knocked === 1 ? ' pin' : ' pins') + ' down'; if (strike || spare) big = { t: 0, s: msg }; else if (!knocked) msg = 'Gutter ball...';
      if (roll === 0 && !strike) roll = 1; else { frame++; roll = 0; pins = bwPins(); }
      if (frame >= 5) { over = true; setTimeout(() => { stop(); fin(box, bwScore(rolls), done, msg); }, 1400); }
    };
    const drawPin = (p, s, tilt) => { const x = p.sx, y = p.sy, k = s * 1.28 * 1.5, h = 34 * k; c.save(); c.translate(x, y); if (tilt) c.rotate(tilt); c.fillStyle = '#0003'; c.beginPath(); c.ellipse(2 * k, 1, 6 * k, 2.5 * k, 0, 0, 6.283); c.fill();
      c.beginPath(); c.moveTo(-4 * k, 0); c.bezierCurveTo(-7 * k, -8 * k, -4 * k, -14 * k, -3 * k, -18 * k); c.bezierCurveTo(-3 * k, -22 * k, -5 * k, -26 * k, -4 * k, -30 * k); c.bezierCurveTo(-4 * k, -35 * k, 4 * k, -35 * k, 4 * k, -30 * k); c.bezierCurveTo(5 * k, -26 * k, 3 * k, -22 * k, 3 * k, -18 * k); c.bezierCurveTo(4 * k, -14 * k, 7 * k, -8 * k, 4 * k, 0); c.closePath();
      const g = c.createLinearGradient(-6 * k, 0, 6 * k, 0); g.addColorStop(0, '#d9d9e0'); g.addColorStop(.45, '#fff'); g.addColorStop(1, '#b8b8c4'); c.fillStyle = g; c.fill(); c.strokeStyle = '#0003'; c.lineWidth = .8; c.stroke();
      c.fillStyle = '#d4202a'; c.fillRect(-3.4 * k, -27 * k, 6.8 * k, 2.2 * k); c.fillRect(-3.4 * k, -23 * k, 6.8 * k, 1.6 * k); c.restore(); };
    const stop = anim(dt => {
      t += dt;
      if (P) { for (let i = 0; i < Math.ceil(dt * 240); i++) { const b0 = P.balls[0]; if (b0.a && (b0.x < 8 || b0.x > 232)) { b0.x = b0.x < 8 ? 8 : 232; b0.vx = 0; } Phys.step(P, 1 / 240); } if (!Phys.moving(P)) settle(); }
      if (over && !P && false) return;
      c.drawImage(bg, 0, 0);
      const items = [];
      if (P) P.balls.forEach(b => { if (b.id && b.a) items.push({ y: b.y, k: 'p', x: b.x, tilt: Math.hypot(b.vx, b.vy) > 8 ? Math.atan2(b.vx, 80) : 0, moved: Math.hypot(b.x - pins[b.id - 1].ox, b.y - pins[b.id - 1].oy) > 3 }); }); else pins.forEach(p => { if (!p.gone) items.push({ y: p.y, k: 'p', x: p.x, tilt: 0 }); });
      const b0 = P ? P.balls[0] : { x: bx, y: BW.by, a: 1 }; if (b0.a) items.push({ y: b0.y, k: 'b', x: b0.x });
      items.sort((a, b) => a.y - b.y).forEach(it => { const q = bwS(clamp(it.y, 0, BW.h)), pt = { sx: q.sx(it.x), sy: q.sy };
        if (it.k === 'p') drawPin(pt, q.s, it.tilt); else { const R = BW.rb * 1.28 * q.s * 1.35; c.fillStyle = '#0005'; c.beginPath(); c.ellipse(pt.sx + 3, pt.sy, R, R * .35, 0, 0, 6.283); c.fill(); const g = c.createRadialGradient(pt.sx - R * .35, pt.sy - R * 1.35, R * .1, pt.sx, pt.sy - R, R); g.addColorStop(0, '#ff9a8a'); g.addColorStop(.5, '#d62323'); g.addColorStop(1, '#5a0a0a'); c.fillStyle = g; c.beginPath(); c.arc(pt.sx, pt.sy - R, R, 0, 6.283); c.fill(); c.fillStyle = '#0006'; [[-.3, -.15], [.1, -.35], [-.05, 0]].forEach(([a, b]) => { c.beginPath(); c.arc(pt.sx + a * R, pt.sy - R + b * R - R * .15, R * .1, 0, 6.283); c.fill(); }); } });
      hudTop(c, W2, bwScore(rolls), 'FRAME ' + Math.min(5, frame + 1) + '/5', (g, w) => { tx(g, 'ROLL ' + (roll + 1), w - 40, 28, 14, '#fff'); });
      if (msg) tx(c, msg, 180, 78, 14, '#fff', 'center', '#000a');
      if (big) { big.t += dt; const k = Math.min(1, big.t * 4); c.globalAlpha = Math.max(0, 1 - Math.max(0, big.t - 1.1) * 2); tx(c, big.s, 180, 300, 44 * (.6 + .4 * k), '#ffd54a', 'center', '#7a1a00'); c.globalAlpha = 1; if (big.t > 1.7) big = null; }
      if (down && !P) { c.strokeStyle = '#ffffffaa'; c.setLineDash([6, 8]); c.lineWidth = 2; const q = bwS(BW.by), r = bwS(40); c.beginPath(); c.moveTo(q.sx(bx), q.sy - 20); c.lineTo(r.sx(bx), r.sy); c.stroke(); c.setLineDash([]); }
    });
    return () => { over = true; stop(); };
  }
});

/* ================= MINI GOLF (water, sand, walls, windmill) ================= */
const GF_L = [
  { name: 'Island Pond', par: 3, start: [180, 520], cup: [180, 120], sand: [{ x: 180, y: 330, rx: 80, ry: 38 }], water: [{ x: 70, y: 230, rx: 42, ry: 70 }, { x: 290, y: 230, rx: 42, ry: 70 }], walls: [{ x: 140, y: 210, w: 80, h: 14 }] },
  { name: 'Dog-leg Bay', par: 4, start: [90, 520], cup: [270, 120], sand: [{ x: 90, y: 160, rx: 50, ry: 32 }], water: [{ x: 240, y: 470, rx: 70, ry: 42 }, { x: 60, y: 300, rx: 30, ry: 40 }], walls: [{ x: 30, y: 350, w: 190, h: 16 }, { x: 140, y: 210, w: 190, h: 16 }] },
  { name: 'Windmill Run', par: 3, start: [180, 530], cup: [180, 110], sand: [{ x: 70, y: 380, rx: 40, ry: 50 }, { x: 290, y: 380, rx: 40, ry: 50 }], water: [{ x: 70, y: 180, rx: 38, ry: 38 }, { x: 290, y: 180, rx: 38, ry: 38 }], walls: [], mill: { x: 180, y: 300, len: 62, sp: 1.7 } },
  { name: 'Zig-Zag Lagoon', par: 4, start: [270, 530], cup: [90, 110], sand: [{ x: 180, y: 250, rx: 60, ry: 26 }], water: [{ x: 90, y: 440, rx: 60, ry: 34 }, { x: 270, y: 170, rx: 50, ry: 28 }], walls: [{ x: 30, y: 400, w: 200, h: 16 }, { x: 130, y: 300, w: 200, h: 16 }] }
];
const GF_IN = { x0: 30, y0: 70, x1: 330, y1: 570 };
const gfIn = (e, x, y) => ((x - e.x) / e.rx) ** 2 + ((y - e.y) / e.ry) ** 2 < 1;
const G_GOLF2 = duel({
  id: 'golf', name: 'Mini Golf', icon: '⛳', low: true, desc: '3 holes. Pull back and release to putt. Sand slows the ball, water costs a stroke. Fewest strokes wins!',
  bot: () => 8 + Math.floor(Math.random() * 7),
  play(box, seed, done) {
    const R = rng(seed), order = [0, 1, 2, 3].sort(() => R() - .5).slice(0, 3), { cv, c } = arena(box, W2, H2);
    const trees = Array.from({ length: 22 }, (_, i) => { const side = i % 2; return { x: side ? 345 + R() * 14 : 5 + R() * 14, y: 80 + (i >> 1) * 45 + R() * 10, r: 11 + R() * 7 }; });
    const bgFor = L => off(W2, H2, (g, w, h) => {
      g.fillStyle = '#6dbd5a'; g.fillRect(0, 0, w, h); for (let y = 0; y < h; y += 24) for (let x = (y / 24) % 2 * 24; x < w; x += 48) { g.fillStyle = '#62b150'; g.fillRect(x, y, 24, 24); }
      g.fillStyle = '#eed9a3'; rr(g, 22, 62, 316, 516, 26); g.fill(); g.strokeStyle = '#c9ae6c'; g.lineWidth = 3; g.stroke();
      const { x0, y0, x1, y1 } = GF_IN; g.fillStyle = '#46b24f'; rr(g, x0, y0, x1 - x0, y1 - y0, 14); g.fill();
      for (let y = y0; y < y1; y += 25) for (let x = x0 + ((y - y0) / 25 % 2) * 25; x < x1; x += 50) { g.fillStyle = '#3ea848'; g.fillRect(x, y, 25, Math.min(25, y1 - y)); }
      g.strokeStyle = '#2a7a35'; g.lineWidth = 3; rr(g, x0, y0, x1 - x0, y1 - y0, 14); g.stroke();
      L.sand.forEach(e => { const gr = g.createRadialGradient(e.x, e.y, 4, e.x, e.y, Math.max(e.rx, e.ry)); gr.addColorStop(0, '#f6e4a4'); gr.addColorStop(1, '#e2c474'); g.fillStyle = gr; g.beginPath(); g.ellipse(e.x, e.y, e.rx, e.ry, 0, 0, 6.283); g.fill(); g.strokeStyle = '#c9a54e'; g.lineWidth = 2.5; g.stroke(); g.fillStyle = '#c9a54e66'; for (let i = 0; i < 22; i++) { const a = i * 2.4, rr_ = Math.sqrt(i / 22); g.fillRect(e.x + Math.cos(a) * e.rx * .8 * rr_, e.y + Math.sin(a) * e.ry * .8 * rr_, 2, 2); } });
      L.water.forEach(e => { g.fillStyle = '#e2c474'; g.beginPath(); g.ellipse(e.x, e.y, e.rx + 5, e.ry + 5, 0, 0, 6.283); g.fill(); const gr = g.createRadialGradient(e.x, e.y, 3, e.x, e.y, Math.max(e.rx, e.ry)); gr.addColorStop(0, '#7fd6ff'); gr.addColorStop(1, '#2a8be0'); g.fillStyle = gr; g.beginPath(); g.ellipse(e.x, e.y, e.rx, e.ry, 0, 0, 6.283); g.fill(); g.strokeStyle = '#ffffff88'; g.lineWidth = 2; for (let k = 1; k < 3; k++) { g.beginPath(); g.ellipse(e.x - 4, e.y - 3, e.rx * (.35 * k), e.ry * (.28 * k), 0, 0, 5); g.stroke(); } g.fillStyle = '#3fae4f'; g.beginPath(); g.arc(e.x + e.rx * .4, e.y + e.ry * .2, 7, .4, 6); g.fill(); g.fillStyle = '#ff7ab8'; g.beginPath(); g.arc(e.x + e.rx * .4, e.y + e.ry * .2, 2.5, 0, 6.283); g.fill(); });
      L.walls.forEach(o => { g.fillStyle = '#0003'; g.fillRect(o.x + 3, o.y + 4, o.w, o.h); g.fillStyle = '#6b3d1c'; g.fillRect(o.x, o.y, o.w, o.h); g.fillStyle = '#a9703a'; g.fillRect(o.x, o.y, o.w, o.h * .45); g.strokeStyle = '#3d210d'; g.lineWidth = 1.5; g.strokeRect(o.x, o.y, o.w, o.h); });
      if (L.mill) { const m = L.mill; g.fillStyle = '#0003'; g.beginPath(); g.arc(m.x + 3, m.y + 4, 14, 0, 6.283); g.fill(); }
    });
    const bgs = order.map(i => bgFor(GF_L[i]));
    let hi = 0, strokes = 0, total = 0, over = false, moving = false, ang0 = 0, t = 0, msg = '', last = null, sink = 0, ball = null;
    const pops = popups(), L = () => GF_L[order[hi]];
    const place = () => { const s = L().start; ball = { x: s[0], y: s[1], vx: 0, vy: 0 }; last = { x: s[0], y: s[1] }; moving = false; };
    place();
    const sl = sling(cv, () => (moving || over || sink ? null : ball), a => { strokes++; const v = 80 + 560 * a.pow; ball.vx = Math.cos(a.ang) * v; ball.vy = Math.sin(a.ang) * v; moving = true; last = { x: ball.x, y: ball.y }; msg = ''; }, 90);
    const nextHole = () => { total += strokes; strokes = 0; hi++; if (hi >= 3) { over = true; stop(); fin(box, total, done, 'Course complete!'); return; } place(); };
    const millSeg = () => { const m = L().mill; if (!m) return null; const a = t * m.sp; return [[m.x + Math.cos(a) * m.len, m.y + Math.sin(a) * m.len], [m.x - Math.cos(a) * m.len, m.y - Math.sin(a) * m.len]]; };
    const step = dt => {
      const hole = L(), b = ball; b.x += b.vx * dt; b.y += b.vy * dt;
      const sp = Math.hypot(b.vx, b.vy), inSand = hole.sand.some(e => gfIn(e, b.x, b.y)), fr = inSand ? 520 : 120;
      if (sp > 0) { const ns = sp - fr * dt; if (ns < 6) { b.vx = 0; b.vy = 0; } else { b.vx *= ns / sp; b.vy *= ns / sp; } }
      const { x0, y0, x1, y1 } = GF_IN, r = 7;
      if (b.x < x0 + r) { b.x = x0 + r; b.vx = Math.abs(b.vx) * .8; } if (b.x > x1 - r) { b.x = x1 - r; b.vx = -Math.abs(b.vx) * .8; }
      if (b.y < y0 + r) { b.y = y0 + r; b.vy = Math.abs(b.vy) * .8; } if (b.y > y1 - r) { b.y = y1 - r; b.vy = -Math.abs(b.vy) * .8; }
      for (const o of hole.walls) {
        const cx = clamp(b.x, o.x, o.x + o.w), cy = clamp(b.y, o.y, o.y + o.h); let dx = b.x - cx, dy = b.y - cy; const d = Math.hypot(dx, dy);
        if (d < r) { if (d === 0) { dx = 0; dy = -1; } else { dx /= d; dy /= d; } b.x = cx + dx * (r + .1); b.y = cy + dy * (r + .1); const dot = b.vx * dx + b.vy * dy; if (dot < 0) { b.vx -= 1.8 * dot * dx; b.vy -= 1.8 * dot * dy; } }
      }
      const seg = millSeg(); if (seg) { const [p, q] = seg, vx = q[0] - p[0], vy = q[1] - p[1], L2 = vx * vx + vy * vy, k = clamp(((b.x - p[0]) * vx + (b.y - p[1]) * vy) / L2, 0, 1), cx = p[0] + vx * k, cy = p[1] + vy * k; let dx = b.x - cx, dy = b.y - cy; const d = Math.hypot(dx, dy); if (d < r + 4) { dx /= d || 1; dy /= d || 1; b.x = cx + dx * (r + 4.1); b.y = cy + dy * (r + 4.1); const dot = b.vx * dx + b.vy * dy; if (dot < 0) { b.vx -= 1.9 * dot * dx; b.vy -= 1.9 * dot * dy; } else { b.vx += dx * 120; b.vy += dy * 120; } } }
      if (hole.water.some(e => gfIn(e, b.x, b.y))) { sink = .9; pops.add('SPLASH! +1', b.x, b.y - 10, '#7fd6ff'); msg = 'Splash! Penalty stroke'; strokes++; b.vx = 0; b.vy = 0; moving = false; return; }
      if (Math.hypot(b.x - hole.cup[0], b.y - hole.cup[1]) < 11 && sp < 380) { pops.add(strokes === 1 ? 'HOLE IN ONE!' : 'IN!', hole.cup[0], hole.cup[1] - 20, '#ffd54a'); sink = -.7; b.x = hole.cup[0]; b.y = hole.cup[1]; b.vx = 0; b.vy = 0; moving = false; return; }
      if (moving && !b.vx && !b.vy) { moving = false; if (strokes >= 6) { msg = 'Max strokes reached'; sink = -.5; } }
    };
    const stop = anim(dt => {
      if (over) return; t += dt;
      if (sink > 0) { sink -= dt; if (sink <= 0) { ball.x = last.x; ball.y = last.y; ball.vx = ball.vy = 0; sink = 0; if (strokes >= 6) { msg = 'Max strokes reached'; sink = -.4; } } }
      else if (sink < 0) { sink += dt; if (sink >= 0) { sink = 0; nextHole(); if (over) return; } }
      else if (moving) for (let i = 0; i < 4 && !over && moving; i++) step(dt / 4);
      if (over) return;
      const hole = L(); c.drawImage(bgs[hi], 0, 0);
      trees.forEach(tr => { c.fillStyle = '#0003'; c.beginPath(); c.arc(tr.x + 3, tr.y + 5, tr.r, 0, 6.283); c.fill(); c.fillStyle = '#2a7a35'; c.beginPath(); c.arc(tr.x, tr.y, tr.r, 0, 6.283); c.fill(); c.fillStyle = '#4cc05a'; c.beginPath(); c.arc(tr.x - 3, tr.y - 3, tr.r * .6, 0, 6.283); c.fill(); });
      const cx = hole.cup[0], cy = hole.cup[1]; c.fillStyle = '#000'; c.beginPath(); c.arc(cx, cy, 10, 0, 6.283); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 2.5; c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx, cy - 34); c.stroke(); c.fillStyle = '#ff3d7a'; c.beginPath(); c.moveTo(cx, cy - 34); c.lineTo(cx + 18, cy - 28); c.lineTo(cx, cy - 22); c.fill();
      const seg = millSeg(); if (seg) { const m = hole.mill; c.strokeStyle = '#fff'; c.lineWidth = 9; c.lineCap = 'round'; c.beginPath(); c.moveTo(seg[0][0], seg[0][1]); c.lineTo(seg[1][0], seg[1][1]); c.stroke(); c.strokeStyle = '#d33'; c.lineWidth = 4; c.beginPath(); c.moveTo(seg[0][0], seg[0][1]); c.lineTo(m.x, m.y); c.stroke(); c.lineCap = 'butt'; c.fillStyle = '#8a5a2b'; c.beginPath(); c.arc(m.x, m.y, 12, 0, 6.283); c.fill(); c.fillStyle = '#ffd54a'; c.beginPath(); c.arc(m.x, m.y, 5, 0, 6.283); c.fill(); }
      if (sink <= 0 || sink > .5) { const s = sink > 0 ? sink / .9 : 1; c.globalAlpha = sink < 0 ? 0 : Math.min(1, s * 1.3); c.fillStyle = '#0004'; c.beginPath(); c.arc(ball.x + 2, ball.y + 3, 7, 0, 6.283); c.fill(); const g = c.createRadialGradient(ball.x - 2, ball.y - 2, 1, ball.x, ball.y, 7); g.addColorStop(0, '#fff'); g.addColorStop(1, '#c8c8d0'); c.fillStyle = g; c.beginPath(); c.arc(ball.x, ball.y, 7, 0, 6.283); c.fill(); c.globalAlpha = 1; }
      if (!moving && !sink && sl.aim) { const a = sl.aim, len = 40 + a.pow * 200; c.strokeStyle = '#ffd54a'; c.lineWidth = 3; c.setLineDash([6, 6]); c.beginPath(); c.moveTo(ball.x, ball.y); c.lineTo(ball.x + Math.cos(a.ang) * len, ball.y + Math.sin(a.ang) * len); c.stroke(); c.setLineDash([]); c.fillStyle = '#0008'; rr(c, 130, 585, 100, 10, 5); c.fill(); c.fillStyle = a.pow > .8 ? '#ff5a3a' : '#5ad66a'; rr(c, 130, 585, 100 * a.pow, 10, 5); c.fill(); }
      hudTop(c, W2, total + strokes, 'HOLE ' + (hi + 1) + '/3', (g, w) => { tx(g, 'PAR ' + hole.par, w - 40, 28, 14, '#fff'); });
      tx(c, msg || (hole.name + ' · strokes ' + strokes + ' (max 6)'), 180, 82, 13, '#fff', 'center', '#000a'); pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});

/* ================= CARROM (luxury board, 9+9 coins and the queen) ================= */
const CX = { w: 400, h: 400, ix: 16, rs: 15, rc: 10 };
const CX_POCK = [[22, 22], [378, 22], [22, 378], [378, 378]].map(([x, y]) => ({ x, y, r: 25 }));
const CX_OWN = seat => seat === 0 ? [2, 4, 6, 8, 10, 12, 14, 16, 18] : [3, 5, 7, 9, 11, 13, 15, 17, 19];
const cxSy = seat => seat === 0 ? 338 : 62, cxSx = R => 82 + (R ? R.sx : .5) * 236;
function cxInit() {
  const b = [[200, 338, 0, 0, 0], [200, 200, 0, 0, 1]];
  for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3 + Math.PI / 6; b[2 + i] = [+(200 + Math.cos(a) * 22).toFixed(2), +(200 + Math.sin(a) * 22).toFixed(2), 0, 0, 1]; }
  for (let j = 0; j < 12; j++) { const a = j * Math.PI / 6; b[8 + j] = [+(200 + Math.cos(a) * 43).toFixed(2), +(200 + Math.sin(a) * 43).toFixed(2), 0, 0, 1]; }
  return b;
}
const cxBoard = off(400, 400, (g, w, h) => {
  const wood = g.createLinearGradient(0, 0, w, h); wood.addColorStop(0, '#f6dba2'); wood.addColorStop(.5, '#ecc785'); wood.addColorStop(1, '#f2d296'); g.fillStyle = wood; g.fillRect(0, 0, w, h);
  g.strokeStyle = '#b9893f22'; g.lineWidth = 1; for (let i = 0; i < 70; i++) { const y = i * 5.8 + (i * 37 % 5); g.beginPath(); g.moveTo(0, y); g.bezierCurveTo(100, y + (i % 3) * 2, 300, y - (i % 4) * 2, w, y + 1); g.stroke(); }
  // arrow patterns from corners
  g.strokeStyle = '#8d2b1f'; g.lineWidth = 1.8; [[1, 1], [-1, 1], [1, -1], [-1, -1]].forEach(([sx, sy]) => { const cx = sx > 0 ? 28 : w - 28, cy = sy > 0 ? 28 : h - 28; g.beginPath(); g.moveTo(cx + sx * 30, cy + sy * 30); g.lineTo(cx + sx * 96, cy + sy * 96); g.stroke(); for (let k = 0; k < 3; k++) { const p = 60 + k * 12; g.beginPath(); g.moveTo(cx + sx * (p + 6), cy + sy * (p - 6)); g.lineTo(cx + sx * (p + 12), cy + sy * (p + 12)); g.lineTo(cx + sx * (p - 6), cy + sy * (p + 6)); g.stroke(); } g.beginPath(); g.arc(cx + sx * 104, cy + sy * 104, 8, 0, 6.283); g.stroke(); });
  // baselines
  const bl = (x0, y0, x1, y1) => { g.strokeStyle = '#6b2a16'; g.lineWidth = 2; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); };
  bl(70, 62 - 11, 330, 62 - 11); bl(70, 62 + 11, 330, 62 + 11); bl(70, 338 - 11, 330, 338 - 11); bl(70, 338 + 11, 330, 338 + 11); bl(62 - 11, 70, 62 - 11, 330); bl(62 + 11, 70, 62 + 11, 330); bl(338 - 11, 70, 338 - 11, 330); bl(338 + 11, 70, 338 + 11, 330);
  [[70, 62], [330, 62], [70, 338], [330, 338], [62, 70], [62, 330], [338, 70], [338, 330]].forEach(([x, y]) => { g.fillStyle = '#b3261e'; g.beginPath(); g.arc(x, y, 9, 0, 6.283); g.fill(); g.strokeStyle = '#6b2a16'; g.lineWidth = 1.5; g.stroke(); g.fillStyle = '#e8b840'; g.beginPath(); g.arc(x, y, 3, 0, 6.283); g.fill(); });
  // compass rose centre
  g.save(); g.translate(200, 200);
  g.strokeStyle = '#8d2b1f'; g.lineWidth = 2; [78, 68, 60].forEach((r, i) => { g.beginPath(); g.arc(0, 0, r, 0, 6.283); g.lineWidth = i === 0 ? 2.5 : 1.3; g.stroke(); });
  for (let i = 0; i < 16; i++) { g.save(); g.rotate(i * Math.PI / 8); const L = i % 2 ? 54 : 74, wd = i % 2 ? 6 : 9; g.beginPath(); g.moveTo(0, -L); g.lineTo(wd, -26); g.lineTo(0, -20); g.lineTo(-wd, -26); g.closePath(); g.fillStyle = i % 4 === 0 ? '#9c2a1e' : (i % 2 ? '#d49a35' : '#b8742a'); g.fill(); g.strokeStyle = '#5a1c10'; g.lineWidth = .8; g.stroke(); g.restore(); }
  for (let i = 0; i < 12; i++) { g.save(); g.rotate(i * Math.PI / 6 + Math.PI / 12); g.beginPath(); g.ellipse(0, -48, 5, 13, 0, 0, 6.283); g.strokeStyle = '#8d2b1f88'; g.lineWidth = 1.2; g.stroke(); g.restore(); }
  const cg = g.createRadialGradient(0, 0, 2, 0, 0, 22); cg.addColorStop(0, '#d94a3a'); cg.addColorStop(1, '#8d1d14'); g.fillStyle = cg; g.beginPath(); g.arc(0, 0, 21, 0, 6.283); g.fill(); g.strokeStyle = '#e8b840'; g.lineWidth = 2.5; g.stroke(); g.strokeStyle = '#ffe9a8'; g.lineWidth = 1; g.beginPath(); g.arc(0, 0, 15, 0, 6.283); g.stroke();
  g.restore();
  // frame
  const fr = g.createLinearGradient(0, 0, w, h); fr.addColorStop(0, '#5a2a12'); fr.addColorStop(.5, '#8a4a22'); fr.addColorStop(1, '#4a200e');
  g.fillStyle = fr; g.fillRect(0, 0, w, 16); g.fillRect(0, h - 16, w, 16); g.fillRect(0, 0, 16, h); g.fillRect(w - 16, 0, 16, h);
  g.strokeStyle = '#f0c75a'; g.lineWidth = 2; g.strokeRect(14, 14, w - 28, h - 28); g.strokeStyle = '#0006'; g.lineWidth = 2; g.strokeRect(16.5, 16.5, w - 33, h - 33); g.strokeStyle = '#ffd98a88'; g.lineWidth = 1.5; g.strokeRect(2, 2, w - 4, h - 4);
  g.fillStyle = '#f0c75a'; for (let i = 1; i < 12; i++) [[50 + i * 25, 8], [50 + i * 25, h - 8], [8, 50 + i * 25], [w - 8, 50 + i * 25]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 2, 0, 6.283); g.fill(); });
  // pockets
  CX_POCK.forEach(p => { g.fillStyle = '#f0c75a'; g.beginPath(); g.arc(p.x, p.y, p.r + 4, 0, 6.283); g.fill(); const pg = g.createRadialGradient(p.x, p.y, 3, p.x, p.y, p.r); pg.addColorStop(0, '#000'); pg.addColorStop(1, '#2a1208'); g.fillStyle = pg; g.beginPath(); g.arc(p.x, p.y, p.r, 0, 6.283); g.fill(); g.strokeStyle = '#6d4a1a'; g.lineWidth = 1; for (let k = 0; k < 6; k++) { g.beginPath(); g.arc(p.x, p.y, p.r - k * 4, 0, 6.283); g.stroke(); } g.strokeStyle = '#8a5a1a'; g.lineWidth = 2; g.beginPath(); g.arc(p.x, p.y, p.r + 4, 0, 6.283); g.stroke(); });
});
function cxCoin(c, x, y, r, kind) {
  c.fillStyle = '#0005'; c.beginPath(); c.arc(x + 2, y + 3, r, 0, 6.283); c.fill();
  const g = c.createRadialGradient(x - r * .35, y - r * .4, r * .1, x, y, r);
  if (kind === 'w') { g.addColorStop(0, '#fffdf4'); g.addColorStop(1, '#d8c7a0'); } else if (kind === 'b') { g.addColorStop(0, '#6a6a74'); g.addColorStop(1, '#101014'); } else if (kind === 'q') { g.addColorStop(0, '#ff8aa8'); g.addColorStop(1, '#b0123c'); } else { g.addColorStop(0, '#f2fbff'); g.addColorStop(.6, '#8fd0ff'); g.addColorStop(1, '#2a6fd0'); }
  c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, 6.283); c.fill();
  c.strokeStyle = kind === 'b' ? '#000' : '#00000055'; c.lineWidth = 1.2; c.stroke(); c.strokeStyle = kind === 'b' ? '#ffffff30' : '#00000030'; c.lineWidth = 1; c.beginPath(); c.arc(x, y, r * .62, 0, 6.283); c.stroke(); c.beginPath(); c.arc(x, y, r * .3, 0, 6.283); c.stroke();
  c.fillStyle = '#ffffff66'; c.beginPath(); c.ellipse(x - r * .35, y - r * .4, r * .28, r * .16, -.6, 0, 6.283); c.fill();
}
const G_CARROM2 = physGame({
  id: 'carrom', name: 'Carrom', icon: '🪙', desc: 'Pocket all your coins first. Slide the striker, pull back and flick!', sym: ['⚪', '⚫'],
  w: CX.w, h: CX.h, ix: CX.ix, fr: 150, rest: .86, pockets: CX_POCK, r: i => i === 0 ? CX.rs : CX.rc, pull: 85, slider: true,
  init: () => ({ b: cxInit(), turn: 0, winner: null, n: 0, msg: '' }),
  prep: (s, m) => ({ ang: +m.ang, pow: clamp(+m.pow || 0, 0, 1), x: clamp(+m.x, 0, 1) }),
  valid: (s, m, seat) => s.winner == null && s.turn === seat && isFinite(m.ang) && isFinite(m.pow),
  launch(P, m, seat) { const st = P.balls[0]; st.a = 1; st.x = 82 + m.x * 236; st.y = cxSy(seat); const v = 160 + 780 * m.pow; st.vx = Math.cos(m.ang) * v; st.vy = Math.sin(m.ang) * v; },
  after(s, ev, seat) {
    s.b[0][4] = 0; s.msg = '';
    const own = CX_OWN(seat), mine = ev.filter(i => own.includes(i)).length, queen = ev.includes(1), foul = ev.includes(0);
    const left = st => CX_OWN(st).filter(i => s.b[i][4]).length;
    if (left(seat) === 0) { s.winner = seat; return; }
    if (left(1 - seat) === 0) { s.winner = 1 - seat; return; }
    if (foul) { s.turn = 1 - seat; s.msg = 'Foul: striker pocketed'; } else s.turn = (mine > 0 || queen) ? seat : 1 - seat;
    if (s.n >= 90) s.winner = left(0) === left(1) ? 'draw' : (left(0) < left(1) ? 0 : 1);
  },
  shooter: (s, R) => (s.winner == null ? { x: cxSx(R), y: cxSy(R.seat) } : null),
  hud: s => `<div class="scorebar"><div class="p0">⚪ ${CX_OWN(0).filter(i => s.b[i][4]).length} left</div><div class="mut">${esc(s.msg || '')}</div><div class="p1">⚫ ${CX_OWN(1).filter(i => s.b[i][4]).length} left</div></div>`,
  cands(s, seat) {
    const own = CX_OWN(seat).filter(i => s.b[i][4]), out = [];
    for (const x of [.1, .5, .9]) {
      const sx = 82 + x * 236, sy = cxSy(seat);
      for (const t of own) for (const p of CX_POCK) {
        const tb = s.b[t], dx = p.x - tb[0], dy = p.y - tb[1], d = Math.hypot(dx, dy) || 1, gx = tb[0] - dx / d * (CX.rs + CX.rc), gy = tb[1] - dy / d * (CX.rs + CX.rc), ang = Math.atan2(gy - sy, gx - sx);
        if ((seat === 0 && Math.sin(ang) > -.1) || (seat === 1 && Math.sin(ang) < .1)) continue;
        for (const pw of [.5, .8]) out.push({ ang, pow: pw, x });
      }
    }
    for (let k = 0; k < 5; k++) out.push({ ang: (seat === 0 ? -1 : 1) * (.6 + Math.random() * 1.9), pow: .5 + Math.random() * .5, x: Math.random() });
    return out.sort(() => Math.random() - .5).slice(0, 40);
  },
  eval(s, ns, seat) {
    if (ns.winner === seat) return 1000; if (ns.winner != null) return -1000;
    const cnt = (st, ids) => ids.filter(i => st.b[i][4]).length, o = CX_OWN(seat), q = CX_OWN(1 - seat);
    return (cnt(s, o) - cnt(ns, o)) * 10 - (cnt(s, q) - cnt(ns, q)) * 7 - (ns.msg ? 20 : 0) + (ns.b[1][4] ? 0 : 5);
  },
  draw(c, balls, R, s, can) {
    c.drawImage(cxBoard, 0, 0);
    for (const b of balls) { if (!b.a || b.id === 0) continue; cxCoin(c, b.x, b.y, CX.rc, b.id === 1 ? 'q' : (b.id % 2 === 0 ? 'w' : 'b')); }
    const st = balls[0];
    if (st && st.a) cxCoin(c, st.x, st.y, CX.rs, 's');
    else if (can) {
      const x = cxSx(R), y = cxSy(R.seat); c.globalAlpha = .9; cxCoin(c, x, y, CX.rs, 's'); c.globalAlpha = 1; const a = R.sling && R.sling.aim;
      if (a) { c.strokeStyle = '#fff'; c.setLineDash([7, 7]); c.lineWidth = 2.5; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a.ang) * (60 + a.pow * 230), y + Math.sin(a.ang) * (60 + a.pow * 230)); c.stroke(); c.setLineDash([]); c.strokeStyle = '#ffd54a'; c.lineWidth = 3; c.beginPath(); c.arc(x, y, CX.rs + 4 + a.pow * 10, 0, 6.283); c.stroke(); }
    }
  }
});

/* ================= TABLE SOCCER (flags, caps, ball) ================= */
const TS = { w: 300, h: 460, ix: 12 };
const TS_FLAGS = [
  ['India', g => { g.fillStyle = '#ff9933'; g.fillRect(0, 0, 30, 10); g.fillStyle = '#fff'; g.fillRect(0, 10, 30, 10); g.fillStyle = '#138808'; g.fillRect(0, 20, 30, 10); g.strokeStyle = '#1a3aa0'; g.lineWidth = 1; g.beginPath(); g.arc(15, 15, 3.5, 0, 6.283); g.stroke(); }],
  ['Brazil', g => { g.fillStyle = '#16a34a'; g.fillRect(0, 0, 30, 30); g.fillStyle = '#facc15'; g.beginPath(); g.moveTo(15, 4); g.lineTo(27, 15); g.lineTo(15, 26); g.lineTo(3, 15); g.fill(); g.fillStyle = '#1d4ed8'; g.beginPath(); g.arc(15, 15, 6, 0, 6.283); g.fill(); }],
  ['Argentina', g => { g.fillStyle = '#74c0fc'; g.fillRect(0, 0, 30, 30); g.fillStyle = '#fff'; g.fillRect(0, 10, 30, 10); g.fillStyle = '#f5b301'; g.beginPath(); g.arc(15, 15, 3, 0, 6.283); g.fill(); }],
  ['Germany', g => { g.fillStyle = '#111'; g.fillRect(0, 0, 30, 10); g.fillStyle = '#dd0000'; g.fillRect(0, 10, 30, 10); g.fillStyle = '#ffce00'; g.fillRect(0, 20, 30, 10); }],
  ['France', g => { g.fillStyle = '#1d4ed8'; g.fillRect(0, 0, 10, 30); g.fillStyle = '#fff'; g.fillRect(10, 0, 10, 30); g.fillStyle = '#ef4135'; g.fillRect(20, 0, 10, 30); }],
  ['Spain', g => { g.fillStyle = '#c60b1e'; g.fillRect(0, 0, 30, 30); g.fillStyle = '#ffc400'; g.fillRect(0, 8, 30, 14); }],
  ['Italy', g => { g.fillStyle = '#009246'; g.fillRect(0, 0, 10, 30); g.fillStyle = '#fff'; g.fillRect(10, 0, 10, 30); g.fillStyle = '#ce2b37'; g.fillRect(20, 0, 10, 30); }],
  ['Japan', g => { g.fillStyle = '#fff'; g.fillRect(0, 0, 30, 30); g.fillStyle = '#bc002d'; g.beginPath(); g.arc(15, 15, 8, 0, 6.283); g.fill(); }],
  ['Sweden', g => { g.fillStyle = '#006aa7'; g.fillRect(0, 0, 30, 30); g.fillStyle = '#fecc00'; g.fillRect(0, 12, 30, 6); g.fillRect(9, 0, 6, 30); }],
  ['Holland', g => { g.fillStyle = '#ae1c28'; g.fillRect(0, 0, 30, 10); g.fillStyle = '#fff'; g.fillRect(0, 10, 30, 10); g.fillStyle = '#21468b'; g.fillRect(0, 20, 30, 10); }],
  ['England', g => { g.fillStyle = '#fff'; g.fillRect(0, 0, 30, 30); g.fillStyle = '#cf142b'; g.fillRect(0, 12, 30, 6); g.fillRect(12, 0, 6, 30); }],
  ['Portugal', g => { g.fillStyle = '#006600'; g.fillRect(0, 0, 12, 30); g.fillStyle = '#ff0000'; g.fillRect(12, 0, 18, 30); g.fillStyle = '#ffd400'; g.beginPath(); g.arc(12, 15, 5, 0, 6.283); g.fill(); }],
  ['USA', g => { for (let i = 0; i < 7; i++) { g.fillStyle = i % 2 ? '#fff' : '#b22234'; g.fillRect(0, i * 30 / 7, 30, 30 / 7 + .5); } g.fillStyle = '#3c3b6e'; g.fillRect(0, 0, 14, 16); g.fillStyle = '#fff'; for (let i = 0; i < 6; i++) g.fillRect(2 + (i % 3) * 4, 2 + (i >> 1) * 4.5, 1.6, 1.6); }],
  ['Mexico', g => { g.fillStyle = '#006847'; g.fillRect(0, 0, 10, 30); g.fillStyle = '#fff'; g.fillRect(10, 0, 10, 30); g.fillStyle = '#ce1126'; g.fillRect(20, 0, 10, 30); g.fillStyle = '#8a6a2a'; g.beginPath(); g.arc(15, 15, 3, 0, 6.283); g.fill(); }],
  ['Croatia', g => { g.fillStyle = '#ff0000'; g.fillRect(0, 0, 30, 10); g.fillStyle = '#fff'; g.fillRect(0, 10, 30, 10); g.fillStyle = '#171796'; g.fillRect(0, 20, 30, 10); g.fillStyle = '#d33'; g.fillRect(11, 9, 8, 11); g.fillStyle = '#fff'; g.fillRect(11, 9, 4, 5.5); g.fillRect(15, 14.5, 4, 5.5); }],
  ['Turkey', g => { g.fillStyle = '#e30a17'; g.fillRect(0, 0, 30, 30); g.fillStyle = '#fff'; g.beginPath(); g.arc(13, 15, 7, 0, 6.283); g.fill(); g.fillStyle = '#e30a17'; g.beginPath(); g.arc(15, 15, 5.6, 0, 6.283); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(20, 15, 2.2, 0, 6.283); g.fill(); }]
];
const tsFlagCv = TS_FLAGS.map(([n, fn]) => off(30, 30, g => fn(g)));
const tsFlagUrl = i => (tsFlagCv[i].__u = tsFlagCv[i].__u || tsFlagCv[i].toDataURL());
const tsForm = () => { const base = [[85, 300], [215, 300], [115, 380], [185, 380]]; const out = [[150, 230, 0, 0, 1]]; base.forEach(([x, y]) => out.push([x, y, 0, 0, 1])); base.forEach(([x, y]) => out.push([x, TS.h - y, 0, 0, 1])); return out; };
const tsOwn = seat => seat === 0 ? [1, 2, 3, 4] : [5, 6, 7, 8];
const tsGoals = [{ x: 150, y: 6, r: 32 }, { x: 150, y: 454, r: 32 }];
let TS_R = null; window.TSFLAG = i => { if (TS_R) { TS_R.fl = i; const el = document.querySelector('.tsflags'); if (el) $$('img', el).forEach((im, k) => im.classList.toggle('on', k === i)); } };
const tsFlag = (s, R, o) => (o === R.seat && R.fl != null) ? R.fl : (s && s.fl && s.fl[o] != null ? s.fl[o] : (o === 0 ? 0 : 1));
const tsStripe = off(300, 460, (g, w, h) => {
  for (let i = 0; i < 12; i++) { g.fillStyle = i % 2 ? '#2f9e44' : '#37b24d'; g.fillRect(0, i * h / 12, w, h / 12 + 1); }
  g.strokeStyle = '#ffffffcc'; g.lineWidth = 3; g.strokeRect(14, 14, w - 28, h - 28); g.beginPath(); g.moveTo(14, h / 2); g.lineTo(w - 14, h / 2); g.stroke(); g.beginPath(); g.arc(w / 2, h / 2, 42, 0, 6.283); g.stroke(); g.fillStyle = '#fff'; g.beginPath(); g.arc(w / 2, h / 2, 3, 0, 6.283); g.fill();
  g.strokeRect(70, 14, 160, 68); g.strokeRect(70, h - 82, 160, 68); g.strokeRect(105, 14, 90, 30); g.strokeRect(105, h - 44, 90, 30); g.beginPath(); g.arc(w / 2, 82, 26, 0.2 * Math.PI, 0.8 * Math.PI); g.stroke(); g.beginPath(); g.arc(w / 2, h - 82, 26, 1.2 * Math.PI, 1.8 * Math.PI); g.stroke();
  // goals with nets
  [[0, 1], [h, -1]].forEach(([y, d]) => { g.fillStyle = '#0c1a10'; g.beginPath(); g.ellipse(150, y, 40, 26, 0, 0, 6.283); g.fill(); g.fillStyle = '#e8eaf0'; g.fillRect(104, y === 0 ? 0 : h - 12, 92, 12); g.strokeStyle = '#ffffff90'; g.lineWidth = 1; for (let k = 0; k < 10; k++) { g.beginPath(); g.moveTo(112 + k * 8, y === 0 ? 0 : h); g.lineTo(112 + k * 8, y === 0 ? 24 : h - 24); g.stroke(); } for (let k = 1; k < 4; k++) { g.beginPath(); g.moveTo(110, y === 0 ? k * 7 : h - k * 7); g.lineTo(190, y === 0 ? k * 7 : h - k * 7); g.stroke(); } });
  // ad boards
  g.fillStyle = '#12306a'; g.fillRect(0, 0, w, 12); g.fillRect(0, h - 12, w, 12); g.fillRect(0, 0, 12, h); g.fillRect(w - 12, 0, 12, h); g.fillStyle = '#ffd54a'; for (let i = 0; i < 14; i++) { g.fillRect(8 + i * 21, 4, 12, 4); g.fillRect(8 + i * 21, h - 8, 12, 4); } for (let i = 0; i < 20; i++) { g.fillRect(4, 8 + i * 22, 4, 12); g.fillRect(w - 8, 8 + i * 22, 4, 12); }
});
const G_TSOC2 = physGame({
  id: 'tsoc', name: 'Table Soccer', icon: '⚽', desc: 'Pick your team flag, tap a cap, pull back and flick it into the ball. First to 3 goals wins!', sym: ['🔴', '🔵'],
  w: TS.w, h: TS.h, ix: TS.ix, fr: 175, rest: .9, pockets: tsGoals, r: i => i === 0 ? 8 : 15, pull: 85,
  pickCap(s, R, p) { let best = null, bd = 34; tsOwn(R.seat).forEach(i => { const q = s.b[i], d = Math.hypot(q[0] - p.x, q[1] - p.y); if (d < bd) { bd = d; best = i; } }); return best; },
  init: () => ({ b: tsForm(), sc: [0, 0], turn: 0, winner: null, n: 0, msg: '', fl: [null, null] }),
  prep: (s, m, seat) => ({ ang: +m.ang, pow: clamp(+m.pow || 0, 0, 1), k: tsOwn(seat).includes(m.k) ? m.k : tsOwn(seat)[0], f: Number.isInteger(m.f) && m.f >= 0 && m.f < TS_FLAGS.length ? m.f : null }),
  valid: (s, m, seat) => s.winner == null && s.turn === seat && isFinite(m.ang) && isFinite(m.pow),
  launch(P, m) { const q = P.balls[m.k]; const v = 140 + 760 * m.pow; q.vx = Math.cos(m.ang) * v; q.vy = Math.sin(m.ang) * v; },
  after(s, ev, seat) {
    s.msg = ''; s.fl = s.fl || [null, null]; if (s.shot && s.shot.f != null) s.fl[seat] = s.shot.f;
    const scored = ev.includes(0) ? (s.b[0][1] < TS.h / 2 ? 0 : 1) : -1;
    if (scored >= 0) { s.sc[scored]++; s.msg = '⚽ GOAL!'; s.b = tsForm(); if (s.sc[scored] >= 3) { s.winner = scored; return; } s.turn = 1 - scored; return; }
    const f0 = tsForm(); ev.forEach(i => { if (i > 0) s.b[i] = f0[i].slice(); });
    s.turn = 1 - seat;
    if (s.n >= 40) s.winner = s.sc[0] === s.sc[1] ? 'draw' : (s.sc[0] > s.sc[1] ? 0 : 1);
  },
  shooter: (s, R) => { TS_R = R; if (s.winner != null) return null; const own = tsOwn(R.seat); if (R.sel == null || !own.includes(R.sel)) R.sel = own[0]; const q = s.b[R.sel]; return { x: q[0], y: q[1] }; },
  hud: (s, seat) => {
    const pick = s.turn === seat && s.winner == null && !(s.fl && s.fl[seat] != null);
    return `<div class="scorebar"><div class="p0">🔴 ${s.sc[0]}</div><div class="mut">${esc(s.msg || (s.turn === seat ? 'Tap a cap, pull back, release' : 'Opponent’s shot'))}</div><div class="p1">🔵 ${s.sc[1]}</div></div>` +
      (pick ? `<div class="tsflags"><div class="mut" style="text-align:center;margin:2px">Choose your team</div><div class="tsrow">${TS_FLAGS.map(([n], i) => `<img src="${tsFlagUrl(i)}" title="${n}" class="${(TS_R && TS_R.fl === i) || (!TS_R && i === (seat === 0 ? 0 : 1)) ? 'on' : ''}" onclick="TSFLAG(${i})">`).join('')}</div></div>` : '');
  },
  cands(s, seat) {
    const out = [], ball = s.b[0], gy = seat === 0 ? 0 : TS.h;
    for (const k of tsOwn(seat)) { const q = s.b[k]; for (const pw of [.5, .75, 1]) { out.push({ k, ang: Math.atan2(ball[1] - q[1], ball[0] - q[0]), pow: pw }); out.push({ k, ang: Math.atan2(gy - q[1], 150 - q[0]), pow: pw }); } out.push({ k, ang: Math.random() * 6.283, pow: .6 + Math.random() * .4 }); }
    return out;
  },
  eval(s, ns, seat) {
    if (ns.winner === seat) return 1000; if (ns.winner != null) return -1000;
    const gdiff = ns.sc[seat] - s.sc[seat] - (ns.sc[1 - seat] - s.sc[1 - seat]);
    return gdiff * 200 + (seat === 0 ? (230 - ns.b[0][1]) : (ns.b[0][1] - 230)) * .5 + Math.random() * 3;
  },
  draw(c, balls, R, s, can) {
    TS_R = R; c.drawImage(tsStripe, 0, 0);
    const own = tsOwn(R.seat);
    for (const b of balls) {
      if (!b.a) continue;
      if (b.id === 0) { c.fillStyle = '#0005'; c.beginPath(); c.ellipse(b.x + 2, b.y + 3, 8, 6, 0, 0, 6.283); c.fill(); const g = c.createRadialGradient(b.x - 2, b.y - 2, 1, b.x, b.y, 8); g.addColorStop(0, '#fff'); g.addColorStop(1, '#c9ccd6'); c.fillStyle = g; c.beginPath(); c.arc(b.x, b.y, 8, 0, 6.283); c.fill(); c.fillStyle = '#222'; for (let k = 0; k < 5; k++) { const a = k * 1.2566; c.beginPath(); c.arc(b.x + Math.cos(a) * 4.6, b.y + Math.sin(a) * 4.6, 1.8, 0, 6.283); c.fill(); } c.beginPath(); c.arc(b.x, b.y, 2.4, 0, 6.283); c.fill(); continue; }
      const o = b.id < 5 ? 0 : 1, fi = tsFlag(s, R, o), sel = can && own.includes(b.id) && R.sel === b.id;
      c.fillStyle = '#0006'; c.beginPath(); c.arc(b.x + 2, b.y + 4, 15, 0, 6.283); c.fill();
      c.fillStyle = o ? '#2a6fe8' : '#e8374f'; c.beginPath(); c.arc(b.x, b.y, 15, 0, 6.283); c.fill();
      c.save(); c.beginPath(); c.arc(b.x, b.y, 12, 0, 6.283); c.clip(); c.drawImage(tsFlagCv[fi], b.x - 12, b.y - 12, 24, 24); c.restore();
      const hl = c.createRadialGradient(b.x - 4, b.y - 5, 1, b.x, b.y, 14); hl.addColorStop(0, '#ffffff70'); hl.addColorStop(.5, '#ffffff00'); hl.addColorStop(1, '#00000030'); c.fillStyle = hl; c.beginPath(); c.arc(b.x, b.y, 12, 0, 6.283); c.fill();
      c.strokeStyle = sel ? '#ffd54a' : '#fff'; c.lineWidth = sel ? 4 : 2; c.beginPath(); c.arc(b.x, b.y, 15, 0, 6.283); c.stroke();
    }
    const a = R.sling && R.sling.aim, q = can && R.sel != null ? balls[R.sel] : null;
    if (a && q && q.a) { c.strokeStyle = '#fff'; c.setLineDash([6, 6]); c.lineWidth = 2.5; c.beginPath(); c.moveTo(q.x, q.y); c.lineTo(q.x + Math.cos(a.ang) * (60 + a.pow * 230), q.y + Math.sin(a.ang) * (60 + a.pow * 230)); c.stroke(); c.setLineDash([]); }
  }
});

/* ================= MATCH MONSTER (monsters charge up when you match their gem colour) ================= */
const MM_COL = [['#ff6a3a', '#ffd08a', '#ffb02e'], ['#3aa0ff', '#d6f0ff', '#1c64d6'], ['#4cc05a', '#e2f9cc', '#2a8a3a'], ['#ffd23a', '#fff3b0', '#f08a00'], ['#9a66e6', '#e2d2ff', '#4b2a8a'], ['#c98a4a', '#f4dcb4', '#7a4a1f']];
const MM_NAME = ['Embro', 'Splashy', 'Leafo', 'Zappy', 'Grimbat', 'Rocko'];
function monsterSVG(e) {
  const [b, bel, ac] = MM_COL[e];
  const eye = `<circle cx="38" cy="52" r="7.5" fill="#fff"/><circle cx="62" cy="52" r="7.5" fill="#fff"/><circle cx="39.5" cy="53" r="4" fill="#1a1030"/><circle cx="60.5" cy="53" r="4" fill="#1a1030"/><circle cx="41" cy="51" r="1.4" fill="#fff"/><circle cx="62" cy="51" r="1.4" fill="#fff"/>`;
  const mouth = `<path d="M42 68 Q50 75 58 68" stroke="#3a1a1a" stroke-width="2.4" fill="none" stroke-linecap="round"/>`;
  const base = `<ellipse cx="50" cy="94" rx="26" ry="5" fill="#0003"/><ellipse cx="50" cy="62" rx="31" ry="29" fill="${b}"/><ellipse cx="50" cy="71" rx="19" ry="16" fill="${bel}"/>`;
  const hl = `<ellipse cx="36" cy="40" rx="9" ry="5" fill="#fff" opacity=".35" transform="rotate(-25 36 40)"/>`;
  const ex = [
    `<path d="M30 38 L24 14 L40 32 Z" fill="${ac}"/><path d="M70 38 L76 14 L60 32 Z" fill="${ac}"/><path d="M80 66 Q96 58 92 38 Q86 52 78 54 Z" fill="${ac}"/><path d="M86 56 Q92 46 90 40 Q88 50 84 54 Z" fill="#fff6" /><path d="M20 62 Q6 50 12 36 Q18 52 26 56 Z" fill="${ac}"/>`,
    `<path d="M46 62 L54 62 L50 70 Z" fill="#ffa21a"/><path d="M38 28 Q50 10 62 28 Q50 22 38 28 Z" fill="${ac}"/><path d="M20 66 Q6 74 12 84 Q24 78 28 70 Z" fill="${ac}"/><path d="M80 66 Q94 74 88 84 Q76 78 72 70 Z" fill="${ac}"/>`,
    `<ellipse cx="50" cy="26" rx="9" ry="18" fill="${ac}" transform="rotate(-18 50 26)"/><ellipse cx="62" cy="28" rx="7" ry="15" fill="#6fe07a" transform="rotate(30 62 28)"/><path d="M34 70 Q50 82 66 70" stroke="#2a5a2a" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    `<path d="M26 40 L20 8 L42 30 Z" fill="${b}" stroke="${ac}" stroke-width="2"/><path d="M74 40 L80 8 L58 30 Z" fill="${b}" stroke="${ac}" stroke-width="2"/><path d="M20 8 L26 14 L22 14 Z" fill="#222"/><path d="M80 8 L74 14 L78 14 Z" fill="#222"/><path d="M80 70 L92 62 L86 74 L98 70 L82 88 L86 76 L78 80 Z" fill="${ac}"/>`,
    `<path d="M20 58 L2 34 Q6 62 14 78 Z" fill="${ac}"/><path d="M80 58 L98 34 Q94 62 86 78 Z" fill="${ac}"/><path d="M32 40 L28 22 L42 34 Z" fill="${b}"/><path d="M68 40 L72 22 L58 34 Z" fill="${b}"/><path d="M44 69 L47 78 L50 70 Z M50 70 L53 78 L56 69 Z" fill="#fff"/>`,
    `<path d="M26 40 L32 22 L40 38 Z M42 34 L50 14 L58 34 Z M60 38 L68 22 L74 40 Z" fill="${ac}"/><path d="M28 46 Q38 40 48 46" stroke="#3a2a14" stroke-width="3.5" fill="none"/><path d="M52 46 Q62 40 72 46" stroke="#3a2a14" stroke-width="3.5" fill="none"/><circle cx="30" cy="78" r="5" fill="${ac}"/><circle cx="70" cy="78" r="5" fill="${ac}"/>`
  ];
  return `<svg viewBox="0 0 100 100">${ex[e] && (e === 4 || e === 3 || e === 0 || e === 1) ? ex[e] : ''}${base}${e === 2 || e === 5 ? ex[e] : ''}${hl}${eye}${e === 1 || e === 2 || e === 4 ? '' : ''}${e === 1 ? '' : mouth}</svg>`;
}

/* ================= FINAL LIST (same order as the Playmates design sheet; 18+ always last) ================= */
G_BOT.name = 'Brawlbots'; G_BANK.name = 'Bankroll'; G_BG.name = 'Backgammon'; G_RV.name = 'Reversi';
const META = {
  pool: ['sports', '2 Players'], bowl: ['sports', '2 Players'], monster: ['puzzle', '2 Players'], bots: ['arcade', '2 Players'], bounce: ['arcade', '2 Players'],
  dice: ['arcade', '2 Players'], golf: ['sports', '2 Players'], tsoc: ['sports', '2 Players'], darts: ['sports', '2 Players'], carrom: ['board', '2 Players'],
  word: ['puzzle', '2 Players'], plox: ['puzzle', '2 Players'], disco: ['arcade', '2 Players'], arch: ['sports', '2 Players'], skee: ['arcade', '2 Players'],
  c4: ['board', '2 Players'], dom: ['board', '2 Players'], bg: ['board', '2 Players'], sea: ['board', '2 Players'], bloko: ['puzzle', '2 Players'],
  db: ['board', '2 Players'], hoop: ['sports', '2 Players'], ck: ['board', '2 Players'], rv: ['board', '2 Players'], ttt: ['board', '2 Players'],
  mem: ['puzzle', '2 Players'], ludo: ['board', '2 Players'], bank: ['board', '2 Players'], brawl: ['arcade', '2 Players'], safari: ['arcade', '2 Players'], tower: ['arcade', '2 Players'], candy: ['puzzle', '2 Players'], puzzle: ['puzzle', '2 Players'],
  quiz: ['adult', '2 Players'], pun: ['adult', '2 Players'], int: ['adult', '2 Players']
};
const ALL_GAMES = [G_POOL, G_BOWL2, G_MEM, G_BRAWL, G_BOUNCE2, G_DICE, G_GOLF2, G_TSOC2, G_DART2, G_CARROM2, G_WORD2, G_PLOX2, G_DISCO2, G_ARCH2, G_SKEE2, G_C4, G_DOM, G_BG, G_SEA2, G_BLOKO3, G_DB, G_HOOP2, G_CK, G_RV, G_TTT, G_LUDO, G_BANK2, G_SAFARI, G_TOWER, G_CANDY, G_PUZZLE, G_QUIZ, G_PUN, G_INT];
ALL_GAMES.forEach(g => { const m = META[g.id]; g.cat = m[0]; g.players = m[1]; });
const READY = ['ludo', 'pool', 'ttt', 'monster', 'bowl', 'darts', 'carrom', 'golf', 'tsoc', 'hoop', 'arch', 'skee', 'plox', 'bloko', 'disco', 'bounce', 'word', 'dom', 'bg', 'sea', 'ck', 'c4', 'rv', 'db', 'brawl', 'bank', 'safari', 'tower', 'candy', 'puzzle'];   // fully finished games; the rest stay "Coming soon" until they are improved
ALL_GAMES.forEach(g => { g.soon = !g.adult && !READY.includes(g.id); });
const GAMES = [...READY.map(i => ALL_GAMES.find(g => g.id === i)), ...ALL_GAMES.filter(g => g.soon), ...ALL_GAMES.filter(g => g.adult)];
