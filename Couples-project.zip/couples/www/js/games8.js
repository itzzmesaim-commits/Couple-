/* Playmates - Wave 3 (part 1): Plox, Bloko (Blokus style), Disc-o (Plinko), Bounce (platformer) */

function shade(hex, k) { const n = parseInt(hex.slice(1), 16), f = v => Math.max(0, Math.min(255, Math.round(v + (k > 0 ? (255 - v) * k : v * k)))); return `rgb(${f(n >> 16)},${f((n >> 8) & 255)},${f(n & 255)})`; }
function tile(c, x, y, s, col, a) {
  c.save(); if (a != null) c.globalAlpha = a;
  const g = c.createLinearGradient(x, y, x, y + s); g.addColorStop(0, shade(col, .35)); g.addColorStop(.5, col); g.addColorStop(1, shade(col, -.3));
  c.fillStyle = shade(col, -.5); rr(c, x + 1, y + 2.5, s - 2, s - 2, s * .2); c.fill();
  c.fillStyle = g; rr(c, x + 1, y + 1, s - 2, s - 3, s * .2); c.fill();
  c.fillStyle = '#ffffff55'; rr(c, x + s * .14, y + s * .1, s * .72, s * .28, s * .12); c.fill();
  c.restore();
}

/* ---------- Tetris-style shapes for Plox ---------- */
const PLX = [
  ['I', [[1, 1, 1, 1]]], ['I', [[1], [1], [1], [1]]], ['O', [[1, 1], [1, 1]]],
  ['T', [[1, 1, 1], [0, 1, 0]]], ['T', [[0, 1], [1, 1], [0, 1]]], ['T', [[0, 1, 0], [1, 1, 1]]], ['T', [[1, 0], [1, 1], [1, 0]]],
  ['S', [[0, 1, 1], [1, 1, 0]]], ['S', [[1, 0], [1, 1], [0, 1]]], ['Z', [[1, 1, 0], [0, 1, 1]]], ['Z', [[0, 1], [1, 1], [1, 0]]],
  ['L', [[1, 0], [1, 0], [1, 1]]], ['L', [[1, 1, 1], [1, 0, 0]]], ['L', [[1, 1], [0, 1], [0, 1]]], ['L', [[0, 0, 1], [1, 1, 1]]],
  ['J', [[0, 1], [0, 1], [1, 1]]], ['J', [[1, 0, 0], [1, 1, 1]]], ['J', [[1, 1], [1, 0], [1, 0]]], ['J', [[1, 1, 1], [0, 0, 1]]],
  ['D', [[1]]], ['D', [[1, 1]]], ['D', [[1], [1]]], ['D', [[1, 1, 1]]], ['D', [[1], [1], [1]]], ['W', [[1, 1, 1, 1, 1]]], ['W', [[1], [1], [1], [1], [1]]], ['O', [[1, 1, 1], [1, 1, 1], [1, 1, 1]]]
];
const PLX_COL = { I: '#22d3ee', O: '#ffd54a', T: '#a259ff', S: '#3ddc97', Z: '#ff4d5a', L: '#ff8a3d', J: '#4a7dff', D: '#ff6fb5', W: '#7cf06a' };

/* generic drag-and-drop block board used by Plox (solo duel); shapes come from o.shapes */
function blockUI(box, o) {
  const { cv, c } = arena(box, 360, 560), N = o.N, CS = Math.floor(320 / N), BX = 20, BY = 80, BW = CS * N, SH = o.shapes;
  let drag = null, fx = [], t = 0, pops = popups();
  const slot = i => ({ x: 14 + i * 114, y: 430, w: 108, h: 112 });
  const sizeOf = (p, cs) => ({ w: p[0].length * cs, h: p.length * cs });
  const anchor = () => { const p = SH[o.tray()[drag.i].k][1], sz = sizeOf(p, CS), tx_ = drag.x - sz.w / 2, ty = drag.y - 70 - sz.h / 2; return { r: Math.round((ty - BY) / CS), c: Math.round((tx_ - BX) / CS), tx: tx_, ty }; };
  cv.addEventListener('pointerdown', e => {
    e.preventDefault(); if (!o.canPlay()) return; const p = ptr(cv, e), tr = o.tray();
    for (let i = 0; i < 3; i++) { const s = slot(i); if (tr[i] && p.x > s.x && p.x < s.x + s.w && p.y > s.y - 10 && p.y < s.y + s.h + 10) { drag = { i, x: p.x, y: p.y }; try { cv.setPointerCapture(e.pointerId); } catch (x) {} return; } }
  });
  cv.addEventListener('pointermove', e => { if (drag) { const p = ptr(cv, e); drag.x = p.x; drag.y = p.y; } });
  cv.addEventListener('pointerup', () => { if (!drag) return; const a = anchor(), p = SH[o.tray()[drag.i].k][1]; if (pFits(o.grid(), N, p, a.r, a.c)) o.place(drag.i, a.r, a.c, fx); drag = null; });
  cv.addEventListener('pointercancel', () => { drag = null; });
  const stop = anim(dt => {
    t += dt; const g = o.grid(), tr = o.tray();
    const bgc = c.createLinearGradient(0, 0, 0, 560); bgc.addColorStop(0, '#102a52'); bgc.addColorStop(1, '#081433'); c.fillStyle = bgc; c.fillRect(0, 0, 360, 560);
    o.hud(c, t);
    c.fillStyle = '#0a1330'; rr(c, BX - 8, BY - 8, BW + 16, BW + 16, 14); c.fill(); c.strokeStyle = '#3aa0ff77'; c.lineWidth = 3; c.stroke();
    for (let r = 0; r < N; r++) for (let q = 0; q < N; q++) { c.fillStyle = (r + q) % 2 ? '#14234a' : '#182a58'; rr(c, BX + q * CS + 1, BY + r * CS + 1, CS - 2, CS - 2, 4); c.fill(); }
    for (let r = 0; r < N; r++) for (let q = 0; q < N; q++) { const v = g[r * N + q]; if (v) tile(c, BX + q * CS, BY + r * CS, CS, v); }
    if (drag) {
      const a = anchor(), p = SH[tr[drag.i].k][1], ok = pFits(g, N, p, a.r, a.c);
      if (ok) { p.forEach((row, i) => row.forEach((v, j) => { if (v) { c.fillStyle = '#ffffff30'; rr(c, BX + (a.c + j) * CS + 1, BY + (a.r + i) * CS + 1, CS - 2, CS - 2, 5); c.fill(); } })); const tg = g.slice(); p.forEach((row, i) => row.forEach((v, j) => { if (v) tg[(a.r + i) * N + a.c + j] = 1; })); for (let r = 0; r < N; r++) if (Array.from({ length: N }, (_, q) => tg[r * N + q]).every(Boolean)) { c.fillStyle = '#ffd54a44'; c.fillRect(BX, BY + r * CS, BW, CS); } for (let q = 0; q < N; q++) if (Array.from({ length: N }, (_, r) => tg[r * N + q]).every(Boolean)) { c.fillStyle = '#ffd54a44'; c.fillRect(BX + q * CS, BY, CS, BW); } }
    }
    fx = fx.filter(f => (f.age += dt) < .55); fx.forEach(f => { c.globalAlpha = 1 - f.age / .55; c.fillStyle = '#fff'; const s = CS * (1 + f.age * .8); c.fillRect(BX + f.q * CS + CS / 2 - s / 2, BY + f.r * CS + CS / 2 - s / 2, s, s); c.globalAlpha = 1; });
    tx(c, 'NEXT', 40, 418, 12, '#8fb4ff', 'center');
    for (let i = 0; i < 3; i++) {
      const s = slot(i); c.fillStyle = '#0a1330'; rr(c, s.x, s.y, s.w, s.h, 14); c.fill(); c.strokeStyle = (drag && drag.i === i) ? '#ffd54a' : '#3a5acc66'; c.lineWidth = 2; c.stroke();
      const it = tr[i]; if (!it) continue; const p = SH[it.k][1], cs = Math.min(26, 84 / Math.max(p.length, p[0].length)), sz = sizeOf(p, cs), ox = s.x + (s.w - sz.w) / 2, oy = s.y + (s.h - sz.h) / 2;
      const fits = o.canPlay() && pAnyFit(g, N, p); p.forEach((row, a) => row.forEach((v, b) => { if (v) tile(c, ox + b * cs, oy + a * cs, cs, o.colorOf(it.k), (drag && drag.i === i) ? .25 : (fits ? 1 : .4)); }));
    }
    if (drag) { const a = anchor(), p = SH[tr[drag.i].k][1]; p.forEach((row, i) => row.forEach((v, j) => { if (v) tile(c, a.tx + j * CS, a.ty + i * CS, CS, o.colorOf(tr[drag.i].k), .92); })); }
    pops.draw(c, dt);
  });
  return { stop, pops, cv };
}
const lineFlash = (g, N, fx) => { for (let r = 0; r < N; r++) if (Array.from({ length: N }, (_, c) => g[r * N + c]).every(Boolean)) for (let c = 0; c < N; c++) fx.push({ r, q: c, age: 0 }); for (let c = 0; c < N; c++) if (Array.from({ length: N }, (_, r) => g[r * N + c]).every(Boolean)) for (let r = 0; r < N; r++) fx.push({ r, q: c, age: 0 }); };

/* ================= PLOX ================= */
const G_PLOX2 = duel({
  id: 'plox', name: 'Plox', icon: '🧱', desc: 'Drag block shapes onto the grid. Fill full rows or columns to clear them. Combos score big!',
  bot: () => 220 + Math.floor(Math.random() * 360),
  play(box, seed, done) {
    const R = rng(seed), N = 10; let g = new Array(N * N).fill(0), score = 0, lines = 0, tray = [], over = false, combo = 0, msg = 'Drag a block onto the grid';
    const nt = () => { tray = [0, 1, 2].map(() => ({ k: Math.floor(R() * PLX.length) })); }; nt();
    const ui = blockUI(box, {
      N, shapes: PLX, grid: () => g, tray: () => tray, canPlay: () => !over, colorOf: k => PLX_COL[PLX[k][0]],
      place(i, r, c, fx) {
        const it = tray[i], p = PLX[it.k][1], col = PLX_COL[PLX[it.k][0]]; p.forEach((row, a) => row.forEach((v, b) => { if (v) g[(r + a) * N + c + b] = col; })); score += pCells(p);
        lineFlash(g, N, fx); const n = pClear(g, N);
        if (n) { combo++; lines += n; const gain = n * 10 + (n - 1) * 15 + (combo > 1 ? combo * 5 : 0); score += gain; msg = (n > 1 ? n + ' lines! ' : 'Line! ') + (combo > 1 ? 'Combo x' + combo + ' ' : '') + '+' + gain; ui.pops.add('+' + gain, 180, 250, '#ffd54a'); } else { combo = 0; msg = '+' + pCells(p); }
        tray[i] = null; if (tray.every(x => !x)) nt();
        if (!tray.some(x => x && pAnyFit(g, N, PLX[x.k][1]))) { over = true; setTimeout(() => { ui.stop(); fin(box, score, done, 'No more moves!'); }, 900); }
      },
      hud(c) { hudTop(c, 360, score, null, (gg, w) => { tx(gg, 'LINES ' + lines, w - 56, 28, 15, '#ffd54a'); }); tx(c, msg, 180, 68, 13, '#fff', 'center', '#000a'); }
    });
    return () => { over = true; ui.stop(); };
  }
});

/* ================= BLOKO (Blokus-style territory game) ================= */
const BK_N = 14, BK_SRC = ['#', '##', '###', '#../##.', '####', '##/##', '###/.#.', '#./#./##', '##./.##', '.##/##./.#.', '#####', '#.../####', '##../.###', '##/##/#.', '###/.#./.#.', '#.#/###', '#../#../###', '#../##./.##', '.#./###/.#.', '.#../####', '##./.#./.##'];
function bkParse(str) { const rows = str.split(/[\/]/); if (str.includes('.') && !str.includes('/') && str.includes('##') && str.includes('#..')) return null; return rows.map(r => r.split('').map(ch => ch === '#' ? 1 : 0)); }
const BK_PIECES = [
  [[1]], [[1, 1]], [[1, 1, 1]], [[1, 0], [1, 1]], [[1, 1, 1, 1]], [[1, 1], [1, 1]], [[1, 1, 1], [0, 1, 0]], [[1, 0], [1, 0], [1, 1]], [[1, 1, 0], [0, 1, 1]],
  [[0, 1, 1], [1, 1, 0], [0, 1, 0]], [[1, 1, 1, 1, 1]], [[1, 0, 0, 0], [1, 1, 1, 1]], [[1, 1, 0, 0], [0, 1, 1, 1]], [[1, 1], [1, 1], [1, 0]], [[1, 1, 1], [0, 1, 0], [0, 1, 0]],
  [[1, 0, 1], [1, 1, 1]], [[1, 0, 0], [1, 0, 0], [1, 1, 1]], [[1, 0, 0], [1, 1, 0], [0, 1, 1]], [[0, 1, 0], [1, 1, 1], [0, 1, 0]], [[0, 1, 0, 0], [1, 1, 1, 1]], [[1, 1, 0], [0, 1, 0], [0, 1, 1]]
];
const bkRot = p => p[0].map((_, c) => p.map(r => r[c]).reverse()), bkFlip = p => p.map(r => r.slice().reverse());
const BK_ORI = BK_PIECES.map(p => { const seen = new Set(), out = []; let q = p; for (let f = 0; f < 2; f++) { for (let r = 0; r < 4; r++) { const k = JSON.stringify(q); if (!seen.has(k)) { seen.add(k); out.push(q); } q = bkRot(q); } q = bkFlip(q); } return out; });
const BK_SIZE = BK_PIECES.map(p => pCells(p));
const bkCells = (o, r, c) => { const out = []; o.forEach((row, i) => row.forEach((v, j) => { if (v) out.push([r + i, c + j]); })); return out; };
function bkLegal(s, seat, ori, r, c) {
  const me = seat + 1, cells = bkCells(ori, r, c), first = !s.placed[seat]; let corner = false;
  for (const [y, x] of cells) {
    if (y < 0 || x < 0 || y >= BK_N || x >= BK_N || s.g[y * BK_N + x]) return false;
    for (const [dy, dx] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && s.g[yy * BK_N + xx] === me) return false; }
    for (const [dy, dx] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && s.g[yy * BK_N + xx] === me) corner = true; }
    if (first && y === (seat ? BK_N - 1 : 0) && x === (seat ? BK_N - 1 : 0)) corner = true;
  }
  return corner;
}
function bkMoves(s, seat, limit) {
  const out = [];
  for (let p = 0; p < 21; p++) { if (s.used[seat][p]) continue; for (let o = 0; o < BK_ORI[p].length; o++) { const ori = BK_ORI[p][o]; for (let r = -ori.length + 1; r < BK_N; r++) for (let c = -ori[0].length + 1; c < BK_N; c++) if (bkLegal(s, seat, ori, r, c)) { out.push({ p, o, r, c }); if (limit && out.length >= limit) return out; } } }
  return out;
}
const bkLeft = (s, seat) => s.used[seat].reduce((a, u, p) => a + (u ? 0 : BK_SIZE[p]), 0);
const G_BLOKO2 = {
  id: 'bloko', name: 'Bloko', icon: '🟦', type: 'turn', sym: ['🟥', '🟦'], desc: 'Place pieces so they touch your own colour only at the corners. Cover the most area! Fewest leftover squares wins.',
  init: () => ({ g: new Array(BK_N * BK_N).fill(0), used: [Array(21).fill(0), Array(21).fill(0)], placed: [0, 0], turn: 0, winner: null, n: 0, msg: '' }),
  status: (s, seat) => s.winner != null ? '' : (s.turn === seat ? '👉 Pick a piece, tap the board, then Place' : '⏳ Opponent’s turn'),
  move(s, m, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    const p = m.p | 0, o = m.o | 0, r = m.r | 0, c = m.c | 0; if (p < 0 || p > 20 || s.used[seat][p] || !BK_ORI[p][o]) return null;
    const ori = BK_ORI[p][o]; if (!bkLegal(s, seat, ori, r, c)) return null;
    bkCells(ori, r, c).forEach(([y, x]) => { s.g[y * BK_N + x] = seat + 1; }); s.used[seat][p] = 1; s.placed[seat]++; s.n++; s.msg = '';
    const opp = 1 - seat;
    if (bkMoves(s, opp, 1).length) s.turn = opp; else if (bkMoves(s, seat, 1).length) { s.msg = 'Opponent has no moves'; s.turn = seat; } else { const a = bkLeft(s, 0), b = bkLeft(s, 1); s.winner = a === b ? 'draw' : (a < b ? 0 : 1); }
    return s;
  },
  bot(s, seat) {
    const all = bkMoves(s, seat); if (!all.length) return null; let best = null, bs = -1e9;
    const sample = all.length > 900 ? all.filter(() => Math.random() < 900 / all.length) : all;
    for (const m of sample) { const ori = BK_ORI[m.p][m.o], cells = bkCells(ori, m.r, m.c); let sc = BK_SIZE[m.p] * 3 + Math.random() * 2; cells.forEach(([y, x]) => { sc += (7 - Math.abs(y - 6.5) - Math.abs(x - 6.5)) * .12; for (const [dy, dx] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && !s.g[yy * BK_N + xx]) sc += .35; } const oo = 3 - (seat + 1); for (const [dy, dx] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && s.g[yy * BK_N + xx] === oo) sc += .5; } }); if (sc > bs) { bs = sc; best = m; } }
    return best;
  },
  render(el, s, seat, send) {
    let R = el.__bk;
    if (!R || el.__sg !== s.gid) {
      if (el.__stop) try { el.__stop(); } catch (e) {} el.innerHTML = ''; el.__sg = s.gid;
      const { cv, c } = arena(el, 360, 440); const ctl = document.createElement('div'); ctl.className = 'bkctl'; el.appendChild(ctl);
      R = el.__bk = { s, seat, sel: -1, ori: 0, at: null, cv, c, ctl, t: 0, lastN: s.n };
      const cs = 25, bx = 5, by = 70, ghost = () => { if (R.sel < 0 || !R.at) return null; const o = BK_ORI[R.sel][R.ori], r = clamp(R.at.r - Math.floor(o.length / 2), 0, BK_N - o.length), cc = clamp(R.at.c - Math.floor(o[0].length / 2), 0, BK_N - o[0].length); return { o, r, c: cc, ok: bkLegal(R.s, R.seat, o, r, cc) }; };
      cv.addEventListener('pointerdown', e => { const p = ptr(cv, e), cc = Math.floor((p.x - bx) / cs), r = Math.floor((p.y - by) / cs); if (r < 0 || cc < 0 || r >= BK_N || cc >= BK_N) return; R.at = { r, c: cc }; draw(); e.preventDefault(); });
      const build = () => {
        const S = R.s, mine = S.turn === R.seat && S.winner == null; R.ctl.innerHTML = `<div class="bkstrip">${BK_PIECES.map((p, i) => S.used[R.seat][i] ? '' : `<button class="bkp ${R.sel === i ? 'sel' : ''}" data-p="${i}"><div class="mini" style="grid-template-columns:repeat(${p[0].length},1fr)">${p.map(row => row.map(v => `<i style="background:${v ? (R.seat ? '#4aa3ff' : '#ff4d8d') : 'transparent'}"></i>`).join('')).join('')}</div></button>`).join('')}</div><div class="bkbtns"><button class="btn sec" id="bkr">⟳ Rotate</button><button class="btn sec" id="bkf">⇋ Flip</button><button class="btn" id="bkok">✔ Place</button></div>`;
        bindAll(R.ctl, '[data-p]', b => { R.sel = +b.dataset.p; R.ori = 0; if (!R.at) R.at = { r: R.seat ? 9 : 4, c: R.seat ? 9 : 4 }; build(); draw(); });
        $('#bkr', R.ctl).onclick = () => { if (R.sel < 0) return; const L = BK_ORI[R.sel]; const cur = BK_ORI[R.sel][R.ori]; let q = bkRot(cur), k = L.findIndex(x => JSON.stringify(x) === JSON.stringify(q)); R.ori = k < 0 ? 0 : k; draw(); };
        $('#bkf', R.ctl).onclick = () => { if (R.sel < 0) return; const L = BK_ORI[R.sel]; const q = bkFlip(BK_ORI[R.sel][R.ori]); let k = L.findIndex(x => JSON.stringify(x) === JSON.stringify(q)); R.ori = k < 0 ? R.ori : k; draw(); };
        $('#bkok', R.ctl).onclick = () => { const gh = ghost(); if (mine && gh && gh.ok) { const p = R.sel; R.sel = -1; R.at = null; send({ p, o: R.ori, r: gh.r, c: gh.c }); } else toast(mine ? 'Pick a piece, tap the board where it should go (corner-touch only)' : 'Wait for your turn'); };
      };
      R.build = build;
      const draw = () => {
        const S = R.s, g0 = ghost(); const bgc = c.createLinearGradient(0, 0, 0, 440); bgc.addColorStop(0, '#16224a'); bgc.addColorStop(1, '#0a1230'); c.fillStyle = bgc; c.fillRect(0, 0, 360, 440);
        c.fillStyle = '#ff4d8d'; rr(c, 10, 10, 150, 44, 12); c.fill(); c.fillStyle = '#4aa3ff'; rr(c, 200, 10, 150, 44, 12); c.fill();
        [[0, 18], [1, 208]].forEach(([o, x]) => { tx(c, (o === R.seat ? 'You' : 'Opp') + ' · ' + bkLeft(S, o) + ' left', x + 66, 32, 14, '#fff', 'center', '#0006'); if (S.turn === o && S.winner == null) { c.strokeStyle = '#ffd54a'; c.lineWidth = 3; rr(c, o ? 200 : 10, 10, 150, 44, 12); c.stroke(); } });
        c.fillStyle = '#0a1230'; rr(c, bx - 3, by - 3, cs * BK_N + 6, cs * BK_N + 6, 8); c.fill();
        for (let r = 0; r < BK_N; r++) for (let q = 0; q < BK_N; q++) { const v = S.g[r * BK_N + q]; if (v) tile(c, bx + q * cs, by + r * cs, cs, v === 1 ? '#ff4d8d' : '#4aa3ff'); else { c.fillStyle = (r + q) % 2 ? '#e8eef8' : '#dce6f5'; c.fillRect(bx + q * cs + .5, by + r * cs + .5, cs - 1, cs - 1); } }
        [[0, 0], [BK_N - 1, BK_N - 1]].forEach(([r, q], o) => { if (!S.placed[o] && !S.g[r * BK_N + q]) { c.strokeStyle = o ? '#4aa3ff' : '#ff4d8d'; c.lineWidth = 3; c.strokeRect(bx + q * cs + 2, by + r * cs + 2, cs - 4, cs - 4); } });
        if (S.turn === R.seat && S.winner == null && S.placed[R.seat]) { c.fillStyle = (R.seat ? '#4aa3ff' : '#ff4d8d') + '99'; for (let r = 0; r < BK_N; r++) for (let q = 0; q < BK_N; q++) if (!S.g[r * BK_N + q]) { let ok = false; for (const [dy, dx] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { const yy = r + dy, xx = q + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && S.g[yy * BK_N + xx] === R.seat + 1) ok = true; } for (const [dy, dx] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) { const yy = r + dy, xx = q + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && S.g[yy * BK_N + xx] === R.seat + 1) ok = false; } if (ok) { c.beginPath(); c.arc(bx + q * cs + cs / 2, by + r * cs + cs / 2, 3, 0, 6.283); c.fill(); } } }
        if (g0) bkCells(g0.o, g0.r, g0.c).forEach(([y, x]) => { if (y >= 0 && x >= 0 && y < BK_N && x < BK_N) { c.fillStyle = g0.ok ? '#3ddc97bb' : '#ff4d4dbb'; c.fillRect(bx + x * cs, by + y * cs, cs, cs); c.strokeStyle = '#fff'; c.lineWidth = 2; c.strokeRect(bx + x * cs + 1, by + y * cs + 1, cs - 2, cs - 2); } });
        tx(c, S.winner != null ? (S.winner === R.seat ? '🏆 You win!' : S.winner === 'draw' ? 'Draw' : 'You lose') : S.msg || (S.turn === R.seat ? 'Your turn' : 'Opponent’s turn'), 180, 428, 13, '#fff', 'center', '#000a');
      };
      R.draw = draw; R.stop = anim(() => { }); el.__stop = R.stop; build(); draw();
    }
    const changed = s.n !== R.s.n || s.turn !== R.s.turn || s.winner !== R.s.winner; R.s = s; R.seat = seat; if (changed || R.first == null) { R.first = 1; R.build(); } R.draw();
  }
};

/* ================= DISC-O (Plinko with multiplier slots) ================= */
const PK = { W: 360, H: 560, top: 92, bot: 470, r: 8, pr: 5 };
const PK_MULT = [2, 4, 8, 4, 2], PK_COL = ['#ff8a3d', '#ffd54a', '#3ddc97', '#ffd54a', '#ff8a3d'];
const pkPegs = (() => { const out = []; for (let row = 0; row < 8; row++) { const n = row % 2 ? 8 : 9, off = row % 2 ? 22 : 0; for (let i = 0; i < n; i++) out.push({ x: 36 + off + i * 44 - (row % 2 ? 0 : 0), y: 150 + row * 38 }); } return out.filter(p => p.x > 14 && p.x < 346); })();
const G_DISCO2 = duel({
  id: 'disco', name: 'Disc-o', icon: '🥏', desc: '5 discs. Drag to choose where to drop, release to let it fall. Bounce off the pegs into the x8 slot!',
  bot: () => 700 + Math.floor(Math.random() * 1500),
  play(box, seed, done) {
    const R = rng(seed), { cv, c } = arena(box, PK.W, PK.H), bonus = new Set(); while (bonus.size < 5) bonus.add(Math.floor(R() * pkPegs.length));
    const bg = off(PK.W, PK.H, (g, w, h) => {
      const bgc = g.createLinearGradient(0, 0, 0, h); bgc.addColorStop(0, '#3a1a78'); bgc.addColorStop(1, '#120a3a'); g.fillStyle = bgc; g.fillRect(0, 0, w, h);
      g.fillStyle = '#ff9a2e'; g.beginPath(); g.moveTo(0, 70); g.quadraticCurveTo(w / 2, 10, w, 70); g.lineTo(w, 90); g.quadraticCurveTo(w / 2, 36, 0, 90); g.fill();
      g.fillStyle = '#ffffff10'; for (let i = 0; i < 40; i++) { g.beginPath(); g.arc((i * 83) % w, 100 + (i * 47) % 380, 2, 0, 6.283); g.fill(); }
      g.strokeStyle = '#d66bff'; g.lineWidth = 6; g.strokeRect(3, 3, w - 6, h - 6);
      PK_MULT.forEach((m, i) => { const x0 = i * 72, col = PK_COL[i]; const gr = g.createLinearGradient(0, PK.bot, 0, PK.bot + 60); gr.addColorStop(0, shade(col, .2)); gr.addColorStop(1, shade(col, -.4)); g.fillStyle = gr; rr(g, x0 + 3, PK.bot + 4, 66, 58, 8); g.fill(); g.strokeStyle = '#fff8'; g.lineWidth = 2; g.stroke(); g.fillStyle = '#2a1050'; g.font = '900 26px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('x' + m, x0 + 36, PK.bot + 34); });
      g.fillStyle = '#ffffff30'; for (let i = 1; i < 5; i++) g.fillRect(i * 72 - 2, PK.bot - 30, 4, 34);
    });
    let n = 0, total = 0, over = false, t = 0, dropX = 180, aiming = false, disc = null, msg = 'Drag left/right, release to drop', hitB = new Set(), trail = [];
    const pops = popups();
    cv.addEventListener('pointerdown', e => { e.preventDefault(); if (over || disc) return; aiming = true; dropX = clamp(ptr(cv, e).x, 24, 336); try { cv.setPointerCapture(e.pointerId); } catch (x) {} });
    cv.addEventListener('pointermove', e => { if (aiming) dropX = clamp(ptr(cv, e).x, 24, 336); });
    cv.addEventListener('pointerup', () => { if (!aiming) return; aiming = false; if (disc || over) return; disc = { x: dropX, y: PK.top, vx: 0, vy: 0, t: 0 }; hitB = new Set(); trail = []; });
    const land = () => {
      const i = clamp(Math.floor(disc.x / 72), 0, 4), mult = PK_MULT[i], pts = mult * 100 + hitB.size * 50; total += pts; n++;
      msg = 'x' + mult + (hitB.size ? ' + ' + hitB.size + ' bonus pegs' : '') + ' = ' + pts; pops.add('+' + pts, disc.x, PK.bot - 20, '#ffd54a'); disc = null;
      if (n >= 5) { over = true; setTimeout(() => { stop(); fin(box, total, done, 'All discs dropped!'); }, 1000); }
    };
    const stop = anim(dt => {
      t += dt; if (disc) for (let k = 0; k < 4; k++) {
        const d = dt / 4, b = disc; b.vy += 900 * d; b.x += b.vx * d; b.y += b.vy * d; b.t += d;
        if (b.x < 14 + PK.r) { b.x = 14 + PK.r; b.vx = Math.abs(b.vx) * .6; } if (b.x > PK.W - 14 - PK.r) { b.x = PK.W - 14 - PK.r; b.vx = -Math.abs(b.vx) * .6; }
        pkPegs.forEach((p, i) => { const dx = b.x - p.x, dy = b.y - p.y, dd = Math.hypot(dx, dy), rr_ = PK.r + PK.pr; if (dd < rr_ && dd > 0) { const nx = dx / dd, ny = dy / dd, dot = b.vx * nx + b.vy * ny; if (dot < 0) { b.vx -= 1.62 * dot * nx; b.vy -= 1.62 * dot * ny; } b.x = p.x + nx * (rr_ + .1); b.y = p.y + ny * (rr_ + .1); if (bonus.has(i) && !hitB.has(i)) { hitB.add(i); pops.add('+50', p.x, p.y - 8, '#7fd6ff'); } } });
        if (b.y > PK.bot - 6) { b.y = PK.bot - 6; land(); break; }
      }
      if (disc) { trail.push({ x: disc.x, y: disc.y }); if (trail.length > 8) trail.shift(); }
      c.drawImage(bg, 0, 0);
      pkPegs.forEach((p, i) => { const bn = bonus.has(i), hit = hitB.has(i); c.fillStyle = bn ? (hit ? '#ffd54a' : '#4fd0ff') : '#e8e0ff'; if (bn) { c.shadowColor = '#4fd0ff'; c.shadowBlur = hit ? 4 : 12; } c.beginPath(); c.arc(p.x, p.y, PK.pr, 0, 6.283); c.fill(); c.shadowBlur = 0; });
      trail.forEach((q, i) => { c.globalAlpha = i / trail.length * .35; c.fillStyle = '#ffb02e'; c.beginPath(); c.arc(q.x, q.y, PK.r * .8, 0, 6.283); c.fill(); }); c.globalAlpha = 1;
      const dd = disc || (over ? null : { x: dropX, y: PK.top - 6 });
      if (dd) { if (aiming) { c.strokeStyle = '#ffffff55'; c.setLineDash([5, 7]); c.lineWidth = 2; c.beginPath(); c.moveTo(dd.x, PK.top); c.lineTo(dd.x, PK.bot); c.stroke(); c.setLineDash([]); } const g = c.createRadialGradient(dd.x - 3, dd.y - 3, 1, dd.x, dd.y, PK.r); g.addColorStop(0, '#fff3a0'); g.addColorStop(.6, '#ffb02e'); g.addColorStop(1, '#c26a00'); c.fillStyle = g; c.beginPath(); c.arc(dd.x, dd.y, PK.r, 0, 6.283); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 1.5; c.stroke(); }
      hudTop(c, PK.W, total, null, (g, w) => { for (let i = 0; i < 5; i++) { g.fillStyle = i < 5 - n ? '#ffb02e' : '#ffffff22'; g.beginPath(); g.arc(w - 120 + i * 24, 28, 8, 0, 6.283); g.fill(); } });
      tx(c, msg, 180, 78, 13, '#fff', 'center', '#000a'); pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});

/* ================= BOUNCE (side-scrolling platformer) ================= */
const BN = { W: 360, H: 560, L: 4600, G: 1500, R: 16 };
function bnLevel(seed) {
  const R = rng(seed), plats = [{ x: -60, w: 520, y: 400, spikes: [] }], rings = [], spikes = []; let x = 460, y = 400;
  while (x < BN.L - 600) {
    const gap = 70 + R() * 80, w = 150 + R() * 230, ny = clamp(y + (R() - .5) * 120, 300, 430); x += gap;
    if (gap > 100 && R() < .6) plats.push({ x: x - gap / 2 - 35, w: 70, y: Math.min(y, ny) - 70, float: true });
    plats.push({ x, w, y: ny }); if (w > 190 && R() < .7) spikes.push({ x: x + 70 + R() * (w - 160), y: ny });
    const cnt = 3 + Math.floor(R() * 3); for (let k = 0; k < cnt; k++) rings.push({ x: x - gap + (gap + w) * (k / cnt) + 20, y: Math.min(y, ny) - 70 - Math.sin(k / cnt * Math.PI) * 60 });
    x += w; y = ny;
  }
  plats.push({ x: x + 90, w: 420, y: 400, end: true });
  return { plats, rings, spikes, endX: x + 330 };
}
const G_BOUNCE2 = duel({
  id: 'bounce', name: 'Bounce', icon: '🏐', desc: 'Guide the red ball to the flag! ◀ ▶ to move, ▲ to jump high. Collect rings, avoid spikes and water.',
  bot: () => 380 + Math.floor(Math.random() * 520),
  play(box, seed, done) {
    const lv = bnLevel(seed), { cv, c } = arena(box, BN.W, BN.H), pops = popups();
    const rings = lv.rings.map(r => Object.assign({ got: 0 }, r));
    let ball = { x: 60, y: 360, vx: 0, vy: 0 }, cam = 0, lives = 3, time = 60, got = 0, over = false, t = 0, inv = 0, check = { x: 60, y: 360 }, keys = { l: 0, r: 0, j: 0 }, won = false, jumpReq = 0;
    const zone = p => p.y > 470 ? (p.x < 120 ? 'l' : p.x < 240 ? 'r' : p.x > 270 ? 'j' : null) : null; const ptrs = {};
    const setK = () => { keys.l = keys.r = keys.j = 0; Object.values(ptrs).forEach(z => { if (z) keys[z] = 1; }); };
    cv.addEventListener('pointerdown', e => { e.preventDefault(); try { cv.setPointerCapture(e.pointerId); } catch (x) {} const z = zone(ptr(cv, e)); ptrs[e.pointerId] = z; if (z === 'j') jumpReq = .15; setK(); });
    cv.addEventListener('pointermove', e => { if (ptrs[e.pointerId] === undefined) return; ptrs[e.pointerId] = zone(ptr(cv, e)); setK(); });
    const up = e => { delete ptrs[e.pointerId]; setK(); }; cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    const finish = () => { if (over) return; over = true; setTimeout(() => { stop(); const sc = got * 50 + (won ? 500 + Math.round(time) * 10 : Math.round(ball.x / 12)); fin(box, sc, done, won ? 'You reached the flag!' : 'Run over'); }, 700); };
    const hurt = why => { if (inv > 0) return; lives--; inv = 1.4; pops.add(why, ball.x - cam, ball.y - 30, '#ff6b6b'); if (lives <= 0) return finish(); ball.x = check.x; ball.y = check.y - 60; ball.vx = 0; ball.vy = 0; time -= 3; };
    const stop = anim(dt => {
      if (over && !won) { } t += dt; if (!over) { time -= dt; if (time <= 0) { time = 0; finish(); } } inv = Math.max(0, inv - dt);
      if (!over) for (let k = 0; k < 2; k++) {
        const d = dt / 2, b = ball; b.vx += ((keys.r - keys.l) * 220 - b.vx) * Math.min(1, 9 * d); b.vy += BN.G * d; b.x += b.vx * d; b.y += b.vy * d; jumpReq = Math.max(0, jumpReq - d);
        let ground = false;
        for (const p of lv.plats) {
          if (b.x + BN.R > p.x && b.x - BN.R < p.x + p.w) {
            const top = p.y, th = p.float ? 18 : 400; if (b.vy >= 0 && b.y + BN.R >= top && b.y + BN.R - b.vy * d <= top + 12) { b.y = top - BN.R; b.vy = 0; ground = true; if (!p.float && !p.end) check = { x: Math.max(p.x + 30, Math.min(b.x, p.x + p.w - 30)), y: top }; if (p.end) check = { x: p.x + 40, y: top }; }
            else if (!p.float && b.y > top + 4 && b.y < top + th) { if (b.x < p.x + p.w / 2) b.x = p.x - BN.R; else b.x = p.x + p.w + BN.R; b.vx = 0; }
          }
        }
        if (ground) { b.vy = jumpReq > 0 || keys.j ? -640 : -330; jumpReq = 0; }
        if (b.y > BN.H + 40) hurt('Splash!');
        lv.spikes.forEach(s => { if (Math.abs(b.x - s.x) < BN.R + 7 && b.y + BN.R > s.y - 16 && b.y < s.y) hurt('Ouch!'); });
        rings.forEach(r => { if (!r.got && Math.hypot(r.x - b.x, r.y - b.y) < BN.R + 12) { r.got = 1; got++; pops.add('+50', r.x - cam, r.y - 10, '#ffd54a'); } });
        if (b.x > lv.endX - 260 && !won) { won = true; pops.add('FINISH!', 180, 240, '#7fff9a'); finish(); }
        if (b.x < BN.R) { b.x = BN.R; b.vx = 0; }
      }
      cam += (clamp(ball.x - 130, 0, BN.L - BN.W + 300) - cam) * Math.min(1, dt * 6);
      const sky = c.createLinearGradient(0, 0, 0, BN.H); sky.addColorStop(0, '#5db4ff'); sky.addColorStop(1, '#bfe9ff'); c.fillStyle = sky; c.fillRect(0, 0, BN.W, BN.H);
      c.fillStyle = '#ffffffcc'; [[40, 90], [200, 60], [330, 120], [480, 80]].forEach(([x, y]) => { const px = ((x - cam * .2) % 560 + 560) % 560 - 100; for (let i = 0; i < 4; i++) { c.beginPath(); c.arc(px + i * 22, y + (i % 2) * 8, 20 - i * 2, 0, 6.283); c.fill(); } });
      c.fillStyle = '#7fbf8a'; c.beginPath(); c.moveTo(0, 470); for (let x = 0; x <= BN.W; x += 20) c.lineTo(x, 400 - Math.sin((x + cam * .4) / 70) * 30 - Math.sin((x + cam * .4) / 31) * 8); c.lineTo(BN.W, 470); c.fill();
      c.fillStyle = '#2a8bd8'; c.fillRect(0, 500, BN.W, 80); c.fillStyle = '#6cc4ff'; for (let x = -30; x < BN.W + 30; x += 30) { c.beginPath(); c.arc(x + ((t * 40) % 30), 500, 15, Math.PI, 0); c.fill(); }
      lv.plats.forEach(p => { const x = p.x - cam; if (x > BN.W || x + p.w < 0) return; const h = p.float ? 18 : 560 - p.y; c.fillStyle = '#8a5a2b'; c.fillRect(x, p.y + 10, p.w, h); c.fillStyle = '#6b3d1c'; for (let i = 0; i < p.w; i += 26) c.fillRect(x + i + 4, p.y + 16, 10, 5); c.fillStyle = '#4fc04a'; rr(c, x - 2, p.y - 2, p.w + 4, 16, 6); c.fill(); c.fillStyle = '#7ee26a'; c.fillRect(x + 2, p.y, p.w - 4, 4); });
      lv.spikes.forEach(s => { const x = s.x - cam; c.fillStyle = '#b8bcc8'; for (let i = -1; i <= 1; i++) { c.beginPath(); c.moveTo(x + i * 12 - 6, s.y); c.lineTo(x + i * 12, s.y - 16); c.lineTo(x + i * 12 + 6, s.y); c.fill(); } });
      rings.forEach(r => { if (r.got) return; const x = r.x - cam; c.strokeStyle = '#ffd54a'; c.lineWidth = 4; c.beginPath(); c.ellipse(x, r.y, 7 + Math.sin(t * 5) * 1.5, 12, 0, 0, 6.283); c.stroke(); c.strokeStyle = '#fff8'; c.lineWidth = 1.5; c.stroke(); });
      const fx = lv.endX - 200 - cam; c.strokeStyle = '#eee'; c.lineWidth = 4; c.beginPath(); c.moveTo(fx, 400); c.lineTo(fx, 300); c.stroke(); c.fillStyle = '#ff5a3a'; c.beginPath(); c.moveTo(fx, 300); c.lineTo(fx + 40, 314 + Math.sin(t * 6) * 3); c.lineTo(fx, 330); c.fill();
      if (!(inv > 0 && Math.floor(t * 14) % 2)) { const bx = ball.x - cam, by = ball.y; c.fillStyle = '#0003'; c.beginPath(); c.ellipse(bx, by + BN.R, 12, 4, 0, 0, 6.283); c.fill(); const g = c.createRadialGradient(bx - 5, by - 6, 2, bx, by, BN.R); g.addColorStop(0, '#ff9a8a'); g.addColorStop(1, '#c4161c'); c.fillStyle = g; c.beginPath(); c.arc(bx, by, BN.R, 0, 6.283); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.arc(bx - 5, by - 3, 4, 0, 6.283); c.arc(bx + 6, by - 3, 4, 0, 6.283); c.fill(); c.fillStyle = '#222'; c.beginPath(); c.arc(bx - 4, by - 3, 2, 0, 6.283); c.arc(bx + 7, by - 3, 2, 0, 6.283); c.fill(); c.strokeStyle = '#222'; c.lineWidth = 2; c.beginPath(); c.arc(bx + 1, by + 3, 5, .2, Math.PI - .2); c.stroke(); }
      const btn = (x, y, lab, on) => { c.fillStyle = on ? '#ffffffaa' : '#ffffff55'; c.beginPath(); c.arc(x, y, 30, 0, 6.283); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 3; c.stroke(); tx(c, lab, x, y + 1, 26, '#1c3a6a'); };
      btn(50, 520, '◀', keys.l); btn(130, 520, '▶', keys.r); btn(310, 520, '▲', keys.j);
      hudTop(c, BN.W, got * 50 + Math.round(ball.x / 12), Math.ceil(time) + 's', (g, w) => { for (let i = 0; i < lives; i++) tx(g, '♥', w - 20 - i * 20, 28, 20, '#ff4d7a'); });
      pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});
