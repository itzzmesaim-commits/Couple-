/* Playmates - procedural background music, a different style for every game */
const MUSIC = (() => {
  const T = {
    arcade: { bpm: 150, root: 60, sc: [0, 2, 4, 7, 9], lead: 'square', bass: 'triangle', prog: [0, 3, 4, 3], drums: 'k.h.s.h.', dens: .7, vol: .5 },
    epic: { bpm: 128, root: 45, sc: [0, 2, 3, 5, 7, 8, 10], lead: 'sawtooth', bass: 'sawtooth', prog: [0, 0, 5, 4], drums: 'k.hks.hk', dens: .6, vol: .5, oct: 1 },
    chill: { bpm: 84, root: 60, sc: [0, 2, 4, 5, 7, 9, 11], lead: 'sine', bass: 'sine', prog: [0, 5, 3, 4], drums: 'k.......', dens: .45, vol: .55 },
    jazz: { bpm: 104, root: 55, sc: [0, 2, 3, 5, 7, 9, 10], lead: 'triangle', bass: 'sine', prog: [1, 4, 0, 0], drums: 'h.hh.hh.', dens: .55, vol: .55, swing: 1 },
    tense: { bpm: 96, root: 48, sc: [0, 1, 3, 5, 7, 8], lead: 'triangle', bass: 'sawtooth', prog: [0, 0, 1, 0], drums: 'k...k...', dens: .35, vol: .5 },
    fun: { bpm: 132, root: 62, sc: [0, 2, 4, 5, 7, 9, 11], lead: 'triangle', bass: 'square', prog: [0, 4, 5, 3], drums: 'k.h.k.hh', dens: .65, vol: .5 },
    safari: { bpm: 112, root: 52, sc: [0, 3, 5, 7, 10], lead: 'triangle', bass: 'sine', prog: [0, 0, 3, 4], drums: 'kkh.k.hk', dens: .6, vol: .55, tribal: 1 },
    sport: { bpm: 140, root: 57, sc: [0, 2, 4, 7, 9], lead: 'sawtooth', bass: 'square', prog: [0, 5, 3, 4], drums: 'k.hsk.hs', dens: .55, vol: .42 },
    build: { bpm: 100, root: 58, sc: [0, 2, 4, 7, 9], lead: 'sine', bass: 'triangle', prog: [0, 3, 0, 4], drums: 'k...h...', dens: .5, vol: .55 }
  };
  const MAP = { ludo: 'fun', pool: 'jazz', ttt: 'fun', mem: 'fun', monster: 'epic', bowl: 'sport', darts: 'tense', carrom: 'jazz', golf: 'chill', tsoc: 'sport', hoop: 'sport', arch: 'tense', skee: 'arcade', plox: 'fun', bloko: 'fun', disco: 'arcade', bounce: 'arcade', word: 'chill', dom: 'jazz', bg: 'jazz', sea: 'tense', ck: 'jazz', c4: 'fun', rv: 'tense', db: 'chill', bots: 'epic', brawl: 'epic', bank: 'jazz', dice: 'arcade', safari: 'safari', tower: 'build', dareduel: 'tense', candy: 'fun', runup: 'arcade', puzzle: 'chill' };
  let ac = null, cur = null, timer = null, step = 0, next = 0, th = null, phrase = [], seed = 1, bus = null;
  const mf = n => 440 * Math.pow(2, (n - 69) / 12);
  const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const ctx = () => { if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { } } return ac; };
  const note = (f, t, d, type, v) => { const o = ac.createOscillator(), g = ac.createGain(); o.type = type; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + .01); g.gain.exponentialRampToValueAtTime(0.0001, t + d); o.connect(g); g.connect(bus); o.start(t); o.stop(t + d + .03); };
  const nz = (t, d, f, v, type) => { const n = Math.floor(ac.sampleRate * d), b = ac.createBuffer(1, n, ac.sampleRate), c = b.getChannelData(0); for (let i = 0; i < n; i++) c[i] = (Math.random() * 2 - 1) * (1 - i / n); const s = ac.createBufferSource(), fl = ac.createBiquadFilter(), g = ac.createGain(); s.buffer = b; fl.type = type; fl.frequency.value = f; g.gain.value = v; s.connect(fl); fl.connect(g); g.connect(bus); s.start(t); };
  const mkPhrase = () => { phrase = []; let d = Math.floor(rnd() * th.sc.length); for (let i = 0; i < 16; i++) { if (rnd() < th.dens) { d = Math.max(0, Math.min(th.sc.length * 2 - 1, d + Math.floor(rnd() * 5) - 2)); phrase.push(d); } else phrase.push(-1); } };
  const degNote = (d, base) => base + th.sc[d % th.sc.length] + 12 * Math.floor(d / th.sc.length);
  function tick() {
    if (!cur || !ac) return; const spb = 60 / th.bpm / 2;
    while (next < ac.currentTime + .4) {
      if (!SFX.muted && ac.state === 'running') {
        const bar = Math.floor(step / 8), pos = step % 8, ch = th.prog[bar % th.prog.length], t = next + ((th.swing && pos % 2) ? spb * .3 : 0), vol = th.vol * .22;
        if (step % 16 === 0) mkPhrase();
        const bn = degNote(ch, th.root - 12 + (th.oct ? 0 : 0));
        if (pos % 4 === 0) note(mf(bn), t, spb * 3.6, th.bass, vol * 1.5);
        if (pos === 2 || pos === 6) note(mf(bn + 12), t, spb * .8, th.bass, vol * .6);
        const ld = phrase[step % 16]; if (ld >= 0) note(mf(degNote(ld, th.root + 12)), t, spb * (th.tribal ? .5 : 1.4), th.lead, vol);
        if (pos === 0 && step % 4 === 0) { [0, 2, 4].forEach(k => note(mf(degNote(ch + k, th.root)), t, spb * 7, 'sine', vol * .45)); }
        const dc = th.drums[pos % th.drums.length];
        if (dc === 'k') { const o = ac.createOscillator(), g = ac.createGain(); o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(45, t + .12); g.gain.setValueAtTime(th.vol * .7, t); g.gain.exponentialRampToValueAtTime(.001, t + .15); o.connect(g); g.connect(bus); o.start(t); o.stop(t + .2); }
        else if (dc === 'h') nz(t, .04, 7000, th.vol * .28, 'highpass');
        else if (dc === 's') nz(t, .12, 2200, th.vol * .4, 'bandpass');
        if (th.tribal && pos % 2 === 1) nz(t, .05, 400, th.vol * .22, 'bandpass');
      }
      next += spb; step++;
    }
  }
  function start(id) {
    const key = MAP[id] || 'fun'; if (cur === id) return; stop(); if (!ctx()) return; if (ac.state === 'suspended') ac.resume();
    cur = id; th = T[key]; step = 0; next = ac.currentTime + .15; seed = 1 + [...id].reduce((a, c) => a * 31 + c.charCodeAt(0), 7) % 99991;
    bus = ac.createGain(); bus.gain.value = .9; bus.connect(ac.destination); timer = setInterval(tick, 100);
  }
  function stop() { if (timer) clearInterval(timer); timer = null; if (bus) { try { bus.gain.setTargetAtTime(0, ac.currentTime, .08); const b = bus; setTimeout(() => { try { b.disconnect(); } catch (e) { } }, 500); } catch (e) { } } bus = null; cur = null; }
  document.addEventListener('visibilitychange', () => { if (document.hidden) { if (ac && ac.state === 'running') ac.suspend(); } else if (ac && cur) ac.resume(); });
  setInterval(() => { if (cur && !document.querySelector('#gm,#solo')) stop(); }, 1000);
  return { start, stop, get current() { return cur; }, themes: MAP };
})();
window.MUSIC = MUSIC;
