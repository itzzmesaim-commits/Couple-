/* Playmates rooms: ONE room code for all games, bot mode, invite */
const me2 = () => ({ uid: me.uid, name: me.name, avatar: me.avatar });
const CATS = { board: 'Board', sports: 'Sports', arcade: 'Arcade', puzzle: 'Puzzle', adult: '18+' };
const IMG_GAMES = new Set(['brawl', 'bank', 'safari', 'tower', 'candy', 'puzzle', 'runup', 'pool', 'bowl', 'monster', 'bots', 'bounce', 'dice', 'golf', 'tsoc', 'darts', 'carrom', 'word', 'plox', 'disco', 'arch', 'skee', 'c4', 'dom', 'bg', 'sea', 'bloko', 'db', 'hoop', 'ck', 'rv', 'ttt']);
const gameTile = (g, wide) => IMG_GAMES.has(g.id)
  ? `<button class="tile imgt ${wide === true ? 'wide' : ''} ${g.soon ? 'soon' : ''}" data-g="${g.id}" style="background-image:url(img/games/${g.id}.jpg)">${g.soon ? '<em class="sb">Coming soon</em>' : ''}<span class="lbl">${esc(g.name)}<small>${g.players || '2 Players'}</small></span></button>`
  : `<button class="tile t-${g.cat || 'board'}" data-g="${g.id}"><b>${g.icon}</b>${esc(g.name)}<small>${g.adult ? '🔞 18+' : (g.players || '2 Players')}</small></button>`;
const freshState = g => { const s = g.init(ctx()); if (s && typeof s === 'object') s.gid = Date.now(); return s; };
const statusText = (g, s, seat, bot) => {
  if (s.winner != null) return s.winner === 'draw' ? '🤝 Draw!' : (s.winner === seat ? '🎉 You won!' : (bot ? '🤖 Bot won' : '😅 Partner won'));
  if (g.status) { const t = g.status(s, seat); if (t) return t; }
  return s.turn === seat ? '👉 Your turn' : (bot ? '🤖 Bot’s turn' : '⏳ Partner’s turn');
};

/* ---------- result card (victory / defeat) ---------- */
function resultCard(s, seat, bot) {
  if (s.winner == null) return '';
  const pts = bot ? '' : (s.winner === 'draw' ? '+5 points' : s.winner === seat ? '+10 points' : '+2 points');
  if (s.winner === 'draw') return `<div class="resultcard lose"><div class="crown">🤝</div><h3>It’s a draw!</h3><p>${pts}</p></div>`;
  return s.winner === seat
    ? `<div class="resultcard"><div class="crown">👑</div><h3>Victory is all yours!</h3><p>${bot ? 'You beat the bot' : 'Congratulations, champion!'}</p><p><b>${pts}</b></p></div>`
    : `<div class="resultcard lose"><div class="crown">🎮</div><h3>Good game!</h3><p>${bot ? 'The bot won this time' : 'Your partner won this one'}. Try again!</p><p>${pts}</p></div>`;
}

/* ---------- home / lobby ---------- */
function bindTiles(root) {
  $$('[data-g]', root).forEach(b => b.onclick = () => openGame(GAMES.find(x => x.id === b.dataset.g)));
}
function openGame(g) {
  if (g.soon) return toast('Coming soon. This game is being improved.');
  const bot = g.bot || g.solo;
  const m = modal(`<h2>${g.icon} ${esc(g.name)}</h2><p class="mut">${esc(g.desc)}</p><p class="mut">${g.players || '2 Players'} · Real-time</p>
    ${g.init ? '<button class="btn full" id="gf">👥 Play with a friend</button>' : ''}${bot ? '<button class="btn sec full" id="gb">🤖 Play with Bot (offline)</button>' : ''}<button class="back" id="gx">Cancel</button>`);
  $('#gx', m).onclick = closeModal;
  if ($('#gf', m)) $('#gf', m).onclick = () => { closeModal(); g.adult ? requireAdult(() => createScreen(g)) : createScreen(g); };
  if (bot) $('#gb', m).onclick = () => { closeModal(); const go = () => g.solo ? openSolo(g) : playBot(g); g.adult ? requireAdult(go) : go(); };
}
function askJoin() {
  const m = modal(`<h2>🔑 Join a room</h2><input id="jc" placeholder="Room ID" maxlength="5" style="text-transform:uppercase"><button class="btn full" id="jg">Join</button><button class="back" id="jx">Cancel</button>`);
  $('#jx', m).onclick = closeModal;
  $('#jg', m).onclick = () => { const c = $('#jc', m).value.trim().toUpperCase(); if (c) { closeModal(); doJoin(c); } };
}
function homeScreen() {
  const pop = ['pool', 'ludo', 'monster', 'bowl'].map(i => GAMES.find(g => g.id === i)).filter(Boolean);
  $('#screen').innerHTML = `<div class="banner"><div><h2>Play with Friends</h2><p>One room, every game. Share the code and play!</p><button class="btn" id="cr">Create Private Room</button></div><div class="bn-ico">🎮</div></div>
    <div class="quick"><button id="qa"><i>🎮</i>All Games</button><button id="qm"><i>⚡</i>Quick Match</button><button id="jn"><i>🔑</i>Join Room</button></div>
    <div class="sec"><b>Popular Games</b><a id="sa">See All ›</a></div><div class="hscroll">${pop.map(gameTile).join('')}</div>
    <div class="sec"><b>Friends Online</b></div><div class="hscroll" id="fo"><span class="mut">Looking for players...</span></div>${ownerLine()}`;
  $('#cr').onclick = () => createScreen(null);
  $('#qa').onclick = $('#sa').onclick = () => show('games');
  $('#jn').onclick = askJoin; $('#qm').onclick = quickMatch;
  bindTiles($('#screen'));
  db.collection('users').orderBy('lastSeen', 'desc').limit(15).get().then(q => {
    const now = Date.now(), list = q.docs.map(d => d.data()).filter(u => u.name && u.lastSeen && u.lastSeen.toMillis && now - u.lastSeen.toMillis() < 180000 && u.nameLower !== (me.nameLower));
    const box = $('#fo'); if (!box) return;
    box.innerHTML = list.length ? list.map(u => `<div class="fr"><div class="av">${u.avatar}</div><small>${esc(u.name)}</small><i class="dot-on"></i></div>`).join('') : '<span class="mut">No one else is online right now.</span>';
  }).catch(() => {});
}
function gamesScreen(tab = 'all') {
  const tabs = ['all', 'new', 'board', 'sports', 'arcade', 'puzzle', 'adult'];
  $('#screen').innerHTML = `<h2>All Games</h2><div class="cats">${tabs.map(c => `<button class="cat ${c === tab ? 'on' : ''}" data-c="${c}">${c === 'all' ? 'All' : c === 'new' ? '✨ New' : CATS[c]}</button>`).join('')}</div>
    <div class="grid g2">${GAMES.filter(g => tab === 'all' || (tab === 'new' ? g.isNew : g.cat === tab)).map((g, i) => gameTile(g, i === 0 && tab === 'all')).join('')}</div>`;
  $$('[data-c]').forEach(b => b.onclick = () => gamesScreen(b.dataset.c));
  bindTiles($('#screen'));
}
function createScreen(g) {
  let pub = false;
  $('#screen').innerHTML = `<button class="back" id="bk">← Back</button><h2>Create Room</h2>
    <div class="card row">${g ? `<span style="font-size:34px">${g.icon}</span><div><b>${esc(g.name)}</b><div class="mut">${g.players || '2 Players'} · ${CATS[g.cat] || ''}</div></div>` : '<div class="mut">No game picked yet. You can choose any game inside the room.</div>'}</div>
    <div class="tabs"><button class="btn" id="pv">Private Room</button><button class="btn sec" id="pb">Public Room</button></div>
    <button class="btn full" id="mk">Create Room</button>
    <p class="mut center">Or join an existing room</p>
    <div class="row"><input id="code" placeholder="Room ID" maxlength="5" style="text-transform:uppercase"><button class="btn" id="jn">Join</button></div>
    <p class="mut center">Or invite friends</p>
    <button class="btn sec full" id="iv">👥 Invite Friends</button><p class="mut center">Start a private game with your friends.</p>`;
  $('#bk').onclick = () => show('home');
  const tg = p => { pub = p; $('#pv').className = 'btn ' + (p ? 'sec' : ''); $('#pb').className = 'btn ' + (p ? '' : 'sec'); };
  $('#pv').onclick = () => tg(false); $('#pb').onclick = () => tg(true);
  const make = async inv => { try { const id = await createRoom(pub, g); enterRoom(id); if (inv) invite(id); } catch (e) { toast('Could not create room: ' + (e.message || e)); } };
  $('#mk').onclick = () => make(false); $('#iv').onclick = () => make(true);
  $('#jn').onclick = () => { const c = $('#code').value.trim().toUpperCase(); if (c) doJoin(c); };
}
async function doJoin(c) { try { (await joinRoom(c)) ? enterRoom(c) : toast('Room not found or it is full.'); } catch (e) { toast('Could not join.'); } }

/* ---------- room create / join ---------- */
async function createRoom(pub = false, g = null) {
  const ch = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let id, tries = 0;
  do { id = Array.from({ length: 5 }, () => ch[Math.floor(Math.random() * ch.length)]).join(''); tries++; } while (tries < 8 && (await db.collection('rooms').doc(id).get()).exists);
  await db.collection('rooms').doc(id).set({ uids: [me.uid], players: [me2()], status: 'open', pub: !!pub, game: g ? g.id : null, gst: g && !g.solo ? JSON.stringify(freshState(g)) : null, gid: g ? Date.now() : 0, paid: {}, created: FV.serverTimestamp() });
  return id;
}
async function joinRoom(id) {
  const ref = db.collection('rooms').doc(id);
  return db.runTransaction(async tx => {
    const s = await tx.get(ref); if (!s.exists) return false;
    const r = s.data();
    if (r.uids.includes(me.uid)) return true;
    if (r.uids.length !== 1) return false;
    tx.update(ref, { uids: [...r.uids, me.uid], players: [...r.players, me2()], status: 'ready' });
    return true;
  });
}
async function quickMatch() {
  const b = $('#qm'); if (b) b.innerHTML = '<i>⏳</i>Searching...';
  try {
    const q = await db.collection('rooms').where('status', '==', 'open').limit(8).get();
    for (const d of q.docs) { if (d.data().pub && !d.data().uids.includes(me.uid) && await joinRoom(d.id)) return enterRoom(d.id); }
    enterRoom(await createRoom(true));
  } catch (e) { toast('Quick match failed.'); if (b) b.innerHTML = '<i>⚡</i>Quick Match'; }
}
function invite(code) {
  const url = INVITE_BASE + '?room=' + code;
  const text = `💞 Play with me on Playmates! Room code: ${code}\nTap Join in the app and enter the code, or open this link: ${url}`;
  const Sh = window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.Share;
  if (Sh) Sh.share({ title: 'Playmates invite', text, dialogTitle: 'Send to partner' }).catch(() => {});
  else if (navigator.share) navigator.share({ title: 'Playmates', text }).catch(() => {});
  else if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => toast('Invite copied. Paste it and send it to your partner.'));
  else toast(text);
}

/* ---------- room screen ---------- */
function enterRoom(id) {
  clearListeners();
  const ref = db.collection('rooms').doc(id);
  $('#screen').innerHTML = `<button class="back" id="lv">← Leave room</button>
    <div id="pl" class="vsbar"></div>
    <div class="row" style="justify-content:space-between"><span class="mut">Room code</span><span class="code">${id}</span><button class="btn sec" id="inv">📨 Invite</button></div>
    <div class="status" id="stt"></div><div id="gm"></div><div id="gctl"></div>
    <details open><summary class="mut" style="margin:8px 0">💬 Chat (you can send photos too)</summary><div id="gc" style="height:280px"></div></details>`;
  $('#inv').onclick = () => invite(id);
  $('#lv').onclick = async () => {
    try { const s = await ref.get(); if (s.exists && s.data().uids.length === 1 && s.data().uids[0] === me.uid) await ref.delete(); } catch (e) {}
    show('home');
  };
  let chatOn = false, okGid = null, askGid = null, soloGid = null, last = null;
  const ctl = (label, fn, cls = '') => { const b = document.createElement('button'); b.className = 'btn full ' + cls; b.textContent = label; b.onclick = fn; $('#gctl').appendChild(b); };
  const toPicker = () => ref.update({ game: null, gst: null }).catch(() => {});

  const showGame = (r, seat) => {
    const g = GAMES.find(x => x.id === r.game), gm = $('#gm'), stt = $('#stt');
    $('#gctl').innerHTML = '';
    if (!g) { toPicker(); return; }
    if (g.adult && okGid !== r.gid) {
      stt.textContent = '🔞 18+ game: please verify your age'; gm.innerHTML = '';
      if (askGid !== r.gid) { askGid = r.gid; requireAdult(() => { okGid = r.gid; if (last) showGame(last, seat); }, toPicker); }
      return;
    }
    if (g.solo) {
      stt.textContent = g.name;
      if (soloGid !== r.gid) { soloGid = r.gid; g.solo(gm, ctx()); }
      ctl('↩️ Choose another game', toPicker, 'sec'); return;
    }
    const s = JSON.parse(r.gst);
    stt.textContent = statusText(g, s, seat, false);
    g.render(gm, s, seat, m => sendMove(id, g, m), ctx());
    if (s.winner != null) { $('#gctl').insertAdjacentHTML('beforeend', resultCard(s, seat, false)); creditOnce(ref, r, seat, s.winner); ctl('🔄 Rematch', () => startGame(id, g)); ctl('🎮 Choose another game', toPicker, 'sec'); }
    else ctl('↩️ Change game', () => confirmBox('Change the game? The current game will stop.', toPicker), 'sec');
  };

  listen(ref.onSnapshot(snap => {
    if (!snap.exists) { show('home'); return; }
    const r = snap.data(), seat = r.uids.indexOf(me.uid);
    if (seat < 0) { show('home'); return; }
    last = r;
    $('#pl').innerHTML = [0, 1].map(i => { const p = r.players[i]; return `<div class="pv"><div class="av">${p ? p.avatar : '⏳'}</div><small>${p ? esc(p.name) : 'Waiting...'}${i === seat ? ' (you)' : ''}</small></div>`; }).join('<span class="vs">VS</span>');
    const gm = $('#gm'), stt = $('#stt');
    if (r.uids.length < 2) { stt.textContent = 'Waiting for partner... Tap Invite and send the code.'; gm.innerHTML = ''; $('#gctl').innerHTML = ''; }
    else if (!r.game) {
      soloGid = null; $('#gctl').innerHTML = ''; stt.textContent = 'Pick any game 👇 (18+ at the bottom)';
      gm.innerHTML = `<div class="grid">${GAMES.map(gameTile).join('')}</div>`;
      $$('[data-g]', gm).forEach(b => b.onclick = () => { const g = GAMES.find(x => x.id === b.dataset.g); if (g.soon) return toast('Coming soon.'); g.adult ? requireAdult(() => startGame(id, g)) : startGame(id, g); });
    } else showGame(r, seat);
    if (!chatOn && r.uids.length === 2) { chatOn = true; chatPanel($('#gc'), ref.collection('messages')); }
  }));
}

async function startGame(id, g) {
  try { await db.collection('rooms').doc(id).update({ game: g.id, gst: g.solo ? null : JSON.stringify(freshState(g)), gid: Date.now(), paid: {} }); }
  catch (e) { toast('Could not start the game.'); }
}
async function sendMove(id, g, m) {
  const ref = db.collection('rooms').doc(id);
  try {
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref), r = snap.data(), seat = r.uids.indexOf(me.uid);
      if (seat < 0 || r.uids.length < 2 || !r.gst) return;
      const s = JSON.parse(r.gst);
      if (s.winner != null && (m.a !== 'pun' && m.a !== 'skip')) return;
      if (!g.simul && s.turn !== seat) return;
      const ns = g.move(s, m, seat, ctx());
      if (ns) tx.update(ref, { gst: JSON.stringify(ns) });
    });
  } catch (e) { console.warn(e); }
}
const credited = {};
function creditOnce(ref, r, seat, winner) {
  const key = ref.id + ':' + r.gid;
  if (credited[key] || (r.paid && r.paid[me.uid] === r.gid)) return;
  credited[key] = 1;
  const pts = winner === 'draw' ? 5 : (winner === seat ? 10 : 2);
  db.runTransaction(async tx => {
    const rr = (await tx.get(ref)).data();
    if (!rr || rr.gid !== r.gid || (rr.paid && rr.paid[me.uid] === rr.gid)) return;
    tx.update(ref, { ['paid.' + me.uid]: rr.gid });
    tx.update(db.collection('users').doc(me.uid), { points: FV.increment(pts) });
  }).catch(() => {});
}

/* ---------- offline bot mode ---------- */
function leaveBot() { me ? show('home') : offlineHome(); }
function playBot(g) {
  clearListeners();
  let s = freshState(g), timer = null, alive = true;
  listen(() => { alive = false; clearTimeout(timer); const gm = $('#gm'); if (gm && gm.__stop) { try { gm.__stop(); } catch (e) {} } });
  $('#screen').innerHTML = `<button class="back" id="bk">← Back</button><h2>${g.icon} ${esc(g.name)} <span class="botTag">🤖 vs Bot</span></h2>
    <div class="status" id="stt"></div><div id="gm"></div><div id="gctl"></div>`;
  $('#bk').onclick = leaveBot;
  function draw() {
    if (!alive) return;
    $('#stt').textContent = statusText(g, s, 0, true);
    g.render($('#gm'), s, 0, send, ctx());
    $('#gctl').innerHTML = '';
    if (s.winner != null) { $('#gctl').insertAdjacentHTML('beforeend', resultCard(s, 0, true)); const b = document.createElement('button'); b.className = 'btn full'; b.textContent = '🔄 Play again'; b.onclick = () => { s = freshState(g); draw(); schedule(); }; $('#gctl').appendChild(b); }
  }
  function send(m) {
    if (!alive || (s.winner != null && (m.a !== 'pun' && m.a !== 'skip')) || (!g.simul && s.turn !== 0)) return;
    const ns = g.move(clone(s), m, 0, ctx()); if (!ns) return;
    s = ns; draw(); schedule();
  }
  function schedule() {
    clearTimeout(timer);
    if (!alive || s.winner != null || !g.bot) return;
    if (!g.simul) { if (s.turn !== 1) return; if (!g.bot(clone(s), 1, ctx())) return; }
    timer = setTimeout(() => {
      if (!alive || s.winner != null) return;
      const m = g.bot(clone(s), 1, ctx());
      if (m) { const ns = g.move(clone(s), m, 1, ctx()); if (ns) { s = ns; draw(); } }
      schedule();
    }, g.botDelay || 850);
  }
  draw(); schedule();
}
function openSolo(g) {
  clearListeners();
  $('#screen').innerHTML = `<button class="back" id="bk">← Back</button><div id="solo"></div>`;
  $('#bk').onclick = leaveBot;
  g.solo($('#solo'), ctx());
}

/* ---------- full-screen game mode: every canvas is scaled up to fill the screen ---------- */
(() => {
  let on = false, fitT = null;
  const fit = () => {
    const root = document.querySelector('#screen #gm, #screen #solo'); if (!root) return;
    const vw = window.innerWidth, vh = window.innerHeight;
    if (!root.querySelector('canvas')) {   // DOM games (Ludo, boards...): zoom to fill
      root.style.zoom = 1; [...root.children].forEach(k => { k.style.zoom = 1; }); let h = 0; [...root.children].forEach(k => { h += k.getBoundingClientRect().height + 8; }); h = Math.max(h, 300); let z = Math.min(vw / 340, 1.8); if (h * z > vh - 8) z = (vh - 8) / h; const zz = Math.max(1, +z.toFixed(2)); [...root.children].forEach(k => { k.style.zoom = zz; }); return;
    }
    root.style.zoom = 1;
    root.querySelectorAll('canvas').forEach(cv => {
      if (cv.width < 120 || cv.height < 120) return;
      const sib = cv.parentElement && cv.parentElement !== root ? 0 : 0;
      const s = Math.min(vw / cv.width, (vh - 40) / cv.height);
      cv.style.width = Math.floor(cv.width * s) + 'px'; cv.style.height = Math.floor(cv.height * s) + 'px';
    });
  };
  const sync = () => {
    const rt = document.querySelector('#screen #gm, #screen #solo'), now = !!(rt && rt.children.length && !rt.querySelector('[data-g]'));
    if (now === on) return; on = now;
    document.body.classList.toggle('ingame', now);
    clearInterval(fitT); if (now) { fitT = setInterval(fit, 200); fit(); }
    try {
      if (now) { const el = document.documentElement; (el.requestFullscreen && el.requestFullscreen().catch(() => {})); }
      else { if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {}); }
    } catch (e) {}
  };
  new MutationObserver(sync).observe(document.getElementById('screen'), { childList: true, subtree: true });
  window.addEventListener('resize', fit);
})();
