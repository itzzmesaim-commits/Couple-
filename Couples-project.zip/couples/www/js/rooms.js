/* Playmates rooms: ONE room code for all games, bot mode, invite */
const me2 = () => ({ uid: me.uid, name: me.name, avatar: me.avatar });
const gameTile = g => `<button class="tile ${g.adult ? 'adult' : ''}" data-g="${g.id}"><b>${g.icon}</b>${esc(g.name)}${g.adult ? '<br>🔞 18+' : ''}</button>`;
const freshState = g => { const s = g.init(ctx()); if (s && typeof s === 'object') s.gid = Date.now(); return s; };
const statusText = (g, s, seat, bot) => {
  if (s.winner != null) return s.winner === 'draw' ? '🤝 Draw!' : (s.winner === seat ? '🎉 Aap jeet gaye!' : (bot ? '🤖 Bot jeet gaya' : '😅 Partner jeet gaya'));
  if (g.status) { const t = g.status(s, seat); if (t) return t; }
  return s.turn === seat ? '👉 Aapki baari' : (bot ? '🤖 Bot ki baari' : '⏳ Partner ki baari');
};

/* ---------- home ---------- */
function homeScreen() {
  $('#screen').innerHTML = `<div class="card"><button class="btn full" id="cr">🏠 Room banao &amp; partner ko invite karo</button>
    <div class="row"><input id="code" placeholder="Room code" maxlength="5" style="text-transform:uppercase"><button class="btn" id="jn">Join</button></div>
    <button class="btn sec full" id="qm">⚡ Quick Match (random partner)</button>
    <p class="mut center" style="margin:6px 0 0">Ek hi room mein saare games khelo, har game ka alag code nahi.</p></div>
    <h2>🤖 Bot ke saath khelo (offline)</h2><div class="grid">${GAMES.filter(g => g.bot || g.solo).map(gameTile).join('')}</div>${ownerLine()}`;
  $('#cr').onclick = async () => { try { enterRoom(await createRoom()); } catch (e) { toast('Room nahi bana: ' + (e.message || e)); } };
  $('#jn').onclick = () => { const c = $('#code').value.trim().toUpperCase(); if (c) doJoin(c); };
  $('#qm').onclick = quickMatch;
  $$('[data-g]').forEach(b => b.onclick = () => {
    const g = GAMES.find(x => x.id === b.dataset.g);
    const go = () => g.solo ? openSolo(g) : playBot(g);
    g.adult ? requireAdult(go) : go();
  });
}
async function doJoin(c) { try { (await joinRoom(c)) ? enterRoom(c) : toast('Room nahi mila, ya full hai.'); } catch (e) { toast('Join nahi hua.'); } }

/* ---------- room create / join ---------- */
async function createRoom() {
  const ch = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let id, tries = 0;
  do { id = Array.from({ length: 5 }, () => ch[Math.floor(Math.random() * ch.length)]).join(''); tries++; } while (tries < 8 && (await db.collection('rooms').doc(id).get()).exists);
  await db.collection('rooms').doc(id).set({ uids: [me.uid], players: [me2()], status: 'open', game: null, gst: null, gid: 0, paid: {}, created: FV.serverTimestamp() });
  return id;
}
async function joinRoom(id) {
  const ref = db.collection('rooms').doc(id);
  return db.runTransaction(async tx => {
    const s = await tx.get(ref); if (!s.exists) return false;
    const r = s.data();
    if (r.uids.includes(me.uid)) return true;
    if (r.uids.length !== 1) return false;
    tx.update(ref, { uids: [...r.uids, me.uid], players: [...r.players, me2()], status: 'ready' });
    return true;
  });
}
async function quickMatch() {
  const b = $('#qm'); b.textContent = 'Dhundh raha hoon...';
  try {
    const q = await db.collection('rooms').where('status', '==', 'open').limit(8).get();
    for (const d of q.docs) { if (!d.data().uids.includes(me.uid) && await joinRoom(d.id)) return enterRoom(d.id); }
    enterRoom(await createRoom());
  } catch (e) { toast('Quick match nahi hua.'); b.textContent = '⚡ Quick Match (random partner)'; }
}
function invite(code) {
  const url = INVITE_BASE + '?room=' + code;
  const text = `💞 Playmates par mere saath khelo! Room code: ${code}\nApp mein Join dabake code daalo, ya ye link kholo: ${url}`;
  const Sh = window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.Share;
  if (Sh) Sh.share({ title: 'Playmates invite', text, dialogTitle: 'Partner ko bhejo' }).catch(() => {});
  else if (navigator.share) navigator.share({ title: 'Playmates', text }).catch(() => {});
  else if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => toast('Invite copy ho gaya, partner ko paste karke bhejo.'));
  else toast(text);
}

/* ---------- room screen ---------- */
function enterRoom(id) {
  clearListeners();
  const ref = db.collection('rooms').doc(id);
  $('#screen').innerHTML = `<button class="back" id="lv">← Room se bahar</button>
    <div id="pl" class="scorebar"></div>
    <div class="row" style="justify-content:space-between"><span class="mut">Room code</span><span class="code">${id}</span><button class="btn sec" id="inv">📨 Invite</button></div>
    <div class="status" id="stt"></div><div id="gm"></div><div id="gctl"></div>
    <details open><summary class="mut" style="margin:8px 0">💬 Chat (photo bhi bhej sakte ho)</summary><div id="gc" style="height:280px"></div></details>`;
  $('#inv').onclick = () => invite(id);
  $('#lv').onclick = async () => {
    try { const s = await ref.get(); if (s.exists && s.data().uids.length === 1 && s.data().uids[0] === me.uid) await ref.delete(); } catch (e) {}
    show('home');
  };
  let chatOn = false, okGid = null, askGid = null, soloGid = null, last = null;
  const ctl = (label, fn, cls = '') => { const b = document.createElement('button'); b.className = 'btn full ' + cls; b.textContent = label; b.onclick = fn; $('#gctl').appendChild(b); };
  const toPicker = () => ref.update({ game: null, gst: null }).catch(() => {});

  const showGame = (r, seat) => {
    const g = GAMES.find(x => x.id === r.game), gm = $('#gm'), stt = $('#stt');
    $('#gctl').innerHTML = '';
    if (!g) { toPicker(); return; }
    if (g.adult && okGid !== r.gid) {
      stt.textContent = '🔞 18+ game: age verify karo'; gm.innerHTML = '';
      if (askGid !== r.gid) { askGid = r.gid; requireAdult(() => { okGid = r.gid; if (last) showGame(last, seat); }, toPicker); }
      return;
    }
    if (g.solo) {
      stt.textContent = g.name;
      if (soloGid !== r.gid) { soloGid = r.gid; g.solo(gm, ctx()); }
      ctl('↩️ Dusra game chuno', toPicker, 'sec'); return;
    }
    const s = JSON.parse(r.gst);
    stt.textContent = statusText(g, s, seat, false);
    g.render(gm, s, seat, m => sendMove(id, g, m), ctx());
    if (s.winner != null) { creditOnce(ref, r, seat, s.winner); ctl('🔄 Rematch', () => startGame(id, g)); ctl('🎮 Dusra game chuno', toPicker, 'sec'); }
    else ctl('↩️ Game badlo', () => confirmBox('Game badalna hai? Ye wala game beech mein ruk jaayega.', toPicker), 'sec');
  };

  listen(ref.onSnapshot(snap => {
    if (!snap.exists) { show('home'); return; }
    const r = snap.data(), seat = r.uids.indexOf(me.uid);
    if (seat < 0) { show('home'); return; }
    last = r;
    $('#pl').innerHTML = [0, 1].map(i => { const p = r.players[i]; return `<div>${p ? p.avatar + ' ' + esc(p.name) : '⏳ ...'}${i === seat ? ' (aap)' : ''}</div>`; }).join('');
    const gm = $('#gm'), stt = $('#stt');
    if (r.uids.length < 2) { stt.textContent = 'Partner ka wait... Invite dabake code bhejo.'; gm.innerHTML = ''; $('#gctl').innerHTML = ''; }
    else if (!r.game) {
      soloGid = null; $('#gctl').innerHTML = ''; stt.textContent = 'Koi bhi game chuno 👇 (18+ sabse neeche)';
      gm.innerHTML = `<div class="grid">${GAMES.map(gameTile).join('')}</div>`;
      $$('[data-g]', gm).forEach(b => b.onclick = () => { const g = GAMES.find(x => x.id === b.dataset.g); g.adult ? requireAdult(() => startGame(id, g)) : startGame(id, g); });
    } else showGame(r, seat);
    if (!chatOn && r.uids.length === 2) { chatOn = true; chatPanel($('#gc'), ref.collection('messages')); }
  }));
}

async function startGame(id, g) {
  try { await db.collection('rooms').doc(id).update({ game: g.id, gst: g.solo ? null : JSON.stringify(freshState(g)), gid: Date.now(), paid: {} }); }
  catch (e) { toast('Game start nahi hua.'); }
}
async function sendMove(id, g, m) {
  const ref = db.collection('rooms').doc(id);
  try {
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref), r = snap.data(), seat = r.uids.indexOf(me.uid);
      if (seat < 0 || r.uids.length < 2 || !r.gst) return;
      const s = JSON.parse(r.gst);
      if (s.winner != null) return;
      if (!g.simul && s.turn !== seat) return;
      const ns = g.move(s, m, seat, ctx());
      if (ns) tx.update(ref, { gst: JSON.stringify(ns) });
    });
  } catch (e) { console.warn(e); }
}
const credited = {};
function creditOnce(ref, r, seat, winner) {
  const key = ref.id + ':' + r.gid;
  if (credited[key] || (r.paid && r.paid[me.uid] === r.gid)) return;
  credited[key] = 1;
  const pts = winner === 'draw' ? 5 : (winner === seat ? 10 : 2);
  db.runTransaction(async tx => {
    const rr = (await tx.get(ref)).data();
    if (!rr || rr.gid !== r.gid || (rr.paid && rr.paid[me.uid] === rr.gid)) return;
    tx.update(ref, { ['paid.' + me.uid]: rr.gid });
    tx.update(db.collection('users').doc(me.uid), { points: FV.increment(pts) });
  }).catch(() => {});
}

/* ---------- offline bot mode ---------- */
function leaveBot() { me ? show('home') : offlineHome(); }
function playBot(g) {
  clearListeners();
  let s = freshState(g), timer = null, alive = true;
  listen(() => { alive = false; clearTimeout(timer); const gm = $('#gm'); if (gm && gm.__stop) { try { gm.__stop(); } catch (e) {} } });
  $('#screen').innerHTML = `<button class="back" id="bk">← Back</button><h2>${g.icon} ${esc(g.name)} <span class="botTag">🤖 vs Bot</span></h2>
    <div class="status" id="stt"></div><div id="gm"></div><div id="gctl"></div>`;
  $('#bk').onclick = leaveBot;
  function draw() {
    if (!alive) return;
    $('#stt').textContent = statusText(g, s, 0, true);
    g.render($('#gm'), s, 0, send, ctx());
    $('#gctl').innerHTML = '';
    if (s.winner != null) { const b = document.createElement('button'); b.className = 'btn full'; b.textContent = '🔄 Dobara khelo'; b.onclick = () => { s = freshState(g); draw(); schedule(); }; $('#gctl').appendChild(b); }
  }
  function send(m) {
    if (!alive || s.winner != null || (!g.simul && s.turn !== 0)) return;
    const ns = g.move(clone(s), m, 0, ctx()); if (!ns) return;
    s = ns; draw(); schedule();
  }
  function schedule() {
    clearTimeout(timer);
    if (!alive || s.winner != null || !g.bot) return;
    if (!g.simul) { if (s.turn !== 1) return; if (!g.bot(clone(s), 1, ctx())) return; }
    timer = setTimeout(() => {
      if (!alive || s.winner != null) return;
      const m = g.bot(clone(s), 1, ctx());
      if (m) { const ns = g.move(clone(s), m, 1, ctx()); if (ns) { s = ns; draw(); } }
      schedule();
    }, g.botDelay || 850);
  }
  draw(); schedule();
}
function openSolo(g) {
  clearListeners();
  $('#screen').innerHTML = `<button class="back" id="bk">← Back</button><div id="solo"></div>`;
  $('#bk').onclick = leaveBot;
  g.solo($('#solo'), ctx());
}
