/* Playmates screens: navigation, chat (text + photo), live chat, ranks, profile, owner panel */
const screens = { home: homeScreen, games: () => gamesScreen('all'), live: liveScreen, rank: rankScreen, me: meScreen, admin: adminScreen };
function show(name) {
  clearListeners();
  $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.s === name));
  setNav(true); $('#screen').style.padding = '12px 14px';
  screens[name]();
}

/* ---------- WhatsApp-style chat ---------- */
const tm = t => { try { return t && t.toDate ? t.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''; } catch (e) { return ''; } };
function chatPanel(el, col, o = {}) {
  const img = o.img !== false;
  el.innerHTML = `<div class="chatwrap"><div class="msgs"></div><div class="compose">
    ${img ? '<label class="btn sec" style="margin:0;cursor:pointer">📷<input type="file" accept="image/*" hidden></label>' : ''}
    <input class="mi" placeholder="Type a message..."><button class="btn sd">➤</button></div></div>`;
  const box = $('.msgs', el), inp = $('.mi', el);
  const send = async (extra = {}) => {
    const text = inp.value.trim();
    if (!text && !extra.img) return;
    inp.value = '';
    try { await col.add({ uid: me.uid, name: me.name, avatar: me.avatar, text, ...extra, t: FV.serverTimestamp() }); } catch (e) { toast('Message not sent.'); }
  };
  $('.sd', el).onclick = () => send();
  inp.onkeydown = e => { if (e.key === 'Enter') send(); };
  const f = $('input[type=file]', el);
  if (f) f.onchange = async () => { if (!f.files[0]) return; try { await send({ img: await shrink(f.files[0]) }); } catch (e) { toast('Could not send the photo.'); } f.value = ''; };
  listen(col.orderBy('t', 'desc').limit(80).onSnapshot(s => {
    const arr = s.docs.map(d => d.data()).reverse();
    box.innerHTML = arr.map(m => `<div class="msg ${m.uid === me.uid ? 'me' : ''}">${m.uid !== me.uid ? `<small>${m.avatar || ''} ${esc(m.name)}</small>` : ''}${esc(m.text)}${m.img ? `<img src="${m.img}" data-big="1">` : ''}<div class="tm">${tm(m.t)}</div></div>`).join('');
    box.scrollTop = box.scrollHeight;
    $$('img[data-big]', box).forEach(i => i.onclick = () => { const mm = modal(`<img src="${i.src}" style="width:100%;border-radius:12px"><button class="btn full" id="ok">Close</button>`); $('#ok', mm).onclick = closeModal; });
  }));
}
function shrink(file, max = 720) {
  return new Promise((res, rej) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.6));
    };
    img.onerror = rej; img.src = url;
  });
}

function liveScreen() {
  $('#screen').style.padding = '8px 12px';
  $('#screen').innerHTML = `<h2>💬 Live Chat <span class="mut">(with everyone)</span></h2><div id="lc" style="height:calc(100vh - 235px)"></div>`;
  chatPanel($('#lc'), db.collection('public_chat'));
}

function rankScreen() {
  $('#screen').innerHTML = `<h2>🏆 Leaderboard</h2><div id="rk"><p class="mut">Loading...</p></div>`;
  listen(db.collection('users').orderBy('points', 'desc').limit(50).onSnapshot(s => {
    $('#rk').innerHTML = s.docs.map((d, i) => { const u = d.data(); return `<div class="rank" style="${d.id === me.uid ? 'outline:2px solid var(--rose)' : ''}"><span class="n">${i < 3 ? ['🥇', '🥈', '🥉'][i] : i + 1}</span><span class="av">${u.avatar}</span><b style="flex:1">${esc(u.name)}</b><span>⭐ ${u.points}</span></div>`; }).join('');
  }));
}

function meScreen() {
  const dob = localStorage.getItem('dob');
  $('#screen').innerHTML = `<h2>👤 Profile</h2><div class="card"><div style="font-size:48px;text-align:center">${me.avatar}</div>
    <input id="nm" maxlength="14" value="${esc(me.name)}">
    <div class="grid" style="grid-template-columns:repeat(6,1fr)">${AVATARS.map(a => `<button class="tile av" data-a="${a}">${a}</button>`).join('')}</div>
    <button class="btn full" id="sv">Save</button></div>
    <div class="card">⭐ Points: <b>${me.points}</b><br><span class="mut">Win = 10, loss = 2, draw = 5 (no points in bot games)</span><br><span class="mut">📧 ${esc(me.email)}</span></div>
    <div class="card">🔞 Age verification: ${dob && ageOf(dob) >= 18 ? 'Done' : 'Pending'} ${dob ? '<button class="btn sec" id="rv" style="margin-left:8px">Reset</button>' : ''}</div>
    <button class="btn sec full" id="lo">🚪 Logout</button>${ownerLine()}`;
  let av = me.avatar;
  $$('[data-a]').forEach(b => b.onclick = () => { av = b.dataset.a; $$('[data-a]').forEach(x => x.classList.remove('adult')); b.classList.add('adult'); });
  $('#sv').onclick = async () => {
    const name = $('#nm').value.trim();
    if (name.length < 2) return toast('Name is too short.');
    try { await db.collection('users').doc(me.uid).update({ name, nameLower: name.toLowerCase(), avatar: av }); toast('Saved ✅'); } catch (e) { toast('Could not save.'); }
  };
  const rv = $('#rv'); if (rv) rv.onclick = () => { localStorage.removeItem('dob'); show('me'); };
  $('#lo').onclick = () => confirmBox('Do you want to log out?', () => auth.signOut());
}

/* ---------- owner panel (only ADMIN_EMAIL; Firestore rules enforce it too) ---------- */
async function adminScreen() {
  if (!isAdmin()) { show('home'); return; }
  $('#screen').innerHTML = `<h2>🛡️ Owner Panel</h2><p class="mut">Loading...</p>`;
  try {
    const [us, ps, rs] = await Promise.all([db.collection('users').limit(500).get(), db.collection('users_private').limit(500).get(), db.collection('rooms').limit(200).get()]);
    const em = {}; ps.forEach(d => em[d.id] = d.data().email);
    const now = Date.now(); let online = 0; const rows = [];
    us.forEach(d => { const u = d.data(), ls = u.lastSeen && u.lastSeen.toDate ? u.lastSeen.toDate().getTime() : 0, on = now - ls < 120000; if (on) online++; rows.push({ n: u.name, e: em[d.id] || '-', p: u.points, on, ls }); });
    rows.sort((a, b) => b.ls - a.ls);
    const playing = rs.docs.filter(d => d.data().uids.length === 2).length;
    $('#screen').innerHTML = `<h2>🛡️ Owner Panel</h2>
      <div class="grid"><div class="tile"><b>${us.size}</b>Total users</div><div class="tile"><b>${online}</b>Online now</div><div class="tile"><b>${playing}</b>Rooms active</div></div>
      <button class="btn sec full" id="rf" style="margin-top:10px">🔄 Refresh</button>
      ${rows.map(r => `<div class="adminrow"><span>${r.on ? '🟢' : '⚪'} <b>${esc(r.n)}</b><br><span class="mut">${esc(r.e)}</span></span><span>⭐ ${r.p}</span></div>`).join('')}`;
    $('#rf').onclick = adminScreen;
  } catch (e) { $('#screen').innerHTML = `<h2>🛡️ Owner Panel</h2><p class="mut">Could not load data: ${esc(e.message || e)}<br>Check the ADMIN email in your Firestore rules.</p>`; }
}

boot();
