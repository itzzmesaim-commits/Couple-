/* Playmates - synthesized sound effects (no audio files) + global game feedback */
const SFX = (() => {
  let ac = null, muted = false, last = {};
  try { muted = localStorage.getItem('pm_mute') === '1'; } catch (e) { }
  const ctx = () => { if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { } } if (ac && ac.state === 'suspended') ac.resume(); return ac; };
  const tone = (f, d, o = {}) => {
    const a = ctx(); if (!a || muted) return; const t = a.currentTime + (o.at || 0), os = a.createOscillator(), g = a.createGain();
    os.type = o.type || 'sine'; os.frequency.setValueAtTime(f, t); if (o.to) os.frequency.exponentialRampToValueAtTime(o.to, t + d);
    const v = o.v == null ? .18 : o.v; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + .008); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    os.connect(g); g.connect(a.destination); os.start(t); os.stop(t + d + .02);
  };
  const noise = (d, o = {}) => {
    const a = ctx(); if (!a || muted) return; const n = Math.floor(a.sampleRate * d), b = a.createBuffer(1, n, a.sampleRate), ch = b.getChannelData(0); for (let i = 0; i < n; i++) ch[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const s = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain(); s.buffer = b; f.type = o.type || 'lowpass'; f.frequency.value = o.f || 1200; g.gain.value = o.v || .25; s.connect(f); f.connect(g); g.connect(a.destination); s.start(a.currentTime + (o.at || 0));
  };
  const S = {
    tap: () => tone(620, .05, { type: 'triangle', v: .09 }),
    place: () => { tone(220, .09, { type: 'square', to: 140, v: .1 }); noise(.05, { f: 900, v: .12 }); },
    good: () => { tone(660, .09, { type: 'triangle' }); tone(990, .14, { type: 'triangle', at: .07 }); },
    bad: () => { tone(200, .22, { type: 'sawtooth', to: 110, v: .12 }); },
    coin: () => { tone(1100, .07, { type: 'square', v: .08 }); tone(1650, .16, { type: 'square', v: .08, at: .06 }); },
    hit: () => { noise(.12, { f: 1800, v: .3 }); tone(160, .12, { type: 'square', to: 70, v: .14 }); },
    boom: () => { noise(.45, { f: 500, v: .45 }); tone(110, .4, { type: 'sawtooth', to: 40, v: .2 }); },
    splash: () => { noise(.3, { type: 'bandpass', f: 1400, v: .22 }); },
    whoosh: () => { noise(.22, { type: 'bandpass', f: 700, v: .2 }); tone(300, .2, { to: 900, v: .05 }); },
    clack: () => { tone(900, .035, { type: 'square', v: .12 }); tone(480, .06, { type: 'triangle', v: .12, at: .02 }); noise(.04, { f: 3000, v: .12 }); },
    dice: () => { for (let i = 0; i < 5; i++) { tone(300 + Math.random() * 400, .03, { type: 'square', v: .08, at: i * .06 }); noise(.03, { f: 2500, v: .1, at: i * .06 }); } },
    pop: () => tone(500, .08, { type: 'sine', to: 900, v: .14 }),
    heal: () => { tone(520, .12, { v: .12 }); tone(780, .2, { v: .12, at: .1 }); },
    shield: () => { tone(300, .12, { type: 'triangle', to: 600, v: .14 }); noise(.06, { f: 4000, v: .08 }); },
    clear: () => { [523, 659, 784, 1047].forEach((f, i) => tone(f, .13, { type: 'triangle', at: i * .06, v: .15 })); },
    win: () => { [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, .2, { type: 'triangle', at: i * .11, v: .17 })); },
    lose: () => { [392, 349, 294, 220].forEach((f, i) => tone(f, .26, { type: 'sawtooth', at: i * .15, v: .1 })); },
    tick: () => tone(1200, .03, { type: 'square', v: .05 })
  };
  const play = n => { const nw = Date.now(); if (last[n] && nw - last[n] < 45) return; last[n] = nw; try { (S[n] || S.tap)(); } catch (e) { } };
  return { play, get muted() { return muted; }, toggle() { muted = !muted; try { localStorage.setItem('pm_mute', muted ? '1' : '0'); } catch (e) { } return muted; }, unlock: ctx };
})();
window.SFX = SFX;
['pointerdown', 'keydown'].forEach(ev => document.addEventListener(ev, () => SFX.unlock(), { once: true, passive: true }));
/* tap feedback on any button / game tile */
document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('button,.cell,.gem,.dh,.wmt,.sbc,.bkp,[data-i],[data-t]'); if (!b || b.id === 'sfxbtn' || b.disabled) return;
  SFX.play(b.matches('.btn') ? 'tap' : 'pop');
}, true);
document.addEventListener('DOMContentLoaded', () => {
  const m = document.createElement('button'); m.id = 'sfxbtn'; m.textContent = SFX.muted ? '🔇' : '🔊'; m.setAttribute('aria-label', 'Sound');
  m.onclick = () => { m.textContent = SFX.toggle() ? '🔇' : '🔊'; if (!SFX.muted) SFX.play('good'); }; document.body.appendChild(m);
});
