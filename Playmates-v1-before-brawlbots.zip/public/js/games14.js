/* Playmates - Dice Party (Yahtzee style, 2 players) + Puzzles (luxury slide puzzle) */

/* ================= DICE PARTY ================= */
const DP_NAMES = ['1', '2', '3', '4', '5', '6', '3X', '4X', 'FH', 'SM', 'LG', '5X', 'CH'];
const DP_COL = ['#e53935', '#fb8c00', '#1e88e5', '#43a047', '#8e24aa', '#00bcd4'];
const DP_BASE = [2.1, 4.2, 6.3, 8.4, 10.5, 12.6, 14, 8, 9, 6, 3.5, 1.5, 21];
function dpScore(c, d) {
  const cnt = [0, 0, 0, 0, 0, 0, 0]; d.forEach(v => cnt[v]++); const sum = d.reduce((a, b) => a + b, 0), has = n => cnt.some(x => x >= n), faces = new Set(d);
  if (c < 6) return cnt[c + 1] * (c + 1);
  if (c === 6) return has(3) ? sum : 0; if (c === 7) return has(4) ? sum : 0;
  if (c === 8) return (cnt.includes(3) && cnt.includes(2)) ? 25 : 0;
  if (c === 9) return [[1, 2, 3, 4], [2, 3, 4, 5], [3, 4, 5, 6]].some(r => r.every(v => faces.has(v))) ? 30 : 0;
  if (c === 10) return ([1, 2, 3, 4, 5].every(v => faces.has(v)) || [2, 3, 4, 5, 6].every(v => faces.has(v))) ? 40 : 0;
  if (c === 11) return has(5) ? 50 : 0; return sum;
}
const dpUpper = sc => sc.slice(0, 6).reduce((a, v) => a + (v || 0), 0), dpLower = sc => sc.slice(6).reduce((a, v) => a + (v || 0), 0), dpBonus = sc => dpUpper(sc) >= 63 ? 35 : 0, dpTotal = sc => dpUpper(sc) + dpBonus(sc) + dpLower(sc);
const G_DICE2 = {
  id: 'dice', name: 'Dice Party', icon: '🎲', type: 'turn', sym: ['🟦', '🟧'],
  desc: 'Roll five dice up to 3 times, tap dice to hold them, then pick a box to score. Fill all 13 boxes — upper score of 63+ earns a 35 point bonus. Highest total wins!',
  init() { return { dice: [1, 2, 3, 4, 5], held: [0, 0, 0, 0, 0], rolls: 3, rolled: false, sc: [Array(13).fill(null), Array(13).fill(null)], turn: 0, winner: null, rs: newSeed(), n: 0, last: null }; },
  status: (s, seat) => s.winner != null ? '' : (s.turn === seat ? (s.rolled ? '🎯 Hold dice, roll again or pick a box' : '🎲 Roll the dice!') : '⏳ Opponent’s turn'),
  move(s, m, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    if (m.a === 'hold') { if (!s.rolled || s.rolls <= 0) return null; const i = m.i | 0; if (i < 0 || i > 4) return null; s.held[i] = s.held[i] ? 0 : 1; return s; }
    if (m.a === 'roll') {
      if (s.rolls <= 0) return null; if (s.rolled && Array.isArray(m.h) && m.h.length === 5) s.held = m.h.map(x => x ? 1 : 0);
      const R = rng(s.rs + (s.n + 1) * 977); s.n++; for (let i = 0; i < 5; i++) if (!s.rolled || !s.held[i]) s.dice[i] = 1 + Math.floor(R() * 6); s.rolled = true; s.rolls--; if (s.rolls === 0) s.held = [0, 0, 0, 0, 0]; return s;
    }
    if (m.a === 'play') {
      const c = m.c | 0; if (!s.rolled || c < 0 || c > 12 || s.sc[seat][c] != null) return null;
      const v = dpScore(c, s.dice); s.sc[seat][c] = v; s.last = { by: seat, c, v }; s.n++; s.rolled = false; s.rolls = 3; s.held = [0, 0, 0, 0, 0];
      if (s.sc[0].every(x => x != null) && s.sc[1].every(x => x != null)) { const a = dpTotal(s.sc[0]), b = dpTotal(s.sc[1]); s.winner = a === b ? 'draw' : (a > b ? 0 : 1); } else s.turn = 1 - seat; return s;
    }
    return null;
  },
  bot(s, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    const open = []; s.sc[seat].forEach((v, i) => { if (v == null) open.push(i); });
    const bestNow = d => { let b = -1e9, bc = open[0]; open.forEach(c => { const v = dpScore(c, d) - DP_BASE[c] + (c < 6 && dpScore(c, d) >= 3 * (c + 1) ? 3 : 0); if (v > b) { b = v; bc = c; } }); return { b, c: bc }; };
    if (!s.rolled) return { a: 'roll' };
    const now = bestNow(s.dice); if (s.rolls <= 0) return { a: 'play', c: now.c };
    let bestM = null, bestV = -1e9;
    for (let mask = 0; mask < 32; mask++) { let tot = 0; const N = 28; for (let k = 0; k < N; k++) { const d = s.dice.map((v, i) => (mask >> i & 1) ? v : 1 + Math.floor(Math.random() * 6)); tot += bestNow(d).b; } const ev = tot / N; if (ev > bestV) { bestV = ev; bestM = mask; } }
    if (bestV > now.b + .6) return { a: 'roll', h: [0, 1, 2, 3, 4].map(i => bestM >> i & 1) };
    return { a: 'play', c: now.c };
  },
  render(el, s, seat, send) {
    const me = seat, th = 1 - seat, mine = s.turn === seat && s.winner == null, sel = el.__sel != null && s.sc[me][el.__sel] == null && s.rolled ? el.__sel : null;
    if (el.__gs !== s.gid || el.__turn !== s.turn || el.__nn !== s.n) { el.__gs = s.gid; if (el.__turn !== s.turn || el.__nn !== s.n) el.__sel = null; }
    const rolledNew = el.__nn !== s.n && s.rolled; el.__turn = s.turn; el.__nn = s.n; const sel2 = el.__sel != null && s.sc[me][el.__sel] == null && s.rolled ? el.__sel : null;
    const pot = c => (mine && s.rolled && s.sc[me][c] == null) ? dpScore(c, s.dice) : null;
    const cell = (p, c) => { const v = s.sc[p][c], you = p === me; if (v != null) return `<div class="dpc on ${s.last && s.last.by === p && s.last.c === c ? 'new' : ''}">${v}</div>`; if (you && mine && s.rolled) return `<button class="dpc pot ${sel2 === c ? 'sel' : ''}" data-c="${c}">${pot(c)}</button>`; return '<div class="dpc"></div>'; };
    const die = (n, col) => `<span class="dpdie" style="--pc:${col || '#222'}">${DOM_PIPS[n].map(([x, y]) => `<i style="left:${x * 100}%;top:${y * 100}%"></i>`).join('')}</span>`;
    const up = c => `<div class="dprow"><div class="dplab">${die(c + 1, DP_COL[c])}</div>${cell(th, c)}${cell(me, c)}</div>`;
    const lo = c => `<div class="dprow"><div class="dplab"><span class="dpchip">${DP_NAMES[c]}</span></div>${cell(th, c)}${cell(me, c)}</div>`;
    const tot = p => dpTotal(s.sc[p]);
    const left = s.sc[me].filter(x => x == null).length;
    el.innerHTML = `<div class="dp"><div class="dphead"><b class="s1">${tot(th)}</b><span class="av ${s.turn === th && s.winner == null ? 'act' : ''}">🤖</span><i>VS</i><span class="av ${mine ? 'act' : ''}">🙂</span><b class="s2">${tot(me)}</b></div>
      <div class="dpmsgt">${s.winner != null ? (s.winner === me ? '🏆 You won!' : s.winner === 'draw' ? '🤝 Draw' : '😅 You lost') : (s.last ? `${s.last.by === me ? 'You' : 'Rival'} scored ${s.last.v} in ${DP_NAMES[s.last.c]}` : 'Game started')}</div>
      <div class="dptable"><div class="dpcols"><div class="dpcol"><div class="dpth"><span></span><span>THEM</span><span>YOU</span></div>${[0, 1, 2, 3, 4, 5].map(up).join('')}<div class="dprow bon"><div class="dplab"><b>BONUS</b><small>If upper is over 62</small></div><div class="dpc on b">${dpBonus(s.sc[th])}</div><div class="dpc on b">${dpBonus(s.sc[me])}</div></div></div>
      <div class="dpcol"><div class="dpth"><span></span><span>THEM</span><span>YOU</span></div>${[6, 7, 8, 9, 10, 11, 12].map(lo).join('')}</div></div>
      <div class="dptot"><div><b>UPPER</b><span class="a">${dpUpper(s.sc[th])}</span><span class="b">${dpUpper(s.sc[me])}</span></div><div><b>LOWER</b><span class="a">${dpLower(s.sc[th])}</span><span class="b">${dpLower(s.sc[me])}</span></div></div></div>
      <div class="dpdice ${rolledNew ? 'rolling' : ''}">${s.rolled || s.winner == null ? s.dice.map((v, i) => `<button class="dpd ${s.held[i] ? 'held' : ''} ${s.rolled ? '' : 'idle'}" data-h="${i}">${die(v, '#1b1b2a')}${s.held[i] ? '<em>HOLD</em>' : ''}</button>`).join('') : ''}</div>
      <div class="dpmsg">${s.winner != null ? '' : mine ? (s.rolled ? (s.rolls > 0 ? 'Tap dice to HOLD · tap a box to score' : 'Pick a box to score') : 'Tap on ROLL button to roll the dice!') : '⏳ Waiting for the rival…'}</div>
      <div class="dpbtns"><button class="dpb roll" id="dpr" ${mine && s.rolls > 0 ? '' : 'disabled'}>ROLL (${s.rolls})</button><button class="dpb play" id="dpp" ${mine && sel2 != null ? '' : 'disabled'}>PLAY</button></div><div class="dpleft">${left} turns left</div></div>`;
    if (!mine) return;
    $$('[data-c]', el).forEach(b => b.onclick = () => { el.__sel = +b.dataset.c; SFX.play('tap'); G_DICE2.render(el, s, seat, send); });
    $$('[data-h]', el).forEach(b => b.onclick = () => { if (s.rolled && s.rolls > 0) send({ a: 'hold', i: +b.dataset.h }); });
    const r = $('#dpr', el); if (r) r.onclick = () => send({ a: 'roll' });
    const p = $('#dpp', el); if (p) p.onclick = () => { if (sel2 != null) { const c = sel2; el.__sel = null; send({ a: 'play', c }); } };
  }
};

/* ================= PUZZLES (luxury) ================= */
function luxPic(c, S, seed) {
  const style = seed % 3, R = rng(seed);
  const star = (x, y, r, a) => { c.globalAlpha = a; c.fillStyle = '#fff'; c.beginPath(); c.arc(x, y, r, 0, 6.283); c.fill(); c.globalAlpha = 1; };
  if (style === 0) { // golden palace at dusk
    let g = c.createLinearGradient(0, 0, 0, S * .72); g.addColorStop(0, '#1b1450'); g.addColorStop(.45, '#7a2f86'); g.addColorStop(.8, '#ff8a4a'); g.addColorStop(1, '#ffd27a'); c.fillStyle = g; c.fillRect(0, 0, S, S);
    for (let i = 0; i < 60; i++) star(R() * S, R() * S * .45, R() * 1.3 + .3, .3 + R() * .7);
    const sun = c.createRadialGradient(S * .5, S * .66, 4, S * .5, S * .66, S * .3); sun.addColorStop(0, '#fff6c0'); sun.addColorStop(.35, '#ffc65a88'); sun.addColorStop(1, '#ffc65a00'); c.fillStyle = sun; c.fillRect(0, 0, S, S);
    c.fillStyle = '#2a1030'; c.beginPath(); c.moveTo(0, S * .7); const dome = (cx, w, h, spire) => { c.lineTo(cx - w / 2, S * .7); c.lineTo(cx - w / 2, S * .7 - h * .55); c.quadraticCurveTo(cx - w / 2, S * .7 - h, cx, S * .7 - h); c.quadraticCurveTo(cx + w / 2, S * .7 - h, cx + w / 2, S * .7 - h * .55); c.lineTo(cx + w / 2, S * .7); if (spire) { c.moveTo(cx, S * .7 - h); } }; c.lineTo(S * .06, S * .7); dome(S * .2, S * .16, S * .22); c.lineTo(S * .32, S * .7); c.lineTo(S * .32, S * .38); c.lineTo(S * .335, S * .3); c.lineTo(S * .35, S * .38); c.lineTo(S * .35, S * .7); dome(S * .5, S * .26, S * .36); c.lineTo(S * .66, S * .7); c.lineTo(S * .66, S * .38); c.lineTo(S * .675, S * .3); c.lineTo(S * .69, S * .38); c.lineTo(S * .69, S * .7); dome(S * .8, S * .18, S * .26); c.lineTo(S, S * .7); c.lineTo(S, S * .7); c.fill();
    c.fillStyle = '#ffd27a'; for (let i = 0; i < 18; i++) c.fillRect(S * (.14 + R() * .72), S * (.5 + R() * .18), 2.5, 4);
    g = c.createLinearGradient(0, S * .7, 0, S); g.addColorStop(0, '#6a3a7a'); g.addColorStop(1, '#14103a'); c.fillStyle = g; c.fillRect(0, S * .7, S, S * .3);
    c.strokeStyle = '#ffd27acc'; c.lineWidth = 2; for (let i = 0; i < 16; i++) { const y = S * (.72 + i * .017), w = S * (.1 + (i % 5) * .05); c.beginPath(); c.moveTo(S * .5 - w / 2 + R() * 14 - 7, y); c.lineTo(S * .5 + w / 2 + R() * 14 - 7, y); c.stroke(); }
  } else if (style === 1) { // royal yacht sunset
    let g = c.createLinearGradient(0, 0, 0, S * .62); g.addColorStop(0, '#0f2a5a'); g.addColorStop(.5, '#e0527a'); g.addColorStop(1, '#ffc65a'); c.fillStyle = g; c.fillRect(0, 0, S, S);
    for (let i = 0; i < 40; i++) star(R() * S, R() * S * .3, R() * 1.2 + .3, .3 + R() * .6);
    c.fillStyle = '#fff3c0'; c.beginPath(); c.arc(S * .72, S * .52, S * .08, 0, 6.283); c.fill(); g = c.createLinearGradient(0, S * .62, 0, S); g.addColorStop(0, '#ff9a6a'); g.addColorStop(.25, '#2a3f7a'); g.addColorStop(1, '#0a1838'); c.fillStyle = g; c.fillRect(0, S * .62, S, S * .38);
    c.strokeStyle = '#ffe19acc'; c.lineWidth = 3; for (let i = 0; i < 12; i++) { const y = S * (.64 + i * .026), w = S * (.2 - i * .008); c.beginPath(); c.moveTo(S * .72 - w, y); c.lineTo(S * .72 + w, y); c.stroke(); }
    c.fillStyle = '#f7f7ff'; c.beginPath(); c.moveTo(S * .1, S * .62); c.lineTo(S * .62, S * .62); c.lineTo(S * .56, S * .72); c.lineTo(S * .16, S * .72); c.closePath(); c.fill(); c.fillStyle = '#1a2a5a'; c.fillRect(S * .12, S * .655, S * .46, 4); c.fillStyle = '#e8e8f4'; rr(c, S * .2, S * .54, S * .3, S * .08, 6); c.fill(); rr(c, S * .27, S * .47, S * .18, S * .07, 6); c.fill(); c.fillStyle = '#4a6a9a'; for (let i = 0; i < 6; i++) c.fillRect(S * (.22 + i * .045), S * .565, 7, 7); c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.moveTo(S * .36, S * .47); c.lineTo(S * .36, S * .38); c.stroke(); c.fillStyle = '#ffd54a'; c.fillRect(S * .36, S * .38, 14, 8);
    c.fillStyle = '#ffffff44'; c.beginPath(); c.moveTo(S * .16, S * .72); c.lineTo(S * .56, S * .72); c.lineTo(S * .5, S * .8); c.lineTo(S * .2, S * .8); c.fill();
  } else { // alpine lake at golden hour
    let g = c.createLinearGradient(0, 0, 0, S * .6); g.addColorStop(0, '#3f6fc0'); g.addColorStop(.6, '#ffd8a0'); g.addColorStop(1, '#ffb15a'); c.fillStyle = g; c.fillRect(0, 0, S, S);
    const sun = c.createRadialGradient(S * .3, S * .35, 2, S * .3, S * .35, S * .35); sun.addColorStop(0, '#fff8d8'); sun.addColorStop(1, '#fff8d800'); c.fillStyle = sun; c.fillRect(0, 0, S, S);
    const mt = (pts, col, snow) => { c.fillStyle = col; c.beginPath(); c.moveTo(0, S * .6); pts.forEach(([x, y]) => c.lineTo(S * x, S * y)); c.lineTo(S, S * .6); c.closePath(); c.fill(); if (snow) { c.fillStyle = '#fff'; pts.forEach(([x, y]) => { if (y < .35) { c.beginPath(); c.moveTo(S * x, S * y); c.lineTo(S * (x - .07), S * (y + .1)); c.lineTo(S * (x - .02), S * (y + .08)); c.lineTo(S * x, S * (y + .12)); c.lineTo(S * (x + .03), S * (y + .08)); c.lineTo(S * (x + .07), S * (y + .1)); c.closePath(); c.fill(); } }); } };
    mt([[.15, .42], [.3, .55], [.45, .3], [.62, .56], [.78, .38], [1, .55]], '#5a6a9a', 1); mt([[.1, .55], [.28, .48], [.5, .58], [.72, .46], [.9, .56]], '#3a4a78', 0);
    c.fillStyle = '#1f3a2a'; for (let i = 0; i < 14; i++) { const x = S * (R() < .5 ? R() * .3 : .7 + R() * .3), y = S * (.56 + R() * .06), h = S * (.1 + R() * .08); c.beginPath(); c.moveTo(x, y - h); c.lineTo(x + h * .22, y); c.lineTo(x - h * .22, y); c.fill(); }
    g = c.createLinearGradient(0, S * .6, 0, S); g.addColorStop(0, '#ffc07a'); g.addColorStop(.3, '#4a7aa8'); g.addColorStop(1, '#16304a'); c.fillStyle = g; c.fillRect(0, S * .6, S, S * .4); c.save(); c.globalAlpha = .35; c.translate(0, S * 1.2); c.scale(1, -1); mt([[.15, .42], [.3, .55], [.45, .3], [.62, .56], [.78, .38], [1, .55]], '#5a6a9a', 0); c.restore(); c.fillStyle = g; c.globalAlpha = .55; c.fillRect(0, S * .6, S, S * .4); c.globalAlpha = 1;
    c.strokeStyle = '#ffffff55'; c.lineWidth = 1.5; for (let i = 0; i < 14; i++) { const y = S * (.65 + i * .022); c.beginPath(); c.moveTo(R() * S * .5, y); c.lineTo(R() * S * .5 + S * .3, y); c.stroke(); }
  }
  const vg = c.createRadialGradient(S / 2, S / 2, S * .35, S / 2, S / 2, S * .75); vg.addColorStop(0, '#0000'); vg.addColorStop(1, '#0007'); c.fillStyle = vg; c.fillRect(0, 0, S, S);
}
const GOLD = (c, x0, y0, x1, y1) => { const g = c.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, '#fbeeb0'); g.addColorStop(.35, '#d9aa42'); g.addColorStop(.7, '#9c721a'); g.addColorStop(1, '#f1d27a'); return g; };
const G_PUZZLE2 = duel({
  id: 'puzzle', name: 'Puzzles', icon: '🧩', low: true, desc: 'A 3D sliding picture puzzle (3×3 or 4×4). Every game gives a new painting and new tiles. Rebuild it fastest to win!',
  bot: () => 60 + Math.floor(Math.random() * 90),
  play(box, seed, done) {
    const N = Math.floor(seed / 3) % 2 ? 3 : 4, NN = N * N, R = rng(seed), S = 360;
    const url = off(S, S, (g, w) => luxPic(g, w, seed)).toDataURL('image/jpeg', .9);
    const b = Array.from({ length: NN }, (_, i) => i); let e = NN - 1;
    const nb = i => { const r = (i / N) | 0, q = i % N, o = []; if (r > 0) o.push(i - N); if (r < N - 1) o.push(i + N); if (q > 0) o.push(i - 1); if (q < N - 1) o.push(i + 1); return o; };
    let last = -1; for (let k = 0; k < (N === 3 ? 90 : 170); k++) { const o = nb(e).filter(x => x !== last), n = o[Math.floor(R() * o.length)]; b[e] = b[n]; b[n] = NN - 1; last = e; e = n; }
    if (b.every((v, i) => v === i)) { b[e] = b[e - 1]; b[e - 1] = NN - 1; e--; }
    box.innerHTML = `<div class="pz3" style="--n:${N}"><div class="pzhud"><span>🧩 ${N}×${N}</span><span id="pzm">Moves 0</span><span id="pzt">0:00</span></div><div class="pzscene"><div class="pzboard"></div></div><div class="pzfoot"><img class="pzth" src="${url}" alt=""><small>THE MASTERPIECE</small></div></div>`;
    const board = box.querySelector('.pzboard'), scene = box.querySelector('.pzscene'); board.style.setProperty('--img', 'url(' + url + ')');
    const tiles = [];
    for (let v = 0; v < NN; v++) {
      const t = document.createElement('div'); t.className = 'pzt'; t.dataset.v = v; const sc = v % N, sr = (v / N) | 0;
      t.innerHTML = Array.from({ length: 6 }, (_, k) => `<i style="transform:translateZ(${k * 2}px)"></i>`).join('') + `<b style="background-size:${N * 100}% ${N * 100}%;background-position:${sc / (N - 1) * 100}% ${sr / (N - 1) * 100}%"></b>`;
      board.appendChild(t); tiles[v] = t;
    }
    let T = 0, moves = 0, over = false, solved = false;
    const place = () => b.forEach((v, i) => { const t = tiles[v]; t.style.setProperty('--c', i % N); t.style.setProperty('--r', (i / N) | 0); t.classList.toggle('pzhole', v === NN - 1 && !solved); });
    place(); requestAnimationFrame(() => board.classList.add('go'));
    const upd = () => { box.querySelector('#pzm').textContent = 'Moves ' + moves; box.querySelector('#pzt').textContent = Math.floor(T / 60) + ':' + String(Math.floor(T % 60)).padStart(2, '0'); };
    const iv = setInterval(() => { if (over) return; T += .25; upd(); if (T >= 240) { over = true; setTimeout(() => fin(box, 240 + b.filter((v, i) => v !== i).length, done, '⏱ Time up'), 300); } }, 250);
    scene.addEventListener('pointermove', ev => { const r = scene.getBoundingClientRect(); board.style.setProperty('--ry', (((ev.clientX - r.left) / r.width) - .5) * 16 + 'deg'); });
    board.addEventListener('pointerdown', ev => {
      const t = ev.target.closest('.pzt'); if (!t || over) return; const i = b.indexOf(+t.dataset.v);
      if (!nb(e).includes(i)) { SFX.play('bad'); return; }
      b[e] = b[i]; b[i] = NN - 1; e = i; moves++; SFX.play('slide'); place(); upd();
      if (b.every((v, k) => v === k)) { solved = true; over = true; place(); board.classList.add('pzwin'); SFX.play('win'); setTimeout(() => SFX.play('perfect'), 450); setTimeout(() => fin(box, Math.round(T), done, '🎉 Solved in ' + moves + ' moves · ' + Math.round(T) + 's'), 1800); }
    });
    return () => { over = true; clearInterval(iv); };
  }
});
