/* Playmates - turn-based / simultaneous board games (pack 2) */
const bindAll = (el, sel, fn) => $$(sel, el).forEach(b => b.onclick = () => fn(b));
const scoreBar = (a, b, mid) => `<div class="scorebar"><div class="p0">${a}</div>${mid ? `<div class="mut">${mid}</div>` : ''}<div class="p1">${b}</div></div>`;
const winBy = (a, b) => a === b ? 'draw' : (a > b ? 0 : 1);

/* ---------- Match It (memory pairs) ---------- */
const MEM_EMO = ['🐶', '🐱', '🦊', '🐼', '🦁', '🐸', '🐵', '🦄', '🐙', '🦋'];
const G_MEM = {
  id: 'mem', name: 'Match It', icon: '🃏', sym: ['🔴', '🔵'], desc: 'Flip two cards. A match gives you another turn!',
  init: () => ({ v: shuffle([...MEM_EMO, ...MEM_EMO]), matched: Array(20).fill(null), open: [], seen: {}, sc: [0, 0], turn: 0, winner: null }),
  move(s, m, seat) {
    if (s.matched[m.i] != null) return null;
    if (s.open.length === 2) s.open = [];
    if (s.open.includes(m.i)) return null;
    s.open.push(m.i); s.seen[m.i] = 1;
    if (s.open.length === 2) {
      const [a, b] = s.open;
      if (s.v[a] === s.v[b]) { s.matched[a] = seat; s.matched[b] = seat; s.sc[seat]++; s.open = []; if (s.matched.every(x => x != null)) s.winner = winBy(s.sc[0], s.sc[1]); }
      else s.turn = 1 - seat;
    }
    return s;
  },
  bot(s, seat) {
    const free = s.v.map((_, i) => i).filter(i => s.matched[i] == null);
    const known = i => s.seen[i] && Math.random() > 0.25;
    if (s.open.length === 1) {
      const a = s.open[0], j = free.find(i => i !== a && known(i) && s.v[i] === s.v[a]);
      if (j != null) return { i: j };
      const unseen = free.filter(i => i !== a && !s.seen[i]);
      return { i: pick(unseen.length ? unseen : free.filter(i => i !== a)) };
    }
    for (const i of free) { const j = free.find(k => k !== i && known(i) && known(k) && s.v[k] === s.v[i]); if (j != null) return { i }; }
    const unseen = free.filter(i => !s.seen[i]);
    return { i: pick(unseen.length ? unseen : free) };
  },
  render(el, s, seat, send) {
    el.innerHTML = scoreBar(s.sc[0], s.sc[1]) + `<div class="board" style="grid-template-columns:repeat(4,1fr);max-width:320px">${s.v.map((v, i) => { const m = s.matched[i], o = s.open.includes(i); return `<button class="cell ${m != null ? 'p' + m : ''}" style="${m != null ? 'opacity:.55;' : ''}" data-i="${i}">${m != null || o ? v : '❓'}</button>`; }).join('')}</div>`;
    bindAll(el, '[data-i]', b => send({ i: +b.dataset.i }));
  }
};

/* ---------- Word Match (unscramble, first to solve wins the point) ---------- */
const WORDS = [['planet', 'Space'], ['guitar', 'Music'], ['pizza', 'Food'], ['rocket', 'Space'], ['garden', 'Nature'], ['monkey', 'Animal'], ['tiger', 'Animal'], ['bridge', 'Building'], ['castle', 'Building'], ['river', 'Nature'], ['mobile', 'Gadget'], ['laptop', 'Gadget'], ['cricket', 'Sport'], ['soccer', 'Sport'], ['banana', 'Fruit'], ['orange', 'Fruit'], ['window', 'Home'], ['pillow', 'Home'], ['summer', 'Season'], ['winter', 'Season'], ['doctor', 'Job'], ['teacher', 'Job'], ['holiday', 'Fun'], ['puzzle', 'Game'], ['wizard', 'Fantasy'], ['dragon', 'Fantasy'], ['coffee', 'Drink'], ['thunder', 'Weather'], ['rainbow', 'Weather'], ['butter', 'Food']];
const scramble = w => { let r; do { r = shuffle(w.split('')).join(''); } while (r === w); return r; };
const G_WORD = {
  id: 'word', name: 'Word Match', icon: '🔤', simul: true, sym: ['●', '●'], desc: 'Unscramble the letters and type the correct word first.',
  init() { const order = shuffle(WORDS.map((_, i) => i)).slice(0, 6); return { order, i: 0, scr: scramble(WORDS[order[0]][0]), solved: null, sc: [0, 0], turn: 0, winner: null }; },
  status: (s, seat) => s.winner != null ? '' : (s.solved == null ? '⌨️ Type the correct word first!' : (s.solved === seat ? '✅ Point aapka!' : '😅 Partner was faster')),
  move(s, m, seat) {
    const w = WORDS[s.order[s.i]][0];
    if (m.a === 'ans') { if (s.solved != null || String(m.w).trim().toLowerCase() !== w) return null; s.solved = seat; s.sc[seat]++; return s; }
    if (m.a === 'next') {
      s.i++; s.solved = null;
      if (s.i >= s.order.length) s.winner = winBy(s.sc[0], s.sc[1]); else s.scr = scramble(WORDS[s.order[s.i]][0]);
      return s;
    }
    return null;
  },
  bot: s => (s.solved == null && s.winner == null && Math.random() < 0.3) ? { a: 'ans', w: WORDS[s.order[s.i]][0] } : null,
  render(el, s, seat, send) {
    if (s.winner != null) { el.innerHTML = scoreBar(s.sc[0], s.sc[1]); return; }
    const [w, hint] = WORDS[s.order[s.i]];
    const keep = $('#wi', el) ? $('#wi', el).value : '';
    el.innerHTML = scoreBar(s.sc[0], s.sc[1], `${s.i + 1}/${s.order.length}`) + `<div class="dare" style="letter-spacing:6px;font-weight:800">${esc(s.scr.toUpperCase())}</div><p class="mut" style="text-align:center">Hint: ${hint}</p>
      ${s.solved == null ? `<div class="row"><input id="wi" autocomplete="off" autocapitalize="off" placeholder="Type your answer"><button class="btn" id="wg">OK</button></div><div id="wm" class="mut" style="text-align:center"></div>` : `<div class="status">Sahi shabd: ${esc(w.toUpperCase())}</div><button class="btn full" id="nx">Aage ➡️</button>`}`;
    const wi = $('#wi', el);
    if (wi) {
      wi.value = keep;
      const go = () => { if (wi.value.trim().toLowerCase() === w) send({ a: 'ans', w: wi.value }); else { $('#wm', el).textContent = '❌ Wrong, try again'; } };
      $('#wg', el).onclick = go; wi.onkeydown = e => { if (e.key === 'Enter') go(); };
    }
    const nx = $('#nx', el); if (nx) nx.onclick = () => send({ a: 'next' });
  }
};

/* ---------- Dominoes ---------- */
const domPlayable = (t, ends) => !ends || t[0] === ends[0] || t[1] === ends[0] || t[0] === ends[1] || t[1] === ends[1];
const domEnds = s => s.board.length ? [s.board[0][0], s.board[s.board.length - 1][1]] : null;
const G_DOM = {
  id: 'dom', name: 'Dominoes', icon: '🁣', sym: ['🔴', '🔵'], desc: 'Match the tile ends. Be first to play all your tiles.',
  init() {
    const all = []; for (let a = 0; a <= 6; a++) for (let b = a; b <= 6; b++) all.push([a, b]);
    const sh = shuffle(all);
    return { hands: [sh.slice(0, 7), sh.slice(7, 14)], stock: sh.slice(14), board: [], passes: 0, turn: 0, winner: null };
  },
  move(s, m, seat) {
    const hand = s.hands[seat], ends = domEnds(s);
    if (m.a === 'draw') { if (!s.stock.length || hand.some(t => domPlayable(t, ends))) return null; hand.push(s.stock.pop()); return s; }
    if (m.a === 'pass') {
      if (s.stock.length || hand.some(t => domPlayable(t, ends))) return null;
      s.passes++;
      if (s.passes >= 2) { const p = s.hands.map(h => h.reduce((a, t) => a + t[0] + t[1], 0)); s.winner = winBy(p[1], p[0]); } else s.turn = 1 - seat;
      return s;
    }
    if (m.a === 'play') {
      const t = hand[m.t]; if (!t) return null;
      if (!ends) s.board.push([t[0], t[1]]);
      else if (m.side === 'R') { if (t[0] === ends[1]) s.board.push([t[0], t[1]]); else if (t[1] === ends[1]) s.board.push([t[1], t[0]]); else return null; }
      else { if (t[1] === ends[0]) s.board.unshift([t[0], t[1]]); else if (t[0] === ends[0]) s.board.unshift([t[1], t[0]]); else return null; }
      hand.splice(m.t, 1); s.passes = 0;
      if (!hand.length) s.winner = seat; else s.turn = 1 - seat;
      return s;
    }
    return null;
  },
  bot(s, seat) {
    const hand = s.hands[seat], ends = domEnds(s);
    let best = null, bs = -1;
    hand.forEach((t, i) => {
      if (!domPlayable(t, ends)) return;
      const v = t[0] + t[1] + Math.random();
      if (v > bs) { bs = v; best = { a: 'play', t: i, side: (!ends || t[0] === ends[1] || t[1] === ends[1]) ? 'R' : 'L' }; }
    });
    if (best) return best;
    return s.stock.length ? { a: 'draw' } : { a: 'pass' };
  },
  status(s, seat) { const p = s.hands[seat].some(t => domPlayable(t, domEnds(s))); return s.turn !== seat ? '⏳ Partner’s turn' : (p ? '👉 Choose a tile' : (s.stock.length ? '📦 No tile, draw from stock' : '⏭ Pass')); },
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null, hand = s.hands[seat], ends = domEnds(s);
    const chip = t => `<span class="dom">${t[0]}|${t[1]}</span>`;
    const sel = el.__sel != null && hand[el.__sel] ? el.__sel : null;
    const can = hand.some(t => domPlayable(t, ends));
    el.innerHTML = `<div class="mut" style="text-align:center">Partner has ${s.hands[1 - seat].length} tiles • Stock ${s.stock.length}</div>
      <div class="domrow">${s.board.length ? s.board.map(chip).join('') : '<span class="mut">Table is empty</span>'}</div>
      <div class="mut" style="margin-top:8px">Aapke tile:</div>
      <div class="domhand">${hand.map((t, i) => `<button class="domb ${mine && domPlayable(t, ends) ? 'ok' : ''} ${sel === i ? 'sel' : ''}" data-t="${i}">${t[0]}|${t[1]}</button>`).join('')}</div>
      ${mine && sel != null ? '<div class="row"><button class="btn sec" style="flex:1" data-side="L">⬅️ Left</button><button class="btn sec" style="flex:1" data-side="R">Right ➡️</button></div>' : ''}
      ${mine && !can && s.stock.length ? '<button class="btn full" id="dw">📦 Stock se uthao</button>' : ''}
      ${mine && !can && !s.stock.length ? '<button class="btn full" id="ps">⏭ Pass</button>' : ''}`;
    if (!mine) return;
    bindAll(el, '[data-t]', b => {
      const i = +b.dataset.t, t = hand[i];
      if (!domPlayable(t, ends)) return;
      if (!ends) return send({ a: 'play', t: i, side: 'R' });
      const r = t[0] === ends[1] || t[1] === ends[1], l = t[0] === ends[0] || t[1] === ends[0];
      if (r && l && ends[0] !== ends[1]) { el.__sel = i; G_DOM.render(el, s, seat, send); } else send({ a: 'play', t: i, side: r ? 'R' : 'L' });
    });
    bindAll(el, '[data-side]', b => { const i = el.__sel; el.__sel = null; send({ a: 'play', t: i, side: b.dataset.side }); });
    const dw = $('#dw', el); if (dw) dw.onclick = () => send({ a: 'draw' });
    const ps = $('#ps', el); if (ps) ps.onclick = () => send({ a: 'pass' });
  }
};

/* ---------- Backgammon ---------- */
const bgCnt = (s, seat, i) => seat === 0 ? Math.max(0, s.pts[i]) : Math.max(0, -s.pts[i]);
const bgTarget = (seat, from, die) => from === 'bar' ? (seat === 0 ? 24 - die : die - 1) : from + (seat === 0 ? -die : die);
function bgAllHome(s, seat) { if (s.bar[seat]) return false; for (let i = 0; i < 24; i++) if (bgCnt(s, seat, i) && !(seat === 0 ? i <= 5 : i >= 18)) return false; return true; }
function bgMoves(s, seat) {
  const out = [];
  for (const die of [...new Set(s.d)]) {
    if (s.bar[seat] > 0) { const t = bgTarget(seat, 'bar', die); if (bgCnt(s, 1 - seat, t) < 2) out.push({ from: 'bar', die, to: t }); continue; }
    for (let i = 0; i < 24; i++) {
      if (!bgCnt(s, seat, i)) continue;
      const t = bgTarget(seat, i, die);
      if (t >= 0 && t <= 23) { if (bgCnt(s, 1 - seat, t) < 2) out.push({ from: i, die, to: t }); }
      else if (bgAllHome(s, seat)) {
        const need = seat === 0 ? i + 1 : 24 - i;
        if (die === need) out.push({ from: i, die, to: 'off' });
        else if (die > need) { let far = false; for (let k = 0; k < 24; k++) if (bgCnt(s, seat, k) && (seat === 0 ? k > i : k < i)) { far = true; break; } if (!far) out.push({ from: i, die, to: 'off' }); }
      }
    }
  }
  return out;
}
function bgRoll(s) { const a = 1 + rnd(6), b = 1 + rnd(6); s.rolled = [a, b]; s.d = a === b ? [a, a, a, a] : [a, b]; s.rc = (s.rc | 0) + 1; }
function bgNext(s, seat) {
  let p = 1 - seat;
  for (let k = 0; k < 30; k++) { bgRoll(s); s.turn = p; if (bgMoves(s, p).length) return; p = 1 - p; }
}
const G_BG = {
  id: 'bg', name: 'Backgammon', icon: '⚀', sym: ['🔴', '🔵'], desc: 'Dice se checker ghar tak le jao aur bahar nikalo.',
  init() {
    const pts = Array(24).fill(0);
    pts[23] = 2; pts[12] = 5; pts[7] = 3; pts[5] = 5; pts[0] = -2; pts[11] = -5; pts[16] = -3; pts[18] = -5;
    const s = { pts, bar: [0, 0], off: [0, 0], d: [], rolled: null, turn: 0, winner: null };
    bgRoll(s); return s;
  },
  status: (s, seat) => s.turn !== seat ? '⏳ Partner’s turn' : '👉 Choose a checker, then a spot',
  move(s, m, seat) {
    const ok = bgMoves(s, seat).find(x => x.from === m.from && x.die === m.die);
    if (!ok) return null;
    if (m.from === 'bar') s.bar[seat]--; else s.pts[m.from] += seat === 0 ? -1 : 1;
    if (ok.to === 'off') s.off[seat]++;
    else { if (bgCnt(s, 1 - seat, ok.to) === 1) { s.pts[ok.to] = 0; s.bar[1 - seat]++; } s.pts[ok.to] += seat === 0 ? 1 : -1; }
    s.d.splice(s.d.indexOf(m.die), 1);
    if (s.off[seat] >= 15) { s.winner = seat; return s; }
    if (!s.d.length || !bgMoves(s, seat).length) bgNext(s, seat);
    return s;
  },
  bot(s, seat) {
    let best = null, bs = -1e9;
    for (const m of bgMoves(s, seat)) {
      let v = Math.random();
      if (m.to === 'off') v += 8;
      else { if (bgCnt(s, 1 - seat, m.to) === 1) v += 6; if (bgCnt(s, seat, m.to) >= 1) v += 3; if (bgCnt(s, seat, m.to) === 0 && bgCnt(s, 1 - seat, m.to) === 0) v -= 1; }
      if (m.from === 'bar') v += 20; else if (bgCnt(s, seat, m.from) === 1) v -= 0.5;
      v += m.die * 0.2;
      if (v > bs) { bs = v; best = { from: m.from, die: m.die }; }
    }
    return best;
  },
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null, mv = mine ? bgMoves(s, seat) : [];
    let sel = el.__sel; if (sel != null && !mv.some(m => m.from === sel)) sel = el.__sel = null;
    const dests = sel != null ? mv.filter(m => m.from === sel) : [];
    const froms = new Set(mv.map(m => m.from));
    const cell = i => { const n = s.pts[i], c = Math.abs(n), who = n > 0 ? 0 : 1; const isD = dests.some(m => m.to === i); return `<button class="cell ${froms.has(i) ? 'opt' : ''} ${sel === i ? 'sel' : ''} ${isD ? 'sel' : ''}" style="font-size:12px;aspect-ratio:auto;height:54px;${(i % 2) ? 'background:#3b2358' : 'background:#523375'}" data-p="${i}">${c ? `<span class="p${who}">●${c > 1 ? c : ''}</span>` : ''}</button>`; };
    const top = [], bot = []; for (let i = 12; i < 24; i++) top.push(cell(i)); for (let i = 11; i >= 0; i--) bot.push(cell(i));
    const dice = s.d.length ? s.d.map(d => `<span class="die" style="display:inline-flex;width:38px;height:38px;font-size:22px">${PIPS[d - 1]}</span>`).join(' ') : '';
    el.innerHTML = `<div class="mut" style="text-align:center">🔴 off ${s.off[0]} • bar ${s.bar[0]} &nbsp; | &nbsp; 🔵 off ${s.off[1]} • bar ${s.bar[1]}</div>
      <div class="board" style="grid-template-columns:repeat(12,1fr);max-width:380px;gap:1px">${top.join('')}${bot.join('')}</div>
      <div style="text-align:center;margin:6px 0">${dice}</div>
      ${mine && s.bar[seat] ? `<button class="btn ${sel === 'bar' ? '' : 'sec'} full" data-bar="1">🚧 Bar se checker nikalo</button>` : ''}
      ${dests.some(m => m.to === 'off') ? '<button class="btn full" id="off">🏁 Bahar nikalo (Bear off)</button>' : ''}`;
    if (!mine) return;
    bindAll(el, '[data-p]', b => {
      const i = +b.dataset.p;
      const d = dests.find(m => m.to === i);
      if (d) { el.__sel = null; return send({ from: d.from, die: d.die }); }
      if (!s.bar[seat] && froms.has(i)) { el.__sel = i; G_BG.render(el, s, seat, send); }
    });
    const bb = $('[data-bar]', el); if (bb) bb.onclick = () => { const ds = mv.filter(m => m.from === 'bar'); if (ds.length === 1) send({ from: 'bar', die: ds[0].die }); else { el.__sel = 'bar'; G_BG.render(el, s, seat, send); } };
    const of = $('#off', el); if (of) of.onclick = () => { const d = dests.find(m => m.to === 'off'); el.__sel = null; send({ from: d.from, die: d.die }); };
  }
};
/* bar entry with 2 dice: tapping a destination cell works because dests include bar moves */

/* ---------- Sea Battle ---------- */
const SEA_N = 8, SEA_SHIPS = [4, 3, 3, 2, 2];
function seaPlace() {
  const g = Array(SEA_N * SEA_N).fill(-1);
  SEA_SHIPS.forEach((len, id) => {
    for (let tries = 0; tries < 500; tries++) {
      const h = Math.random() < 0.5, r = rnd(SEA_N - (h ? 0 : len - 1)), c = rnd(SEA_N - (h ? len - 1 : 0));
      const cells = Array.from({ length: len }, (_, k) => (h ? r * SEA_N + c + k : (r + k) * SEA_N + c));
      if (cells.every(i => g[i] < 0)) { cells.forEach(i => g[i] = id); break; }
    }
  });
  return g;
}
const seaSunk = (ships, sh, id) => ships.every((v, i) => v !== id || sh[i] === 2);
const G_SEA = {
  id: 'sea', name: 'Sea Battle', icon: '🚢', sym: ['🔴', '🔵'], desc: 'Find and sink the enemy ships. A hit gives you another shot!',
  init: () => ({ ships: [seaPlace(), seaPlace()], sh: [Array(64).fill(0), Array(64).fill(0)], turn: 0, winner: null }),
  move(s, m, seat) {
    const t = 1 - seat; if (s.sh[t][m.i]) return null;
    const hit = s.ships[t][m.i] >= 0; s.sh[t][m.i] = hit ? 2 : 1;
    if (s.ships[t].every((v, i) => v < 0 || s.sh[t][i] === 2)) s.winner = seat; else if (!hit) s.turn = t;
    return s;
  },
  bot(s, seat) {
    const t = 1 - seat, sh = s.sh[t], free = sh.map((v, i) => v === 0 ? i : -1).filter(i => i >= 0);
    const near = [];
    sh.forEach((v, i) => { if (v === 2 && !seaSunk(s.ships[t], sh, s.ships[t][i])) [[0, 1], [0, -1], [1, 0], [-1, 0]].forEach(([dr, dc]) => { const r = (i / SEA_N | 0) + dr, c = i % SEA_N + dc; if (r >= 0 && r < SEA_N && c >= 0 && c < SEA_N && sh[r * SEA_N + c] === 0) near.push(r * SEA_N + c); }); });
    if (near.length) return { i: pick(near) };
    const par = free.filter(i => ((i / SEA_N | 0) + i % SEA_N) % 2 === 0);
    return { i: pick(par.length ? par : free) };
  },
  render(el, s, seat, send) {
    const t = 1 - seat, mine = s.turn === seat && s.winner == null;
    const tc = i => { const v = s.sh[t][i], id = s.ships[t][i], rev = v === 2 && seaSunk(s.ships[t], s.sh[t], id); return `<button class="cell" style="font-size:16px;${v === 0 ? '' : 'opacity:.85'}" data-i="${i}">${v === 2 ? (rev ? '🔥' : '💥') : v === 1 ? '•' : ''}</button>`; };
    const oc = i => { const v = s.sh[seat][i], sh = s.ships[seat][i] >= 0; return `<div class="cell" style="font-size:9px;border-radius:3px;${sh ? 'background:#2e6fb7' : ''}">${v === 2 ? '💥' : v === 1 ? '•' : ''}</div>`; };
    el.innerHTML = `<div class="mut" style="text-align:center">🎯 Enemy sea (tap to fire)</div>
      <div class="board" style="grid-template-columns:repeat(8,1fr);max-width:320px;gap:2px">${Array.from({ length: 64 }, (_, i) => tc(i)).join('')}</div>
      <div class="mut" style="text-align:center">🚢 Aapka samundar</div>
      <div class="board" style="grid-template-columns:repeat(8,1fr);max-width:170px;gap:1px">${Array.from({ length: 64 }, (_, i) => oc(i)).join('')}</div>`;
    if (mine) bindAll(el, '[data-i]', b => send({ i: +b.dataset.i }));
  }
};

/* ---------- Trap Tiles (isolation: move, then remove a tile) ---------- */
const TR_N = 7;
const trNb = (s, p) => { const r = p / TR_N | 0, c = p % TR_N, o = []; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { if (!dr && !dc) continue; const rr = r + dr, cc = c + dc; if (rr < 0 || rr >= TR_N || cc < 0 || cc >= TR_N) continue; const q = rr * TR_N + cc; if (!s.gone[q] && q !== s.pos[0] && q !== s.pos[1]) o.push(q); } return o; };
const G_TRAP = {
  id: 'trap', name: 'Trap Tiles', icon: '🧩', sym: ['🔴', '🔵'], desc: 'Ek kadam chalo, phir ek tile hata do. Partner ko fasa do!',
  init: () => ({ pos: [45, 3], gone: Array(49).fill(0), phase: 'mv', turn: 0, winner: null }),
  status: (s, seat) => s.turn !== seat ? '⏳ Partner’s turn' : (s.phase === 'mv' ? '👟 Ek kadam chalo' : '🕳 Ek tile hata do'),
  move(s, m, seat) {
    if (m.a === 'mv') { if (s.phase !== 'mv' || !trNb(s, s.pos[seat]).includes(m.i)) return null; s.pos[seat] = m.i; s.phase = 'rm'; return s; }
    if (m.a === 'rm') {
      if (s.phase !== 'rm' || s.gone[m.i] || m.i === s.pos[0] || m.i === s.pos[1]) return null;
      s.gone[m.i] = 1; s.phase = 'mv'; s.turn = 1 - seat;
      if (!trNb(s, s.pos[s.turn]).length) s.winner = seat;
      return s;
    }
    return null;
  },
  bot(s, seat) {
    if (s.phase === 'mv') {
      let best = null, bs = -1e9;
      for (const q of trNb(s, s.pos[seat])) { const t = clone(s); t.pos[seat] = q; const v = trNb(t, q).length - 1.5 * trNb(t, t.pos[1 - seat]).length + Math.random(); if (v > bs) { bs = v; best = q; } }
      return { a: 'mv', i: best };
    }
    const cand = []; for (let i = 0; i < 49; i++) if (!s.gone[i] && i !== s.pos[0] && i !== s.pos[1]) cand.push(i);
    let best = null, bs = -1e9;
    for (const q of cand) { const t = clone(s); t.gone[q] = 1; const v = -trNb(t, t.pos[1 - seat]).length * 2 + trNb(t, t.pos[seat]).length * 0.5 + Math.random(); if (v > bs) { bs = v; best = q; } }
    return { a: 'rm', i: best };
  },
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null, opts = mine && s.phase === 'mv' ? trNb(s, s.pos[seat]) : [];
    el.innerHTML = `<div class="board" style="grid-template-columns:repeat(7,1fr);max-width:340px">${Array.from({ length: 49 }, (_, i) => {
      const g = s.gone[i], p = s.pos.indexOf(i);
      return `<button class="cell ${opts.includes(i) ? 'opt' : ''}" style="${g ? 'background:#0a0510;opacity:.4' : ''}" data-i="${i}">${p >= 0 ? `<span class="disc p${p}"></span>` : ''}</button>`;
    }).join('')}</div>`;
    if (mine) bindAll(el, '[data-i]', b => { const i = +b.dataset.i; send(s.phase === 'mv' ? { a: 'mv', i } : { a: 'rm', i }); });
  }
};

/* ---------- Bank Run (push your luck dice, first to 100) ---------- */
const G_BANK = {
  id: 'bank', name: 'Bank Run', icon: '💰', sym: ['🔴', '🔵'], desc: 'Roll the dice and build your pot. Roll a 1 and lose it all! Bank it and reach 100.',
  init: () => ({ tot: [0, 0], pot: 0, last: null, turn: 0, winner: null }),
  move(s, m, seat) {
    if (m.a === 'roll') { const r = 1 + rnd(6); s.last = r; if (r === 1) { s.pot = 0; s.turn = 1 - seat; } else s.pot += r; return s; }
    if (m.a === 'bank') { if (!s.pot) return null; s.tot[seat] += s.pot; s.pot = 0; s.last = null; if (s.tot[seat] >= 100) s.winner = seat; else s.turn = 1 - seat; return s; }
    return null;
  },
  bot: (s, seat) => (s.pot >= 15 || (s.pot > 0 && s.tot[seat] + s.pot >= 100) || (s.pot >= 9 && s.tot[1 - seat] > s.tot[seat] + 25 === false && s.pot >= 12)) ? { a: 'bank' } : { a: 'roll' },
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null;
    el.innerHTML = scoreBar('💰 ' + s.tot[0], '💰 ' + s.tot[1], 'Target 100') + `<div class="dare">${s.last ? PIPS[s.last - 1] : '🎲'}<br><small class="mut">This turn’s pot</small><br><b>${s.pot}</b></div>
      ${mine ? `<button class="btn full" id="rl">🎲 Roll the dice</button><button class="btn sec full" id="bk" ${s.pot ? '' : 'disabled'}>🏦 Bank it (${s.pot})</button>` : ''}`;
    if (mine) { $('#rl', el).onclick = () => send({ a: 'roll' }); $('#bk', el).onclick = () => send({ a: 'bank' }); }
  }
};

/* ---------- Battle Bots (attack > charge > block > attack) ---------- */
const BOT_ACT = ['⚔️ Attack', '🛡 Block', '⚡ Charge'];
const G_BOT = {
  id: 'bots', name: 'Battle Bots', icon: '🤖', simul: true, sym: ['🔴', '🔵'], desc: 'Pick Attack, Block or Charge. Attack beats Charge, Charge beats Block, Block beats Attack.',
  init: () => ({ hp: [10, 10], pick: [null, null], last: null, round: 1, turn: 0, winner: null }),
  status: (s, seat) => s.winner != null ? '' : (s.pick[seat] == null ? '👉 Pick your move' : '⏳ Waiting for partner'),
  move(s, m, seat) {
    if (m.a !== 'pick' || s.pick[seat] != null || ![0, 1, 2].includes(m.k)) return null;
    s.pick[seat] = m.k;
    if (s.pick[0] != null && s.pick[1] != null) {
      const [a, b] = s.pick, d = [0, 0];
      if (a === b) { if (a === 0) { d[0] = 1; d[1] = 1; } }
      else {
        const beats = (x, y) => (x === 0 && y === 2) || (x === 2 && y === 1) || (x === 1 && y === 0);
        const w = beats(a, b) ? 0 : 1, l = 1 - w, wp = w === 0 ? a : b;
        d[l] = wp === 1 ? 1 : 2;
      }
      s.hp[0] = Math.max(0, s.hp[0] - d[0]); s.hp[1] = Math.max(0, s.hp[1] - d[1]);
      s.last = { p: [a, b], d }; s.pick = [null, null]; s.round++;
      if (s.hp[0] <= 0 || s.hp[1] <= 0 || s.round > 25) s.winner = winBy(s.hp[0], s.hp[1]);
    }
    return s;
  },
  bot: (s, seat) => s.pick[seat] == null && s.winner == null ? { a: 'pick', k: rnd(3) } : null,
  render(el, s, seat, send) {
    const bar = h => '█'.repeat(h) + '░'.repeat(10 - h);
    el.innerHTML = `<div class="scorebar"><div class="p0">🤖 ${s.hp[0]}<br><small>${bar(s.hp[0])}</small></div><div class="p1">🤖 ${s.hp[1]}<br><small>${bar(s.hp[1])}</small></div></div>
      ${s.last ? `<div class="card" style="text-align:center">${BOT_ACT[s.last.p[0]]} vs ${BOT_ACT[s.last.p[1]]}<br><small class="mut">Damage: ${s.last.d[0]} / ${s.last.d[1]}</small></div>` : ''}
      ${s.winner == null ? BOT_ACT.map((n, k) => `<button class="opt-btn ${s.pick[seat] === k ? 'pick' : ''}" data-k="${k}">${n}</button>`).join('') : ''}`;
    bindAll(el, '[data-k]', b => send({ a: 'pick', k: +b.dataset.k }));
  }
};

/* ---------- Table Soccer (penalty shoot-out, 5 shots each) ---------- */
const TS_DIR = ['⬅️ Left', '⏺ Centre', 'Right ➡️'];
const G_TSOC = {
  id: 'tsoc', name: 'Table Soccer', icon: '⚽', simul: true, sym: ['🔴', '🔵'], desc: 'Shoot or save. Both pick at the same time!',
  init: () => ({ r: 0, pick: [null, null], sc: [0, 0], last: null, turn: 0, winner: null }),
  status: (s, seat) => s.winner != null ? '' : (s.pick[seat] != null ? '⏳ Waiting for partner' : (s.r % 2 === seat ? '🥅 You are shooting. Pick a direction' : '🧤 You are the goalkeeper. Pick a direction')),
  move(s, m, seat) {
    if (m.a !== 'pick' || s.pick[seat] != null || ![0, 1, 2].includes(m.k)) return null;
    s.pick[seat] = m.k;
    if (s.pick[0] != null && s.pick[1] != null) {
      const att = s.r % 2, goal = s.pick[att] !== s.pick[1 - att];
      if (goal) s.sc[att]++;
      s.last = { att, shot: s.pick[att], keep: s.pick[1 - att], goal }; s.pick = [null, null]; s.r++;
      if (s.r >= 10) s.winner = winBy(s.sc[0], s.sc[1]);
    }
    return s;
  },
  bot: (s, seat) => s.pick[seat] == null && s.winner == null ? { a: 'pick', k: rnd(3) } : null,
  render(el, s, seat, send) {
    const att = s.r % 2 === seat;
    el.innerHTML = scoreBar(s.sc[0], s.sc[1], `Round ${Math.min(s.r + 1, 10)}/10`) +
      (s.last ? `<div class="card" style="text-align:center">${s.last.goal ? '⚽🥅 GOAL!' : '🧤 SAVE!'}<br><small class="mut">Shot ${TS_DIR[s.last.shot]} • Keeper ${TS_DIR[s.last.keep]}</small></div>` : '') +
      (s.winner == null ? `<div class="mut" style="text-align:center">${att ? 'Aap shoot kar rahe ho' : 'Aap goalkeeper ho'}</div>` + TS_DIR.map((n, k) => `<button class="opt-btn ${s.pick[seat] === k ? 'pick' : ''}" data-k="${k}">${n}</button>`).join('') : '');
    bindAll(el, '[data-k]', b => send({ a: 'pick', k: +b.dataset.k }));
  }
};
