/* Playmates - Wave 3 (part 1): Plox, Bloko (Blokus style), Disc-o (Plinko), Bounce (platformer) */

function shade(hex, k) { const n = parseInt(hex.slice(1), 16), f = v => Math.max(0, Math.min(255, Math.round(v + (k > 0 ? (255 - v) * k : v * k)))); return `rgb(${f(n >> 16)},${f((n >> 8) & 255)},${f(n & 255)})`; }
function tile(c, x, y, s, col, a) {
  c.save(); if (a != null) c.globalAlpha = a;
  const g = c.createLinearGradient(x, y, x, y + s); g.addColorStop(0, shade(col, .35)); g.addColorStop(.5, col); g.addColorStop(1, shade(col, -.3));
  c.fillStyle = shade(col, -.5); rr(c, x + 1, y + 2.5, s - 2, s - 2, s * .2); c.fill();
  c.fillStyle = g; rr(c, x + 1, y + 1, s - 2, s - 3, s * .2); c.fill();
  c.fillStyle = '#ffffff55'; rr(c, x + s * .14, y + s * .1, s * .72, s * .28, s * .12); c.fill();
  c.restore();
}

/* ---------- Tetris-style shapes for Plox ---------- */
const PLX = [
  ['I', [[1, 1, 1, 1]]], ['I', [[1], [1], [1], [1]]], ['O', [[1, 1], [1, 1]]],
  ['T', [[1, 1, 1], [0, 1, 0]]], ['T', [[0, 1], [1, 1], [0, 1]]], ['T', [[0, 1, 0], [1, 1, 1]]], ['T', [[1, 0], [1, 1], [1, 0]]],
  ['S', [[0, 1, 1], [1, 1, 0]]], ['S', [[1, 0], [1, 1], [0, 1]]], ['Z', [[1, 1, 0], [0, 1, 1]]], ['Z', [[0, 1], [1, 1], [1, 0]]],
  ['L', [[1, 0], [1, 0], [1, 1]]], ['L', [[1, 1, 1], [1, 0, 0]]], ['L', [[1, 1], [0, 1], [0, 1]]], ['L', [[0, 0, 1], [1, 1, 1]]],
  ['J', [[0, 1], [0, 1], [1, 1]]], ['J', [[1, 0, 0], [1, 1, 1]]], ['J', [[1, 1], [1, 0], [1, 0]]], ['J', [[1, 1, 1], [0, 0, 1]]],
  ['D', [[1]]], ['D', [[1, 1]]], ['D', [[1], [1]]], ['D', [[1, 1, 1]]], ['D', [[1], [1], [1]]], ['W', [[1, 1, 1, 1, 1]]], ['W', [[1], [1], [1], [1], [1]]], ['O', [[1, 1, 1], [1, 1, 1], [1, 1, 1]]]
];
const PLX_COL = { I: '#22d3ee', O: '#ffd54a', T: '#a259ff', S: '#3ddc97', Z: '#ff4d5a', L: '#ff8a3d', J: '#4a7dff', D: '#ff6fb5', W: '#7cf06a' };

/* generic drag-and-drop block board used by Plox (solo duel); shapes come from o.shapes */
function blockUI(box, o) {
  const { cv, c } = arena(box, 360, 560), N = o.N, CS = Math.floor(320 / N), BX = 20, BY = 80, BW = CS * N, SH = o.shapes;
  let drag = null, fx = [], t = 0, pops = popups(), sparks = [];
  const slot = i => ({ x: 14 + i * 114, y: 430, w: 108, h: 112 });
  const sizeOf = (p, cs) => ({ w: p[0].length * cs, h: p.length * cs });
  const anchor = () => { const p = SH[o.tray()[drag.i].k][1], sz = sizeOf(p, CS), tx_ = drag.x - sz.w / 2, ty = drag.y - 70 - sz.h / 2; return { r: Math.round((ty - BY) / CS), c: Math.round((tx_ - BX) / CS), tx: tx_, ty }; };
  cv.addEventListener('pointerdown', e => {
    e.preventDefault(); if (!o.canPlay()) return; const p = ptr(cv, e), tr = o.tray();
    for (let i = 0; i < 3; i++) { const s = slot(i); if (tr[i] && p.x > s.x && p.x < s.x + s.w && p.y > s.y - 10 && p.y < s.y + s.h + 10) { drag = { i, x: p.x, y: p.y }; try { cv.setPointerCapture(e.pointerId); } catch (x) {} return; } }
  });
  cv.addEventListener('pointermove', e => { if (drag) { const p = ptr(cv, e); drag.x = p.x; drag.y = p.y; } });
  cv.addEventListener('pointerup', () => { if (!drag) return; const a = anchor(), p = SH[o.tray()[drag.i].k][1]; if (pFits(o.grid(), N, p, a.r, a.c)) { const n0 = fx.length; o.place(drag.i, a.r, a.c, fx); SFX.play(fx.length > n0 ? 'clear' : 'place'); for (let k = 0; k < 6; k++) sparks.push({ x: a.tx + 40, y: a.ty + 40, vx: (Math.random() - .5) * 220, vy: -Math.random() * 160, age: 0 }); } else if (a.r > -3) SFX.play('bad'); drag = null; });
  cv.addEventListener('pointercancel', () => { drag = null; });
  const stop = anim(dt => {
    t += dt; const g = o.grid(), tr = o.tray();
    const bgc = c.createLinearGradient(0, 0, 0, 560); bgc.addColorStop(0, '#102a52'); bgc.addColorStop(1, '#081433'); c.fillStyle = bgc; c.fillRect(0, 0, 360, 560);
    o.hud(c, t);
    c.fillStyle = '#0a1330'; rr(c, BX - 8, BY - 8, BW + 16, BW + 16, 14); c.fill(); c.strokeStyle = '#3aa0ff77'; c.lineWidth = 3; c.stroke();
    for (let r = 0; r < N; r++) for (let q = 0; q < N; q++) { c.fillStyle = (r + q) % 2 ? '#14234a' : '#182a58'; rr(c, BX + q * CS + 1, BY + r * CS + 1, CS - 2, CS - 2, 4); c.fill(); }
    for (let r = 0; r < N; r++) for (let q = 0; q < N; q++) { const v = g[r * N + q]; if (v) tile(c, BX + q * CS, BY + r * CS, CS, v); }
    if (drag) {
      const a = anchor(), p = SH[tr[drag.i].k][1], ok = pFits(g, N, p, a.r, a.c);
      if (ok) { p.forEach((row, i) => row.forEach((v, j) => { if (v) { c.fillStyle = '#ffffff30'; rr(c, BX + (a.c + j) * CS + 1, BY + (a.r + i) * CS + 1, CS - 2, CS - 2, 5); c.fill(); } })); const tg = g.slice(); p.forEach((row, i) => row.forEach((v, j) => { if (v) tg[(a.r + i) * N + a.c + j] = 1; })); for (let r = 0; r < N; r++) if (Array.from({ length: N }, (_, q) => tg[r * N + q]).every(Boolean)) { c.fillStyle = '#ffd54a44'; c.fillRect(BX, BY + r * CS, BW, CS); } for (let q = 0; q < N; q++) if (Array.from({ length: N }, (_, r) => tg[r * N + q]).every(Boolean)) { c.fillStyle = '#ffd54a44'; c.fillRect(BX + q * CS, BY, CS, BW); } }
    }
    fx = fx.filter(f => (f.age += dt) < .55); fx.forEach(f => { c.globalAlpha = 1 - f.age / .55; c.fillStyle = '#fff'; const s = CS * (1 + f.age * .8); c.fillRect(BX + f.q * CS + CS / 2 - s / 2, BY + f.r * CS + CS / 2 - s / 2, s, s); c.globalAlpha = 1; });
    sparks = sparks.filter(q => (q.age += dt) < .6); sparks.forEach(q => { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 500 * dt; c.globalAlpha = 1 - q.age / .6; c.fillStyle = '#ffd54a'; c.fillRect(q.x, q.y, 5, 5); c.globalAlpha = 1; });
    fx.forEach((f, i) => { if (f.age < .5) for (let k = 0; k < 2; k++) { const an = (i * 2.4 + k * 3.1), d = f.age * 90; c.globalAlpha = 1 - f.age / .5; c.fillStyle = k ? '#fff' : '#ff9ae0'; c.fillRect(BX + f.q * CS + CS / 2 + Math.cos(an) * d, BY + f.r * CS + CS / 2 + Math.sin(an) * d, 4, 4); c.globalAlpha = 1; } });
    tx(c, 'NEXT', 40, 418, 12, '#8fb4ff', 'center');
    for (let i = 0; i < 3; i++) {
      const s = slot(i); c.fillStyle = '#0a1330'; rr(c, s.x, s.y, s.w, s.h, 14); c.fill(); c.strokeStyle = (drag && drag.i === i) ? '#ffd54a' : '#3a5acc66'; c.lineWidth = 2; c.stroke();
      const it = tr[i]; if (!it) continue; const p = SH[it.k][1], cs = Math.min(26, 84 / Math.max(p.length, p[0].length)), sz = sizeOf(p, cs), ox = s.x + (s.w - sz.w) / 2, oy = s.y + (s.h - sz.h) / 2;
      const fits = o.canPlay() && pAnyFit(g, N, p); p.forEach((row, a) => row.forEach((v, b) => { if (v) tile(c, ox + b * cs, oy + a * cs, cs, o.colorOf(it.k), (drag && drag.i === i) ? .25 : (fits ? 1 : .4)); }));
    }
    if (drag) { const a = anchor(), p = SH[tr[drag.i].k][1]; p.forEach((row, i) => row.forEach((v, j) => { if (v) tile(c, a.tx + j * CS, a.ty + i * CS, CS, o.colorOf(tr[drag.i].k), .92); })); }
    pops.draw(c, dt);
  });
  return { stop, pops, cv };
}
const lineFlash = (g, N, fx) => { for (let r = 0; r < N; r++) if (Array.from({ length: N }, (_, c) => g[r * N + c]).every(Boolean)) for (let c = 0; c < N; c++) fx.push({ r, q: c, age: 0 }); for (let c = 0; c < N; c++) if (Array.from({ length: N }, (_, r) => g[r * N + c]).every(Boolean)) for (let r = 0; r < N; r++) fx.push({ r, q: c, age: 0 }); };

/* ================= PLOX ================= */
const G_PLOX2 = duel({
  id: 'plox', name: 'Plox', icon: '🧱', desc: 'Drag block shapes onto the grid. Fill full rows or columns to clear them. Combos score big!',
  bot: () => 220 + Math.floor(Math.random() * 360),
  play(box, seed, done) {
    const R = rng(seed), N = 10; let g = new Array(N * N).fill(0), score = 0, lines = 0, tray = [], over = false, combo = 0, msg = 'Drag a block onto the grid';
    const nt = () => { tray = [0, 1, 2].map(() => ({ k: Math.floor(R() * PLX.length) })); }; nt();
    const ui = blockUI(box, {
      N, shapes: PLX, grid: () => g, tray: () => tray, canPlay: () => !over, colorOf: k => PLX_COL[PLX[k][0]],
      place(i, r, c, fx) {
        const it = tray[i], p = PLX[it.k][1], col = PLX_COL[PLX[it.k][0]]; p.forEach((row, a) => row.forEach((v, b) => { if (v) g[(r + a) * N + c + b] = col; })); score += pCells(p);
        lineFlash(g, N, fx); const n = pClear(g, N);
        if (n) { combo++; lines += n; const gain = n * 10 + (n - 1) * 15 + (combo > 1 ? combo * 5 : 0); score += gain; msg = (n > 1 ? n + ' lines! ' : 'Line! ') + (combo > 1 ? 'Combo x' + combo + ' ' : '') + '+' + gain; ui.pops.add('+' + gain, 180, 250, '#ffd54a'); } else { combo = 0; msg = '+' + pCells(p); }
        tray[i] = null; if (tray.every(x => !x)) nt();
        if (!tray.some(x => x && pAnyFit(g, N, PLX[x.k][1]))) { over = true; setTimeout(() => { ui.stop(); fin(box, score, done, 'No more moves!'); }, 900); }
      },
      hud(c) { hudTop(c, 360, score, null, (gg, w) => { tx(gg, 'LINES ' + lines, w - 56, 28, 15, '#ffd54a'); }); tx(c, msg, 180, 68, 13, '#fff', 'center', '#000a'); }
    });
    return () => { over = true; ui.stop(); };
  }
});

/* ================= BLOKO (Blokus-style territory game) ================= */
const BK_N = 14, BK_SRC = ['#', '##', '###', '#../##.', '####', '##/##', '###/.#.', '#./#./##', '##./.##', '.##/##./.#.', '#####', '#.../####', '##../.###', '##/##/#.', '###/.#./.#.', '#.#/###', '#../#../###', '#../##./.##', '.#./###/.#.', '.#../####', '##./.#./.##'];
function bkParse(str) { const rows = str.split(/[\/]/); if (str.includes('.') && !str.includes('/') && str.includes('##') && str.includes('#..')) return null; return rows.map(r => r.split('').map(ch => ch === '#' ? 1 : 0)); }
const BK_PIECES = [
  [[1]], [[1, 1]], [[1, 1, 1]], [[1, 0], [1, 1]], [[1, 1, 1, 1]], [[1, 1], [1, 1]], [[1, 1, 1], [0, 1, 0]], [[1, 0], [1, 0], [1, 1]], [[1, 1, 0], [0, 1, 1]],
  [[0, 1, 1], [1, 1, 0], [0, 1, 0]], [[1, 1, 1, 1, 1]], [[1, 0, 0, 0], [1, 1, 1, 1]], [[1, 1, 0, 0], [0, 1, 1, 1]], [[1, 1], [1, 1], [1, 0]], [[1, 1, 1], [0, 1, 0], [0, 1, 0]],
  [[1, 0, 1], [1, 1, 1]], [[1, 0, 0], [1, 0, 0], [1, 1, 1]], [[1, 0, 0], [1, 1, 0], [0, 1, 1]], [[0, 1, 0], [1, 1, 1], [0, 1, 0]], [[0, 1, 0, 0], [1, 1, 1, 1]], [[1, 1, 0], [0, 1, 0], [0, 1, 1]]
];
const bkRot = p => p[0].map((_, c) => p.map(r => r[c]).reverse()), bkFlip = p => p.map(r => r.slice().reverse());
const BK_ORI = BK_PIECES.map(p => { const seen = new Set(), out = []; let q = p; for (let f = 0; f < 2; f++) { for (let r = 0; r < 4; r++) { const k = JSON.stringify(q); if (!seen.has(k)) { seen.add(k); out.push(q); } q = bkRot(q); } q = bkFlip(q); } return out; });
const BK_SIZE = BK_PIECES.map(p => pCells(p));
const bkCells = (o, r, c) => { const out = []; o.forEach((row, i) => row.forEach((v, j) => { if (v) out.push([r + i, c + j]); })); return out; };
function bkLegal(s, seat, ori, r, c) {
  const me = seat + 1, cells = bkCells(ori, r, c), first = !s.placed[seat]; let corner = false;
  for (const [y, x] of cells) {
    if (y < 0 || x < 0 || y >= BK_N || x >= BK_N || s.g[y * BK_N + x]) return false;
    for (const [dy, dx] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && s.g[yy * BK_N + xx] === me) return false; }
    for (const [dy, dx] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && s.g[yy * BK_N + xx] === me) corner = true; }
    if (first && y === (seat ? BK_N - 1 : 0) && x === (seat ? BK_N - 1 : 0)) corner = true;
  }
  return corner;
}
function bkMoves(s, seat, limit) {
  const out = [];
  for (let p = 0; p < 21; p++) { if (s.used[seat][p]) continue; for (let o = 0; o < BK_ORI[p].length; o++) { const ori = BK_ORI[p][o]; for (let r = -ori.length + 1; r < BK_N; r++) for (let c = -ori[0].length + 1; c < BK_N; c++) if (bkLegal(s, seat, ori, r, c)) { out.push({ p, o, r, c }); if (limit && out.length >= limit) return out; } } }
  return out;
}
const bkLeft = (s, seat) => s.used[seat].reduce((a, u, p) => a + (u ? 0 : BK_SIZE[p]), 0);
const G_BLOKO2 = {
  id: 'bloko', name: 'Bloko', icon: '🟦', type: 'turn', sym: ['🟥', '🟦'], desc: 'Place pieces so they touch your own colour only at the corners. Cover the most area! Fewest leftover squares wins.',
  init: () => ({ g: new Array(BK_N * BK_N).fill(0), used: [Array(21).fill(0), Array(21).fill(0)], placed: [0, 0], turn: 0, winner: null, n: 0, msg: '' }),
  status: (s, seat) => s.winner != null ? '' : (s.turn === seat ? '👉 Pick a piece, tap the board, then Place' : '⏳ Opponent’s turn'),
  move(s, m, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    const p = m.p | 0, o = m.o | 0, r = m.r | 0, c = m.c | 0; if (p < 0 || p > 20 || s.used[seat][p] || !BK_ORI[p][o]) return null;
    const ori = BK_ORI[p][o]; if (!bkLegal(s, seat, ori, r, c)) return null;
    bkCells(ori, r, c).forEach(([y, x]) => { s.g[y * BK_N + x] = seat + 1; }); s.used[seat][p] = 1; s.placed[seat]++; s.n++; s.msg = '';
    const opp = 1 - seat;
    if (bkMoves(s, opp, 1).length) s.turn = opp; else if (bkMoves(s, seat, 1).length) { s.msg = 'Opponent has no moves'; s.turn = seat; } else { const a = bkLeft(s, 0), b = bkLeft(s, 1); s.winner = a === b ? 'draw' : (a < b ? 0 : 1); }
    return s;
  },
  bot(s, seat) {
    const all = bkMoves(s, seat); if (!all.length) return null; let best = null, bs = -1e9;
    const sample = all.length > 900 ? all.filter(() => Math.random() < 900 / all.length) : all;
    for (const m of sample) { const ori = BK_ORI[m.p][m.o], cells = bkCells(ori, m.r, m.c); let sc = BK_SIZE[m.p] * 3 + Math.random() * 2; cells.forEach(([y, x]) => { sc += (7 - Math.abs(y - 6.5) - Math.abs(x - 6.5)) * .12; for (const [dy, dx] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && !s.g[yy * BK_N + xx]) sc += .35; } const oo = 3 - (seat + 1); for (const [dy, dx] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) { const yy = y + dy, xx = x + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && s.g[yy * BK_N + xx] === oo) sc += .5; } }); if (sc > bs) { bs = sc; best = m; } }
    return best;
  },
  render(el, s, seat, send) {
    let R = el.__bk;
    if (!R || el.__sg !== s.gid) {
      if (el.__stop) try { el.__stop(); } catch (e) {} el.innerHTML = ''; el.__sg = s.gid;
      const { cv, c } = arena(el, 360, 440); const ctl = document.createElement('div'); ctl.className = 'bkctl'; el.appendChild(ctl);
      R = el.__bk = { s, seat, sel: -1, ori: 0, at: null, cv, c, ctl, t: 0, lastN: s.n };
      const cs = 25, bx = 5, by = 70, ghost = () => { if (R.sel < 0 || !R.at) return null; const o = BK_ORI[R.sel][R.ori], r = clamp(R.at.r - Math.floor(o.length / 2), 0, BK_N - o.length), cc = clamp(R.at.c - Math.floor(o[0].length / 2), 0, BK_N - o[0].length); return { o, r, c: cc, ok: bkLegal(R.s, R.seat, o, r, cc) }; };
      cv.addEventListener('pointerdown', e => { const p = ptr(cv, e), cc = Math.floor((p.x - bx) / cs), r = Math.floor((p.y - by) / cs); if (r < 0 || cc < 0 || r >= BK_N || cc >= BK_N) return; R.at = { r, c: cc }; draw(); e.preventDefault(); });
      const build = () => {
        const S = R.s, mine = S.turn === R.seat && S.winner == null; R.ctl.innerHTML = `<div class="bkstrip">${BK_PIECES.map((p, i) => S.used[R.seat][i] ? '' : `<button class="bkp ${R.sel === i ? 'sel' : ''}" data-p="${i}"><div class="mini" style="grid-template-columns:repeat(${p[0].length},1fr)">${p.map(row => row.map(v => `<i style="background:${v ? (R.seat ? '#4aa3ff' : '#ff4d8d') : 'transparent'}"></i>`).join('')).join('')}</div></button>`).join('')}</div><div class="bkbtns"><button class="btn sec" id="bkr">⟳ Rotate</button><button class="btn sec" id="bkf">⇋ Flip</button><button class="btn" id="bkok">✔ Place</button></div>`;
        bindAll(R.ctl, '[data-p]', b => { R.sel = +b.dataset.p; R.ori = 0; if (!R.at) R.at = { r: R.seat ? 9 : 4, c: R.seat ? 9 : 4 }; build(); draw(); });
        $('#bkr', R.ctl).onclick = () => { if (R.sel < 0) return; const L = BK_ORI[R.sel]; const cur = BK_ORI[R.sel][R.ori]; let q = bkRot(cur), k = L.findIndex(x => JSON.stringify(x) === JSON.stringify(q)); R.ori = k < 0 ? 0 : k; draw(); };
        $('#bkf', R.ctl).onclick = () => { if (R.sel < 0) return; const L = BK_ORI[R.sel]; const q = bkFlip(BK_ORI[R.sel][R.ori]); let k = L.findIndex(x => JSON.stringify(x) === JSON.stringify(q)); R.ori = k < 0 ? R.ori : k; draw(); };
        $('#bkok', R.ctl).onclick = () => { const gh = ghost(); if (mine && gh && gh.ok) { const p = R.sel; R.sel = -1; R.at = null; send({ p, o: R.ori, r: gh.r, c: gh.c }); } else toast(mine ? 'Pick a piece, tap the board where it should go (corner-touch only)' : 'Wait for your turn'); };
      };
      R.build = build;
      const draw = () => {
        const S = R.s, g0 = ghost(); const bgc = c.createLinearGradient(0, 0, 0, 440); bgc.addColorStop(0, '#16224a'); bgc.addColorStop(1, '#0a1230'); c.fillStyle = bgc; c.fillRect(0, 0, 360, 440);
        c.fillStyle = '#ff4d8d'; rr(c, 10, 10, 150, 44, 12); c.fill(); c.fillStyle = '#4aa3ff'; rr(c, 200, 10, 150, 44, 12); c.fill();
        [[0, 18], [1, 208]].forEach(([o, x]) => { tx(c, (o === R.seat ? 'You' : 'Opp') + ' · ' + bkLeft(S, o) + ' left', x + 66, 32, 14, '#fff', 'center', '#0006'); if (S.turn === o && S.winner == null) { c.strokeStyle = '#ffd54a'; c.lineWidth = 3; rr(c, o ? 200 : 10, 10, 150, 44, 12); c.stroke(); } });
        c.fillStyle = '#0a1230'; rr(c, bx - 3, by - 3, cs * BK_N + 6, cs * BK_N + 6, 8); c.fill();
        for (let r = 0; r < BK_N; r++) for (let q = 0; q < BK_N; q++) { const v = S.g[r * BK_N + q]; if (v) tile(c, bx + q * cs, by + r * cs, cs, v === 1 ? '#ff4d8d' : '#4aa3ff'); else { c.fillStyle = (r + q) % 2 ? '#e8eef8' : '#dce6f5'; c.fillRect(bx + q * cs + .5, by + r * cs + .5, cs - 1, cs - 1); } }
        [[0, 0], [BK_N - 1, BK_N - 1]].forEach(([r, q], o) => { if (!S.placed[o] && !S.g[r * BK_N + q]) { c.strokeStyle = o ? '#4aa3ff' : '#ff4d8d'; c.lineWidth = 3; c.strokeRect(bx + q * cs + 2, by + r * cs + 2, cs - 4, cs - 4); } });
        if (S.turn === R.seat && S.winner == null && S.placed[R.seat]) { c.fillStyle = (R.seat ? '#4aa3ff' : '#ff4d8d') + '99'; for (let r = 0; r < BK_N; r++) for (let q = 0; q < BK_N; q++) if (!S.g[r * BK_N + q]) { let ok = false; for (const [dy, dx] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { const yy = r + dy, xx = q + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && S.g[yy * BK_N + xx] === R.seat + 1) ok = true; } for (const [dy, dx] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) { const yy = r + dy, xx = q + dx; if (yy >= 0 && xx >= 0 && yy < BK_N && xx < BK_N && S.g[yy * BK_N + xx] === R.seat + 1) ok = false; } if (ok) { c.beginPath(); c.arc(bx + q * cs + cs / 2, by + r * cs + cs / 2, 3, 0, 6.283); c.fill(); } } }
        if (g0) bkCells(g0.o, g0.r, g0.c).forEach(([y, x]) => { if (y >= 0 && x >= 0 && y < BK_N && x < BK_N) { c.fillStyle = g0.ok ? '#3ddc97bb' : '#ff4d4dbb'; c.fillRect(bx + x * cs, by + y * cs, cs, cs); c.strokeStyle = '#fff'; c.lineWidth = 2; c.strokeRect(bx + x * cs + 1, by + y * cs + 1, cs - 2, cs - 2); } });
        tx(c, S.winner != null ? (S.winner === R.seat ? '🏆 You win!' : S.winner === 'draw' ? 'Draw' : 'You lose') : S.msg || (S.turn === R.seat ? 'Your turn' : 'Opponent’s turn'), 180, 428, 13, '#fff', 'center', '#000a');
      };
      R.draw = draw; R.stop = anim(() => { }); el.__stop = R.stop; build(); draw();
    }
    const changed = s.n !== R.s.n || s.turn !== R.s.turn || s.winner !== R.s.winner; R.s = s; R.seat = seat; if (changed || R.first == null) { R.first = 1; R.build(); } R.draw();
  }
};

/* ================= DISC-O (Plinko with multiplier slots) ================= */
const PK = { W: 360, H: 560, top: 92, bot: 470, r: 8, pr: 5 };
const PK_MULT = [2, 4, 8, 4, 2], PK_COL = ['#ff8a3d', '#ffd54a', '#3ddc97', '#ffd54a', '#ff8a3d'];
const pkPegs = (() => { const out = []; for (let row = 0; row < 8; row++) { const n = row % 2 ? 8 : 9, off = row % 2 ? 22 : 0; for (let i = 0; i < n; i++) out.push({ x: 36 + off + i * 44 - (row % 2 ? 0 : 0), y: 150 + row * 38 }); } return out.filter(p => p.x > 14 && p.x < 346); })();
const G_DISCO2 = duel({
  id: 'disco', name: 'Disc-o', icon: '🥏', desc: '5 discs. Drag to choose where to drop, release to let it fall. Bounce off the pegs into the x8 slot!',
  bot: () => 700 + Math.floor(Math.random() * 1500),
  play(box, seed, done) {
    const R = rng(seed), { cv, c } = arena(box, PK.W, PK.H), bonus = new Set(); while (bonus.size < 5) bonus.add(Math.floor(R() * pkPegs.length));
    const bg = off(PK.W, PK.H, (g, w, h) => {
      const bgc = g.createLinearGradient(0, 0, 0, h); bgc.addColorStop(0, '#3a1a78'); bgc.addColorStop(1, '#120a3a'); g.fillStyle = bgc; g.fillRect(0, 0, w, h);
      g.fillStyle = '#ff9a2e'; g.beginPath(); g.moveTo(0, 70); g.quadraticCurveTo(w / 2, 10, w, 70); g.lineTo(w, 90); g.quadraticCurveTo(w / 2, 36, 0, 90); g.fill();
      g.fillStyle = '#ffffff10'; for (let i = 0; i < 40; i++) { g.beginPath(); g.arc((i * 83) % w, 100 + (i * 47) % 380, 2, 0, 6.283); g.fill(); }
      g.strokeStyle = '#d66bff'; g.lineWidth = 6; g.strokeRect(3, 3, w - 6, h - 6);
      PK_MULT.forEach((m, i) => { const x0 = i * 72, col = PK_COL[i]; const gr = g.createLinearGradient(0, PK.bot, 0, PK.bot + 60); gr.addColorStop(0, shade(col, .2)); gr.addColorStop(1, shade(col, -.4)); g.fillStyle = gr; rr(g, x0 + 3, PK.bot + 4, 66, 58, 8); g.fill(); g.strokeStyle = '#fff8'; g.lineWidth = 2; g.stroke(); g.fillStyle = '#2a1050'; g.font = '900 26px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('x' + m, x0 + 36, PK.bot + 34); });
      g.fillStyle = '#ffffff30'; for (let i = 1; i < 5; i++) g.fillRect(i * 72 - 2, PK.bot - 30, 4, 34);
    });
    let n = 0, total = 0, over = false, t = 0, dropX = 180, aiming = false, disc = null, msg = 'Drag left/right, release to drop', hitB = new Set(), trail = [];
    const pops = popups();
    cv.addEventListener('pointerdown', e => { e.preventDefault(); if (over || disc) return; aiming = true; dropX = clamp(ptr(cv, e).x, 24, 336); try { cv.setPointerCapture(e.pointerId); } catch (x) {} });
    cv.addEventListener('pointermove', e => { if (aiming) dropX = clamp(ptr(cv, e).x, 24, 336); });
    cv.addEventListener('pointerup', () => { if (!aiming) return; aiming = false; if (disc || over) return; disc = { x: dropX, y: PK.top, vx: 0, vy: 0, t: 0 }; hitB = new Set(); trail = []; });
    const land = () => {
      const i = clamp(Math.floor(disc.x / 72), 0, 4), mult = PK_MULT[i], pts = mult * 100 + hitB.size * 50; total += pts; n++;
      msg = 'x' + mult + (hitB.size ? ' + ' + hitB.size + ' bonus pegs' : '') + ' = ' + pts; pops.add('+' + pts, disc.x, PK.bot - 20, '#ffd54a'); disc = null;
      if (n >= 5) { over = true; setTimeout(() => { stop(); fin(box, total, done, 'All discs dropped!'); }, 1000); }
    };
    const stop = anim(dt => {
      t += dt; if (disc) for (let k = 0; k < 4; k++) {
        const d = dt / 4, b = disc; b.vy += 900 * d; b.x += b.vx * d; b.y += b.vy * d; b.t += d;
        if (b.x < 14 + PK.r) { b.x = 14 + PK.r; b.vx = Math.abs(b.vx) * .6; } if (b.x > PK.W - 14 - PK.r) { b.x = PK.W - 14 - PK.r; b.vx = -Math.abs(b.vx) * .6; }
        pkPegs.forEach((p, i) => { const dx = b.x - p.x, dy = b.y - p.y, dd = Math.hypot(dx, dy), rr_ = PK.r + PK.pr; if (dd < rr_ && dd > 0) { const nx = dx / dd, ny = dy / dd, dot = b.vx * nx + b.vy * ny; if (dot < 0) { b.vx -= 1.62 * dot * nx; b.vy -= 1.62 * dot * ny; } b.x = p.x + nx * (rr_ + .1); b.y = p.y + ny * (rr_ + .1); if (bonus.has(i) && !hitB.has(i)) { hitB.add(i); pops.add('+50', p.x, p.y - 8, '#7fd6ff'); } } });
        if (b.y > PK.bot - 6) { b.y = PK.bot - 6; land(); break; }
      }
      if (disc) { trail.push({ x: disc.x, y: disc.y }); if (trail.length > 8) trail.shift(); }
      c.drawImage(bg, 0, 0);
      pkPegs.forEach((p, i) => { const bn = bonus.has(i), hit = hitB.has(i); c.fillStyle = bn ? (hit ? '#ffd54a' : '#4fd0ff') : '#e8e0ff'; if (bn) { c.shadowColor = '#4fd0ff'; c.shadowBlur = hit ? 4 : 12; } c.beginPath(); c.arc(p.x, p.y, PK.pr, 0, 6.283); c.fill(); c.shadowBlur = 0; });
      trail.forEach((q, i) => { c.globalAlpha = i / trail.length * .35; c.fillStyle = '#ffb02e'; c.beginPath(); c.arc(q.x, q.y, PK.r * .8, 0, 6.283); c.fill(); }); c.globalAlpha = 1;
      const dd = disc || (over ? null : { x: dropX, y: PK.top - 6 });
      if (dd) { if (aiming) { c.strokeStyle = '#ffffff55'; c.setLineDash([5, 7]); c.lineWidth = 2; c.beginPath(); c.moveTo(dd.x, PK.top); c.lineTo(dd.x, PK.bot); c.stroke(); c.setLineDash([]); } const g = c.createRadialGradient(dd.x - 3, dd.y - 3, 1, dd.x, dd.y, PK.r); g.addColorStop(0, '#fff3a0'); g.addColorStop(.6, '#ffb02e'); g.addColorStop(1, '#c26a00'); c.fillStyle = g; c.beginPath(); c.arc(dd.x, dd.y, PK.r, 0, 6.283); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 1.5; c.stroke(); }
      hudTop(c, PK.W, total, null, (g, w) => { for (let i = 0; i < 5; i++) { g.fillStyle = i < 5 - n ? '#ffb02e' : '#ffffff22'; g.beginPath(); g.arc(w - 120 + i * 24, 28, 8, 0, 6.283); g.fill(); } });
      tx(c, msg, 180, 78, 13, '#fff', 'center', '#000a'); pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});

/* ================= BOUNCE (side-scrolling platformer) ================= */
const BN = { W: 360, H: 560, L: 4600, G: 1500, R: 16 };
function bnLevel(seed) {
  const R = rng(seed), plats = [{ x: -60, w: 520, y: 400, spikes: [] }], rings = [], spikes = []; let x = 460, y = 400;
  while (x < BN.L - 600) {
    const gap = 70 + R() * 80, w = 150 + R() * 230, ny = clamp(y + (R() - .5) * 120, 300, 430); x += gap;
    if (gap > 100 && R() < .6) plats.push({ x: x - gap / 2 - 35, w: 70, y: Math.min(y, ny) - 70, float: true });
    plats.push({ x, w, y: ny }); if (w > 190 && R() < .7) spikes.push({ x: x + 70 + R() * (w - 160), y: ny });
    const cnt = 3 + Math.floor(R() * 3); for (let k = 0; k < cnt; k++) rings.push({ x: x - gap + (gap + w) * (k / cnt) + 20, y: Math.min(y, ny) - 70 - Math.sin(k / cnt * Math.PI) * 60 });
    x += w; y = ny;
  }
  plats.push({ x: x + 90, w: 420, y: 400, end: true });
  return { plats, rings, spikes, endX: x + 330 };
}
const G_BOUNCE2 = duel({
  id: 'bounce', name: 'Bounce', icon: '🏐', desc: 'Roll the rubber ball across the world! ◀ ▶ to move, ▲ to jump. Collect rings, stomp enemies, bounce on springs, avoid spikes and water, and reach the flag.',
  bot: () => 380 + Math.floor(Math.random() * 520),
  play(box, seed, done) {
    const { cv, c } = arena(box, 360, 520), R = rng(seed + 5), pops = popups(), GY = 380, r = 14;
    const segs = [{ x: -300, y: GY, w: 700, h: 200 }], plats = [], spikes = [], springs = [], rings = [], foes = [], cps = [60];
    let x = 400, flagX = 0;
    for (let k = 0; k < 9; k++) {
      const gap = 70 + R() * 40, L = 280 + R() * 160, x0 = x + gap, f = k === 8 ? 9 : Math.floor(R() * 4);
      segs.push({ x: x0, y: GY, w: L, h: 200 }); cps.push(x0 + 30);
      for (let i = 0; i < 3; i++) rings.push({ x: x + gap * (i + 1) / 4, y: GY - 50 - Math.sin((i + 1) / 4 * Math.PI) * 50 });
      if (f === 0) { spikes.push({ x: x0 + L * .5, y: GY - 14, w: 30, h: 14 }); rings.push({ x: x0 + L * .5 + 15, y: GY - 85 }); }
      else if (f === 1) { plats.push({ x: x0 + L * .3, y: GY - 90, w: 90, h: 14 }); rings.push({ x: x0 + L * .3 + 30, y: GY - 120 }, { x: x0 + L * .3 + 60, y: GY - 120 }); }
      else if (f === 2) { springs.push({ x: x0 + L * .4, y: GY - 12, w: 30, h: 12, t: 0 }); plats.push({ x: x0 + L * .4 + 50, y: GY - 200, w: 90, h: 14 }); rings.push({ x: x0 + L * .4 + 95, y: GY - 232 }); }
      else if (f === 3) { foes.push({ x: x0 + 60, y: GY - 11, x0: x0 + 40, x1: x0 + L - 40, d: 1, alive: true }); rings.push({ x: x0 + L * .6, y: GY - 60 }); }
      x = x0 + L; if (k === 8) flagX = x - 70;
    }
    const ball = { x: 60, y: GY - r - 2, vx: 0, vy: 0, a: 0 }, keys = { l: 0, r: 0, j: 0 }, ptrs = {};
    let lives = 3, time = 75, nr = 0, stomps = 0, over = false, inv = 0, sq = 0, coy = 0, cam = 0, cpx = 60, grd = false, t = 0;
    let jumpT = 0;
    cv.addEventListener('pointerdown', e => { e.preventDefault(); try { cv.setPointerCapture(e.pointerId); } catch (x) { } if (Object.keys(ptrs).length) jumpT = .18; ptrs[e.pointerId] = { sx: e.clientX, sy: e.clientY, t0: performance.now(), dx: 0, j: 0 }; });
    cv.addEventListener('pointermove', e => { const p = ptrs[e.pointerId]; if (!p) return; let dx = e.clientX - p.sx; const dy = e.clientY - p.sy; if (dx > 40) { p.sx = e.clientX - 40; dx = 40; } else if (dx < -40) { p.sx = e.clientX + 40; dx = -40; } p.dx = dx; if (dy < -30 && !p.j) { p.j = 1; jumpT = .18; } });
    const up = e => { const p = ptrs[e.pointerId]; if (p && e.type === 'pointerup' && Math.hypot(e.clientX - p.sx, e.clientY - p.sy) < 10 && performance.now() - p.t0 < 250) jumpT = .18; delete ptrs[e.pointerId]; }; cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    const end = win => { if (over) return; over = true; const sc = nr * 100 + stomps * 50 + (win ? 300 + Math.round(time) * 5 : Math.round(ball.x / 20)); SFX.play(win ? 'win' : 'buzz'); setTimeout(() => { stop(); fin(box, sc, done, (win ? '🏁 Flag reached! ' : '💔 ') + nr + ' rings'); }, 900); };
    const hurt = fall => { if (over || (inv > 0 && !fall)) return; lives--; inv = 1.3; SFX.play('bad'); if (lives <= 0) { end(false); return; } if (fall) { ball.x = cpx; ball.y = GY - r - 40; ball.vx = ball.vy = 0; } else { ball.vy = -380; ball.vx = -ball.vx * .5 - 100; } };
    const rects = () => segs.concat(plats);
    const step = h => {
      const dir = keys.r - keys.l; ball.vx += dir * (grd ? 1100 : 700) * h; if (!dir) ball.vx *= Math.pow(grd ? .004 : .3, h); ball.vx = clamp(ball.vx, -200, 200);
      ball.vy = Math.min(900, ball.vy + 1500 * h);
      if (keys.j && coy > 0) { ball.vy = -560; coy = 0; SFX.play('pop'); }
      ball.x += ball.vx * h; ball.y += ball.vy * h; ball.a += ball.vx * h / r; grd = false;
      for (const q of rects()) {
        const cx = clamp(ball.x, q.x, q.x + q.w), cy = clamp(ball.y, q.y, q.y + q.h), dx = ball.x - cx, dy = ball.y - cy, d = Math.hypot(dx, dy);
        if (d >= r) continue; if (d === 0) { ball.y = q.y - r; ball.vy = 0; grd = true; continue; }
        const nx = dx / d, ny = dy / d; ball.x += nx * (r - d); ball.y += ny * (r - d); const vn = ball.vx * nx + ball.vy * ny;
        if (vn < 0) { const e = (ny < -.5 && -vn > 120) ? 1.25 : 1; ball.vx -= vn * nx * e; ball.vy -= vn * ny * e; if (ny < -.5 && -vn > 200) { sq = Math.min(.35, -vn / 2500); SFX.play('slide'); } }
        if (ny < -.5) grd = true;
      }
      if (grd) coy = .09; else coy -= h;
      for (const s of spikes) if (ball.x > s.x - 8 && ball.x < s.x + s.w + 8 && ball.y + r > s.y + 4) hurt(false);
      for (const s of springs) { s.t = Math.max(0, s.t - h); if (ball.vy > 0 && ball.x > s.x - 4 && ball.x < s.x + s.w + 4 && ball.y + r > s.y && ball.y + r < s.y + s.h + 14) { ball.vy = -900; s.t = .25; SFX.play('good'); } }
      for (const g of rings) if (!g.got && Math.hypot(ball.x - g.x, ball.y - g.y) < 24) { g.got = 1; nr++; pops.add('+100', ball.x - cam, ball.y - 20, '#ffd54a'); }
      for (const f of foes) { if (!f.alive) continue; f.x += f.d * 60 * h; if (f.x < f.x0 || f.x > f.x1) f.d *= -1; if (Math.hypot(ball.x - f.x, ball.y - f.y) < r + 11) { if (ball.vy > 80 && ball.y < f.y - 4) { f.alive = false; ball.vy = -420; stomps++; pops.add('+50', f.x - cam, f.y - 20, '#fff'); } else hurt(false); } }
      for (const p of cps) if (ball.x >= p) cpx = p;
      if (ball.y > 560) hurt(true);
      if (ball.x >= flagX) end(true);
    };
    const stop = anim(dt0 => {
      if (!box.isConnected) { stop(); return; } const dt = Math.min(dt0, 1 / 30); t += dt;
      if (!over) { time -= dt; if (time <= 0) end(false); inv = Math.max(0, inv - dt); keys.l = keys.r = 0; for (const id in ptrs) { const d = ptrs[id].dx; if (d < -12) keys.l = 1; else if (d > 12) keys.r = 1; } keys.j = jumpT > 0 ? 1 : 0; jumpT -= dt; step(dt / 2); step(dt / 2); }
      sq *= Math.pow(.001, dt); cam += (clamp(ball.x - 130, 0, flagX + 100 - 360) - cam) * Math.min(1, dt * 6);
      const sky = c.createLinearGradient(0, 0, 0, 400); sky.addColorStop(0, '#4aa8ff'); sky.addColorStop(1, '#d6f0ff'); c.fillStyle = sky; c.fillRect(0, 0, 360, 520);
      c.fillStyle = '#fff6b0'; c.beginPath(); c.arc(290, 70, 26, 0, 6.283); c.fill();
      [[.2, '#8fd0a0', 330, 40, 90], [.45, '#5bb070', 360, 30, 60]].forEach(([f, col, base, hh, am]) => { c.fillStyle = col; c.beginPath(); c.moveTo(0, 520); for (let q = 0; q <= 360; q += 10) c.lineTo(q, base + Math.sin((q + cam * f) / am) * hh * .6); c.lineTo(360, 520); c.fill(); });
      c.fillStyle = '#fff'; for (let i = 0; i < 4; i++) { const cx = ((i * 190 - cam * .3 - t * 8) % 700 + 700) % 700 - 100; c.beginPath(); c.ellipse(cx, 60 + i * 34, 34, 13, 0, 0, 6.283); c.ellipse(cx + 22, 52 + i * 34, 22, 12, 0, 0, 6.283); c.fill(); }
      c.save(); c.translate(-Math.floor(cam), 0);
      const wg = c.createLinearGradient(0, 470, 0, 520); wg.addColorStop(0, '#3aa0f0'); wg.addColorStop(1, '#14589a'); c.fillStyle = wg; c.fillRect(cam - 10, 470, 380, 60); c.strokeStyle = '#ffffffaa'; c.lineWidth = 2; c.beginPath(); for (let q = cam - 10; q < cam + 370; q += 8) c.lineTo(q, 470 + Math.sin(q / 12 + t * 3) * 3); c.stroke();
      segs.forEach(q => { c.fillStyle = '#8a5a2c'; c.fillRect(q.x, q.y, q.w, q.h); c.fillStyle = '#0000002a'; for (let yy = q.y + 30; yy < 520; yy += 28) c.fillRect(q.x, yy, q.w, 2); c.fillStyle = '#5fcf4a'; c.fillRect(q.x, q.y, q.w, 10); c.fillStyle = '#3fa832'; c.fillRect(q.x, q.y + 8, q.w, 3); });
      plats.forEach(q => { c.fillStyle = '#d9822b'; c.fillRect(q.x, q.y, q.w, q.h); c.fillStyle = '#ffc27a'; c.fillRect(q.x, q.y, q.w, 3); c.fillStyle = '#0003'; for (let xx = q.x + 22; xx < q.x + q.w; xx += 22) c.fillRect(xx, q.y, 2, q.h); });
      c.fillStyle = '#cfd3de'; spikes.forEach(s => { for (let xx = s.x; xx < s.x + s.w; xx += 10) { c.beginPath(); c.moveTo(xx, s.y + s.h); c.lineTo(xx + 5, s.y); c.lineTo(xx + 10, s.y + s.h); c.fill(); } });
      springs.forEach(s => { const hh = s.h * (s.t > 0 ? 1.8 : 1); c.fillStyle = '#444'; c.fillRect(s.x, s.y + s.h - 4, s.w, 4); c.fillStyle = '#ff4d6d'; rr(c, s.x + 2, s.y + s.h - 4 - hh, s.w - 4, hh, 4); c.fill(); });
      rings.forEach(g => { if (g.got) return; c.strokeStyle = '#ffc83a'; c.lineWidth = 4; c.beginPath(); c.ellipse(g.x, g.y, Math.abs(Math.cos(t * 3 + g.x)) * 9 + 2, 11, 0, 0, 6.283); c.stroke(); });
      foes.forEach(f => { if (!f.alive) return; c.fillStyle = '#7a3ad6'; c.beginPath(); c.arc(f.x, f.y, 11, 0, 6.283); c.fill(); for (let i = 0; i < 8; i++) { const a = i / 8 * 6.283 + t * 2; c.beginPath(); c.moveTo(f.x + Math.cos(a) * 10, f.y + Math.sin(a) * 10); c.lineTo(f.x + Math.cos(a) * 17, f.y + Math.sin(a) * 17); c.lineTo(f.x + Math.cos(a + .3) * 10, f.y + Math.sin(a + .3) * 10); c.fill(); } c.fillStyle = '#fff'; c.fillRect(f.x - 6, f.y - 4, 4, 5); c.fillRect(f.x + 2, f.y - 4, 4, 5); });
      c.fillStyle = '#eee'; c.fillRect(flagX, GY - 100, 4, 100); c.fillStyle = '#e53935'; c.beginPath(); c.moveTo(flagX + 4, GY - 100); c.lineTo(flagX + 44, GY - 86 + Math.sin(t * 5) * 3); c.lineTo(flagX + 4, GY - 72); c.fill();
      if (!(inv > 0 && Math.floor(t * 14) % 2)) { c.fillStyle = '#0003'; c.beginPath(); c.ellipse(ball.x, Math.min(GY, ball.y + 60), 12, 4, 0, 0, 6.283); c.save(); c.translate(ball.x, ball.y); c.scale(1 + sq, 1 - sq); c.rotate(ball.a); const bg = c.createRadialGradient(-4, -5, 2, 0, 0, r); bg.addColorStop(0, '#ff9a8a'); bg.addColorStop(.55, '#e02a2a'); bg.addColorStop(1, '#7a0c0c'); c.fillStyle = bg; c.beginPath(); c.arc(0, 0, r, 0, 6.283); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 3; c.beginPath(); c.arc(0, 0, r - 4, .4, 2.2); c.stroke(); c.restore(); c.fillStyle = '#fff8'; c.beginPath(); c.arc(ball.x - 5, ball.y - 6, 3, 0, 6.283); c.fill(); }
      c.restore();
      c.fillStyle = '#0007'; c.fillRect(0, 0, 360, 32); tx(c, '♥'.repeat(Math.max(0, lives)), 40, 17, 17, '#ff4d6d', 'center'); tx(c, '⭕ ' + nr, 130, 17, 15, '#ffd54a', 'center'); tx(c, '⏱ ' + Math.max(0, Math.ceil(time)) + 's', 215, 17, 15, '#fff', 'center'); c.fillStyle = '#fff3'; c.fillRect(250, 14, 96, 6); c.fillStyle = '#7cf08a'; c.fillRect(250, 14, 96 * clamp(ball.x / flagX, 0, 1), 6);
      if (t < 6) tx(c, 'Drag to roll ◀ ▶ · flick up or tap to jump', 180, 480, 13, '#fff', 'center', '#000');
      pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});
