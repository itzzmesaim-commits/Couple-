/* Playza - offline bots for the base games. bot(state, seat, ctx) -> move | null */
const pick = a => a[Math.floor(Math.random() * a.length)];

/* Tic Tac Toe: perfect play with a little randomness */
function tttBest(b, turn, me) {
  const w = p => TTT_LINES.some(l => l.every(i => b[i] === p));
  if (w(me)) return { v: 1 }; if (w(1 - me)) return { v: -1 };
  const free = b.map((v, i) => v == null ? i : -1).filter(i => i >= 0);
  if (!free.length) return { v: 0 };
  let best = null;
  for (const i of free) {
    b[i] = turn; const r = tttBest(b, 1 - turn, me); b[i] = null;
    const v = r.v;
    if (!best || (turn === me ? v > best.v : v < best.v)) best = { v, i, all: [i] };
    else if (v === best.v) best.all.push(i);
  }
  return best;
}
G_TTT.bot = (s, seat) => {
  if (Math.random() < 0.15) return { i: pick(s.b.map((v, i) => v == null ? i : -1).filter(i => i >= 0)) };
  const r = tttBest(s.b.slice(), seat, seat); return { i: pick(r.all) };
};

/* 4 in a Row: win now, block, else prefer centre and avoid gifting a win */
G_C4.bot = (s, seat, c) => {
  const cols = [0, 1, 2, 3, 4, 5, 6].filter(x => s.b[x] == null);
  const test = (col, p) => { let r = 5; while (r >= 0 && s.b[r * 7 + col] != null) r--; if (r < 0) return null; const b = s.b.slice(); b[r * 7 + col] = p; return { b, r, win: c4win(b, r, col, p) }; };
  for (const x of cols) if (test(x, seat).win) return { c: x };
  for (const x of cols) if (test(x, 1 - seat).win) return { c: x };
  const safe = cols.filter(x => { const t = test(x, seat); if (t.r === 0) return true; const b = t.b; let r = t.r - 1; b[r * 7 + x] = 1 - seat; return !c4win(b, r, x, 1 - seat); });
  const pool = safe.length ? safe : cols;
  pool.sort((a, b) => Math.abs(a - 3) - Math.abs(b - 3) + (Math.random() - 0.5) * 2);
  return { c: pool[0] };
};

/* Reversi: most flips, corners preferred */
G_RV.bot = (s, seat) => {
  let best = null, bs = -1;
  for (const i of rvMoves(s.b, seat)) {
    const r = i >> 3, c = i & 7, corner = (r === 0 || r === 7) && (c === 0 || c === 7), edge = r === 0 || r === 7 || c === 0 || c === 7;
    const v = rvFlips(s.b, r, c, seat).length + (corner ? 12 : 0) + (edge ? 2 : 0) + Math.random();
    if (v > bs) { bs = v; best = i; }
  }
  return best == null ? null : { i: best };
};

/* Checkers */
G_CK.bot = (s, seat) => {
  const mv = ckMoves(s, seat); if (!mv.length) return null;
  const king = mv.filter(m => (seat === 0 && m.tr === 0) || (seat === 1 && m.tr === 7));
  return pick(king.length ? king : mv);
};

/* Dots & Boxes */
G_DB.bot = (s, seat) => {
  const lines = [];
  for (let r = 0; r <= DB_N; r++) for (let c = 0; c < DB_N; c++) if (s.h[r][c] == null) lines.push({ t: 'h', r, c });
  for (let r = 0; r < DB_N; r++) for (let c = 0; c <= DB_N; c++) if (s.v[r][c] == null) lines.push({ t: 'v', r, c });
  const sides = (i, j) => (s.h[i][j] != null) + (s.h[i + 1][j] != null) + (s.v[i][j] != null) + (s.v[i][j + 1] != null);
  const boxes = l => (l.t === 'h' ? [[l.r - 1, l.c], [l.r, l.c]] : [[l.r, l.c - 1], [l.r, l.c]]).filter(([i, j]) => i >= 0 && i < DB_N && j >= 0 && j < DB_N);
  const take = lines.filter(l => boxes(l).some(([i, j]) => sides(i, j) === 3));
  if (take.length) return pick(take);
  const safe = lines.filter(l => boxes(l).every(([i, j]) => sides(i, j) < 2));
  return pick(safe.length ? safe : lines);
};

/* Dice Party */
G_DICE.bot = (s, seat) => {
  if (s.rolls === 0) return { a: 'roll' };
  const cnt = {}; s.dice.forEach(x => cnt[x] = (cnt[x] || 0) + 1);
  const top = +Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a] || b - a)[0];
  if (s.rolls >= 3 || cnt[top] >= 4 || diceScore(s.dice) >= 38 && s.rolls >= 2) return { a: 'score' };
  return { a: 'roll', held: s.dice.map(x => x === top || (cnt[top] === 1 && x >= 5)) };
};

/* Ludo */
G_LUDO.bot = (s, seat) => {
  if (s.roll == null) return { a: 'roll' };
  const legal = ludoLegal(s, seat, s.roll); if (!legal.length) return null;
  let best = legal[0], bs = -1;
  for (const i of legal) {
    const pr = s.p[seat][i], np = pr === -1 ? 1 : pr + s.roll; let v = np + Math.random();
    if (pr === -1) v += 40;
    if (np === 28) v += 60;
    if (np < 28) { const rp = ringPos(seat, np), o = 1 - seat; if (s.p[o].some(q => q >= 1 && q < 28 && ringPos(o, q) === rp)) v += 50; }
    if (v > bs) { bs = v; best = i; }
  }
  return { a: 'tok', i: best };
};

/* Adult quiz / punishment */
G_QUIZ.bot = (s, seat, c) => { if (s.rev || s.ans[seat] != null || s.winner != null) return null; const q = c.data.quiz[s.order[s.i]]; return { a: 'ans', k: Math.random() < 0.55 && q.a != null ? q.a : Math.floor(Math.random() * q.o.length) }; };
G_PUN.bot = () => ({ a: 'draw' });
