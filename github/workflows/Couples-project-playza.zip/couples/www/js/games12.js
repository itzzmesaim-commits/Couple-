/* Playza - Extra games: Safari, Build Tower, Candy Crush-style, Puzzles */

/* ================= SAFARI (photo hunt) ================= */
const SF_AN = [{ e: '🦁', p: 30, d: .85, w: 3 }, { e: '🐘', p: 10, d: 1.5, w: 3 }, { e: '🦒', p: 15, d: 1.3, w: 3 }, { e: '🦓', p: 20, d: 1.05, w: 3 }, { e: '🐵', p: 25, d: .85, w: 3 }, { e: '🦏', p: 12, d: 1.4, w: 2 }, { e: '🐆', p: 35, d: .7, w: 2 }, { e: '🤠', p: -25, d: 1.2, w: 2, bad: 1 }];
const SF_BUSH = [[70, 215], [180, 195], [290, 215], [60, 335], [180, 315], [300, 335], [110, 450], [250, 450]];
const G_SAFARI = duel({
  id: 'safari', name: 'Safari', icon: '🦁', desc: '45 seconds! Tap the animals when they pop out of the bushes to snap a photo. Rare animals are worth more — never photograph the hunter 🤠!',
  bot: () => 330 + Math.floor(Math.random() * 420),
  play(box, seed, done) {
    const { cv, c } = arena(box, 360, 520), R = rng(seed), pops = popups(); const ev = []; let t0 = 1.0;
    const pool = []; SF_AN.forEach((a, i) => { for (let k = 0; k < a.w; k++) pool.push(i); });
    while (t0 < 43.5) { const a = SF_AN[pool[Math.floor(R() * pool.length)]]; ev.push({ t: t0, b: Math.floor(R() * SF_BUSH.length), a, hit: 0 }); t0 += .42 + R() * .45; }
    let T = 0, score = 0, combo = 0, shots = 0, flash = 0, over = false, finishAt = null; const parts = [];
    cv.addEventListener('pointerdown', e => {
      if (over) return; e.preventDefault(); const p = ptr(cv, e); SFX.play('shutter'); flash = .12; let best = null, bd = 1e9;
      ev.forEach(v => { if (!v.hit && T >= v.t && T < v.t + v.a.d) { const bx = SF_BUSH[v.b][0], by = SF_BUSH[v.b][1] - 26, d = Math.hypot(p.x - bx, p.y - by); if (d < 40 && d < bd) { bd = d; best = v; } } });
      shots++; if (!best) { combo = 0; return; }
      best.hit = 1; const a = best.a; if (a.bad) { score = Math.max(0, score + a.p); combo = 0; pops.add(a.p + '!', p.x, p.y - 20, '#ff5252'); SFX.play('buzz'); }
      else { combo++; const mul = 1 + Math.min(4, Math.floor(combo / 3)) * .5, pts = Math.round(a.p * mul); score += pts; pops.add('+' + pts, p.x, p.y - 20, '#ffd54a'); SFX.play('animal'); for (let k = 0; k < 8; k++) parts.push({ x: p.x, y: p.y, vx: (Math.random() - .5) * 200, vy: -Math.random() * 180, a: 0 }); }
    });
    const stop = anim(dt => {
      T += dt; flash = Math.max(0, flash - dt);
      const sky = c.createLinearGradient(0, 0, 0, 520); sky.addColorStop(0, '#ffb35a'); sky.addColorStop(.35, '#ffd98a'); sky.addColorStop(.36, '#d9b45a'); sky.addColorStop(1, '#a8802f'); c.fillStyle = sky; c.fillRect(0, 0, 360, 520);
      c.fillStyle = '#ff7a2e'; c.beginPath(); c.arc(260, 92, 38, 0, 6.283); c.fill(); c.fillStyle = '#ffffff55'; c.beginPath(); c.arc(260, 92, 52, 0, 6.283); c.fill();
      c.fillStyle = '#5a3a1a'; [[60, 175], [300, 168]].forEach(([x, y]) => { c.fillRect(x - 3, y - 20, 6, 28); c.beginPath(); c.ellipse(x, y - 24, 36, 11, 0, 0, 6.283); c.fill(); });
      c.fillStyle = '#c9a24a'; for (let i = 0; i < 20; i++) c.fillRect((i * 41 + 7) % 350, 220 + (i * 37) % 280, 14, 3);
      // animals behind bushes
      ev.forEach(v => { if (T >= v.t && T < v.t + v.a.d + .25) { const k = Math.min(1, (T - v.t) / .22), out = T > v.t + v.a.d ? Math.max(0, 1 - (T - v.t - v.a.d) / .25) : 1, rise = k * out, [bx, by] = SF_BUSH[v.b]; c.save(); c.beginPath(); c.rect(bx - 50, by - 90, 100, 90); c.clip(); c.globalAlpha = v.hit ? .45 : 1; c.font = '46px serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(v.a.e, bx, by - 8 - rise * 38 + 30 * (1 - rise)); c.restore(); c.globalAlpha = 1; if (v.hit) { tx(c, '📸', bx, by - 60, 22, '#fff'); } } });
      SF_BUSH.forEach(([x, y]) => { [[-22, 4, 22], [0, -3, 26], [22, 4, 22]].forEach(([dx, dy, r], i) => { const g = c.createRadialGradient(x + dx - 5, y + dy - 6, 2, x + dx, y + dy, r); g.addColorStop(0, '#7bd34a'); g.addColorStop(1, '#2f7a24'); c.fillStyle = g; c.beginPath(); c.arc(x + dx, y + dy, r, 0, 6.283); c.fill(); }); });
      parts.forEach(q => { q.a += dt; q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 400 * dt; c.globalAlpha = Math.max(0, 1 - q.a / .7); c.fillStyle = '#fff3a0'; c.fillRect(q.x, q.y, 5, 5); c.globalAlpha = 1; });
      const left = Math.max(0, 45 - T); hudTop(c, 360, score, Math.ceil(left) + 's', (g, w) => { tx(g, combo > 2 ? 'x' + (1 + Math.min(4, Math.floor(combo / 3)) * .5) : '', w - 40, 28, 18, '#ffd54a', 'center', '#000'); });
      pops.draw(c, dt);
      if (flash > 0) { c.fillStyle = '#fff'; c.globalAlpha = flash / .12 * .6; c.fillRect(0, 0, 360, 520); c.globalAlpha = 1; }
      if (!over && left <= 0) { over = true; finishAt = T; setTimeout(() => { stop(); fin(box, score, done, '📸 Safari over!'); }, 500); }
    });
    return () => { over = true; stop(); };
  }
});

/* ================= BUILD TOWER ================= */
const G_TOWER = duel({
  id: 'tower', name: 'Build Tower', icon: '🏗️', desc: 'Tap to drop the swinging block. Only the part that lands on the tower stays, so time it well! Perfect drops keep the block wide and give bonus points.',
  bot: () => 90 + Math.floor(Math.random() * 280),
  play(box, seed, done) {
    const { cv, c } = arena(box, 360, 520), R = rng(seed), pops = popups(); const BH = 26;
    let stack = [{ x: 110, w: 140, h: 0 }], cur = { x: 0, w: 140, dir: 1 }, level = 0, score = 0, perfect = 0, cam = 0, falling = [], over = false, t = 0, shake = 0, drop = null;
    const hue = i => (i * 23 + Math.floor(R() * 4)) % 360, hues = []; for (let i = 0; i < 400; i++) hues.push((i * 22 + 190) % 360);
    const speed = () => Math.min(330, 110 + level * 9);
    const place = () => {
      if (over || drop) return; const top = stack[stack.length - 1], a = Math.max(cur.x, top.x), b = Math.min(cur.x + cur.w, top.x + top.w), ov = b - a;
      if (ov <= 0) { over = true; falling.push({ x: cur.x, w: cur.w, y: 0, vy: 0, h: stack.length, hue: hues[level] }); SFX.play('buzz'); setTimeout(() => { stop(); fin(box, score, done, '🏗️ Tower fell at floor ' + level); }, 900); return; }
      level++; const d = cur.x - top.x;
      if (Math.abs(d) < 5) { perfect++; score += 10 + Math.min(perfect, 6) * 5; stack.push({ x: top.x, w: top.w, hue: hues[level] }); pops.add('PERFECT!', 180, 150, '#ffd54a'); SFX.play('perfect'); shake = .2; if (perfect % 4 === 0) { const nw = Math.min(140, top.w + 10); stack[stack.length - 1].w = nw; stack[stack.length - 1].x = top.x - (nw - top.w) / 2; } }
      else { perfect = 0; score += 10; stack.push({ x: a, w: ov, hue: hues[level] }); if (d < 0) falling.push({ x: cur.x, w: -d, y: 0, vy: 0, h: stack.length, hue: hues[level] }); else falling.push({ x: b, w: cur.x + cur.w - b, y: 0, vy: 0, h: stack.length, hue: hues[level] }); SFX.play('stack'); }
      const nt = stack[stack.length - 1]; cur = { x: R() < .5 ? -nt.w : 360, w: nt.w, dir: 1 }; cur.dir = cur.x < 0 ? 1 : -1;
    };
    cv.addEventListener('pointerdown', e => { e.preventDefault(); place(); });
    const stop = anim(dt => {
      t += dt; shake = Math.max(0, shake - dt);
      const top = stack.length; const targetCam = Math.max(0, (top - 7) * BH); cam += (targetCam - cam) * Math.min(1, dt * 4);
      if (!over) { cur.x += cur.dir * speed() * dt; if (cur.x < -cur.w * .2 && cur.dir < 0) cur.dir = 1; if (cur.x + cur.w > 360 + cur.w * .2 && cur.dir > 0) cur.dir = -1; }
      const k = Math.min(1, cam / 1500), sky = c.createLinearGradient(0, 0, 0, 520); sky.addColorStop(0, `hsl(${210 + k * 60},70%,${55 - k * 40}%)`); sky.addColorStop(1, `hsl(${200 + k * 40},80%,${80 - k * 50}%)`); c.fillStyle = sky; c.fillRect(0, 0, 360, 520);
      if (k > .15) { c.fillStyle = '#fff'; for (let i = 0; i < 30; i++) { c.globalAlpha = Math.min(1, k * 2) * (.4 + .6 * ((i * 7) % 5) / 5); c.fillRect((i * 83) % 360, (i * 47) % 400, 2, 2); } c.globalAlpha = 1; }
      c.fillStyle = '#ffffffaa'; for (let i = 0; i < 4; i++) { const cx = ((i * 130 + t * 8) % 460) - 50, cy = 90 + i * 70 + cam * .2 % 40; c.beginPath(); c.ellipse(cx, cy, 36, 12, 0, 0, 6.283); c.ellipse(cx + 20, cy - 8, 24, 11, 0, 0, 6.283); c.fill(); }
      const baseY = 470 + cam, sx = shake ? (Math.random() - .5) * 6 : 0; c.save(); c.translate(sx, 0);
      c.fillStyle = '#3a7a2a'; c.fillRect(0, 470 + cam, 360, 80); c.fillStyle = '#5ab048'; c.fillRect(0, 470 + cam, 360, 6);
      stack.forEach((b, i) => { const y = baseY - (i + 1) * BH; if (y > 540 || y < -40) return; const col = `hsl(${b.hue != null ? b.hue : 200},70%,55%)`; c.fillStyle = i === 0 ? '#555a62' : `hsl(${b.hue},70%,34%)`; c.fillRect(b.x, y + 3, b.w, BH - 2); c.fillStyle = i === 0 ? '#9aa0aa' : col; c.fillRect(b.x, y, b.w, BH - 3); c.fillStyle = '#ffffff44'; c.fillRect(b.x, y, b.w, 5); c.fillStyle = '#00000022'; for (let wx = b.x + 8; wx < b.x + b.w - 10; wx += 18) c.fillRect(wx, y + 9, 8, 8); });
      falling.forEach(f => { f.vy += 900 * dt; f.y += f.vy * dt; c.globalAlpha = Math.max(0, 1 - f.y / 400); c.fillStyle = `hsl(${f.hue},70%,50%)`; c.fillRect(f.x, baseY - f.h * BH + f.y, f.w, BH - 3); c.globalAlpha = 1; });
      falling = falling.filter(f => f.y < 420);
      if (!over) { const cy = baseY - stack.length * BH - 80; c.strokeStyle = '#444'; c.lineWidth = 2; c.beginPath(); c.moveTo(cur.x + cur.w / 2, 0); c.lineTo(cur.x + cur.w / 2, cy); c.stroke(); c.fillStyle = `hsl(${hues[level + 1] || 200},70%,55%)`; c.fillRect(cur.x, cy, cur.w, BH - 3); c.fillStyle = '#ffffff44'; c.fillRect(cur.x, cy, cur.w, 5); }
      c.restore(); hudTop(c, 360, score, 'Floor ' + level, null); pops.draw(c, dt);
      if (!level && !over) tx(c, 'TAP to drop the block', 180, 300, 20, '#fff', 'center', '#000');
    });
    return () => { over = true; stop(); };
  }
});

/* ================= CANDY CRUSH-style ================= */
const CD_N = 8, CD_COL = ['#ff4d6d', '#4aa3ff', '#3ddc97', '#ffd54a', '#ff8a3d', '#b36bff'];
function candyDraw(c, x, y, s, t, sp, k) {
  const col = CD_COL[t], cx = x + s / 2, cy = y + s / 2, r = s * .4; c.save();
  if (sp === 3) { const g = c.createRadialGradient(cx - 5, cy - 6, 2, cx, cy, r); g.addColorStop(0, '#fff'); g.addColorStop(1, '#6a4a8a'); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, r, 0, 6.283); c.fill(); for (let i = 0; i < 6; i++) { c.fillStyle = CD_COL[i]; c.beginPath(); c.arc(cx + Math.cos(i + k * 2) * r * .6, cy + Math.sin(i + k * 2) * r * .6, 4, 0, 6.283); c.fill(); } c.restore(); return; }
  const g = c.createRadialGradient(cx - r * .35, cy - r * .4, 1, cx, cy, r * 1.15); g.addColorStop(0, shade(col, .55)); g.addColorStop(.6, col); g.addColorStop(1, shade(col, -.35)); c.fillStyle = g; c.strokeStyle = shade(col, -.5); c.lineWidth = 1.5;
  c.beginPath();
  if (t === 0) { c.arc(cx, cy, r, 0, 6.283); }
  else if (t === 1) { rr(c, cx - r * .9, cy - r * .9, r * 1.8, r * 1.8, r * .45); }
  else if (t === 2) { c.moveTo(cx, cy - r * 1.05); c.lineTo(cx + r * 1.05, cy); c.lineTo(cx, cy + r * 1.05); c.lineTo(cx - r * 1.05, cy); c.closePath(); }
  else if (t === 3) { for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rad = i % 2 ? r * .5 : r * 1.1; c.lineTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad); } c.closePath(); }
  else if (t === 4) { c.ellipse(cx, cy, r * 1.1, r * .8, 0, 0, 6.283); }
  else { for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; c.lineTo(cx + Math.cos(a) * r * 1.05, cy + Math.sin(a) * r * 1.05); } c.closePath(); }
  c.fill(); c.stroke(); c.fillStyle = '#ffffff99'; c.beginPath(); c.ellipse(cx - r * .3, cy - r * .4, r * .28, r * .16, -.6, 0, 6.283); c.fill();
  if (sp === 1 || sp === 2) { c.strokeStyle = '#ffffffcc'; c.lineWidth = 3; for (let i = -1; i <= 1; i++) { c.beginPath(); if (sp === 1) { c.moveTo(cx - r * .8, cy + i * r * .45); c.lineTo(cx + r * .8, cy + i * r * .45); } else { c.moveTo(cx + i * r * .45, cy - r * .8); c.lineTo(cx + i * r * .45, cy + r * .8); } c.stroke(); } }
  c.restore();
}
const G_CANDY = duel({
  id: 'candy', name: 'Candy Crush', icon: '🍬', desc: 'Swipe candies to match 3 or more. Match 4 for a striped candy, 5 for a colour bomb. You have 20 moves — score as high as you can!',
  bot: () => 700 + Math.floor(Math.random() * 1000),
  play(box, seed, done) {
    const { cv, c } = arena(box, 360, 470), R = rng(seed), pops = popups(), cs = 42, bx = 12, by = 82;
    const mk = (t, row, col) => ({ t: t != null ? t : Math.floor(R() * 6), sp: 0, x: bx + col * cs, y: by + row * cs, sc: 1 });
    let B = []; for (let r = 0; r < CD_N; r++) { B.push([]); for (let q = 0; q < CD_N; q++) { let t; do { t = Math.floor(R() * 6); } while ((q >= 2 && B[r][q - 1].t === t && B[r][q - 2].t === t) || (r >= 2 && B[r - 1][q].t === t && B[r - 2][q].t === t)); B[r].push(mk(t, r, q)); } }
    let moves = 20, score = 0, mode = 'idle', sel = null, pair = null, chain = 0, over = false, T = 0, parts = [], pend = null, wait = 0;
    const settled = () => { for (let r = 0; r < CD_N; r++) for (let q = 0; q < CD_N; q++) { const o = B[r][q]; if (o && (Math.abs(o.x - (bx + q * cs)) > .6 || Math.abs(o.y - (by + r * cs)) > .6)) return false; } return true; };
    const runs = () => { // returns {set:Set(idx), specials:[{i,sp,t}]}
      const set = new Set(), specials = [];
      for (let r = 0; r < CD_N; r++) { let q = 0; while (q < CD_N) { const a = B[r][q]; let e = q + 1; while (a && e < CD_N && B[r][e] && B[r][e].t === a.t && B[r][e].sp !== 3 && a.sp !== 3) e++; const len = e - q; if (a && len >= 3) { for (let k = q; k < e; k++) set.add(r * CD_N + k); if (len >= 4) { const pos = pair && pair.some(p => p.r === r && p.c >= q && p.c < e) ? pair.find(p => p.r === r && p.c >= q && p.c < e).c : q + 1; specials.push({ i: r * CD_N + pos, sp: len >= 5 ? 3 : 2, t: a.t }); } } q = e; } }
      for (let q = 0; q < CD_N; q++) { let r = 0; while (r < CD_N) { const a = B[r][q]; let e = r + 1; while (a && e < CD_N && B[e][q] && B[e][q].t === a.t && B[e][q].sp !== 3 && a.sp !== 3) e++; const len = e - r; if (a && len >= 3) { for (let k = r; k < e; k++) set.add(k * CD_N + q); if (len >= 4) { const pos = pair && pair.some(p => p.c === q && p.r >= r && p.r < e) ? pair.find(p => p.c === q && p.r >= r && p.r < e).r : r + 1; specials.push({ i: pos * CD_N + q, sp: len >= 5 ? 3 : 1, t: a.t }); } } r = e; } }
      return { set, specials };
    };
    const expand = set => { let grow = true; while (grow) { grow = false; [...set].forEach(i => { const o = B[(i / CD_N) | 0][i % CD_N]; if (!o) return; if (o.sp === 1) for (let q = 0; q < CD_N; q++) { const j = ((i / CD_N) | 0) * CD_N + q; if (!set.has(j)) { set.add(j); grow = true; } } if (o.sp === 2) for (let r = 0; r < CD_N; r++) { const j = r * CD_N + i % CD_N; if (!set.has(j)) { set.add(j); grow = true; } } }); } return set; };
    const swap = (a, b) => { const t = B[a.r][a.c]; B[a.r][a.c] = B[b.r][b.c]; B[b.r][b.c] = t; };
    const tryMove = (a, b) => {
      if (mode !== 'idle' || over) return; swap(a, b); pair = [a, b]; SFX.play('slide');
      const A = B[a.r][a.c], Bb = B[b.r][b.c]; let bomb = null;
      if (A.sp === 3 || Bb.sp === 3) { const ot = A.sp === 3 ? Bb.t : A.t; bomb = { t: Bb.sp === 3 && A.sp === 3 ? -1 : ot }; }
      pend = bomb; mode = 'swap1';
    };
    const clearSet = (set, specials) => {
      chain++; let pts = 0; const keep = new Map(); specials.forEach(s => keep.set(s.i, s));
      set.forEach(i => { const r = (i / CD_N) | 0, q = i % CD_N, o = B[r][q]; if (!o) return; pts += 10; for (let k = 0; k < 4; k++) parts.push({ x: o.x + cs / 2, y: o.y + cs / 2, vx: (Math.random() - .5) * 220, vy: (Math.random() - .8) * 200, a: 0, col: CD_COL[o.t % 6] }); if (keep.has(i)) { o.sp = keep.get(i).sp; o.t = keep.get(i).t; o.sc = 1.35; } else { if (o.sp) pts += 30; B[r][q] = null; } });
      pts *= chain; score += pts; pops.add('+' + pts, 180, 78, chain > 1 ? '#ffd54a' : '#fff'); SFX.play(chain > 2 ? 'clear' : chain > 1 ? 'good' : 'pop'); if (specials.length) SFX.play('perfect');
    };
    const gravity = () => { for (let q = 0; q < CD_N; q++) { const col = []; for (let r = CD_N - 1; r >= 0; r--) if (B[r][q]) col.push(B[r][q]); let n = col.length; for (let r = CD_N - 1, k = 0; r >= 0; r--, k++) { if (k < col.length) B[r][q] = col[k]; else { const o = mk(null, r, q); o.y = by - (CD_N - r) * cs - 10; B[r][q] = o; } } } };
    const hasMove = () => { for (let r = 0; r < CD_N; r++) for (let q = 0; q < CD_N; q++) for (const [dr, dc] of [[0, 1], [1, 0]]) { const r2 = r + dr, q2 = q + dc; if (r2 >= CD_N || q2 >= CD_N) continue; const a = B[r][q], b = B[r2][q2]; if (a.sp === 3 || b.sp === 3) return true; B[r][q] = b; B[r2][q2] = a; const s = runs().set.size; B[r][q] = a; B[r2][q2] = b; if (s) return true; } return false; };
    cv.addEventListener('pointerdown', e => { e.preventDefault(); if (mode !== 'idle' || over) return; const p = ptr(cv, e), q = Math.floor((p.x - bx) / cs), r = Math.floor((p.y - by) / cs); if (r < 0 || q < 0 || r >= CD_N || q >= CD_N) return; if (sel && Math.abs(sel.r - r) + Math.abs(sel.c - q) === 1) { const a = sel; sel = null; tryMove(a, { r, c: q }); } else { sel = { r, c: q, px: p.x, py: p.y, sw: true }; SFX.play('tap'); } });
    cv.addEventListener('pointermove', e => { if (!sel || !sel.sw || mode !== 'idle') return; const p = ptr(cv, e), dx = p.x - sel.px, dy = p.y - sel.py; if (Math.hypot(dx, dy) > 20) { const d = Math.abs(dx) > Math.abs(dy) ? [0, Math.sign(dx)] : [Math.sign(dy), 0], a = { r: sel.r, c: sel.c }, b = { r: a.r + d[0], c: a.c + d[1] }; sel = null; if (b.r >= 0 && b.c >= 0 && b.r < CD_N && b.c < CD_N) tryMove(a, b); } });
    cv.addEventListener('pointerup', () => { if (sel) sel.sw = false; });
    const finish = () => { over = true; setTimeout(() => { stop(); fin(box, score, done, '🍬 Out of moves!'); }, 700); };
    const stop = anim(dt => {
      T += dt; wait -= dt;
      for (let r = 0; r < CD_N; r++) for (let q = 0; q < CD_N; q++) { const o = B[r][q]; if (!o) continue; const tx_ = bx + q * cs, ty = by + r * cs; o.x += (tx_ - o.x) * Math.min(1, dt * 16); o.y += (ty - o.y) * Math.min(1, dt * (o.y < ty - 4 ? 11 : 16)); o.sc += (1 - o.sc) * Math.min(1, dt * 10); }
      if (wait <= 0 && settled() && !over) {
        if (mode === 'swap1') {
          const rs = runs();
          if (pend) { const a = pair[0], b = pair[1], A = B[a.r][a.c], Bb = B[b.r][b.c]; const set = new Set([a.r * CD_N + a.c, b.r * CD_N + b.c]); for (let r = 0; r < CD_N; r++) for (let q = 0; q < CD_N; q++) { const o = B[r][q]; if (o && (pend.t < 0 || o.t === pend.t)) set.add(r * CD_N + q); } moves--; chain = 0; clearSet(expand(set), []); pend = null; mode = 'fall'; wait = .25; SFX.play('boom'); }
          else if (!rs.set.size) { swap(pair[0], pair[1]); mode = 'swapback'; SFX.play('bad'); }
          else { moves--; chain = 0; clearSet(expand(new Set(rs.set)), rs.specials); mode = 'fall'; wait = .22; }
        } else if (mode === 'swapback') { mode = 'idle'; pair = null; }
        else if (mode === 'fall') { gravity(); mode = 'check'; wait = .12; }
        else if (mode === 'check') { const rs = runs(); if (rs.set.size) { pair = null; clearSet(expand(new Set(rs.set)), rs.specials); mode = 'fall'; wait = .22; } else { if (moves <= 0) { mode = 'done'; finish(); } else { if (!hasMove()) { for (let r = 0; r < CD_N; r++) for (let q = 0; q < CD_N; q++) { B[r][q] = mk(null, r, q); B[r][q].y -= 60; } pops.add('Shuffle!', 180, 240, '#fff'); mode = 'check'; wait = .5; } else { mode = 'idle'; pair = null; } } } }
      }
      const bg = c.createLinearGradient(0, 0, 0, 470); bg.addColorStop(0, '#5b2a86'); bg.addColorStop(1, '#2a1250'); c.fillStyle = bg; c.fillRect(0, 0, 360, 470);
      for (let i = 0; i < 12; i++) { c.fillStyle = '#ffffff10'; c.beginPath(); c.arc((i * 61 + T * 10) % 380, (i * 83) % 470, 14 + (i % 4) * 6, 0, 6.283); c.fill(); }
      c.fillStyle = '#00000044'; rr(c, bx - 4, by - 4, cs * CD_N + 8, cs * CD_N + 8, 12); c.fill();
      for (let r = 0; r < CD_N; r++) for (let q = 0; q < CD_N; q++) { c.fillStyle = (r + q) % 2 ? '#ffffff12' : '#ffffff08'; c.fillRect(bx + q * cs, by + r * cs, cs, cs); }
      for (let r = 0; r < CD_N; r++) for (let q = 0; q < CD_N; q++) { const o = B[r][q]; if (!o) continue; const s = cs * o.sc; if (o.y < by - 2) { c.save(); c.beginPath(); c.rect(bx, by, cs * CD_N, cs * CD_N); c.clip(); candyDraw(c, o.x + (cs - s) / 2, o.y + (cs - s) / 2, s, o.t, o.sp, T); c.restore(); } else candyDraw(c, o.x + (cs - s) / 2, o.y + (cs - s) / 2, s, o.t, o.sp, T); }
      if (sel && !sel.sw || (sel && mode === 'idle')) { c.strokeStyle = '#fff'; c.lineWidth = 3; c.strokeRect(bx + sel.c * cs + 1, by + sel.r * cs + 1, cs - 2, cs - 2); }
      parts = parts.filter(q => (q.a += dt) < .6); parts.forEach(q => { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 500 * dt; c.globalAlpha = 1 - q.a / .6; c.fillStyle = q.col; c.beginPath(); c.arc(q.x, q.y, 3.5, 0, 6.283); c.fill(); c.globalAlpha = 1; });
      hudTop(c, 360, score, 'Moves ' + moves, null); pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});

/* ================= PUZZLES (picture slide puzzle) ================= */
function puzPic(c, S, seed) {
  const R = rng(seed), hue = Math.floor(R() * 360), sky = c.createLinearGradient(0, 0, 0, S); sky.addColorStop(0, `hsl(${hue},80%,70%)`); sky.addColorStop(.6, `hsl(${(hue + 40) % 360},85%,82%)`); sky.addColorStop(1, `hsl(${(hue + 40) % 360},60%,60%)`); c.fillStyle = sky; c.fillRect(0, 0, S, S);
  c.fillStyle = '#fff6c8'; c.beginPath(); c.arc(S * (.2 + R() * .6), S * .2, S * .09, 0, 6.283); c.fill();
  for (let L = 0; L < 3; L++) { c.fillStyle = `hsl(${(hue + 200 + L * 20) % 360},${40 + L * 10}%,${55 - L * 12}%)`; c.beginPath(); c.moveTo(0, S); let x = 0; c.lineTo(0, S * (.55 + L * .1)); while (x < S) { x += S * (.12 + R() * .15); c.lineTo(x, S * (.35 + L * .1 + R() * .18)); } c.lineTo(S, S); c.fill(); }
  c.fillStyle = `hsl(${(hue + 180) % 360},70%,50%)`; for (let i = 0; i < 6; i++) { const x = S * R(), y = S * (.72 + R() * .2); c.beginPath(); c.moveTo(x, y - S * .1); c.lineTo(x + S * .04, y); c.lineTo(x - S * .04, y); c.fill(); }
  const w = c.createLinearGradient(0, S * .85, 0, S); w.addColorStop(0, '#6fd0ff'); w.addColorStop(1, '#1c6fb0'); c.fillStyle = w; c.fillRect(0, S * .86, S, S * .14);
  c.fillStyle = '#fff'; for (let i = 0; i < 10; i++) c.fillRect(S * R(), S * (.88 + R() * .1), S * .06, 2);
}
const G_PUZZLE = duel({
  id: 'puzzle', name: 'Puzzles', icon: '🧩', low: true, desc: 'Slide the picture tiles to rebuild the image. Tap a tile next to the empty space. The fastest solver wins!',
  bot: () => 28 + Math.floor(Math.random() * 45),
  play(box, seed, done) {
    const { cv, c } = arena(box, 360, 520), R = rng(seed), N = 3, cs = 108, bx = 18, by = 120, S = cs * N; const pic = off(S, S, (g, w) => puzPic(g, w, seed));
    let b = Array.from({ length: N * N }, (_, i) => i); let e = N * N - 1; const nb = i => { const r = (i / N) | 0, q = i % N, o = []; if (r > 0) o.push(i - N); if (r < N - 1) o.push(i + N); if (q > 0) o.push(i - 1); if (q < N - 1) o.push(i + 1); return o; };
    let last = -1; for (let k = 0; k < 90; k++) { const o = nb(e).filter(x => x !== last); const n = o[Math.floor(R() * o.length)]; b[e] = b[n]; b[n] = N * N - 1; last = e; e = n; }
    if (b.every((v, i) => v === i)) { b[e] = b[e - 1]; b[e - 1] = N * N - 1; e--; }
    const pos = b.map((v, i) => ({ x: bx + (i % N) * cs, y: by + ((i / N) | 0) * cs })); // visual by tile id
    const vis = {}; b.forEach((v, i) => { vis[v] = { x: bx + (i % N) * cs, y: by + ((i / N) | 0) * cs }; });
    let T = 0, moves = 0, over = false, solved = false; const pops = popups();
    cv.addEventListener('pointerdown', ev => { ev.preventDefault(); if (over) return; const p = ptr(cv, ev), q = Math.floor((p.x - bx) / cs), r = Math.floor((p.y - by) / cs); if (r < 0 || q < 0 || r >= N || q >= N) return; const i = r * N + q; if (!nb(e).includes(i)) { SFX.play('bad'); return; } b[e] = b[i]; b[i] = N * N - 1; e = i; moves++; SFX.play('slide'); if (b.every((v, k) => v === k)) { solved = true; over = true; SFX.play('win'); setTimeout(() => { stop(); fin(box, Math.round(T), done, '🧩 Solved in ' + Math.round(T) + 's, ' + moves + ' moves'); }, 900); } });
    const stop = anim(dt => {
      if (!over) T += dt; if (T > 150 && !over) { over = true; setTimeout(() => { stop(); fin(box, 150 + b.filter((v, i) => v !== i).length, done, '⏱ Time up'); }, 300); }
      b.forEach((v, i) => { const t = vis[v], tx_ = bx + (i % N) * cs, ty = by + ((i / N) | 0) * cs; t.x += (tx_ - t.x) * Math.min(1, dt * 18); t.y += (ty - t.y) * Math.min(1, dt * 18); });
      const bg = c.createLinearGradient(0, 0, 0, 520); bg.addColorStop(0, '#1b2b5e'); bg.addColorStop(1, '#0c1431'); c.fillStyle = bg; c.fillRect(0, 0, 360, 520);
      hudTop(c, 360, moves, Math.floor(T) + 's', null); tx(c, 'moves', 91, 46, 10, '#9fb4ff');
      c.fillStyle = '#00000055'; rr(c, bx - 6, by - 6, S + 12, S + 12, 12); c.fill();
      b.forEach((v, i) => { if (v === N * N - 1 && !solved) return; const t = vis[v], sx = (v % N) * cs, sy = ((v / N) | 0) * cs; c.drawImage(pic, sx, sy, cs, cs, t.x + 1, t.y + 1, cs - 2, cs - 2); c.strokeStyle = '#ffffffaa'; c.lineWidth = 2; c.strokeRect(t.x + 2, t.y + 2, cs - 4, cs - 4); if (!solved) tx(c, String(v + 1), t.x + 14, t.y + 14, 14, '#fff', 'center', '#000'); });
      tx(c, 'Goal', 180, 454, 12, '#9fb4ff'); c.drawImage(pic, 0, 0, S, S, 156, 466, 48, 48);
      pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});
