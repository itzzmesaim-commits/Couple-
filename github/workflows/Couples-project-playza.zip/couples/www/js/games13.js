/* Playza - Challenge games (levels): Candy Crush, Build Tower, Runup */

/* ---------- challenge framework: level list + play screen + result card ---------- */
const CH = {
  load(id) { try { return JSON.parse(localStorage.getItem('pm_ch_' + id)) || {}; } catch (e) { return {}; } },
  save(id, o) { try { localStorage.setItem('pm_ch_' + id, JSON.stringify(o)); } catch (e) { } }
};
function chSolo(def) {
  return Object.assign({ players: '1 Player · Challenges', type: 'solo' }, def, {
    solo(box) {
      window.__curGame = def.id; try { MUSIC.start(def.id); } catch (e) { }
      let stopFn = null; const P = () => CH.load(def.id);
      const menu = () => {
        if (stopFn) { try { stopFn(); } catch (e) { } stopFn = null; }
        const pr = P(), st = pr.stars || {}, total = Object.values(st).reduce((a, b) => a + b, 0);
        box.innerHTML = `<div class="chmenu ${def.cls || ''}"><div class="chtitle">${def.icon} ${esc(def.name)}</div><div class="chsub">⭐ ${total} / ${def.levels.length * 3} · Pick a challenge</div><div class="chlist">${def.levels.map((L, i) => `<button class="chcard" data-l="${i}"><div class="chnum">${i + 1}</div><div class="chinfo"><b>${esc(L.n)}</b><small>${esc(L.goal)}</small></div><div class="chstars">${[1, 2, 3].map(k => `<span class="${(st[i] || 0) >= k ? 'on' : ''}">★</span>`).join('')}</div></button>`).join('')}</div></div>`;
        $$('[data-l]', box).forEach(b => b.onclick = () => { SFX.play('pop'); start(+b.dataset.l); });
      };
      let startRandom; const start = i => {
        if (stopFn) { try { stopFn(); } catch (e) { } stopFn = null; } const L = def.levels[i];
        box.innerHTML = `<div class="chbar"><button class="chb" id="chm">🎲 New challenge</button><span><b>${esc(L.n)}</b></span><button class="chb" id="chr">↻</button></div><div class="chstage" id="chs"></div><div class="chgoal">${esc(L.goal)}</div>`;
        $('#chm', box).onclick = () => startRandom(); $('#chr', box).onclick = () => start(i);
        const stage = $('#chs', box); let done = false;
        stopFn = def.play(stage, L, i, res => {
          if (done) return; done = true; const pr = P(); pr.stars = pr.stars || {}; if (res.win) pr.stars[i] = Math.max(pr.stars[i] || 0, res.stars); CH.save(def.id, pr);
          SFX.play(res.win ? 'win' : 'lose');
          const el = document.createElement('div'); el.className = 'chres'; el.innerHTML = `<div class="chrc"><div class="chbig">${res.win ? '🎉 Level Complete!' : '💔 ' + (res.msg || 'Try again!')}</div>${res.win ? `<div class="chst">${[1, 2, 3].map(k => `<span class="${res.stars >= k ? 'on' : ''}">★</span>`).join('')}</div>` : ''}<div class="chsc">Score <b>${res.score != null ? res.score : 0}</b></div>${res.info ? `<div class="mut">${esc(res.info)}</div>` : ''}<div class="chbtns"><button class="btn" id="chn">${res.win ? 'Next ▶' : 'New 🎲'}</button><button class="btn sec" id="chp">↻ Replay</button></div></div>`;
          stage.appendChild(el); const nx = $('#chn', el); if (nx) nx.onclick = () => startRandom(); $('#chp', el).onclick = () => start(i);
        }) || null;
      };
      let lastL = -1; const rnd2 = () => { let n; do { n = Math.floor(Math.random() * def.levels.length); } while (n === lastL && def.levels.length > 1); lastL = n; return n; };
      startRandom = () => start(rnd2()); startRandom();
    }
  });
}

/* ================= CANDY CRUSH ================= */
const CDN = 8, CD_C = ['#2d8cf0', '#e23b3b', '#ff9a1a', '#2fbf3a', '#ffd21f', '#a24be0'];
function cdPath(c, t, cx, cy, r) {
  c.beginPath();
  if (t === 0) c.arc(cx, cy, r * 1.05, 0, 6.283);
  else if (t === 1) c.ellipse(cx, cy, r * 1.2, r * .62, -.7, 0, 6.283);
  else if (t === 2) c.ellipse(cx, cy, r * .8, r * 1.02, 0, 0, 6.283);
  else if (t === 3) rr(c, cx - r * .95, cy - r * .95, r * 1.9, r * 1.9, r * .45);
  else if (t === 4) { c.moveTo(cx, cy - r * 1.15); c.bezierCurveTo(cx + r * .3, cy - r * .5, cx + r * 1.0, cy - r * .1, cx + r * .95, cy + r * .35); c.bezierCurveTo(cx + r * .85, cy + r * 1.0, cx - r * .85, cy + r * 1.0, cx - r * .95, cy + r * .35); c.bezierCurveTo(cx - r * 1.0, cy - r * .1, cx - r * .3, cy - r * .5, cx, cy - r * 1.15); c.closePath(); }
  else { for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; c.moveTo(cx + Math.cos(a) * r * .72 + r * .38, cy + Math.sin(a) * r * .72); c.arc(cx + Math.cos(a) * r * .72, cy + Math.sin(a) * r * .72, r * .38, 0, 6.283); } c.moveTo(cx + r * .8, cy); c.arc(cx, cy, r * .8, 0, 6.283); }
}
function cdDraw(c, x, y, s, o, T) {
  const cx = x + s / 2, cy = y + s / 2, r = s * .4; c.save();
  if (o.k === 'k') { c.fillStyle = '#1b1b22'; rr(c, x + 2, y + 2, s - 4, s - 4, 8); c.fill(); for (let i = 1; i <= 4; i++) { c.strokeStyle = i % 2 ? '#555a66' : '#2c2f38'; c.lineWidth = 2.2; c.beginPath(); c.arc(cx, cy, i * s * .09, 0, 6.283); c.stroke(); } c.fillStyle = '#d0d4dc'; c.beginPath(); c.arc(cx, cy, 3, 0, 6.283); c.fill(); c.restore(); return; }
  if (o.k === 'h') { c.strokeStyle = '#2f8f2a'; c.lineWidth = 2.5; c.beginPath(); c.moveTo(cx - 6, cy + 4); c.quadraticCurveTo(cx - 2, cy - 14, cx + 6, cy - 16); c.moveTo(cx + 8, cy + 6); c.quadraticCurveTo(cx + 8, cy - 10, cx + 6, cy - 16); c.stroke(); [[-7, 8], [9, 10]].forEach(([dx, dy]) => { const g = c.createRadialGradient(cx + dx - 3, cy + dy - 3, 1, cx + dx, cy + dy, 9); g.addColorStop(0, '#ff8a8a'); g.addColorStop(1, '#a50f1f'); c.fillStyle = g; c.beginPath(); c.arc(cx + dx, cy + dy, 8.5, 0, 6.283); c.fill(); }); c.restore(); return; }
  if (o.sp === 3) { const g = c.createRadialGradient(cx - 6, cy - 7, 2, cx, cy, r * 1.1); g.addColorStop(0, '#8a5a3a'); g.addColorStop(1, '#2b1608'); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, r * 1.08, 0, 6.283); c.fill(); for (let i = 0; i < 14; i++) { const a = i * 2.4 + T * .6, d = r * (.25 + (i % 4) * .17); c.fillStyle = CD_C[i % 6]; c.beginPath(); c.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d, 2.6, 0, 6.283); c.fill(); } c.fillStyle = '#ffffff55'; c.beginPath(); c.ellipse(cx - r * .35, cy - r * .45, r * .3, r * .15, -.6, 0, 6.283); c.fill(); c.restore(); return; }
  const col = CD_C[o.t % 6]; cdPath(c, o.t % 6, cx, cy + 1.5, r); c.fillStyle = '#00000033'; c.fill();
  cdPath(c, o.t % 6, cx, cy, r); const g = c.createRadialGradient(cx - r * .35, cy - r * .45, 1, cx, cy, r * 1.25); g.addColorStop(0, shade(col, .65)); g.addColorStop(.45, col); g.addColorStop(1, shade(col, -.4)); c.fillStyle = g; c.fill(); c.strokeStyle = shade(col, -.55); c.lineWidth = 1.4; c.stroke();
  if (o.sp === 1 || o.sp === 2) { c.save(); cdPath(c, o.t % 6, cx, cy, r); c.clip(); c.strokeStyle = '#ffffffd9'; c.lineWidth = 3.4; for (let i = -2; i <= 2; i++) { c.beginPath(); if (o.sp === 1) { c.moveTo(cx - r * 1.3, cy + i * r * .42); c.lineTo(cx + r * 1.3, cy + i * r * .42); } else { c.moveTo(cx + i * r * .42, cy - r * 1.3); c.lineTo(cx + i * r * .42, cy + r * 1.3); } c.stroke(); } c.restore(); }
  c.fillStyle = '#ffffffa8'; c.beginPath(); c.ellipse(cx - r * .32, cy - r * .42, r * .3, r * .15, -.7, 0, 6.283); c.fill(); c.restore();
}
const CD_LEVELS = [
  { n: 'Sweet Start', moves: 20, goals: [{ k: 'score', v: 1200 }], goal: 'Score 1,200 points in 20 moves' },
  { n: 'Blue Rush', moves: 20, goals: [{ k: 'collect', t: 0, v: 20 }], goal: 'Collect 20 blue candies in 20 moves' },
  { n: 'Cherry Drop', moves: 26, cherries: [[0, 2], [0, 5]], goals: [{ k: 'cherry', v: 2 }], goal: 'Bring 2 cherries down in 26 moves' },
  { n: 'Licorice Locks', moves: 26, locks: [[7, 0], [7, 1], [7, 2], [7, 3], [7, 4], [7, 5], [7, 6], [7, 7]], goals: [{ k: 'lock', v: 8 }], goal: 'Break all 8 licorice locks in 26 moves' },
  { n: 'Double Trouble', moves: 24, goals: [{ k: 'collect', t: 4, v: 15 }, { k: 'collect', t: 5, v: 15 }], goal: 'Collect 15 yellow + 15 purple in 24 moves' },
  { n: 'Sky High', moves: 22, goals: [{ k: 'score', v: 4500 }], goal: 'Score 4,500 points in 22 moves' },
  { n: 'Locked Cherries', moves: 28, cherries: [[0, 1], [0, 4], [0, 6]], locks: [[7, 1], [7, 3], [7, 5], [7, 7]], goals: [{ k: 'cherry', v: 3 }, { k: 'lock', v: 4 }], goal: 'Drop 3 cherries and break 4 locks in 28 moves' },
  { n: 'Candy Master', moves: 30, goals: [{ k: 'score', v: 6500 }, { k: 'collect', t: 3, v: 25 }], goal: 'Score 6,500 and collect 25 green in 30 moves' }
];
function candyPlay(stage, L, lv, finish) {
  const { cv, c } = arena(stage, 360, 520), R = rng(newSeed()), pops = popups(), cs = 42, bx = 12, by = 100;
  const cand = o => o && o.k === 'c', same = (a, b) => cand(a) && cand(b) && a.t === b.t && a.sp !== 3 && b.sp !== 3;
  const mk = (t, r, q) => ({ k: 'c', t: t != null ? t : Math.floor(R() * 6), sp: 0, x: bx + q * cs, y: by + r * cs, sc: 1 });
  const B = []; for (let r = 0; r < CDN; r++) B.push(Array(CDN).fill(null));
  (L.locks || []).forEach(([r, q]) => { B[r][q] = { k: 'k', t: -1, sp: 0, x: bx + q * cs, y: by + r * cs, sc: 1 }; });
  (L.cherries || []).forEach(([r, q]) => { B[r][q] = { k: 'h', t: 6, sp: 0, x: bx + q * cs, y: by + r * cs, sc: 1 }; });
  for (let r = 0; r < CDN; r++) for (let q = 0; q < CDN; q++) { if (B[r][q]) continue; let t, g = 0; do { t = Math.floor(R() * 6); g++; } while (g < 50 && ((q >= 2 && same({ k: 'c', t, sp: 0 }, B[r][q - 1]) && same(B[r][q - 1], B[r][q - 2]) && B[r][q - 1].t === t) || (r >= 2 && B[r - 1][q] && B[r - 2][q] && B[r - 1][q].t === t && B[r - 2][q].t === t && cand(B[r - 1][q]) && cand(B[r - 2][q])))); B[r][q] = mk(t, r, q); }
  const gs = L.goals.map(g => Object.assign({ have: 0 }, g)); let score = 0, moves = L.moves, mode = 'idle', sel = null, pair = null, pend = null, chain = 0, T = 0, wait = 0, parts = [], over = false, idle = 0, hintMv = null;
  const needScore = (gs.find(g => g.k === 'score') || {}).v;
  const settled = () => { for (let r = 0; r < CDN; r++) for (let q = 0; q < CDN; q++) { const o = B[r][q]; if (o && (Math.abs(o.x - (bx + q * cs)) > .6 || Math.abs(o.y - (by + r * cs)) > .6)) return false; } return true; };
  const runs = () => {
    const set = new Set(), sp = [];
    for (let r = 0; r < CDN; r++) { let q = 0; while (q < CDN) { const a = B[r][q]; let e = q + 1; while (e < CDN && same(a, B[r][e])) e++; const len = e - q; if (cand(a) && len >= 3) { for (let k = q; k < e; k++) set.add(r * CDN + k); if (len >= 4) { const pm = pair && pair.find(p => p.r === r && p.c >= q && p.c < e); sp.push({ i: r * CDN + (pm ? pm.c : q + 1), sp: len >= 5 ? 3 : 2, t: a.t }); } } q = e; } }
    for (let q = 0; q < CDN; q++) { let r = 0; while (r < CDN) { const a = B[r][q]; let e = r + 1; while (e < CDN && same(a, B[e][q])) e++; const len = e - r; if (cand(a) && len >= 3) { for (let k = r; k < e; k++) set.add(k * CDN + q); if (len >= 4) { const pm = pair && pair.find(p => p.c === q && p.r >= r && p.r < e); sp.push({ i: (pm ? pm.r : r + 1) * CDN + q, sp: len >= 5 ? 3 : 1, t: a.t }); } } r = e; } }
    return { set, sp };
  };
  const expand = set => { let grow = true; while (grow) { grow = false;[...set].forEach(i => { const r = (i / CDN) | 0, q = i % CDN, o = B[r][q]; if (!cand(o)) return; if (o.sp === 1) for (let k = 0; k < CDN; k++) { const j = r * CDN + k; if (!set.has(j) && cand(B[r][k])) { set.add(j); grow = true; } } if (o.sp === 2) for (let k = 0; k < CDN; k++) { const j = k * CDN + q; if (!set.has(j) && cand(B[k][q])) { set.add(j); grow = true; } } }); } return set; };
  const swap = (a, b) => { const t = B[a.r][a.c]; B[a.r][a.c] = B[b.r][b.c]; B[b.r][b.c] = t; };
  const tryMove = (a, b) => {
    if (mode !== 'idle' || over) return; if (!cand(B[a.r][a.c]) || !cand(B[b.r][b.c])) { SFX.play('bad'); return; }
    swap(a, b); pair = [a, b]; SFX.play('slide'); const A = B[a.r][a.c], Bb = B[b.r][b.c];
    pend = (A.sp === 3 || Bb.sp === 3) ? { t: (A.sp === 3 && Bb.sp === 3) ? -1 : (A.sp === 3 ? Bb.t : A.t) } : null; mode = 'swap1'; sel = null; idle = 0; hintMv = null;
  };
  const clearSet = (set, specials) => {
    chain++; let pts = 0; const keep = new Map(); specials.forEach(s => keep.set(s.i, s)); const lockHit = new Set();
    set.forEach(i => { const r = (i / CDN) | 0, q = i % CDN, o = B[r][q]; if (!cand(o)) return; pts += 10; gs.forEach(g => { if (g.k === 'collect' && g.t === o.t % 6) g.have++; });
      [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dr, dc]) => { const rr_ = r + dr, qq = q + dc; if (rr_ >= 0 && qq >= 0 && rr_ < CDN && qq < CDN && B[rr_][qq] && B[rr_][qq].k === 'k') lockHit.add(rr_ * CDN + qq); });
      for (let k = 0; k < 4; k++) parts.push({ x: o.x + cs / 2, y: o.y + cs / 2, vx: (Math.random() - .5) * 240, vy: (Math.random() - .85) * 220, a: 0, col: CD_C[o.t % 6] });
      if (keep.has(i)) { o.sp = keep.get(i).sp; o.t = keep.get(i).t; o.sc = 1.4; } else { if (o.sp) pts += 40; B[r][q] = null; } });
    lockHit.forEach(i => { const r = (i / CDN) | 0, q = i % CDN, o = B[r][q]; for (let k = 0; k < 8; k++) parts.push({ x: o.x + cs / 2, y: o.y + cs / 2, vx: (Math.random() - .5) * 260, vy: (Math.random() - .8) * 240, a: 0, col: '#444' }); B[r][q] = null; pts += 60; gs.forEach(g => { if (g.k === 'lock') g.have++; }); SFX.play('crunch'); });
    pts *= chain; score += pts; pops.add('+' + pts, 180, 92, chain > 1 ? '#ffe65a' : '#fff'); SFX.play(chain > 3 ? 'clear' : chain > 1 ? 'good' : 'pop'); if (specials.length) SFX.play('perfect');
    if (chain >= 3) pops.add(chain >= 5 ? 'DIVINE!' : chain >= 4 ? 'DELICIOUS!' : 'SWEET!', 180, 270, '#ff7ad9');
  };
  const gravity = () => {
    for (let q = 0; q < CDN; q++) { let w = CDN - 1; for (let r = CDN - 1; r >= 0; r--) { const o = B[r][q]; if (o && o.k === 'k') { w = r - 1; continue; } if (o) { if (w !== r) { B[w][q] = o; B[r][q] = null; } w--; } } let n = 0; for (let r = w; r >= 0; r--) { const o = mk(null, r, q); o.y = by - (n + 1) * cs; n++; B[r][q] = o; } }
  };
  const harvest = () => { let got = 0; for (let q = 0; q < CDN; q++) { const o = B[CDN - 1][q]; if (o && o.k === 'h') { B[CDN - 1][q] = null; got++; gs.forEach(g => { if (g.k === 'cherry') g.have++; }); for (let k = 0; k < 8; k++) parts.push({ x: o.x + cs / 2, y: o.y + cs / 2, vx: (Math.random() - .5) * 200, vy: -Math.random() * 200, a: 0, col: '#ff3b52' }); pops.add('+500', o.x + cs / 2, o.y - 10, '#ff6b81'); score += 500; SFX.play('cash'); } } return got; };
  const hasMove = () => { for (let r = 0; r < CDN; r++) for (let q = 0; q < CDN; q++) for (const [dr, dc] of [[0, 1], [1, 0]]) { const r2 = r + dr, q2 = q + dc; if (r2 >= CDN || q2 >= CDN) continue; const a = B[r][q], b = B[r2][q2]; if (!cand(a) || !cand(b)) continue; if (a.sp === 3 || b.sp === 3) { hintMv = [{ r, c: q }, { r: r2, c: q2 }]; return true; } B[r][q] = b; B[r2][q2] = a; const s = runs().set.size; B[r][q] = a; B[r2][q2] = b; if (s) { hintMv = [{ r, c: q }, { r: r2, c: q2 }]; return true; } } return false; };
  const complete = () => gs.every(g => g.k === 'score' ? score >= g.v : g.have >= g.v);
  cv.addEventListener('pointerdown', e => { e.preventDefault(); if (mode !== 'idle' || over) return; idle = 0; const p = ptr(cv, e), q = Math.floor((p.x - bx) / cs), r = Math.floor((p.y - by) / cs); if (r < 0 || q < 0 || r >= CDN || q >= CDN) return; if (sel && Math.abs(sel.r - r) + Math.abs(sel.c - q) === 1) { const a = { r: sel.r, c: sel.c }; sel = null; tryMove(a, { r, c: q }); } else { sel = { r, c: q, px: p.x, py: p.y, sw: true }; SFX.play('tap'); } });
  cv.addEventListener('pointermove', e => { if (!sel || !sel.sw || mode !== 'idle') return; const p = ptr(cv, e), dx = p.x - sel.px, dy = p.y - sel.py; if (Math.hypot(dx, dy) > 18) { const d = Math.abs(dx) > Math.abs(dy) ? [0, Math.sign(dx)] : [Math.sign(dy), 0], a = { r: sel.r, c: sel.c }, b = { r: a.r + d[0], c: a.c + d[1] }; sel = null; if (b.r >= 0 && b.c >= 0 && b.r < CDN && b.c < CDN) tryMove(a, b); } });
  cv.addEventListener('pointerup', () => { if (sel) sel.sw = false; });
  const end = win => { over = true; const left = moves / L.moves; setTimeout(() => { stop(); finish({ win, stars: left >= .4 ? 3 : left >= .15 ? 2 : 1, score, msg: 'Out of moves!', info: win ? moves + ' moves left' : '' }); }, 650); };
  const goalIcon = (g, x, y) => { if (g.k === 'score') { tx(c, '⭐', x, y, 16, '#fff'); } else if (g.k === 'collect') cdDraw(c, x - 14, y - 15, 28, { k: 'c', t: g.t, sp: 0 }, 0); else if (g.k === 'cherry') cdDraw(c, x - 14, y - 15, 28, { k: 'h', t: 6 }, 0); else cdDraw(c, x - 14, y - 15, 28, { k: 'k', t: -1 }, 0); };
  const stop = anim(dt => {
    if (!stage.isConnected) { stop(); return; } T += dt; wait -= dt; if (mode === 'idle' && !over) idle += dt;
    for (let r = 0; r < CDN; r++) for (let q = 0; q < CDN; q++) { const o = B[r][q]; if (!o) continue; const tx_ = bx + q * cs, ty = by + r * cs; o.x += (tx_ - o.x) * Math.min(1, dt * 16); o.y += (ty - o.y) * Math.min(1, dt * (o.y < ty - 4 ? 12 : 16)); o.sc += (1 - o.sc) * Math.min(1, dt * 10); }
    if (wait <= 0 && settled() && !over) {
      if (mode === 'swap1') { const rs = runs(); if (pend) { const a = pair[0], b = pair[1], set = new Set([a.r * CDN + a.c, b.r * CDN + b.c]); for (let r = 0; r < CDN; r++) for (let q = 0; q < CDN; q++) { const o = B[r][q]; if (cand(o) && (pend.t < 0 || o.t === pend.t)) set.add(r * CDN + q); } moves--; chain = 0; clearSet(expand(set), []); SFX.play('boom'); pend = null; mode = 'fall'; wait = .25; } else if (!rs.set.size) { swap(pair[0], pair[1]); mode = 'swapback'; SFX.play('bad'); } else { moves--; chain = 0; clearSet(expand(new Set(rs.set)), rs.sp); mode = 'fall'; wait = .22; } }
      else if (mode === 'swapback') { mode = 'idle'; pair = null; }
      else if (mode === 'fall') { gravity(); const h = harvest(); if (h) { mode = 'fall'; wait = .25; } else { mode = 'check'; wait = .12; } }
      else if (mode === 'check') { const rs = runs(); if (rs.set.size) { pair = null; clearSet(expand(new Set(rs.set)), rs.sp); mode = 'fall'; wait = .22; } else if (complete()) { mode = 'done'; pops.add('SWEET!', 180, 250, '#ffe65a'); end(true); } else if (moves <= 0) { mode = 'done'; end(false); } else if (!hasMove()) { for (let r = 0; r < CDN; r++) for (let q = 0; q < CDN; q++) if (cand(B[r][q])) { B[r][q] = mk(null, r, q); B[r][q].y -= 70; } pops.add('Shuffle!', 180, 250, '#fff'); mode = 'check'; wait = .5; } else { mode = 'idle'; pair = null; idle = 0; } }
    }
    // background
    const bg = c.createLinearGradient(0, 0, 0, 520); bg.addColorStop(0, '#6fb8ff'); bg.addColorStop(1, '#2d78c8'); c.fillStyle = bg; c.fillRect(0, 0, 360, 520);
    for (let i = 0; i < 9; i++) { c.fillStyle = '#ffffff18'; c.beginPath(); c.arc((i * 71 + T * 8) % 400 - 20, (i * 97) % 520, 22 + (i % 3) * 14, 0, 6.283); c.fill(); }
    // HUD
    c.fillStyle = '#10305acc'; rr(c, 8, 8, 344, 82, 14); c.fill();
    const mg = c.createRadialGradient(46, 40, 4, 46, 46, 32); mg.addColorStop(0, '#ffb05a'); mg.addColorStop(1, '#d4540a'); c.fillStyle = mg; c.beginPath(); c.arc(46, 48, 30, 0, 6.283); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 3; c.stroke(); tx(c, String(moves), 46, 46, 28, '#fff', 'center', '#7a2e00'); tx(c, 'MOVES', 46, 72, 9, '#ffe', 'center');
    tx(c, 'SCORE', 120, 24, 11, '#9fd0ff', 'left'); tx(c, String(score), 120, 44, 24, '#ffe65a', 'left', '#000');
    gs.forEach((g, i) => { const x = 130 + i * 78, y = 68; c.fillStyle = '#ffffff22'; rr(c, x - 36 + 40, y - 14, 76, 28, 10); c.fill(); goalIcon(g, x + 22, y); const rem = g.k === 'score' ? Math.max(0, g.v - score) : Math.max(0, g.v - g.have); tx(c, rem === 0 ? '✔' : String(rem), x + 58, y + 1, 15, rem === 0 ? '#7dff9a' : '#fff', 'center', '#000'); });
    // board
    c.fillStyle = '#0a2a5a55'; rr(c, bx - 5, by - 5, cs * CDN + 10, cs * CDN + 10, 12); c.fill();
    for (let r = 0; r < CDN; r++) for (let q = 0; q < CDN; q++) { c.fillStyle = (r + q) % 2 ? '#ffffff2e' : '#ffffff1a'; c.fillRect(bx + q * cs, by + r * cs, cs, cs); }
    c.save(); c.beginPath(); c.rect(bx, by, cs * CDN, cs * CDN); c.clip();
    for (let r = 0; r < CDN; r++) for (let q = 0; q < CDN; q++) { const o = B[r][q]; if (!o) continue; const s = cs * o.sc; cdDraw(c, o.x + (cs - s) / 2, o.y + (cs - s) / 2, s, o, T); }
    c.restore();
    if (sel && mode === 'idle') { c.strokeStyle = '#fff'; c.lineWidth = 3; rr(c, bx + sel.c * cs + 1, by + sel.r * cs + 1, cs - 2, cs - 2, 8); c.stroke(); }
    if (mode === 'idle' && idle > 6 && hintMv) { const k = .5 + .5 * Math.sin(T * 7); c.strokeStyle = `rgba(255,255,255,${.4 + k * .5})`; c.lineWidth = 3; hintMv.forEach(p => { rr(c, bx + p.c * cs + 2, by + p.r * cs + 2, cs - 4, cs - 4, 8); c.stroke(); }); }
    parts = parts.filter(q => (q.a += dt) < .6); parts.forEach(q => { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 520 * dt; c.globalAlpha = 1 - q.a / .6; c.fillStyle = q.col; c.beginPath(); c.arc(q.x, q.y, 3.6, 0, 6.283); c.fill(); c.globalAlpha = 1; });
    pops.draw(c, dt);
  });
  stage.__dbg = () => ({ B, gs, moves, mode, score });
  hasMove(); return () => { over = true; stop(); };
}
const G_CANDY2 = chSolo({ id: 'candy', name: 'Candy Crush', icon: '🍬', cls: 'candy', levels: CD_LEVELS, play: candyPlay, desc: 'Swipe candies to match 3 or more. Every level has a different challenge: scores, colour goals, cherries and licorice locks. Match 4 for a striped candy and 5 for a colour bomb!' });

/* ================= BUILD TOWER (isometric) ================= */
const TW_LEVELS = [7, 10, 15, 20, 25, 30, 35].map((n, i) => ({ n: n + ' Blocks', blocks: n, time: [30, 38, 52, 66, 80, 96, 112][i], goal: `Stack ${n} blocks in ${[30, 38, 52, 66, 80, 96, 112][i]} seconds` }));
function towerPlay(stage, L, lv, finish) {
  const { cv, c } = arena(stage, 360, 560), pops = popups(), D = 80, H = 30, K = .866;
  const P = (u, v, z, camY) => [180 + (u - v) * K * .62 + 8, 430 + (u + v) * .5 * .62 - z + camY];
  let stack = [{ u: -50, w: 100 }], cur = { u: -190, w: 100, dir: 1 }, placed = 0, score = 0, perfects = 0, time = L.time, over = false, cam = 0, camT = 0, falling = [], t = 0, shake = 0, combo = 0, started = false;
  const speed = () => Math.min(380, 150 + placed * 9 + lv * 8);
  const face = (pts, col) => { c.fillStyle = col; c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.closePath(); c.fill(); };
  const block = (u, w, z, hue, alpha, cy) => {
    const u1 = u + w, top = z + H; c.save(); if (alpha != null) c.globalAlpha = alpha;
    const A = P(u, D, top, cy), Bq = P(u1, D, top, cy), C = P(u1, 0, top, cy), Dd = P(u, 0, top, cy);
    const A0 = P(u, D, z, cy), B0 = P(u1, D, z, cy), C0 = P(u1, 0, z, cy);
    face([A, A0, B0, Bq], `hsl(${hue},28%,66%)`); face([Bq, B0, C0, C], `hsl(${hue},26%,74%)`); face([A, Bq, C, Dd], `hsl(${hue},30%,84%)`);
    c.strokeStyle = `hsl(${hue},25%,40%)`; c.lineWidth = 1.2; c.beginPath(); c.moveTo(A[0], A[1]); c.lineTo(Bq[0], Bq[1]); c.lineTo(C[0], C[1]); c.moveTo(Bq[0], Bq[1]); c.lineTo(B0[0], B0[1]); c.stroke();
    c.fillStyle = `hsl(${hue},40%,32%)`; const nl = Math.max(1, Math.floor(w / 34)); for (let k = 0; k < nl; k++) { const uu = u + (k + .5) * w / nl - 6, a = P(uu, D, top - 9, cy), b = P(uu + 12, D, top - 9, cy), b2 = P(uu + 12, D, top - 22, cy), a2 = P(uu, D, top - 22, cy); face([a, b, b2, a2], `hsl(${hue},45%,30%)`); }
    for (let k = 0; k < 2; k++) { const vv = 14 + k * 34, a = P(u1, vv, top - 9, cy), b = P(u1, vv + 18, top - 9, cy), b2 = P(u1, vv + 18, top - 22, cy), a2 = P(u1, vv, top - 22, cy); face([a, b, b2, a2], `hsl(${hue},45%,36%)`); }
    c.restore();
  };
  const floorHue = i => (250 + i * 7) % 360;
  const drop = () => {
    if (over) return; started = true; const top = stack[stack.length - 1], a = Math.max(cur.u, top.u), b = Math.min(cur.u + cur.w, top.u + top.w), ov = b - a;
    if (ov <= 4) { over = true; falling.push({ u: cur.u, w: cur.w, z: stack.length * H, vz: 0, hue: floorHue(stack.length) }); SFX.play('buzz'); setTimeout(() => { stop(); finish({ win: false, stars: 0, score, msg: 'The block missed!', info: placed + ' of ' + L.blocks + ' blocks' }); }, 900); return; }
    const d = cur.u - top.u; placed++; const perfect = Math.abs(d) < 5; combo = perfect ? combo + 1 : 0;
    if (perfect) { perfects++; score += 20 + combo * 8; stack.push({ u: top.u, w: top.w }); pops.add('PERFECT +' + (20 + combo * 8), 180, 200, '#ffd54a'); SFX.play('perfect'); shake = .18; }
    else { score += 10; stack.push({ u: a, w: ov }); if (d < 0) falling.push({ u: cur.u, w: -d, z: stack.length * H, vz: 0, hue: floorHue(stack.length) }); else falling.push({ u: b, w: cur.u + cur.w - b, z: stack.length * H, vz: 0, hue: floorHue(stack.length) }); SFX.play('stack'); pops.add('+10', 180, 220, '#fff'); }
    camT = Math.max(0, (stack.length - 5) * H);
    if (placed >= L.blocks) { over = true; SFX.play('clear'); const pr = perfects / L.blocks; setTimeout(() => { stop(); finish({ win: true, stars: pr >= .5 ? 3 : pr >= .2 ? 2 : 1, score: score + Math.round(time) * 5, info: perfects + ' perfect drops · ' + Math.round(time) + 's left' }); }, 800); return; }
    const nt = stack[stack.length - 1]; cur = { u: cur.dir > 0 ? 200 : -200 - nt.w, w: nt.w, dir: cur.dir > 0 ? -1 : 1 };
  };
  stage.__dbg = () => ({ stack, cur, placed, over, time });
  cv.addEventListener('pointerdown', e => { e.preventDefault(); drop(); });
  const stop = anim(dt => {
    if (!stage.isConnected) { stop(); return; } t += dt; shake = Math.max(0, shake - dt); cam += (camT - cam) * Math.min(1, dt * 4);
    if (!over && started) { time -= dt; if (time <= 0) { time = 0; over = true; SFX.play('buzz'); setTimeout(() => { stop(); finish({ win: false, stars: 0, score, msg: 'Time is up!', info: placed + ' of ' + L.blocks + ' blocks' }); }, 500); } else if (time < 8 && Math.floor(time) !== Math.floor(time + dt)) SFX.play('tick'); }
    if (!over) { cur.u += cur.dir * speed() * dt; if (cur.u < -220) { cur.u = -220; cur.dir = 1; } if (cur.u + cur.w > 220) { cur.u = 220 - cur.w; cur.dir = -1; } }
    // sky
    const sky = c.createLinearGradient(0, 0, 0, 560); sky.addColorStop(0, '#ffd39a'); sky.addColorStop(.38, '#ffe9bd'); sky.addColorStop(.42, '#7fd8ee'); sky.addColorStop(1, '#3aa8d8'); c.fillStyle = sky; c.fillRect(0, 0, 360, 560);
    c.fillStyle = '#ffb347'; c.beginPath(); c.arc(190, 232, 70, Math.PI, 0); c.fill(); c.fillStyle = '#ffffff99'; for (let i = 0; i < 3; i++) { c.beginPath(); c.ellipse(((t * 12 + i * 140) % 460) - 50, 160 + i * 40, 50, 14, 0, 0, 6.283); c.fill(); }
    [[60, 340], [290, 300]].forEach(([bx2, by2], i) => { const bob = Math.sin(t * 1.2 + i) * 6; c.fillStyle = '#bfe9f5'; c.beginPath(); c.ellipse(bx2, by2 + bob, 24, 30, 0, 0, 6.283); c.fill(); c.fillStyle = '#fff'; c.fillRect(bx2 - 3, by2 + bob - 28, 6, 56); c.fillStyle = '#c0803a'; c.fillRect(bx2 - 7, by2 + bob + 30, 14, 9); });
    c.strokeStyle = '#ffffff88'; c.lineWidth = 2; for (let i = 0; i < 7; i++) { const y = 262 + i * 22; c.beginPath(); c.moveTo((i * 53 + t * 15) % 360, y); c.lineTo(((i * 53 + t * 15) % 360) + 30, y); c.stroke(); }
    const sx = shake ? (Math.random() - .5) * 6 : 0; c.save(); c.translate(sx, 0);
    // ground
    const gy = P(0, 0, 0, cam)[1] + 36; if (gy < 640) { c.fillStyle = '#f4b99a'; c.fillRect(0, gy, 360, 560); c.fillStyle = '#7fc45a'; c.fillRect(0, gy - 12, 360, 14); c.fillStyle = '#5aa13c'; [[30, 0], [320, 6]].forEach(([x, o]) => { c.beginPath(); c.ellipse(x, gy - 24 + o, 12, 24, 0, 0, 6.283); c.fill(); }); }
    block(-130, 260, -H, 215, null, cam);
    stack.forEach((b, i) => block(b.u, b.w, i * H, floorHue(i), null, cam));
    falling.forEach(f => { f.vz += 900 * dt; f.z -= f.vz * dt; block(f.u, f.w, f.z, f.hue, Math.max(0, 1 + f.z / 500 * 0 + (f.vz > 600 ? -(f.vz - 600) / 500 : 0)), cam); }); falling = falling.filter(f => f.z > -400);
    if (!over || placed >= L.blocks) { if (!over) { const z = stack.length * H + 90, cx = P(cur.u + cur.w / 2, D / 2, z, cam); const top = P(cur.u + cur.w / 2, D / 2, z + 700, cam); c.strokeStyle = '#444'; c.lineWidth = 3; c.beginPath(); c.moveTo(cx[0], 0); c.lineTo(cx[0], cx[1] - 38 + 0); c.stroke(); c.fillStyle = '#f2c230'; rr(c, cx[0] - 16, cx[1] - 44, 32, 22, 4); c.fill(); c.strokeStyle = '#555'; c.lineWidth = 4; c.beginPath(); c.moveTo(cx[0] - 12, cx[1] - 24); c.lineTo(cx[0] - 18, cx[1] - 8); c.moveTo(cx[0] + 12, cx[1] - 24); c.lineTo(cx[0] + 18, cx[1] - 8); c.stroke(); block(cur.u, cur.w, z - H - 12, floorHue(stack.length), null, cam); } }
    c.restore();
    // HUD
    c.fillStyle = '#0006'; c.fillRect(0, 0, 360, 54); c.fillStyle = '#ff6a3a'; rr(c, 12, 10, 36, 34, 6); c.fill(); tx(c, '🏢', 30, 28, 20, '#fff'); pill(c, 54, 14, 110, 28, '#46688f'); tx(c, placed + ' / ' + L.blocks, 109, 29, 18, '#fff'); tx(c, '+' + score, 200, 28, 18, '#7dff9a', 'left', '#000');
    pill(c, 262, 12, 88, 30, time < 8 ? '#c92a2a' : '#2d7be5'); tx(c, '⏱ ' + Math.ceil(time), 306, 28, 16, '#fff');
    pops.draw(c, dt); if (!started && !over) tx(c, 'TAP to drop the block!', 180, 520, 18, '#fff', 'center', '#000');
  });
  return () => { over = true; stop(); };
}
const G_TOWER2 = chSolo({ id: 'tower', name: 'Build Tower', icon: '🏗️', cls: 'tower', levels: TW_LEVELS, play: towerPlay, desc: 'Tap to drop the swinging block onto the tower. Reach the target number of blocks before time runs out. Bigger towers get more time. Perfect drops give bonus points!' });

/* ================= RUNUP (3-lane runner) ================= */
const RU_LEVELS = [
  { n: 'Warm Up', goal: 'Collect 20 💎 gems', kind: 'gems', v: 20, dens: 1, spd: 13 },
  { n: 'City Dash', goal: 'Run 500 metres', kind: 'dist', v: 500, dens: 1, spd: 14 },
  { n: 'Hurdle Master', goal: 'Jump over 8 hurdles', kind: 'jump', v: 8, dens: 1.2, spd: 14 },
  { n: 'Slide Pro', goal: 'Slide under 8 beams', kind: 'slide', v: 8, dens: 1.2, spd: 14 },
  { n: 'Gem Hunter', goal: 'Collect 60 💎 gems', kind: 'gems', v: 60, dens: 1.3, spd: 15 },
  { n: 'Marathon', goal: 'Run 1,200 metres', kind: 'dist', v: 1200, dens: 1.4, spd: 16 },
  { n: 'Treasure Run', goal: 'Collect 120 💎 gems', kind: 'gems', v: 120, dens: 1.5, spd: 17 },
  { n: 'Ultimate Runup', goal: 'Collect 200 💎 and keep a ♥', kind: 'gems', v: 200, dens: 1.7, spd: 18 }
];
function runPlay(stage, L, lv, finish) {
  const { cv, c } = arena(stage, 360, 520), R = rng(newSeed()), pops = popups();
  const pad = document.createElement('div'); pad.className = 'rupad'; pad.innerHTML = '<button data-k="l">◀</button><button data-k="u">▲ Jump</button><button data-k="d">▼ Slide</button><button data-k="r">▶</button>'; stage.appendChild(pad);
  const HZ = 150, GY = 440, LW = 92, pr = d => 1 / (1 + Math.max(-.6, d) * .13), X = (lane, d) => 180 + lane * LW * pr(d), Y = d => HZ + (GY - HZ) * pr(d);
  let lane = 0, lx = 0, jump = 0, slide = 0, vy = 0, dist = 0, speed = L.spd, hearts = 3, gems = 0, score = 0, jumps = 0, slides = 0, inv = 0, t = 0, over = false, objs = [], genZ = 22, flash = 0;
  const seg = () => {
    const kinds = ['gems', 'gems', 'hurdle', 'beam', 'cone', 'car', 'gems']; const k = kinds[Math.floor(R() * kinds.length)], ln = Math.floor(R() * 3) - 1;
    if (k === 'gems') { const n = 5 + Math.floor(R() * 4); for (let i = 0; i < n; i++) objs.push({ k: 'gem', lane: ln, z: genZ + i * 2.2, y: R() < .3 ? 1 : 0 }); genZ += n * 2.2 + 6; }
    else if (k === 'hurdle') { for (let l = -1; l <= 1; l++) if (R() < .75) objs.push({ k: 'hurdle', lane: l, z: genZ }); objs.push({ k: 'gem', lane: ln, z: genZ - 1, y: 1 }); genZ += 14 / L.dens; }
    else if (k === 'beam') { objs.push({ k: 'beam', lane: -9, z: genZ }); for (let i = 0; i < 3; i++) objs.push({ k: 'gem', lane: ln, z: genZ - 3 + i * 1.8 }); genZ += 15 / L.dens; }
    else if (k === 'cone') { const a = Math.floor(R() * 3) - 1, b = (a + 1 + Math.floor(R() * 2) - 1 + 3) % 3 - 1; objs.push({ k: 'cone', lane: a, z: genZ }); if (R() < .5 && b !== a) objs.push({ k: 'cone', lane: b, z: genZ }); genZ += 12 / L.dens; }
    else { objs.push({ k: 'car', lane: ln, z: genZ }); for (let i = 0; i < 4; i++) objs.push({ k: 'gem', lane: (ln + 1 + 3) % 3 - 1 === ln ? 0 : (ln === 0 ? 1 : 0), z: genZ + i * 2 }); genZ += 16 / L.dens; }
  };
  const goalDone = () => L.kind === 'gems' ? gems >= L.v : L.kind === 'dist' ? dist >= L.v : L.kind === 'jump' ? jumps >= L.v : slides >= L.v;
  const prog = () => L.kind === 'gems' ? gems : L.kind === 'dist' ? Math.floor(dist) : L.kind === 'jump' ? jumps : slides;
  const act = k => { if (over) return; if (k === 'l' && lane > -1) { lane--; SFX.play('slide'); } else if (k === 'r' && lane < 1) { lane++; SFX.play('slide'); } else if (k === 'u' && jump <= 0 && !slide) { vy = 8.2; jump = .001; SFX.play('jump'); } else if (k === 'd' && jump <= 0) { slide = .7; SFX.play('whoosh'); } else if (k === 'd') { vy = -14; } };
  $$('[data-k]', pad).forEach(b => b.onpointerdown = e => { e.preventDefault(); act(b.dataset.k); });
  let sp0 = null; cv.addEventListener('pointerdown', e => { sp0 = ptr(cv, e); e.preventDefault(); }); cv.addEventListener('pointerup', e => { if (!sp0) return; const p = ptr(cv, e), dx = p.x - sp0.x, dy = p.y - sp0.y; if (Math.hypot(dx, dy) > 24) { if (Math.abs(dx) > Math.abs(dy)) act(dx > 0 ? 'r' : 'l'); else act(dy < 0 ? 'u' : 'd'); } else act(p.x < 180 ? 'l' : 'r'); sp0 = null; });
  const keyf = e => { const m = { ArrowLeft: 'l', ArrowRight: 'r', ArrowUp: 'u', ArrowDown: 'd' }[e.key]; if (m) act(m); }; document.addEventListener('keydown', keyf);
  const end = (win, msg) => { over = true; document.removeEventListener('keydown', keyf); const st = hearts >= 3 ? 3 : hearts === 2 ? 2 : 1; setTimeout(() => { stop(); finish({ win, stars: st, score: score + gems * 10 + Math.floor(dist), msg, info: Math.floor(dist) + ' m · ' + gems + ' gems' }); }, 600); };
  const runner = (x, y, run, sl, jp) => {
    c.save(); c.translate(x, y); const s = 1.35 * (sl ? .72 : 1), sw = Math.sin(run * 14) * 8; c.scale(1, sl ? .7 : 1); c.fillStyle = '#00000033'; c.beginPath(); c.ellipse(0, 4 + (jp ? 26 : 0) * 0, 26 * s, 8, 0, 0, 6.283); c.fill();
    c.translate(0, -jp * 24); c.fillStyle = '#1f2433'; rr(c, -14, -34 + (jp ? 0 : sw * .3), 12, 34, 5); c.fill(); rr(c, 2, -34 - (jp ? 0 : sw * .3), 12, 34, 5); c.fill(); c.fillStyle = '#f2f2f2'; rr(c, -16, -4 + (jp ? 0 : sw * .3), 15, 8, 3); c.fill(); rr(c, 1, -4 - (jp ? 0 : sw * .3), 15, 8, 3); c.fill();
    c.fillStyle = '#ffc61a'; rr(c, -22, -76, 44, 46, 12); c.fill(); c.fillStyle = '#e3a500'; rr(c, -22, -50, 44, 6, 3); c.fill(); c.fillStyle = '#ffc61a'; rr(c, -30, -72 + sw * .4, 11, 30, 6); c.fill(); rr(c, 19, -72 - sw * .4, 11, 30, 6); c.fill();
    c.fillStyle = '#ffb4a0'; c.beginPath(); c.arc(0, -90, 13, 0, 6.283); c.fill(); c.fillStyle = '#e8123e'; c.beginPath(); c.arc(0, -94, 14, Math.PI, 0); c.fill(); for (let i = -2; i <= 2; i++) { c.beginPath(); c.moveTo(i * 5, -104); c.lineTo(i * 5 + 3, -112 - (i % 2) * 3); c.lineTo(i * 5 + 7, -102); c.fill(); }
    c.fillStyle = '#2d3a8c'; rr(c, -17, -74, 34, 30, 7); c.fill(); c.fillStyle = '#ff7a1a'; c.beginPath(); c.arc(0, -60, 7, 0, 6.283); c.fill(); tx(c, 'S', 0, -59, 9, '#fff'); c.restore();
  };
  const stop = anim(dt => {
    if (!stage.isConnected) { stop(); document.removeEventListener('keydown', keyf); return; } t += dt; inv = Math.max(0, inv - dt); flash = Math.max(0, flash - dt);
    if (!over) { speed = Math.min(L.spd + 10, L.spd + dist / 140); dist += speed * dt; lx += (lane - lx) * Math.min(1, dt * 12); if (jump > 0) { vy -= 22 * dt; jump += vy * dt; if (jump <= 0) { jump = 0; vy = 0; } } if (slide > 0) slide -= dt; while (genZ < dist + 60) seg(); }
    c.fillStyle = '#000'; const sky = c.createLinearGradient(0, 0, 0, HZ + 20); sky.addColorStop(0, '#4a9cf0'); sky.addColorStop(1, '#bfe4ff'); c.fillStyle = sky; c.fillRect(0, 0, 360, 520);
    c.fillStyle = '#ffffffcc'; for (let i = 0; i < 3; i++) { c.beginPath(); c.ellipse(((t * 8 + i * 150) % 440) - 40, 40 + i * 24, 44, 12, 0, 0, 6.283); c.fill(); }
    // sides: buildings
    for (let i = 40; i >= 0; i--) { const dd = i * 3 - (dist % 3), p = pr(dd), y = Y(dd); if (dd < -2) continue; const w = 150 * p + 10, h = (100 + (((Math.floor(dist / 3) + i) * 37) % 5) * 28) * p * 1.6; const hue = (((Math.floor(dist / 3) + i) * 53) % 5); const cols = ['#e07a4f', '#c4c8d6', '#9aa6c8', '#d9b26a', '#7fa88c'];[[-1], [1]].forEach(([sd]) => { c.fillStyle = cols[hue]; const xL = 180 + sd * (LW * 1.65 * p) + (sd < 0 ? -w : 0); c.fillRect(xL, y - h, w, h); c.fillStyle = '#00000022'; c.fillRect(xL, y - h, w, h * .12); c.fillStyle = '#ffffff66'; for (let k = 1; k < 4; k++) c.fillRect(xL + w * .15, y - h + k * h * .22, w * .7, h * .09); }); }
    // road
    c.fillStyle = '#35363f'; c.beginPath(); c.moveTo(180 - LW * 1.55 * pr(60), Y(60)); c.lineTo(180 + LW * 1.55 * pr(60), Y(60)); c.lineTo(180 + LW * 1.55 * 1.9, 520); c.lineTo(180 - LW * 1.55 * 1.9, 520); c.closePath(); c.fill();
    c.fillStyle = '#9aa0ab'; c.beginPath(); c.moveTo(180 - LW * 1.55 * pr(60), Y(60)); c.lineTo(180 - LW * 1.7 * pr(60), Y(60)); c.lineTo(180 - LW * 1.7 * 1.9, 520); c.lineTo(180 - LW * 1.55 * 1.9, 520); c.fill(); c.beginPath(); c.moveTo(180 + LW * 1.55 * pr(60), Y(60)); c.lineTo(180 + LW * 1.7 * pr(60), Y(60)); c.lineTo(180 + LW * 1.7 * 1.9, 520); c.lineTo(180 + LW * 1.55 * 1.9, 520); c.fill();
    c.strokeStyle = '#d0d3da'; c.lineWidth = 3; for (let i = 0; i < 30; i++) { const d0 = i * 3 - (dist % 3), d1 = d0 + 1.4; if (d0 < -1) continue;[-.5, .5].forEach(l => { c.beginPath(); c.moveTo(X(l, d0), Y(d0)); c.lineTo(X(l, d1), Y(d1)); c.lineWidth = 3 * pr(d0) + 1; c.stroke(); }); }
    // objects far to near
    const vis = objs.filter(o => o.z - dist > -1.2 && o.z - dist < 60).sort((a, b) => b.z - a.z);
    vis.forEach(o => {
      const d = o.z - dist, p = pr(d), y = Y(d); if (o.k === 'gem') { if (o.got) return; const x = X(o.lane, d), yy = y - (o.y ? 55 : 22) * p; c.fillStyle = '#7ef0ff'; c.beginPath(); c.moveTo(x, yy - 14 * p * 1.6); c.lineTo(x + 12 * p * 1.6, yy - 3 * p * 1.6); c.lineTo(x, yy + 14 * p * 1.6); c.lineTo(x - 12 * p * 1.6, yy - 3 * p * 1.6); c.closePath(); c.fill(); c.fillStyle = '#d9fbff'; c.beginPath(); c.moveTo(x, yy - 14 * p * 1.6); c.lineTo(x + 5 * p * 1.6, yy - 3 * p * 1.6); c.lineTo(x - 5 * p * 1.6, yy - 3 * p * 1.6); c.fill(); return; }
      if (o.k === 'beam') { const xl = X(-1.5, d), xr = X(1.5, d), h = 90 * p; c.fillStyle = '#e8a41a'; c.fillRect(xl, y - h * 1.0, xr - xl, 16 * p); c.fillStyle = '#222'; for (let i = 0; i < 8; i++) c.fillRect(xl + i * (xr - xl) / 8, y - h * 1.0, (xr - xl) / 16, 16 * p); c.fillStyle = '#b8bcc8'; c.fillRect(xl, y - h, 8 * p, h); c.fillRect(xr - 8 * p, y - h, 8 * p, h); return; }
      const x = X(o.lane, d), w = 70 * p;
      if (o.k === 'hurdle') { c.fillStyle = '#f2c230'; c.fillRect(x - w / 2, y - 40 * p, 7 * p, 40 * p); c.fillRect(x + w / 2 - 7 * p, y - 40 * p, 7 * p, 40 * p); c.fillRect(x - w / 2, y - 40 * p, w, 9 * p); c.fillStyle = '#333'; for (let i = 0; i < 5; i++) c.fillRect(x - w / 2 + i * w / 5, y - 40 * p, w / 10, 9 * p); }
      else if (o.k === 'cone') { c.fillStyle = '#ff6a1a'; c.beginPath(); c.moveTo(x, y - 52 * p); c.lineTo(x + 20 * p, y); c.lineTo(x - 20 * p, y); c.fill(); c.fillStyle = '#fff'; c.fillRect(x - 11 * p, y - 28 * p, 22 * p, 7 * p); }
      else if (o.k === 'car') { c.fillStyle = '#d93a2e'; rr(c, x - 34 * p, y - 40 * p, 68 * p, 34 * p, 6 * p); c.fill(); c.fillStyle = '#ffffffcc'; rr(c, x - 24 * p, y - 54 * p, 48 * p, 18 * p, 5 * p); c.fill(); c.fillStyle = '#111'; c.fillRect(x - 32 * p, y - 8 * p, 12 * p, 8 * p); c.fillRect(x + 20 * p, y - 8 * p, 12 * p, 8 * p); }
    });
    // player
    const px = X(lx, 0); if (!(inv > 0 && Math.floor(t * 14) % 2)) runner(px, GY + 8, t * speed * .12, slide > 0, jump);
    // collisions
    if (!over) objs.forEach(o => { const d = o.z - dist; if (o.k === 'gem') { if (!o.got && d < .5 && d > -.9 && (o.lane === lane || Math.abs(o.lane - lx) < .5) && ((o.y && jump > .5) || (!o.y && jump < 1.1))) { o.got = 1; gems++; score += 10; SFX.play('coin'); pops.add('+1', px, GY - 110, '#7ef0ff'); } return; }
      if (o.done) return; if (d < .5 && d > -.7) { const same = o.k === 'beam' || (Math.abs(o.lane - lx) < .55); if (!same) return; if (o.k === 'hurdle') { if (jump > 1.0) { o.done = 1; jumps++; pops.add('JUMP!', px, GY - 130, '#ffd54a'); SFX.play('good'); return; } } else if (o.k === 'beam') { if (slide > 0) { o.done = 1; slides++; pops.add('SLIDE!', px, GY - 130, '#ffd54a'); SFX.play('good'); return; } } else if (o.k === 'car' && jump > 2.2) { return; } o.done = 1; if (inv <= 0) { hearts--; inv = 1.6; flash = .25; SFX.play('hit'); pops.add('OUCH!', px, GY - 130, '#ff5252'); speed *= .7; dist -= 0; if (hearts <= 0) end(false, 'You crashed!'); } } });
    objs = objs.filter(o => o.z > dist - 3);
    if (!over && goalDone()) { SFX.play('clear'); end(true); }
    if (flash > 0) { c.fillStyle = '#ff2a2a'; c.globalAlpha = flash * 1.5; c.fillRect(0, 0, 360, 520); c.globalAlpha = 1; }
    // HUD
    c.fillStyle = '#00000055'; rr(c, 90, 10, 180, 34, 10); c.fill(); tx(c, 'SCORE: ' + (score + Math.floor(dist)), 180, 28, 17, '#fff', 'center', '#1a3a6a');
    c.fillStyle = '#0a4f6acc'; rr(c, 8, 52, 70, 50, 12); c.fill(); tx(c, '💎', 26, 70, 18, '#fff'); tx(c, L.kind === 'gems' ? gems + '/' + L.v : String(gems), 50, 90, 12, '#fff'); c.fillStyle = '#6a0a1fcc'; rr(c, 8, 108, 70, 40, 12); c.fill(); tx(c, '❤', 26, 128, 18, '#ff4d6d'); tx(c, hearts + '/3', 56, 128, 14, '#fff');
    c.fillStyle = '#00000066'; rr(c, 90, 52, 180, 22, 8); c.fill(); c.fillStyle = '#ffd54a'; rr(c, 92, 54, Math.max(6, 176 * Math.min(1, prog() / L.v)), 18, 6); c.fill(); tx(c, L.goal.replace(/[💎♥]/g, '').trim(), 180, 63, 11, '#fff', 'center', '#000');
    pops.draw(c, dt);
  });
  stage.__dbg = () => ({ gems, hearts, dist, lane, jump, objs });
  return () => { over = true; stop(); document.removeEventListener('keydown', keyf); };
}
const G_RUNUP = chSolo({ id: 'runup', name: 'Runup', icon: '🏃', cls: 'runup', levels: RU_LEVELS, play: runPlay, desc: 'Run through the city! Swipe left/right to change lanes, up to jump and down to slide. Collect gems, dodge cars and cones. Every level has a different challenge.' });
