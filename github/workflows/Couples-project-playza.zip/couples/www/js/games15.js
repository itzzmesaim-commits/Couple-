/* Playza - Dare Duel (18+): a hard steady-hand duel; the loser draws a punishment */
const DD_F = [
  // spicy-but-sweet (10)
  'Give your partner a long, deep kiss for 30 seconds.', 'Take off one piece of clothing of your choice.', 'Kiss your partner softly on the neck, 10 times.',
  'Send your partner a flirty selfie in your best pose.', 'Sit on your partner’s lap and whisper what you love about them.', 'Give your partner a slow, sensual 2-minute massage.',
  'Whisper your dream romantic night idea in your partner’s ear.', 'Let your partner choose where you kiss them: cheek, hand or neck.', 'Slow dance very close with your partner for 1 minute, no talking.',
  'Look into your partner’s eyes and say what you find most attractive about them.',
  // romantic (5)
  'Write “I love you” on your partner’s hand with a kiss.', 'Say 3 things you adore about your partner.', 'Hug your partner for 30 seconds without letting go.', 'Sing one romantic line to your partner.', 'Give your partner a kiss on the forehead and say “mine”.',
  // funny (5)
  'Do your best catwalk across the room.', 'Talk like a robot for the next 2 minutes.', 'Do 10 funny faces in a row.', 'Dance like nobody is watching for 30 seconds.', 'Say “I lost, and I’m your servant” in a dramatic voice.',
  // normal (5)
  'Tell your partner your happiest memory together.', 'Share one secret you never told your partner.', 'Say what you want to do together this year.', 'Give your partner a genuine compliment.', 'Pick the movie for the next movie night.'
];
const DD_M = [
  // spicy-but-sweet (10)
  'Give your partner a slow 30 second kiss.', 'Take off your shirt and flex for 10 seconds.', 'Kiss your partner softly on the neck, 10 times.', 'Send your partner a flirty selfie with your best look.',
  'Hold your partner close and whisper something naughty but sweet.', 'Give your partner a 2-minute massage.', 'Kiss your partner’s hand, then the cheek, then the lips.', 'Tell your partner your favourite thing about their body, politely.',
  'Pull your partner close and slow dance for 1 minute.', 'Whisper your dream romantic date idea in your partner’s ear.',
  // romantic (5)
  'Say “I love you” in 3 different styles.', 'Hug your partner from behind for 30 seconds.', 'Write a 2-line love poem right now.', 'Hold your partner’s hand and say what you promise them.', 'Kiss your partner’s forehead and say “you are my everything”.',
  // caring (5)
  'Make your partner a cup of tea or coffee.', 'Ask your partner how their day really was and listen fully.', 'Give your partner a 1-minute head massage.', 'Tell your partner one thing you will do to make their week easier.', 'Bring your partner a glass of water and a hug.',
  // dares (5)
  'Do 15 push-ups right now.', 'Do a filmy hero entry with a dialogue.', 'Imitate your partner for 1 minute.', 'Call your partner by a funny nickname for the whole night.', 'Hold a plank for 30 seconds.'
];
DD_F.push('Kiss your partner in a deep lip lock.', 'Take off half of your outfit (one or two pieces).', 'Tell your partner what helps you relax and de-stress the most.', 'Tell your partner your favourite way to be romanced.',
  'Write a short love note for your partner and read it aloud.', 'Plan a surprise romantic date and tell your partner the details.', 'Feed your partner a bite of food with your hands, romantically.', 'Dance a slow song with your partner, cheek to cheek.', 'Whisper “I choose you” and give a long hug.',
  'Do 10 jumping jacks while singing a love song.', 'Stand like a statue for 1 minute while your partner tries to make you laugh.', 'Do 10 squats while saying your partner’s name each time.', 'Hold a plank for 1 minute.', 'Do 10 sit-ups with your partner counting out loud.',
  'Tell your partner your favourite childhood memory.', 'Say what you are most grateful for today.', 'Tell your partner your biggest dream.', 'Name 3 things you would do on a perfect holiday together.', 'Say what made you fall for your partner.', 'Share the funniest thing you remember about your partner.');
DD_M.push('Tell your partner your “magic word” — the sweet thing that makes them smile.', 'Kiss your partner for 30 seconds without stopping.', 'Tell your partner which spot on you is the most ticklish or sensitive, and let them kiss it.',
  'Ask your partner how they are feeling and just listen for 2 minutes.', 'Massage your partner’s feet for 2 minutes.', 'Tell your partner one worry of theirs you will help with this week.', 'Make your partner their favourite snack.', 'Give your partner a long forehead kiss and a hug.',
  'Do 10 push-ups while saying “I love you”.', 'Walk like a model across the room.', 'Do a funny dance for 30 seconds.', 'Hold a wall-sit for 1 minute.', 'Do your best movie villain laugh 3 times.',
  'Write your partner a 4-line romantic shayari.', 'Whisper 3 reasons you chose your partner.', 'Hold your partner close, forehead to forehead, for 1 minute.', 'Slow dance in the dark with your partner.', 'Tell your partner your favourite memory of the two of you.');
DD_F.push('Do 10 squats non-stop, then freeze like a statue for 1 minute.',
  'Hold a wall sit for 1 minute while your partner counts.',
  'Hold your breath for 20 seconds while your partner tickles you.',
  'Do 10 jumping jacks, then give your partner a kiss.',
  'Stay completely still for 1 minute while your partner whispers to you.',
  'Tell your partner which kind of kiss you like the most, then show it.',
  'What is your favourite way to relax with your partner?',
  'What is one place you want to travel to together?',
  'What is your favourite memory of the two of you?',
  'What do you want your partner to do more often?',
  'Which of your partner’s habits do you love the most?',
  'Describe your perfect lazy day together.');
DD_M.push('Do 10 push-ups non-stop, then give your partner a kiss.',
  'Hold a plank for 1 minute while your partner counts.',
  'Stay frozen like a statue for 1 minute.',
  'Dance in a funny way for 30 seconds.',
  'Do your best animal imitation for 20 seconds.',
  'Tell your partner which kiss you like the most and show it.',
  'Whisper to your partner what you find most attractive about them.',
  'Let your partner choose where to be kissed: hand, cheek or neck.',
  'Ask your partner what they need from you today and promise to do it.',
  'Tell your partner one worry you have, and ask about theirs.',
  'Plan tomorrow’s dinner together and cook for your partner.',
  'Give your partner a 1 minute foot or hand massage.',
  'Tell your partner what makes you feel most loved by them.');
DD_F.push('Take off half of your outfit, only if you are comfortable (your choice).',
  'Give your partner a long, slow kiss wherever they choose: cheek, hand, neck or lips.',
  'Do a slow, flirty dance for your partner for 1 minute, with your choice of song.',
  'Tell your partner honestly: a passionate night or a cosy cuddle, which do you prefer tonight?',
  'Show your partner your most flirty look and pose for 1 minute.',
  'Stand in your favourite outfit and let your partner admire you for 1 minute.');
DD_M.push('Send your partner a flirty shirtless selfie, only if you choose to.',
  'Whisper your “magic word” in your partner’s ear, the one that makes them blush.',
  'Give your partner a slow 30 second kiss on the neck, your choice of spot.',
  'Give your partner a slow 1 minute back or shoulder massage, your choice of spot.',
  'Tell your partner which part of you is most sensitive or ticklish, and let them kiss it if you choose.',
  'Send your partner a flirty pic in their favourite outfit, only if you choose to.');
const DD_CF = [], DD_CM = [];
const ddList = g => g === 'f' ? (DD_CF.length ? DD_CF : DD_F) : (DD_CM.length ? DD_CM : DD_M);   // your own cards (data/dd_custom) replace the built-in ones when present
const ddCenter = (y, seed) => { const R = rng(seed + 7), a1 = R() * 6, a2 = R() * 6, m1 = 70 + R() * 25, m2 = 28 + R() * 20; return 180 + m1 * Math.sin(y / 75 + a1) + m2 * Math.sin(y / 31 + a2); };
const ddHW = y => 30 - (500 - y) / 440 * 14;
const G_DARE = (() => {
  const g = duel({
    id: 'dareduel', name: 'Dare Duel', icon: '🔥', adult: true, low: false,
    desc: 'Thread the needle! Drag your finger through the narrow tunnel without touching the walls. The winner is safe — the loser draws a punishment. Play only with mutual consent.',
    bot: () => 300 + Math.floor(Math.random() * 1000),
    play(box, seed, done) {
      const { cv, c } = arena(box, 360, 540), pops = popups();
      let down = false, px = 180, py = 500, prog = 0, T = 0, over = false, started = false, trail = [], flash = 0, t = 0;
      const end = (ok, msg) => { if (over) return; over = true; const p = Math.max(0, (500 - prog) / 460), sc = Math.round(p * 1000 + (ok ? 500 + Math.max(0, 30 - T) * 20 : 0)); SFX.play(ok ? 'win' : 'buzz'); flash = 1; setTimeout(() => { stop(); fin(box, sc, done, msg + ' · ' + sc + ' pts'); }, 1100); };
      const upd = p => { if (over) return; const y = Math.max(40, Math.min(500, p.y)); if (!started) { if (Math.hypot(p.x - 180, p.y - 500) > 30) return; started = true; } px = p.x; py = p.y; if (y < prog || prog === 0) prog = Math.min(prog || 500, y); const cx = ddCenter(py, seed), hw = ddHW(py); trail.push([px, py]); if (trail.length > 60) trail.shift(); if (Math.abs(px - cx) > hw || py > 520) { end(false, 'Touched the wall!'); return; } if (py <= 46) end(true, 'Needle threaded!'); };
      cv.addEventListener('pointerdown', e => { e.preventDefault(); try { cv.setPointerCapture(e.pointerId); } catch (x) { } down = true; upd(ptr(cv, e)); });
      cv.addEventListener('pointermove', e => { if (down) upd(ptr(cv, e)); });
      cv.addEventListener('pointerup', () => { if (down && started && !over) end(false, 'Finger lifted'); down = false; });
      const stop = anim(dt => {
        if (!box.isConnected) { stop(); return; } t += dt; if (started && !over) { T += dt; if (T > 30) end(false, 'Time up'); }
        c.fillStyle = '#12061a'; c.fillRect(0, 0, 360, 540); const bg = c.createLinearGradient(0, 0, 0, 540); bg.addColorStop(0, '#3a0d3a'); bg.addColorStop(1, '#12061a'); c.fillStyle = bg; c.fillRect(0, 0, 360, 540);
        c.beginPath(); for (let y = 500; y >= 40; y -= 4) { const x = ddCenter(y, seed) - ddHW(y); y === 500 ? c.moveTo(x, y) : c.lineTo(x, y); } for (let y = 40; y <= 500; y += 4) c.lineTo(ddCenter(y, seed) + ddHW(y), y); c.closePath(); c.fillStyle = '#26102e'; c.fill(); c.strokeStyle = flash > 0 && over ? '#ff3b5c' : '#ff4fa3'; c.lineWidth = 3; c.shadowColor = '#ff4fa3'; c.shadowBlur = 12; c.stroke(); c.shadowBlur = 0;
        c.strokeStyle = '#ffffff22'; c.setLineDash([6, 8]); c.beginPath(); for (let y = 500; y >= 40; y -= 4) { const x = ddCenter(y, seed); y === 500 ? c.moveTo(x, y) : c.lineTo(x, y); } c.stroke(); c.setLineDash([]);
        c.fillStyle = '#44e08a'; c.beginPath(); c.arc(180, 500, 16, 0, 6.283); c.fill(); tx(c, 'START', 180, 524, 10, '#44e08a');
        c.fillStyle = '#ffd54a'; c.beginPath(); c.arc(ddCenter(40, seed), 40, 14, 0, 6.283); c.fill(); tx(c, 'FINISH', ddCenter(40, seed), 18, 10, '#ffd54a');
        trail.forEach((q, i) => { c.globalAlpha = i / trail.length * .6; c.fillStyle = '#fff'; c.beginPath(); c.arc(q[0], q[1], 4, 0, 6.283); c.fill(); }); c.globalAlpha = 1;
        if (started) { c.fillStyle = over ? '#ff3b5c' : '#fff'; c.beginPath(); c.arc(px, py, 7, 0, 6.283); c.fill(); }
        if (!started && !over) tx(c, 'Touch the green START and drag up', 180, 270, 15, '#fff', 'center', '#000');
        else tx(c, '⏱ ' + Math.ceil(Math.max(0, 30 - T)) + 's', 330, 520, 13, '#fff');
        pops.draw(c, dt);
      });
      return () => { over = true; stop(); };
    }
  });
  const base = g.render, bmove = g.move;
  g.move = function (s, m, seat) {
    if (m.a === 'pun') {
      if (s.winner == null || s.winner === 'draw' || s.pun || seat === s.winner) return null;
      const gg = m.g === 'f' ? 'f' : 'm', n = ddList(gg).length, i = (m.i | 0) < 0 ? -1 : Math.min(n - 1, m.i | 0);
      s.pun = { g: gg, i }; return s;
    }
    return bmove.call(this, s, m, seat);
  };
  g.render = function (el, s, seat, send) {
    base.call(this, el, s, seat, send);
    if (s.winner == null) return;
    const loser = s.winner === 'draw' ? -1 : 1 - s.winner, div = document.createElement('div'); div.className = 'ddbox';
    if (s.winner === 'draw') div.innerHTML = '<h3>🤝 Draw!</h3><p class="mut">Nobody is punished. Play again!</p>';
    else if (s.pun) { const lst = ddList(s.pun.g); div.innerHTML = s.pun.i < 0 ? '<h3>🍀 You are Lucky!</h3><p class="ddc lucky">No punishment this time</p>' : `<h3>😈 Punishment${seat === loser ? ' for you' : ''}</h3><p class="ddc">${esc(lst[s.pun.i])}</p><small class="mut">Any dare can be skipped. Play only with mutual consent.</small>`; }
    else if (seat === loser) { div.innerHTML = '<h3>😅 You lost!</h3><button class="btn full" id="ddt">🎴 Tap for punishment</button>'; }
    else div.innerHTML = '<h3>🏆 You won!</h3><p class="mut">Waiting for your partner to draw the punishment…</p>';
    el.appendChild(div);
    const t = $('#ddt', div); if (t) t.onclick = () => {
      div.innerHTML = '<h3>Choose</h3><button class="btn full" id="ddf">👩 Female</button><button class="btn sec full" id="ddm">👨 Male</button>';
      const pick = gg => { SFX.play('pop'); const lucky = Math.random() < .15; send({ a: 'pun', g: gg, i: lucky ? -1 : Math.floor(Math.random() * ddList(gg).length) }); };
      $('#ddf', div).onclick = () => pick('f'); $('#ddm', div).onclick = () => pick('m');
    };
  };
  return g;
})();
/* Your own extra cards. Put them in data/dd_custom.txt (or dd_custom.json). Easy format: one card per line, starting with "F:" (female) or "M:" (male). JSON {"f":[...],"m":[...]} also works; curly quotes are fixed automatically. */
function ddParse(t) {
  t = String(t || '');
  const add = j => { (j.f || []).forEach(x => { if (typeof x === 'string' && x.trim()) DD_CF.push(x); }); (j.m || []).forEach(x => { if (typeof x === 'string' && x.trim()) DD_CM.push(x); }); };
  try { add(JSON.parse(t)); return; } catch (e) { }   // valid JSON: cards are used exactly as written
  t = t.replace(/[\u201C\u201D]/g, '"').replace(/[\u2018\u2019]/g, "'");
  try { const j = JSON.parse(t.replace(/,(\s*[\]}])/g, '$1')); (j.f || []).forEach(x => { if (typeof x === 'string' && x.trim()) DD_CF.push(x.trim()); }); (j.m || []).forEach(x => { if (typeof x === 'string' && x.trim()) DD_CM.push(x.trim()); }); return; } catch (e) { }
  t.split(/\r?\n/).forEach(l => { l = l.trim(); const m = /(?:^|[\[\s,])([fFmM])\s*[:\-]\s*(.+)$/.exec(l); if (m && !/^["']?[fFmM]["']?\s*:\s*\[?\s*\]?,?$/.test(l)) { const x = m[2].replace(/^["']+|["']*,?\s*$/g, '').trim(); if (x) (m[1].toLowerCase() === 'f' ? DD_CF : DD_CM).push(x); } });
}
['data/dd_custom.txt', 'data/dd_custom.json'].forEach(u => { try { fetch(u).then(r => r.ok ? r.text() : '').then(ddParse).catch(() => { }); } catch (e) { } });
