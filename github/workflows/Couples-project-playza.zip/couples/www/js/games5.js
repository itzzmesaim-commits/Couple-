/* Playza - Wave 1 rebuild: Tic Tac Toe (neon, best of 3), Ludo (full 15x15 board), Match It (gem battle) */

/* ================= TIC TAC TOE ================= */
const ttWin = (b, p) => TTT_LINES.find(l => l.every(i => b[i] === p));
const TT_X = '<svg viewBox="0 0 100 100"><path d="M24 24L76 76M76 24L24 76" stroke="#ff3b5c" stroke-width="15" stroke-linecap="round"/></svg>';
const TT_O = '<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="27" fill="none" stroke="#ffe14a" stroke-width="15"/></svg>';
Object.assign(G_TTT, {
  name: 'Tic Tac Toe', icon: '❌', desc: 'Best of 3 rounds. Get three in a row!', simul: false,
  init: () => ({ b: Array(9).fill(null), turn: 0, winner: null, sc: [0, 0], round: 1, rw: null, line: null, first: 0 }),
  status: (s, seat) => s.winner != null ? '' : s.rw != null ? (s.rw === 'draw' ? '🤝 Round draw' : s.rw === seat ? '✅ You won the round!' : '❌ You lost the round') : (s.turn === seat ? '👉 Your turn' : '⏳ Opponent’s turn'),
  move(s, m, seat) {
    if (m.a === 'next') {
      if (s.rw == null || s.winner != null || s.turn !== seat) return null;
      s.b = Array(9).fill(null); s.rw = null; s.line = null; s.round++; s.first = 1 - s.first; s.turn = s.first; return s;
    }
    const i = m.i | 0;
    if (s.rw != null || s.winner != null || s.turn !== seat || i < 0 || i > 8 || s.b[i] != null) return null;
    s.b[i] = seat;
    const l = ttWin(s.b, seat);
    if (l) { s.sc[seat]++; s.rw = seat; s.line = l; }
    else if (s.b.every(x => x != null)) s.rw = 'draw';
    else { s.turn = 1 - seat; return s; }
    if (s.sc[seat] >= 2 || s.round >= 3) { s.winner = s.sc[0] === s.sc[1] ? 'draw' : (s.sc[0] > s.sc[1] ? 0 : 1); return s; }
    s.turn = 1 - s.first; return s;
  },
  render(el, s, seat, send) {
    const chip = i => `<div class="ttp ${s.turn === i && s.rw == null && s.winner == null ? 'on' : ''}"><span class="ttsym">${i ? TT_O : TT_X}</span><b>${s.sc[i]}</b><small>${i === seat ? 'You' : 'Opponent'}</small></div>`;
    let line = '';
    if (s.line) { const a = s.line[0], c = s.line[2]; line = `<svg class="ttline" viewBox="0 0 3 3"><line x1="${a % 3 + .5}" y1="${Math.floor(a / 3) + .5}" x2="${c % 3 + .5}" y2="${Math.floor(c / 3) + .5}" stroke="#fff" stroke-width=".09" stroke-linecap="round"/></svg>`; }
    el.innerHTML = `<div class="tthead">${chip(0)}<div class="ttr"><b>Round ${Math.min(s.round, 3)}</b><small>Best of 3</small></div>${chip(1)}</div>
      <div class="ttboard">${s.b.map((v, i) => `<button class="ttc ${v == null ? '' : 'on'} ${s.line && s.line.includes(i) ? 'win' : ''}" data-i="${i}">${v == null ? '' : v ? TT_O : TT_X}</button>`).join('')}${line}</div>`;
    $$('[data-i]', el).forEach(b => b.onclick = () => { if (s.turn === seat && s.rw == null && s.winner == null) send({ i: +b.dataset.i }); });
    if (s.rw != null && s.winner == null && s.turn === seat) {
      const key = s.gid + '|' + s.round;
      if (el.__nk !== key) { el.__nk = key; setTimeout(() => send({ a: 'next' }), 1500); }
    }
  }
});
G_TTT.bot = (s, seat) => {
  if (s.winner != null || s.turn !== seat) return null;
  if (s.rw != null) return { a: 'next' };
  const free = s.b.map((v, i) => v == null ? i : -1).filter(i => i >= 0);
  if (Math.random() < 0.2) return { i: pick(free) };
  const r = tttBest(s.b.slice(), seat, seat); return { i: pick(r.all) };
};

/* ================= LUDO (2 players, 4 tokens each, standard 52-cell track) ================= */
const LD_RING = (() => {
  const p = [];
  for (let c = 1; c <= 5; c++) p.push([6, c]); for (let r = 5; r >= 0; r--) p.push([r, 6]); p.push([0, 7], [0, 8]);
  for (let r = 1; r <= 5; r++) p.push([r, 8]); for (let c = 9; c <= 14; c++) p.push([6, c]); p.push([7, 14], [8, 14]);
  for (let c = 13; c >= 9; c--) p.push([8, c]); for (let r = 9; r <= 14; r++) p.push([r, 8]); p.push([14, 7], [14, 6]);
  for (let r = 13; r >= 9; r--) p.push([r, 6]); for (let c = 5; c >= 0; c--) p.push([8, c]); p.push([7, 0], [6, 0]);
  return p;
})();
const LD_START = [39, 13], LD_SAFE = new Set([0, 13, 26, 39, 8, 21, 34, 47]);
const LD_HOME = [[[13, 7], [12, 7], [11, 7], [10, 7], [9, 7]], [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]]];
const LD_YARD = [[9, 0], [0, 9]], LD_COL = ['#2f7bff', '#2ecc71'], LD_SLOT = [[1.8, 1.8], [1.8, 4.2], [4.2, 1.8], [4.2, 4.2]];
const ldIdx = (seat, pr) => (LD_START[seat] + pr - 1) % 52;
function ldLegal(s, seat, roll) {
  const out = []; s.p[seat].forEach((pr, i) => { if (pr === -1) { if (roll === 6) out.push(i); } else if (pr < 57 && pr + roll <= 57) out.push(i); }); return out;
}
function ldXY(seat, pr, i) {
  if (pr === -1) return [LD_YARD[seat][1] + LD_SLOT[i][1], LD_YARD[seat][0] + LD_SLOT[i][0]];
  if (pr <= 51) { const [r, c] = LD_RING[ldIdx(seat, pr)]; return [c + .5, r + .5]; }
  if (pr <= 56) { const [r, c] = LD_HOME[seat][pr - 52]; return [c + .5, r + .5]; }
  return [7.5 + (seat ? .35 : -.35) + (i % 2 ? .2 : -.2), 7.5 + (seat ? -.35 : .35) + (i > 1 ? .2 : -.2)];
}
function ldBoardSVG() {
  const cols = { red: '#ff4d4d', green: '#2ecc71', yellow: '#ffc83d', blue: '#2f7bff' };
  let h = '<rect x="0" y="0" width="15" height="15" rx=".6" fill="#f6f1e7"/>';
  [[0, 0, cols.red], [0, 9, cols.green], [9, 0, cols.blue], [9, 9, cols.yellow]].forEach(([r, c, col]) => {
    h += `<rect x="${c}" y="${r}" width="6" height="6" fill="${col}"/><rect x="${c + 1}" y="${r + 1}" width="4" height="4" rx=".5" fill="#fff"/>`;
    LD_SLOT.forEach(([a, b]) => { h += `<circle cx="${c + b}" cy="${r + a}" r=".5" fill="${col}" opacity=".35"/>`; });
  });
  LD_RING.forEach(([r, c], i) => {
    const sc = { 0: cols.red, 13: cols.green, 26: cols.yellow, 39: cols.blue }[i];
    h += `<rect x="${c}" y="${r}" width="1" height="1" fill="${sc || '#fff'}" stroke="#9a8f7c" stroke-width=".06"/>`;
    if (LD_SAFE.has(i) && !sc) h += `<text x="${c + .5}" y="${r + .72}" font-size=".7" text-anchor="middle" fill="#9a8f7c">★</text>`;
  });
  [[[7, 1], [7, 2], [7, 3], [7, 4], [7, 5]], LD_HOME[1], [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9]], LD_HOME[0]].forEach((cells, k) => {
    cells.forEach(([r, c]) => { h += `<rect x="${c}" y="${r}" width="1" height="1" fill="${[cols.red, cols.green, cols.yellow, cols.blue][k]}" stroke="#fff" stroke-width=".06"/>`; });
  });
  h += `<polygon points="6,6 6,9 7.5,7.5" fill="${cols.red}"/><polygon points="6,6 9,6 7.5,7.5" fill="${cols.green}"/><polygon points="9,6 9,9 7.5,7.5" fill="${cols.yellow}"/><polygon points="6,9 9,9 7.5,7.5" fill="${cols.blue}"/>`;
  return h;
}
Object.assign(G_LUDO, {
  name: 'Ludo', icon: '🏠', sym: ['🔵', '🟢'], botDelay: 1250, desc: 'Roll a 6 to bring a token out. Capture rivals and get all four tokens home first!', simul: false,
  init: () => ({ p: [[-1, -1, -1, -1], [-1, -1, -1, -1]], turn: 0, roll: null, last: null, rc: 0, winner: null, msg: '' }),
  status: (s, seat) => s.winner != null ? '' : s.turn !== seat ? '⏳ Opponent’s turn' : (s.roll == null ? '🎲 Roll the dice' : '👉 Tap a glowing token'),
  move(s, m, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    if (m.a === 'roll') {
      if (s.roll != null) return null;
      const r = 1 + rnd(6); s.last = r; s.rc = (s.rc || 0) + 1; s.msg = '';
      if (!ldLegal(s, seat, r).length) { s.roll = null; s.turn = 1 - seat; s.msg = 'No move possible'; } else s.roll = r;
      return s;
    }
    if (m.a === 'tok') {
      if (s.roll == null || !ldLegal(s, seat, s.roll).includes(m.i)) return null;
      const pr = s.p[seat][m.i], np = pr === -1 ? 1 : pr + s.roll; let extra = s.roll === 6; s.msg = '';
      s.p[seat][m.i] = np;
      if (np <= 51) {
        const idx = ldIdx(seat, np), o = 1 - seat;
        if (!LD_SAFE.has(idx)) s.p[o] = s.p[o].map(q => (q >= 1 && q <= 51 && ldIdx(o, q) === idx) ? (extra = true, s.msg = 'Captured!', -1) : q);
      }
      if (np === 57) { extra = true; s.msg = 'Token home!'; }
      s.roll = null;
      if (s.p[seat].every(x => x === 57)) { s.winner = seat; return s; }
      if (!extra) s.turn = 1 - seat;
      return s;
    }
    return null;
  },
  bot(s, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    if (s.roll == null) return { a: 'roll' };
    const lg = ldLegal(s, seat, s.roll); if (!lg.length) return null;
    let best = lg[0], bs = -1;
    for (const i of lg) {
      const pr = s.p[seat][i], np = pr === -1 ? 1 : pr + s.roll; let sc = Math.random() * 3 + np * 0.2;
      if (pr === -1) sc += 30; if (np === 57) sc += 40; else if (np >= 52) sc += 18;
      if (np <= 51) { const idx = ldIdx(seat, np), o = 1 - seat; if (s.p[o].some(q => q >= 1 && q <= 51 && ldIdx(o, q) === idx) && !LD_SAFE.has(idx)) sc += 60; if (LD_SAFE.has(idx)) sc += 8; }
      if (sc > bs) { bs = sc; best = i; }
    }
    return { a: 'tok', i: best };
  },
  render(el, s, seat, send) {
    let R = el.__ld;
    if (!R) {
      el.innerHTML = `<div class="ldwrap"><div class="ldchip" id="ld1"></div><svg class="ldboard" viewBox="0 0 15 15">${ldBoardSVG()}<g id="ldt"></g></svg><div class="ldchip" id="ld0"></div>
        <div class="dr3-stage" id="dstg"><div class="dr3-slot" id="dslot"></div><div class="dr3-side"><div class="dr3-turn" id="dtn"></div><button class="rollbtn dr3-roll" id="rl">🎲 ROLL</button></div></div><div class="ldmsg" id="lm"></div></div>`;
      el.__dice = dr3Dice({ size: 76, n: 1 }); $('#dslot', el).appendChild(el.__dice);
      const g = $('#ldt', el); const toks = [];
      for (let o = 0; o < 2; o++) for (let i = 0; i < 4; i++) {
        const t = document.createElementNS('http://www.w3.org/2000/svg', 'g'); t.setAttribute('class', 'tk');
        t.innerHTML = `<circle r=".62" fill="transparent" class="hit"/><circle r=".4" fill="${LD_COL[o]}" stroke="#fff" stroke-width=".09"/><circle r=".16" cx="-.1" cy="-.12" fill="#fff" opacity=".55"/>`;
        t.dataset.o = o; t.dataset.i = i; g.appendChild(t); toks.push(t);
      }
      R = el.__ld = { toks, rc: -1 };
    }
    const mine = s.turn === seat && s.winner == null, legal = mine && s.roll != null ? ldLegal(s, seat, s.roll) : [];
    const dice = el.__dice, rl = $('#rl', el), stg = $('#dstg', el);
    R.cur = [s, seat, send];
    if (R.rc !== s.rc) {
      if (R.rc !== -1 && s.last) {
        dice.dr3roll(s.last, { dur: 850 }); R.until = Date.now() + 850; clearTimeout(R.tm); R.tm = setTimeout(() => { if (el.isConnected && R.cur) G_LUDO.render(el, ...R.cur); }, 880);
      } else dice.dr3set(s.last || 1);
      R.rc = s.rc;
    } else if (!(R.until > Date.now())) dice.dr3set(s.last || 1);
    const rolling = R.until > Date.now();
    if (rolling) legal.length = 0;
    const occ = {};
    for (let o = 0; o < 2; o++) for (let i = 0; i < 4; i++) { const xy = ldXY(o, s.p[o][i], i); if (s.p[o][i] > -1 && s.p[o][i] < 57) { const k = xy.join(','); (occ[k] = occ[k] || []).push(o * 4 + i); } }
    R.toks.forEach(t => {
      const o = +t.dataset.o, i = +t.dataset.i, pr = s.p[o][i]; let [x, y] = ldXY(o, pr, i);
      const grp = occ[[x, y].join(',')];
      if (grp && grp.length > 1) { const k = grp.indexOf(o * 4 + i); x += ((k % 3) - 1) * .22; y += (Math.floor(k / 3) - .5) * .3; }
      t.style.transform = `translate(${x}px,${y}px)`;
      const can = o === seat && legal.includes(i);
      t.setAttribute('class', 'tk' + (can ? ' legal' : '') + (pr === 57 ? ' fin' : ''));
      t.onclick = can ? () => send({ a: 'tok', i }) : null;
    });
    const chip = (o, id) => { const e = $('#' + id, el); e.innerHTML = `<i style="background:${LD_COL[o]}"></i><b>${o === seat ? 'You' : 'Opponent'}</b><span>🏠 ${s.p[o].filter(x => x === 57).length}/4</span>`; e.className = 'ldchip' + (s.turn === o && s.winner == null ? ' on' : ''); };
    chip(0, 'ld0'); chip(1, 'ld1');
    stg.className = 'dr3-stage ' + (s.winner != null ? '' : s.turn === seat ? 'mine' : 'theirs') + (rolling ? ' rolling' : '');
    stg.style.setProperty('--tc', LD_COL[s.turn] || '#fff');
    $('#dtn', el).textContent = s.winner != null ? 'Game over' : rolling ? 'Rolling…' : s.turn !== seat ? 'Opponent’s turn' : (s.roll == null ? 'Your turn' : 'You rolled ' + s.roll + ' · pick a token');
    rl.disabled = !(mine && s.roll == null) || rolling; rl.onclick = () => send({ a: 'roll' });
    $('#dslot', el).onclick = () => { if (!rl.disabled) rl.click(); };
    $('#dslot', el).classList.toggle('dr3-tap', !rl.disabled);
    $('#lm', el).textContent = s.msg || '';
  }
});

/* ================= MATCH IT (gem battle, turn-based) ================= */
const GN = 8, GT = 6;
function gemMatches(g) {
  const m = new Set();
  for (let r = 0; r < GN; r++) for (let c = 0; c < GN; c++) {
    const v = g[r * GN + c]; if (v < 0) continue;
    if (c < GN - 2 && g[r * GN + c + 1] === v && g[r * GN + c + 2] === v) { m.add(r * GN + c); m.add(r * GN + c + 1); m.add(r * GN + c + 2); }
    if (r < GN - 2 && g[(r + 1) * GN + c] === v && g[(r + 2) * GN + c] === v) { m.add(r * GN + c); m.add((r + 1) * GN + c); m.add((r + 2) * GN + c); }
  }
  return m;
}
function gemHasMove(g) {
  for (let r = 0; r < GN; r++) for (let c = 0; c < GN; c++) for (const [dr, dc] of [[0, 1], [1, 0]]) {
    if (r + dr >= GN || c + dc >= GN) continue;
    const a = r * GN + c, b = (r + dr) * GN + c + dc, t = g[a]; g[a] = g[b]; g[b] = t;
    const ok = gemMatches(g).size > 0; g[b] = g[a]; g[a] = t; if (ok) return true;
  }
  return false;
}
function gemFresh(R) { let g, t = 0; do { g = Array.from({ length: GN * GN }, () => Math.floor(R() * GT)); t++; } while ((gemMatches(g).size || !gemHasMove(g)) && t < 300); return g; }
function gemResolve(s, R) {
  let chain = 0, total = 0, dmg = 0;
  for (; ;) {
    const m = gemMatches(s.g); if (!m.size) break;
    chain++; total += m.size; dmg += m.size * 3 * chain; m.forEach(i => { s.g[i] = -1; });
    for (let c = 0; c < GN; c++) { const col = []; for (let r = GN - 1; r >= 0; r--) if (s.g[r * GN + c] >= 0) col.push(s.g[r * GN + c]); while (col.length < GN) col.push(Math.floor(R() * GT)); for (let r = GN - 1, k = 0; r >= 0; r--, k++) s.g[r * GN + c] = col[k]; }
  }
  return { total, chain, dmg };
}
Object.assign(G_MEM, {
  name: 'Match It', icon: '💎', simul: false, desc: 'Swap gems to match 3 or more. Every match hurts your rival. Drop their HP to zero!',
  init() { const rs = newSeed(); return { g: gemFresh(rng(rs)), hp: [100, 100], turn: 0, winner: null, rs, n: 0, ev: null }; },
  status: (s, seat) => s.winner != null ? '' : (s.turn === seat ? '👉 Swap two gems' : '⏳ Opponent’s turn'),
  move(s, m, seat) {
    if (s.winner != null || s.turn !== seat || m.a !== 'swap') return null;
    const i = m.i | 0, j = m.j | 0;
    if (i < 0 || j < 0 || i >= GN * GN || j >= GN * GN) return null;
    if (Math.abs(Math.floor(i / GN) - Math.floor(j / GN)) + Math.abs((i % GN) - (j % GN)) !== 1) return null;
    const t = s.g[i]; s.g[i] = s.g[j]; s.g[j] = t;
    if (!gemMatches(s.g).size) return null;
    const R = rng(s.rs + (s.n + 1) * 7919), r = gemResolve(s, R);
    s.hp[1 - seat] = Math.max(0, s.hp[1 - seat] - r.dmg); s.ev = { by: seat, total: r.total, chain: r.chain, dmg: r.dmg }; s.n++;
    if (s.hp[1 - seat] <= 0) { s.winner = seat; return s; }
    if (s.n >= 40) { s.winner = s.hp[0] === s.hp[1] ? 'draw' : (s.hp[0] > s.hp[1] ? 0 : 1); return s; }
    s.turn = 1 - seat;
    if (!gemHasMove(s.g)) s.g = gemFresh(rng(s.rs + s.n * 31));
    return s;
  },
  bot(s, seat) {
    if (s.winner != null || s.turn !== seat) return null;
    let best = null, bs = -1;
    for (let r = 0; r < GN; r++) for (let c = 0; c < GN; c++) for (const [dr, dc] of [[0, 1], [1, 0]]) {
      if (r + dr >= GN || c + dc >= GN) continue;
      const i = r * GN + c, j = (r + dr) * GN + c + dc, ns = G_MEM.move(clone(s), { a: 'swap', i, j }, seat);
      if (!ns) continue;
      const sc = ns.ev.dmg + Math.random() * 4; if (sc > bs) { bs = sc; best = { a: 'swap', i, j }; }
    }
    return best;
  },
  render(el, s, seat, send) {
    if (el.__gs !== s.gid) { el.__gs = s.gid; el.__sel = -1; }
    const mine = s.turn === seat && s.winner == null, sel = el.__sel;
    const bar = o => `<div class="gembar ${s.turn === o && s.winner == null ? 'on' : ''}"><b>${o === seat ? 'You' : 'Opponent'}</b><div class="hp"><div style="width:${s.hp[o]}%"></div></div><span>${s.hp[o]}</span></div>`;
    const ev = s.ev ? `${s.ev.by === seat ? 'You' : 'Opponent'}: ${s.ev.total} gems${s.ev.chain > 1 ? ' · x' + s.ev.chain + ' chain' : ''} · ${s.ev.dmg} damage` : 'Match 3 or more gems to attack!';
    el.innerHTML = `${bar(1 - seat)}<div class="gemboard">${s.g.map((v, i) => `<button class="gem g${v} ${i === sel ? 'sel' : ''}" data-i="${i}"></button>`).join('')}</div>${bar(seat)}<div class="ldmsg">${ev}</div>`;
    $$('[data-i]', el).forEach(b => b.onclick = () => {
      if (!mine) return; const i = +b.dataset.i;
      if (el.__sel < 0) { el.__sel = i; return G_MEM.render(el, s, seat, send); }
      const j = el.__sel, adj = Math.abs(Math.floor(i / GN) - Math.floor(j / GN)) + Math.abs((i % GN) - (j % GN)) === 1;
      if (adj) {
        const t = s.g.slice(); [t[i], t[j]] = [t[j], t[i]];
        if (!gemMatches(t).size) { el.__sel = -1; toast('That swap makes no match'); return G_MEM.render(el, s, seat, send); }
        el.__sel = -1; send({ a: 'swap', i: j, j: i });
      } else { el.__sel = i; G_MEM.render(el, s, seat, send); }
    });
  }
});
