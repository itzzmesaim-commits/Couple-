/* Playza - Wave 2 (part 1): first-person arcade games drawn like the Plato catalog: Archery, Darts, Basketball, Skee Ball */

/* ---------- drawing kit ---------- */
const W2 = 360, H2 = 600;
function off(w, h, fn) { const o = document.createElement('canvas'); o.width = w; o.height = h; fn(o.getContext('2d'), w, h); return o; }
function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
function tx(c, s, x, y, size, fill, align, stroke) {
  c.font = `900 ${size}px "Trebuchet MS",Arial,sans-serif`; c.textAlign = align || 'center'; c.textBaseline = 'middle';
  if (stroke) { c.lineWidth = Math.max(3, size / 5); c.strokeStyle = stroke; c.lineJoin = 'round'; c.strokeText(s, x, y); }
  c.fillStyle = fill; c.fillText(s, x, y);
}
function pill(c, x, y, w, h, col) { const g = c.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, col); g.addColorStop(1, '#0008'); c.fillStyle = '#0009'; rr(c, x, y, w, h, h / 2); c.fill(); c.fillStyle = col; rr(c, x + 2, y + 2, w - 4, h / 2 - 1, h / 4); c.globalAlpha = .35; c.fill(); c.globalAlpha = 1; }
function hudTop(c, W, score, mid, right) {
  c.fillStyle = '#0007'; c.fillRect(0, 0, W, 54);
  c.fillStyle = '#ffb02e'; c.beginPath(); c.arc(30, 28, 20, 0, 6.283); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 3; c.stroke();
  tx(c, '🙂', 30, 29, 20, '#fff'); pill(c, 54, 14, 74, 28, '#2a2f55'); tx(c, String(score), 91, 29, 20, '#fff');
  if (mid) { pill(c, W / 2 - 52, 12, 104, 30, '#2d7be5'); tx(c, mid, W / 2, 28, 15, '#fff'); }
  if (right) right(c, W);
}
function popups() { const a = []; return { add(t, x, y, col) { try { SFX.play(String(t).startsWith('+') ? 'coin' : (/MISS|Ouch|oops|!/i.test(String(t)) ? 'bad' : 'pop')); } catch (e) { } a.push({ t, x, y, age: 0, col: col || '#ffd54a' }); }, draw(c, dt) { for (let i = a.length - 1; i >= 0; i--) { const p = a[i]; p.age += dt; if (p.age > 1.1) { a.splice(i, 1); continue; } const k = Math.min(1, p.age * 5); c.globalAlpha = 1 - Math.max(0, p.age - .7) / .4; tx(c, p.t, p.x, p.y - p.age * 40, 22 + 14 * Math.sin(k * Math.PI / 2), p.col, 'center', '#000'); c.globalAlpha = 1; } } }; }
function swipe(cv, cb) {
  let s = null;
  cv.addEventListener('pointerdown', e => { s = { p: ptr(cv, e), t: performance.now() }; try { cv.setPointerCapture(e.pointerId); } catch (x) {} e.preventDefault(); });
  const up = e => { if (!s) return; const p = ptr(cv, e), dt = Math.max(30, performance.now() - s.t), d = { dx: p.x - s.p.x, dy: p.y - s.p.y, v: Math.hypot(p.x - s.p.x, p.y - s.p.y) / dt, sx: s.p.x, sy: s.p.y, ex: p.x, ey: p.y }; s = null; cb(d); };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', () => { s = null; });
}
function fin(box, score, done, text) { box.innerHTML = `<div class="card center">${text}<br>Score: <b>${score}</b></div>`; done(score); }
function arena(box, W, H) { box.innerHTML = ''; const cv = mkCanvas(box, W, H); return { cv, c: cv.getContext('2d') }; }

/* ================= ARCHERY ================= */
const G_ARCH2 = duel({
  id: 'arch', name: 'Archery', icon: '🏹', desc: 'Hold to draw the bow and steady the aim, release to shoot. Watch the wind!',
  bot: () => 44 + Math.floor(Math.random() * 30),
  play(box, seed, done) {
    const R = rng(seed), { cv, c } = arena(box, W2, H2), TX = 180, TY = 235, TR = 78;
    const bg = off(W2, H2, (g, w, h) => {
      const s = g.createLinearGradient(0, 0, 0, 300); s.addColorStop(0, '#5db4ff'); s.addColorStop(1, '#cdeeff'); g.fillStyle = s; g.fillRect(0, 0, w, h);
      g.fillStyle = '#fff'; [[60, 80, 40], [250, 60, 50], [320, 120, 30]].forEach(([x, y, r]) => { for (let i = 0; i < 4; i++) { g.globalAlpha = .75; g.beginPath(); g.arc(x + i * r * .7, y + (i % 2) * 8, r * .7, 0, 6.283); g.fill(); } }); g.globalAlpha = 1;
      g.fillStyle = '#7fbf6d'; g.beginPath(); g.moveTo(0, 290); for (let x = 0; x <= w; x += 20) g.lineTo(x, 270 - Math.sin(x / 55) * 22); g.lineTo(w, 330); g.lineTo(0, 330); g.fill();
      for (let i = 0; i < 26; i++) { const x = i * 15 + ((i * 37) % 11), y = 292 + ((i * 53) % 12), r = 20 + (i * 17) % 18; g.fillStyle = '#1e5a2a'; g.beginPath(); g.arc(x, y - r * .6, r * .8, 0, 6.283); g.fill(); g.fillStyle = '#2f7d3b'; g.beginPath(); g.arc(x - 3, y - r * .8, r * .55, 0, 6.283); g.fill(); g.fillStyle = '#4a2c14'; g.fillRect(x - 2, y, 4, 12); }
      const gr = g.createLinearGradient(0, 300, 0, h); gr.addColorStop(0, '#5cc04a'); gr.addColorStop(1, '#2f8a2a'); g.fillStyle = gr; g.fillRect(0, 300, w, h - 300);
      for (let i = 0; i < 9; i++) { g.fillStyle = i % 2 ? '#ffffff12' : '#00000010'; const y0 = 300 + Math.pow(i / 9, 1.7) * 300, y1 = 300 + Math.pow((i + 1) / 9, 1.7) * 300; g.fillRect(0, y0, w, y1 - y0); }
      g.fillStyle = '#6b4220'; g.fillRect(TX - 46, TY + 40, 7, 70); g.fillRect(TX + 39, TY + 40, 7, 70); g.fillRect(TX - 8, TY + TR - 4, 16, 60);
    });
    let n = 0, total = 0, t = 0, hold = 0, holding = false, over = false, wind = (R() - .5) * 2, arrows = [], fly = null, cool = 0;
    const pops = popups();
    const ret = () => { const amp = holding ? Math.max(.22, 1 - hold * 1.6) + Math.max(0, hold - 2.4) * .8 : 1; return { x: TX + (Math.sin(t * 2.1) * 54 + Math.sin(t * 3.7) * 22) * amp, y: TY + (Math.cos(t * 1.7) * 46 + Math.sin(t * 2.9) * 20) * amp }; };
    cv.addEventListener('pointerdown', e => { e.preventDefault(); if (over || fly || cool > 0) return; holding = true; hold = 0; try { cv.setPointerCapture(e.pointerId); } catch (x) {} });
    const rel = () => {
      if (!holding || over) return; holding = false; const r = ret(), x = r.x + wind * 14, y = r.y + 6 + Math.abs(wind) * 2;
      fly = { t: 0, x, y }; cool = .5;
    };
    cv.addEventListener('pointerup', rel); cv.addEventListener('pointercancel', () => { holding = false; });
    const land = () => {
      const d = Math.hypot(fly.x - TX, fly.y - TY), pts = d > TR ? 0 : Math.max(1, 10 - Math.floor(d / (TR / 10)));
      arrows.push({ x: fly.x, y: fly.y }); total += pts; n++; pops.add(pts ? '+' + pts : 'MISS', fly.x, fly.y - 20, pts >= 9 ? '#ffd54a' : pts ? '#fff' : '#ff6b6b'); fly = null;
      if (n % 3 === 0) wind = (R() - .5) * 2;
      if (n >= 9) { over = true; setTimeout(() => { stop(); fin(box, total, done, pts >= 9 ? 'Great shooting!' : 'Round complete!'); }, 900); }
    };
    const stop = anim(dt => {
      t += dt; cool -= dt; if (holding) hold += dt;
      if (fly) { fly.t += dt; if (fly.t >= .38) land(); }
      c.drawImage(bg, 0, 0);
      // target
      const cols = ['#f4f4f4', '#f4f4f4', '#1d1d1d', '#1d1d1d', '#2f7be5', '#2f7be5', '#e03a3a', '#e03a3a', '#ffd23a', '#ffd23a'];
      for (let i = 0; i < 10; i++) { c.fillStyle = cols[i]; c.beginPath(); c.arc(TX, TY, TR * (1 - i / 10), 0, 6.283); c.fill(); c.strokeStyle = '#0003'; c.lineWidth = 1; c.stroke(); }
      c.fillStyle = '#c8a46a'; c.beginPath(); c.arc(TX, TY, TR + 6, Math.PI * .98, Math.PI * 2.02); c.arc(TX, TY, TR + 6, 0, 0); c.strokeStyle = '#8a5a2b'; c.lineWidth = 5; c.beginPath(); c.arc(TX, TY, TR + 3, 0, 6.283); c.stroke();
      arrows.forEach(a => { c.strokeStyle = '#6b4220'; c.lineWidth = 3; c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(a.x - 8, a.y + 20); c.stroke(); c.fillStyle = '#e03a3a'; c.beginPath(); c.moveTo(a.x - 8, a.y + 20); c.lineTo(a.x - 13, a.y + 27); c.lineTo(a.x - 5, a.y + 25); c.fill(); c.fillStyle = '#ddd'; c.beginPath(); c.arc(a.x, a.y, 2.5, 0, 6.283); c.fill(); });
      // flying arrow
      if (fly) { const k = fly.t / .38, x = 180 + (fly.x - 180) * k, y = 560 + (fly.y - 560) * k, s = 1 - k * .75; c.save(); c.translate(x, y); c.scale(s, s); c.strokeStyle = '#6b4220'; c.lineWidth = 5; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, 70); c.stroke(); c.fillStyle = '#ccd'; c.beginPath(); c.moveTo(0, -8); c.lineTo(-5, 4); c.lineTo(5, 4); c.fill(); c.fillStyle = '#e03a3a'; c.fillRect(-6, 60, 12, 14); c.restore(); }
      // reticle
      const r = ret(), fl = holding ? 1 : .6; c.strokeStyle = holding ? '#2ee6c8' : '#2ee6c8aa'; c.lineWidth = 3; c.beginPath(); c.arc(r.x, r.y, 30 - (holding ? Math.min(10, hold * 8) : 0), 0, 6.283); c.stroke(); c.lineWidth = 2; c.beginPath(); c.moveTo(r.x - 8, r.y); c.lineTo(r.x + 8, r.y); c.moveTo(r.x, r.y - 8); c.lineTo(r.x, r.y + 8); c.stroke();
      // bow
      const pull = holding ? Math.min(1, hold * 3) : (fly ? .0 : 0), by = 575;
      c.strokeStyle = '#7a4a1f'; c.lineWidth = 9; c.lineCap = 'round'; c.beginPath(); c.moveTo(110, by + 25); c.quadraticCurveTo(180, by - 80, 250, by + 25); c.stroke();
      c.strokeStyle = '#ffffffcc'; c.lineWidth = 2; c.beginPath(); c.moveTo(110, by + 25); c.lineTo(180, by + 20 - 25 * pull + 25); c.lineTo(250, by + 25); c.stroke();
      if (!fly) { c.strokeStyle = '#6b4220'; c.lineWidth = 4; c.beginPath(); c.moveTo(180, by + 45 - 25 * pull); c.lineTo(180, by - 60); c.stroke(); c.fillStyle = '#ccd'; c.beginPath(); c.moveTo(180, by - 72); c.lineTo(175, by - 58); c.lineTo(185, by - 58); c.fill(); }
      c.lineCap = 'butt';
      hudTop(c, W2, total, 'ROUND ' + Math.min(3, Math.floor(n / 3) + 1) + '/3', (g, w) => { g.fillStyle = '#0008'; g.beginPath(); g.arc(w - 34, 28, 22, 0, 6.283); g.fill(); g.strokeStyle = '#fff'; g.lineWidth = 3; g.save(); g.translate(w - 34, 28); g.rotate(wind > 0 ? 0 : Math.PI); const L = 6 + Math.abs(wind) * 10; g.beginPath(); g.moveTo(-L, 0); g.lineTo(L, 0); g.moveTo(L - 6, -5); g.lineTo(L, 0); g.lineTo(L - 6, 5); g.stroke(); g.restore(); });
      tx(c, 'Arrow ' + Math.min(9, n + 1) + '/9 · ' + (holding ? 'release to shoot' : 'hold to draw'), 180, 82, 13, '#fff', 'center', '#000a');
      pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});

/* ================= DARTS ================= */
const DB_ORDER = [20, 1, 18, 4, 13, 6, 10, 15, 2, 17, 3, 19, 7, 16, 8, 11, 14, 9, 12, 5];
function dartScore(dx, dy, R) {
  const r = Math.hypot(dx, dy) / R;
  if (r < 0.04) return 50; if (r < 0.095) return 25; if (r > 1) return 0;
  const a = Math.atan2(dx, -dy), idx = Math.floor(((a + 6.283185 + Math.PI / 20) % 6.283185) / (Math.PI / 10)), v = DB_ORDER[idx];
  return r > 0.93 ? v * 2 : (r > 0.58 && r < 0.67) ? v * 3 : v;
}
const G_DART2 = duel({
  id: 'darts', name: 'Darts', icon: '🎯', desc: 'Drag to aim (keep steady!), release to throw. Triples, doubles and the bullseye score big!',
  bot: () => 115 + Math.floor(Math.random() * 90),
  play(box, seed, done) {
    const { cv, c } = arena(box, W2, H2), CX = 180, CY = 250, BR = 140;
    const bg = off(W2, H2, (g, w, h) => {
      g.fillStyle = '#7a3b24'; g.fillRect(0, 0, w, h);
      for (let y = 0, row = 0; y < h; y += 22, row++) for (let x = -(row % 2) * 30; x < w; x += 60) { const v = ((x * 7 + y * 13) % 17) / 17; g.fillStyle = `rgb(${130 + v * 40},${64 + v * 20},${42 + v * 14})`; g.fillRect(x + 1, y + 1, 58, 20); }
      const v = g.createRadialGradient(w / 2, 250, 120, w / 2, 300, 420); v.addColorStop(0, '#0000'); v.addColorStop(1, '#000b'); g.fillStyle = v; g.fillRect(0, 0, w, h);
      g.fillStyle = '#5a3418'; g.beginPath(); g.arc(CX, CY, BR + 34, 0, 6.283); g.fill(); g.strokeStyle = '#3a200c'; g.lineWidth = 3; for (let i = 0; i < 14; i++) { g.beginPath(); g.arc(CX, CY, BR + 12 + i * 1.6, 0, 6.283); g.stroke(); }
      g.fillStyle = '#111'; g.beginPath(); g.arc(CX, CY, BR + 16, 0, 6.283); g.fill();
      for (let i = 0; i < 20; i++) {
        const a0 = -Math.PI / 2 - Math.PI / 20 + i * Math.PI / 10, a1 = a0 + Math.PI / 10, dark = i % 2 === 0;
        const ring = (r0, r1, col) => { g.fillStyle = col; g.beginPath(); g.arc(CX, CY, BR * r1, a0, a1); g.arc(CX, CY, BR * r0, a1, a0, true); g.closePath(); g.fill(); };
        ring(0.095, 0.58, dark ? '#17120e' : '#f0e2b8'); ring(0.58, 0.67, dark ? '#c4252b' : '#1f8a47'); ring(0.67, 0.93, dark ? '#17120e' : '#f0e2b8'); ring(0.93, 1, dark ? '#c4252b' : '#1f8a47');
        g.fillStyle = '#fff'; g.font = '900 17px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; const am = (a0 + a1) / 2; g.fillText(DB_ORDER[i], CX + Math.cos(am) * (BR + 8), CY + Math.sin(am) * (BR + 8));
      }
      g.strokeStyle = '#c9c9c9'; g.lineWidth = 1.2; [.095, .58, .67, .93, 1].forEach(r => { g.beginPath(); g.arc(CX, CY, BR * r, 0, 6.283); g.stroke(); }); for (let i = 0; i < 20; i++) { const a = -Math.PI / 2 - Math.PI / 20 + i * Math.PI / 10; g.beginPath(); g.moveTo(CX + Math.cos(a) * BR * .095, CY + Math.sin(a) * BR * .095); g.lineTo(CX + Math.cos(a) * BR, CY + Math.sin(a) * BR); g.stroke(); }
      g.fillStyle = '#1f8a47'; g.beginPath(); g.arc(CX, CY, BR * 0.095, 0, 6.283); g.fill(); g.fillStyle = '#c4252b'; g.beginPath(); g.arc(CX, CY, BR * 0.04, 0, 6.283); g.fill();
    });
    let n = 0, total = 0, t = 0, over = false, down = null, hold = 0, darts = [], fly = null, last = null;
    const pops = popups();
    const aim = () => { if (!down) return null; const a = Math.max(0, hold - 1.4) * 6 + 4; return { x: down.x + Math.sin(t * 9) * a + Math.sin(t * 5.3) * a * .5, y: down.y - 50 + Math.cos(t * 7.7) * a + Math.cos(t * 4.1) * a * .5 }; };
    cv.addEventListener('pointerdown', e => { e.preventDefault(); if (over || fly) return; down = ptr(cv, e); hold = 0; try { cv.setPointerCapture(e.pointerId); } catch (x) {} });
    cv.addEventListener('pointermove', e => { if (down) down = ptr(cv, e); });
    cv.addEventListener('pointerup', e => { if (!down) return; const a = aim(); down = null; if (!a) return; fly = { t: 0, x: a.x + (Math.random() - .5) * 8, y: a.y + (Math.random() - .5) * 8 }; });
    cv.addEventListener('pointercancel', () => { down = null; });
    const land = () => {
      const s = dartScore(fly.x - CX, fly.y - CY, BR); darts.push({ x: fly.x, y: fly.y }); total += s; n++; last = s;
      pops.add(s === 50 ? 'BULLSEYE 50' : s === 0 ? 'MISS' : String(s), CX, CY + BR + 50, s >= 40 ? '#ffd54a' : '#fff'); fly = null;
      if (n >= 9) { over = true; setTimeout(() => { stop(); fin(box, total, done, 'All darts thrown!'); }, 900); }
    };
    const dart = (x, y, s, rot) => { c.save(); c.translate(x, y); c.rotate(rot || 0); c.scale(s, s); c.fillStyle = '#d33'; c.beginPath(); c.moveTo(-9, 70); c.lineTo(0, 46); c.lineTo(9, 70); c.lineTo(0, 62); c.fill(); c.fillStyle = '#ffd23a'; rr(c, -5, 18, 10, 34, 4); c.fill(); c.fillStyle = '#b8860b'; for (let i = 0; i < 5; i++) c.fillRect(-5, 22 + i * 6, 10, 1.5); c.fillStyle = '#d9d9e4'; c.beginPath(); c.moveTo(0, -4); c.lineTo(-2.5, 18); c.lineTo(2.5, 18); c.fill(); c.restore(); };
    const stop = anim(dt => {
      t += dt; if (down) hold += dt; if (fly) { fly.t += dt; if (fly.t >= .3) land(); }
      c.drawImage(bg, 0, 0);
      darts.forEach(d => { c.save(); c.translate(d.x, d.y); c.fillStyle = '#0004'; c.beginPath(); c.arc(2, 3, 3, 0, 6.283); c.fill(); c.restore(); dart(d.x - 1, d.y - 3, .42, 0); });
      if (fly) { const k = fly.t / .3, x = 180 + (fly.x - 180) * k, y = 540 + (fly.y - 540) * k, s = 1 - k * .58; dart(x, y, s, 0); }
      if (!fly && !over) dart(180, 540, 1, 0);
      const a = aim(); if (a) { c.strokeStyle = '#ffd54a'; c.lineWidth = 3; c.beginPath(); c.arc(a.x, a.y, 14, 0, 6.283); c.stroke(); c.lineWidth = 2; c.beginPath(); c.moveTo(a.x - 22, a.y); c.lineTo(a.x - 8, a.y); c.moveTo(a.x + 8, a.y); c.lineTo(a.x + 22, a.y); c.moveTo(a.x, a.y - 22); c.lineTo(a.x, a.y - 8); c.moveTo(a.x, a.y + 8); c.lineTo(a.x, a.y + 22); c.stroke(); }
      hudTop(c, W2, total, null, (g, w) => { for (let i = 0; i < 9; i++) { g.fillStyle = i < n ? '#555' : '#ffd23a'; g.beginPath(); g.arc(w - 120 + i * 12, 28, 4.5, 0, 6.283); g.fill(); } });
      tx(c, !n && !down ? 'Drag to aim, release to throw' : (last != null && !down ? 'Last throw: ' + last : (hold > 1.4 ? 'Hand is shaking! Throw now!' : 'Aim...')), 180, 76, 13, '#fff', 'center', '#000a');
      pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});

/* ================= BASKETBALL ================= */
const G_HOOP2 = duel({
  id: 'hoop', name: 'Basketball', icon: '🏀', desc: 'Swipe up to shoot. Swipe speed sets the power. The hoop starts moving in later rounds!',
  bot: () => 9 + Math.floor(Math.random() * 12),
  play(box, seed, done) {
    const { cv, c } = arena(box, W2, H2), HY = 190;
    const bg = off(W2, H2, (g, w, h) => {
      const s = g.createLinearGradient(0, 0, 0, h); s.addColorStop(0, '#1b1546'); s.addColorStop(.6, '#3a2a6a'); s.addColorStop(1, '#5a3a5a'); g.fillStyle = s; g.fillRect(0, 0, w, h);
      for (let i = 0; i < 9; i++) { const bx = i * 44 - 10, bh = 140 + (i * 53) % 150; g.fillStyle = '#16113a'; g.fillRect(bx, 400 - bh, 40, bh); for (let y = 400 - bh + 10; y < 390; y += 14) for (let x = bx + 5; x < bx + 36; x += 11) if (((x * 3 + y * 7) % 5) < 2) { g.fillStyle = '#ffd98a'; g.fillRect(x, y, 5, 7); } }
      g.fillStyle = '#7b2d26'; g.fillRect(0, 400, w, h - 400);
      for (let y = 400, row = 0; y < h; y += 24, row++) for (let x = -(row % 2) * 28; x < w; x += 56) { const v = ((x * 11 + y * 5) % 19) / 19; g.fillStyle = `rgb(${150 + v * 40},${60 + v * 18},${46 + v * 10})`; g.fillRect(x + 1.5, y + 1.5, 53, 21); }
      g.fillStyle = '#2f4a2a'; for (let i = 0; i < 12; i++) { g.beginPath(); g.arc(20 + i * 32, 402, 10 + (i * 7) % 8, Math.PI, 0); g.fill(); }
      const v = g.createLinearGradient(0, 400, 0, h); v.addColorStop(0, '#0000'); v.addColorStop(1, '#000a'); g.fillStyle = v; g.fillRect(0, 400, w, h - 400);
    });
    let shot = 0, total = 0, t = 0, over = false, fly = null, msg = 'Swipe up to shoot!', cool = 0;
    const pops = popups(), BXY = { x: 180, y: 520 };
    const hx = tt => shot < 3 ? 180 : 180 + Math.sin(tt * (shot < 6 ? .9 : 1.7)) * (shot < 6 ? 62 : 82);
    swipe(cv, d => {
      if (over || fly || cool > 0 || -d.dy < 45) return;
      const v = Math.min(3, d.v), lx = hx(t + .7) + (d.dx / Math.max(40, -d.dy)) * 120 + (Math.random() - .5) * 6 - (d.sx - 180) * .1, ly = HY + (1.45 - v) * 150 + (Math.random() - .5) * 8;
      fly = { t: 0, lx, ly, tgt: hx(t + .7), res: null }; cool = 1.2;
    });
    const resolve = () => {
      const dx = Math.abs(fly.lx - fly.tgt), dy = fly.ly - HY;
      if (dx < 15 && Math.abs(dy) < 20) fly.res = 'swish'; else if (dx < 30 && Math.abs(dy) < 38 && (dx + Math.abs(dy)) < 52) fly.res = 'rim-in'; else fly.res = 'miss';
      if (fly.res === 'swish') { total += 3; msg = 'PERFECT! +3'; pops.add('+3', 180, 150, '#ffd54a'); } else if (fly.res === 'rim-in') { total += 2; msg = 'Basket! +2'; pops.add('+2', 180, 150, '#fff'); } else { msg = dy > 38 ? 'Too short!' : dy < -38 ? 'Too strong!' : 'Missed!'; pops.add('MISS', 180, 150, '#ff6b6b'); }
    };
    const stop = anim(dt => {
      t += dt; cool -= dt;
      if (fly) { fly.t += dt; if (!fly.res && fly.t >= .55) resolve(); if (fly.t >= 1.35) { fly = null; shot++; if (shot >= 9) { over = true; stop(); fin(box, total, done, msg); } } }
      if (over) return;
      c.drawImage(bg, 0, 0);
      const H = hx(t);
      // pole + backboard
      c.fillStyle = '#8b8f9a'; c.fillRect(H - 8, HY + 40, 16, 230); c.fillStyle = '#5c606b'; c.fillRect(H + 2, HY + 40, 6, 230);
      c.fillStyle = '#e9edf5'; rr(c, H - 74, 42, 148, 106, 7); c.fill(); c.strokeStyle = '#9aa0b5'; c.lineWidth = 5; c.stroke(); c.strokeStyle = '#e24a3a'; c.lineWidth = 5; c.strokeRect(H - 31, 96, 62, 46);
      // net
      const sway = fly && fly.res && fly.res !== 'miss' ? Math.sin(fly.t * 20) * 4 : 0;
      c.strokeStyle = '#ffffffcc'; c.lineWidth = 1.8; for (let i = 0; i <= 8; i++) { const x0 = H - 42 + i * 10.5, x1 = H - 26 + i * 6.5; c.beginPath(); c.moveTo(x0, HY + 4); c.lineTo(x1 + sway, HY + 54); c.stroke(); }
      for (let r = 1; r <= 4; r++) { c.beginPath(); for (let i = 0; i <= 8; i++) { const k = r / 5, x = (H - 42 + i * 10.5) * (1 - k) + (H - 26 + i * 6.5 + sway * k) * k, y = HY + 4 + k * 50; i ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); }
      // ball
      const drawBall = (x, y, r) => { const g = c.createRadialGradient(x - r * .35, y - r * .35, r * .1, x, y, r); g.addColorStop(0, '#ffab5e'); g.addColorStop(1, '#c4540f'); c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, 6.283); c.fill(); c.strokeStyle = '#5a2208'; c.lineWidth = Math.max(1.5, r / 16); c.stroke(); c.beginPath(); c.moveTo(x - r, y); c.lineTo(x + r, y); c.moveTo(x, y - r); c.lineTo(x, y + r); c.stroke(); c.beginPath(); c.arc(x - r * 1.05, y, r * .7, -.9, .9); c.stroke(); c.beginPath(); c.arc(x + r * 1.05, y, r * .7, Math.PI - .9, Math.PI + .9); c.stroke(); };
      if (!fly) drawBall(BXY.x, BXY.y, 48);
      else {
        const f = fly, k = Math.min(1, f.t / .55);
        if (f.t < .55) { const x = BXY.x + (f.lx - BXY.x) * k, yb = BXY.y + (f.ly - BXY.y) * k, y = yb - Math.sin(k * Math.PI) * 140 * (.6 + Math.min(1, Math.max(.3, 1.45 - 0) * .4)), r = 48 - 28 * k; drawBall(x, y, r); }
        else {
          const u = f.t - .55, base = { x: f.lx, y: f.ly };
          if (f.res === 'miss') { const dir = f.lx < f.tgt ? -1 : 1; drawBall(base.x + dir * u * 120, base.y + (-Math.sin(Math.min(1, u * 3) * Math.PI) * 40) + u * u * 520, 20 + u * 6); }
          else drawBall(f.tgt + (f.lx - f.tgt) * Math.max(0, 1 - u * 4), HY + 6 + u * u * 400 + u * 60, 20);
        }
      }
      // rim (front)
      c.strokeStyle = '#ff6a1f'; c.lineWidth = 7; c.lineCap = 'round'; c.beginPath(); c.ellipse(H, HY, 44, 11, 0, 0, Math.PI); c.stroke(); c.strokeStyle = '#c24a0f'; c.lineWidth = 5; c.beginPath(); c.ellipse(H, HY, 44, 11, 0, Math.PI, Math.PI * 2); c.stroke(); c.lineCap = 'butt';
      hudTop(c, W2, total, 'ROUND ' + Math.min(3, Math.floor(shot / 3) + 1) + '/3', null);
      tx(c, msg, 180, 78, 14, '#fff', 'center', '#000a');
      pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});

/* ================= SKEE BALL ================= */
const SK_R = [{ x: 180, y: 112, r: 18, v: 50 }, { x: 118, y: 140, r: 20, v: 40 }, { x: 242, y: 140, r: 20, v: 40 }, { x: 180, y: 170, r: 24, v: 30 }, { x: 98, y: 200, r: 24, v: 20 }, { x: 262, y: 200, r: 24, v: 20 }, { x: 180, y: 232, r: 30, v: 10 }];
const G_SKEE2 = duel({
  id: 'skee', name: 'Skee Ball', icon: '🎱', desc: 'Swipe up to roll the ball up the ramp. Aim for the 50 hole!',
  bot: () => 100 + Math.floor(Math.random() * 130),
  play(box, seed, done) {
    const { cv, c } = arena(box, W2, H2), FAR = 330, NEAR = 585, WF = 80, WN = 150;
    const lx = (x, u) => 180 + x * (WN + (WF - WN) * u), ly = u => NEAR + (FAR - NEAR) * u, sc = u => 1 - u * .55;
    const bg = off(W2, H2, (g, w, h) => {
      g.fillStyle = '#1a0a0e'; g.fillRect(0, 0, w, h);
      const wall = g.createLinearGradient(0, 0, 0, FAR); wall.addColorStop(0, '#3a0d16'); wall.addColorStop(1, '#6a1a22'); g.fillStyle = wall; g.fillRect(0, 0, w, FAR);
      g.fillStyle = '#e8c06a'; g.beginPath(); g.moveTo(0, 20); g.quadraticCurveTo(180, -20, 360, 20); g.lineTo(360, 0); g.lineTo(0, 0); g.fill();
      for (let i = 0; i < 18; i++) { g.fillStyle = i % 2 ? '#ffd54a' : '#ff5a3a'; g.beginPath(); g.arc(14 + i * 20, 66, 4, 0, 6.283); g.fill(); }
      // board
      g.fillStyle = '#9b5b2c'; g.beginPath(); g.moveTo(40, 90); g.quadraticCurveTo(180, 60, 320, 90); g.lineTo(325, 288); g.lineTo(35, 288); g.closePath(); g.fill();
      g.strokeStyle = '#e8c06a'; g.lineWidth = 6; g.stroke();
      const bd = g.createLinearGradient(0, 90, 0, 288); bd.addColorStop(0, '#6b3a1a'); bd.addColorStop(1, '#8a4e24'); g.fillStyle = bd; g.beginPath(); g.moveTo(46, 94); g.quadraticCurveTo(180, 66, 314, 94); g.lineTo(318, 282); g.lineTo(42, 282); g.closePath(); g.fill();
      SK_R.forEach(q => { g.fillStyle = '#e8c06a'; g.beginPath(); g.arc(q.x, q.y, q.r + 5, 0, 6.283); g.fill(); const gg = g.createRadialGradient(q.x, q.y - 4, 2, q.x, q.y, q.r); gg.addColorStop(0, '#2a1208'); gg.addColorStop(1, '#000'); g.fillStyle = gg; g.beginPath(); g.arc(q.x, q.y, q.r, 0, 6.283); g.fill(); g.fillStyle = q.v >= 40 ? '#ffd54a' : '#fff'; g.font = '900 ' + (q.r > 24 ? 22 : 17) + 'px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(q.v, q.x, q.y + 1); });
      // side cabinet
      g.fillStyle = '#b3202c'; g.beginPath(); g.moveTo(0, 290); g.lineTo(46, 288); g.lineTo(36, h); g.lineTo(0, h); g.fill(); g.beginPath(); g.moveTo(w, 290); g.lineTo(w - 46, 288); g.lineTo(w - 36, h); g.lineTo(w, h); g.fill();
      // lane
      const ln = g.createLinearGradient(0, FAR, 0, NEAR); ln.addColorStop(0, '#9a5a2a'); ln.addColorStop(1, '#e0a85a'); g.fillStyle = ln; g.beginPath(); g.moveTo(180 - WF, FAR); g.lineTo(180 + WF, FAR); g.lineTo(180 + WN, NEAR + 20); g.lineTo(180 - WN, NEAR + 20); g.fill();
      g.strokeStyle = '#6a3a1a66'; g.lineWidth = 1.5; for (let i = -4; i <= 4; i++) { g.beginPath(); g.moveTo(180 + i * WF / 4, FAR); g.lineTo(180 + i * (WN + 8) / 4, NEAR + 20); g.stroke(); }
      for (let k = 1; k < 8; k++) { const u = Math.pow(k / 8, 1.0), y = NEAR + (FAR - NEAR) * u; g.strokeStyle = '#0003'; g.beginPath(); g.moveTo(180 - (WN + (WF - WN) * u), y); g.lineTo(180 + (WN + (WF - WN) * u), y); g.stroke(); }
      // rails
      g.fillStyle = '#7a7f8c'; g.beginPath(); g.moveTo(180 - WF - 10, FAR); g.lineTo(180 - WF, FAR); g.lineTo(180 - WN, NEAR + 20); g.lineTo(180 - WN - 26, NEAR + 20); g.fill(); g.beginPath(); g.moveTo(180 + WF + 10, FAR); g.lineTo(180 + WF, FAR); g.lineTo(180 + WN, NEAR + 20); g.lineTo(180 + WN + 26, NEAR + 20); g.fill();
      g.strokeStyle = '#ffd54a'; g.lineWidth = 3; g.setLineDash([8, 8]); g.beginPath(); g.moveTo(180 - WF - 5, FAR); g.lineTo(180 - WN - 13, NEAR + 20); g.moveTo(180 + WF + 5, FAR); g.lineTo(180 + WN + 13, NEAR + 20); g.stroke(); g.setLineDash([]);
      g.fillStyle = '#ffd54a'; g.fillRect(180 - WF, FAR - 6, WF * 2, 8); g.fillStyle = '#c4252b'; g.fillRect(180 - WF, FAR - 2, WF * 2, 4);
    });
    let n = 0, total = 0, over = false, ball = null, msg = 'Swipe up to roll!', cool = 0, t = 0;
    const pops = popups(), lit = {};
    swipe(cv, d => {
      if (over || ball || cool > 0 || -d.dy < 40) return;
      const sp = clamp(d.v, .5, 2.6); ball = { u: 0, x: clamp((d.sx - 180) / WN, -.8, .8), vx: clamp(d.dx / Math.max(40, -d.dy), -.8, .8) * .35, su: .45 + sp * .3, hop: null, z: 0 };
    });
    const finish = (pts, text, bx, by) => { total += pts; msg = text; n++; pops.add(pts ? '+' + pts : 'MISS', bx, by, pts >= 40 ? '#ffd54a' : '#fff'); if (pts) lit[pts + ''] = 1.2; cool = .5; ball = null; if (n >= 9) { over = true; setTimeout(() => { stop(); fin(box, total, done, text); }, 900); } };
    const stop = anim(dt => {
      t += dt; cool -= dt; for (const k in lit) lit[k] = Math.max(0, lit[k] - dt);
      if (ball) {
        const b = ball;
        if (b.hop) { b.hop.t += dt; const k = Math.min(1, b.hop.t / .6); b.px = b.hop.x0 + (b.hop.x1 - b.hop.x0) * k; b.py = b.hop.y0 + (b.hop.y1 - b.hop.y0) * k - Math.sin(k * Math.PI) * 90; b.ps = .45 - .08 * k; if (k >= 1) { const q = SK_R.find(q => Math.hypot(b.px - q.x, b.py - q.y) < q.r + 3); finish(q ? q.v : 0, q ? '+' + q.v + ' points!' : 'No hole!', b.px, b.py); } }
        else {
          b.su -= .32 * dt; b.u += b.su * dt; b.x = clamp(b.x + b.vx * dt, -.9, .9);
          if (b.su < .1 && b.u < 1) { finish(0, 'Too weak. Swipe faster!', lx(b.x, b.u), ly(b.u)); }
          else if (b.u >= 1) { const q = clamp((b.su - .1) / .5, 0, 1), tx_ = 180 + b.x * 150 + b.vx * 200, ty_ = 245 - q * 140 + (Math.random() - .5) * 10; b.hop = { t: 0, x0: lx(b.x, 1), y0: ly(1), x1: tx_, y1: ty_ }; }
        }
      }
      c.drawImage(bg, 0, 0);
      SK_R.forEach(q => { if (lit[q.v]) { c.globalAlpha = Math.min(1, lit[q.v]); c.fillStyle = '#ffd54a'; c.beginPath(); c.arc(q.x, q.y, q.r + 8, 0, 6.283); c.fill(); c.globalAlpha = 1; } });
      const b = ball || { u: 0, x: 0 };
      let bx, by, s, z = 0; if (b.hop) { bx = b.px; by = b.py; s = b.ps; } else { bx = lx(b.x, b.u); by = ly(b.u) - 12 * sc(b.u); s = sc(b.u); }
      c.fillStyle = '#0004'; c.beginPath(); c.ellipse(bx + 3, (b.hop ? ly(1) - 130 + 0 : by + 10 * s) + (b.hop ? 0 : 0), 16 * s, 6 * s, 0, 0, 6.283); if (!b.hop) c.fill();
      const g = c.createRadialGradient(bx - 5 * s, by - 5 * s, 2, bx, by, 18 * s); g.addColorStop(0, '#ff9a8a'); g.addColorStop(.5, '#d62a2a'); g.addColorStop(1, '#6a0c0c'); c.fillStyle = g; c.beginPath(); c.arc(bx, by, 18 * s, 0, 6.283); c.fill();
      hudTop(c, W2, total, 'BALL ' + Math.min(9, n + 1) + '/9', null);
      tx(c, msg, 180, 78, 14, '#fff', 'center', '#000a'); pops.draw(c, dt);
    });
    return () => { over = true; stop(); };
  }
});
