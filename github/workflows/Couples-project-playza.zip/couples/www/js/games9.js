/* Playza - Wave 3 (part 2): Match Monster, Word Match, Dominoes, Backgammon, Sea Battle */

/* ================= MATCH MONSTER (sword / shield / book / star / potion) ================= */
const MT = 5, MM_HP = 720;
const MM_COLS = ['#ff4d4d', '#3a8cff', '#a259ff', '#ffc83a', '#3ddc97'];
const MM_ICON = [
  '<path d="M20 4 L25 9 L16 26 L12 22 Z" fill="#e8eef8"/><path d="M12 22 L16 26 L9 33 L7 31 Z" fill="#8a5a2b"/><rect x="9" y="22" width="12" height="4" rx="1.5" transform="rotate(-45 15 24)" fill="#ffd54a"/>',
  '<path d="M20 5 L33 10 L31 24 Q28 32 20 36 Q12 32 9 24 L7 10 Z" fill="#cfe4ff" stroke="#fff" stroke-width="2"/><path d="M20 9 L28 12 L27 23 Q25 29 20 32 Z" fill="#6aa8ff"/>',
  '<rect x="8" y="7" width="24" height="27" rx="3" fill="#f1e2ff"/><rect x="8" y="7" width="6" height="27" rx="2" fill="#7a3ad6"/><path d="M22 14 l2 4 4 .6 -3 3 .8 4.2 -3.8 -2 -3.8 2 .8 -4.2 -3 -3 4 -.6z" fill="#ffc83a"/>',
  '<path d="M20 4 L25 15 L37 16 L28 24 L31 36 L20 30 L9 36 L12 24 L3 16 L15 15 Z" fill="#fff3a0" stroke="#fff" stroke-width="1.5"/>',
  '<path d="M16 5 h8 v6 l7 13 q3 9 -11 11 q-14 -2 -11 -11 l7 -13 z" fill="#c8ffd8" stroke="#fff" stroke-width="1.5"/><path d="M12 24 q8 4 16 0 q2 8 -8 9 q-10 -1 -8 -9z" fill="#2fcf6b"/><rect x="15" y="3" width="10" height="4" rx="2" fill="#8a5a2b"/>'
];
const mmIcon = k => `<svg viewBox="0 0 40 40" class="mti">${MM_ICON[k]}</svg>`;
function mmFresh(R) { let g, t = 0; do { g = Array.from({ length: GN * GN }, () => Math.floor(R() * MT)); t++; } while ((gemMatches(g).size || !gemHasMove(g)) && t < 300); return g; }
function mmMaxRun(g) { let best = 0; for (let r = 0; r < GN; r++) { let run = 1; for (let c = 1; c < GN; c++) { if (g[r * GN + c] === g[r * GN + c - 1] && g[r * GN + c] >= 0) run++; else run = 1; best = Math.max(best, run); } } for (let c = 0; c < GN; c++) { let run = 1; for (let r = 1; r < GN; r++) { if (g[r * GN + c] === g[(r - 1) * GN + c] && g[r * GN + c] >= 0) run++; else run = 1; best = Math.max(best, run); } } return best; }
function mmResolve(s, R) {
  let chain = 0, total = 0, run = 0; const cnt = Array(MT).fill(0);
  for (; ;) {
    const m = gemMatches(s.g); if (!m.size) break; chain++; run = Math.max(run, mmMaxRun(s.g)); total += m.size; m.forEach(i => { cnt[s.g[i]]++; s.g[i] = -1; });
    for (let c = 0; c < GN; c++) { const col = []; for (let r = GN - 1; r >= 0; r--) if (s.g[r * GN + c] >= 0) col.push(s.g[r * GN + c]); while (col.length < GN) col.push(Math.floor(R() * MT)); for (let r = GN - 1, k = 0; r >= 0; r--, k++) s.g[r * GN + c] = col[k]; }
  }
  return { chain, total, cnt, run };
}
Object.assign(G_MEM, {
  id: 'monster', name: 'Match Monster', icon: '👾', simul: false,
  desc: 'Match 3+ tiles: Swords hurt, Shields add armor, Books charge a special, Stars pierce armor, Potions heal. Match 4+ for an extra turn!',
  init() { const rs = newSeed(), R = rng(rs), a = Math.floor(R() * 6); let b; do { b = Math.floor(R() * 6); } while (b === a); return { g: mmFresh(rng(rs + 1)), mon: [a, b], hp: [MM_HP, MM_HP], ar: [0, 0], sp: [0, 0], turn: 0, winner: null, rs, n: 0, ev: null }; },
  status: (s, seat) => s.winner != null ? '' : (s.turn === seat ? '👉 Swap two tiles' : '⏳ Opponent’s turn'),
  move(s, m, seat) {
    if (s.winner != null || s.turn !== seat || m.a !== 'swap') return null;
    const i = m.i | 0, j = m.j | 0; if (i < 0 || j < 0 || i >= GN * GN || j >= GN * GN) return null;
    if (Math.abs(Math.floor(i / GN) - Math.floor(j / GN)) + Math.abs((i % GN) - (j % GN)) !== 1) return null;
    const t = s.g[i]; s.g[i] = s.g[j]; s.g[j] = t; if (!gemMatches(s.g).size) return null;
    const R = rng(s.rs + (s.n + 1) * 7919), r = mmResolve(s, R), foe = 1 - seat, mult = 1 + .25 * (r.chain - 1), c = r.cnt;
    const hitFoe = (d, pierce) => { let dd = Math.round(d); if (!pierce) { const ab = Math.min(s.ar[foe], dd); s.ar[foe] -= ab; dd -= ab; } s.hp[foe] = Math.max(0, s.hp[foe] - dd); return dd; };
    let dmg = 0, armor = Math.round(c[1] * 20 * mult), heal = 0, special = 0;
    dmg += hitFoe(c[0] * 30 * mult, false); dmg += hitFoe(c[3] * 20 * mult, true);
    s.ar[seat] = Math.min(300, s.ar[seat] + armor); s.sp[seat] += c[2]; while (s.sp[seat] >= 10) { s.sp[seat] -= 10; special++; dmg += hitFoe(150, true); }
    const h0 = s.hp[seat]; s.hp[seat] = Math.min(MM_HP, s.hp[seat] + Math.round(c[4] * 25 * mult)); heal = s.hp[seat] - h0;
    const extra = r.run >= 4 && s.hp[foe] > 0; s.ev = { by: seat, chain: r.chain, cnt: c, dmg, armor, heal, special, extra }; s.n++;
    if (s.hp[foe] <= 0) { s.winner = seat; return s; }
    if (s.n >= 80) { s.winner = s.hp[0] === s.hp[1] ? 'draw' : (s.hp[0] > s.hp[1] ? 0 : 1); return s; }
    s.turn = extra ? seat : foe; if (!gemHasMove(s.g)) s.g = mmFresh(rng(s.rs + s.n * 31));
    return s;
  },
  bot(s, seat) {
    if (s.winner != null || s.turn !== seat) return null; let best = null, bs = -1e9;
    for (let r = 0; r < GN; r++) for (let c = 0; c < GN; c++) for (const [dr, dc] of [[0, 1], [1, 0]]) {
      if (r + dr >= GN || c + dc >= GN) continue; const i = r * GN + c, j = (r + dr) * GN + c + dc, ns = G_MEM.move(clone(s), { a: 'swap', i, j }, seat); if (!ns) continue;
      const e = ns.ev, low = s.hp[seat] < 360, sc = (s.hp[1 - seat] - ns.hp[1 - seat]) * 1.2 + e.armor * (low ? .9 : .4) + e.heal * (low ? 1.2 : .3) + (e.extra ? 70 : 0) + e.cnt[2] * 6 + (ns.winner === seat ? 900 : 0) + Math.random() * 8;
      if (sc > bs) { bs = sc; best = { a: 'swap', i, j }; }
    }
    return best;
  },
  render(el, s, seat, send) {
    if (el.__gs !== s.gid) { el.__gs = s.gid; el.__sel = -1; el.__n = s.n; }
    const mine = s.turn === seat && s.winner == null, sel = el.__sel, fresh = s.n !== el.__n && s.ev; el.__n = s.n; const ev = s.ev, foe = 1 - seat;
    const card = o => {
      let cls = 'mcard mm' + (s.hp[o] <= 0 ? ' ko' : '') + (s.turn === o && s.winner == null ? ' act' : '');
      if (fresh && ev) { if (ev.by === o && ev.dmg > 0) cls += ' lunge' + (o === seat ? 'u' : 'd'); if (ev.by !== o && ev.dmg > 0) cls += ' hurt'; }
      const dm = fresh && ev && ev.by !== o ? ev.dmg : 0, hl = fresh && ev && ev.by === o ? ev.heal : 0;
      return `<div class="${cls}"><div class="msv ${o === seat ? '' : 'flip'}">${monsterSVG(s.mon[o])}</div>${dm ? `<b class="dmg">-${dm}</b>` : ''}${hl ? `<b class="dmg heal">+${hl}</b>` : ''}<div class="mmst"><div class="mmname">${o === seat ? 'You' : 'Rival'} · ${MM_NAME[s.mon[o]]}</div><div class="mhp big"><div style="width:${s.hp[o] / MM_HP * 100}%"></div><span>HP ${s.hp[o]}</span></div><div class="mmrow"><span class="mar">🛡 ${s.ar[o]}</span><span class="msp">📖 ${s.sp[o]}/10</span></div></div></div>`;
    };
    const msg = ev ? `${ev.by === seat ? 'You' : 'Rival'}: ${ev.dmg ? ev.dmg + ' damage ' : ''}${ev.armor ? '+' + ev.armor + ' armor ' : ''}${ev.heal ? '+' + ev.heal + ' HP ' : ''}${ev.special ? '· ✨ SPECIAL ' : ''}${ev.chain > 1 ? '· x' + ev.chain + ' chain ' : ''}${ev.extra ? '· extra turn!' : ''}` : 'Match tiles to attack!';
    el.innerHTML = `<div class="mfield mm2">${card(foe)}${card(seat)}</div><div class="gemboard">${s.g.map((v, i) => `<button class="gem mg mg${v} ${i === sel ? 'sel' : ''}" data-i="${i}">${mmIcon(v)}</button>`).join('')}</div><div class="ldmsg">${msg}</div>`;
    $$('[data-i]', el).forEach(b => b.onclick = () => {
      if (!mine) return; const i = +b.dataset.i;
      if (el.__sel < 0) { el.__sel = i; return G_MEM.render(el, s, seat, send); }
      const j = el.__sel, adj = Math.abs(Math.floor(i / GN) - Math.floor(j / GN)) + Math.abs((i % GN) - (j % GN)) === 1;
      if (adj) { const t = s.g.slice(); [t[i], t[j]] = [t[j], t[i]]; if (!gemMatches(t).size) { el.__sel = -1; toast('That swap makes no match'); return G_MEM.render(el, s, seat, send); } el.__sel = -1; send({ a: 'swap', i: j, j: i }); }
      else { el.__sel = i; G_MEM.render(el, s, seat, send); }
    });
  }
});

/* ================= WORD MATCH (build words from a letter rack, same rack for both players) ================= */
const WM_V = { a: 1, e: 1, i: 1, o: 1, u: 1, l: 1, n: 1, s: 1, t: 1, r: 1, d: 2, g: 2, b: 3, c: 3, m: 3, p: 3, f: 4, h: 4, v: 4, w: 4, y: 4, k: 5, j: 8, x: 8, q: 10, z: 10 };
let WM_SEVEN = null;
const G_WORD2 = duel({
  id: 'word', name: 'Word Match', icon: '🔤', desc: '90 seconds. Build as many words as you can from the 7 letter tiles. Longer words and the ★ bonus tile score more!',
  bot: () => 70 + Math.floor(Math.random() * 90),
  play(box, seed, done) {
    if (!WM_SEVEN) WM_SEVEN = Array.from(WSET).filter(w => w.length === 7 && !/s$/.test(w));
    const R = rng(seed), base = WM_SEVEN[Math.floor(R() * WM_SEVEN.length)], rack = base.split(''); for (let i = rack.length - 1; i > 0; i--) { const j = Math.floor(R() * (i + 1)); [rack[i], rack[j]] = [rack[j], rack[i]]; }
    const bonus = Math.floor(R() * 7); let cur = [], found = [], score = 0, time = 90, over = false, msg = 'Tap tiles to spell a word', ord = [0, 1, 2, 3, 4, 5, 6];
    const LB = { 3: 0, 4: 2, 5: 5, 6: 10, 7: 25 };
    const tileH = (ch, v, cls) => `<span class="wmt ${cls || ''}">${ch.toUpperCase()}<sub>${v}</sub></span>`;
    const draw = () => {
      const w = cur.map(i => rack[i]).join('');
      box.innerHTML = `<div class="wmwrap"><div class="wmtop"><div class="wmscore">Score<b>${score}</b></div><div class="wmtime ${time <= 10 ? 'low' : ''}">⏱ ${Math.floor(time / 60)}:${String(time % 60).padStart(2, '0')}</div><div class="wmcount">${found.length}<small>words</small></div></div>
        <div class="wmboard"><div class="wmfound">${found.length ? found.slice(-6).map(f => `<div class="wmrow">${f.w.split('').map(ch => tileH(ch, WM_V[ch], 'sm')).join('')}<b>+${f.p}</b></div>`).join('') : '<div class="mut" style="text-align:center;padding:14px">Your words will appear here</div>'}</div></div>
        <div class="wmmsg">${esc(msg)}</div><div class="wmcur" id="wcur">${cur.length ? cur.map(i => tileH(rack[i], WM_V[rack[i]], 'cur')).join('') : '<span class="mut">…</span>'}</div>
        <div class="wmrack">${ord.map(i => `<button class="wmt rk ${cur.includes(i) ? 'used' : ''} ${i === bonus ? 'bon' : ''}" data-i="${i}">${rack[i].toUpperCase()}<sub>${WM_V[rack[i]] * (i === bonus ? 2 : 1)}</sub>${i === bonus ? '<em>★</em>' : ''}</button>`).join('')}</div>
        <div class="wmbtns"><button class="btn sec" id="wsh">🔀 Shuffle</button><button class="btn sec" id="wbk">⌫</button><button class="btn" id="wgo" ${w.length < 3 ? 'disabled' : ''}>✔ Submit</button></div></div>`;
      bindAll(box, '[data-i]', b => { const i = +b.dataset.i; if (over || cur.includes(i)) return; cur.push(i); draw(); });
      $('#wsh', box).onclick = () => { for (let i = ord.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [ord[i], ord[j]] = [ord[j], ord[i]]; } draw(); };
      $('#wbk', box).onclick = () => { cur.pop(); draw(); };
      $('#wgo', box).onclick = () => {
        const wd = cur.map(i => rack[i]).join('');
        if (wd.length < 3) return; if (found.some(f => f.w === wd)) { msg = 'Already found!'; SFX.play('bad'); } else if (!WSET.has(wd)) { msg = '"' + wd.toUpperCase() + '" is not a word'; SFX.play('bad'); } else { let p = cur.reduce((a, i) => a + WM_V[rack[i]] * (i === bonus ? 2 : 1), 0) + (LB[wd.length] || 0); found.push({ w: wd, p }); score += p; SFX.play(wd.length >= 6 ? 'clear' : 'coin'); msg = (wd.length === 7 ? '🎉 ALL 7 LETTERS! ' : '✔ ') + wd.toUpperCase() + ' +' + p; }
        cur = []; draw();
      };
    };
    draw();
    const iv = setInterval(() => { if (over) return; time--; if (time <= 10 && time > 0) SFX.play('tick'); if (time <= 0) { over = true; SFX.play('lose'); clearInterval(iv); box.innerHTML = `<div class="card center">Time’s up!<br>${found.length} words · Score: <b>${score}</b></div>`; done(score); } else { const t = $('.wmtime', box); if (t) { t.textContent = '⏱ ' + Math.floor(time / 60) + ':' + String(time % 60).padStart(2, '0'); t.classList.toggle('low', time <= 10); } } }, 1000);
    return () => { over = true; clearInterval(iv); };
  }
});

/* ================= DOMINOES (ivory tiles on green felt, snake chain) ================= */
const DOM_PIPS = { 0: [], 1: [[.5, .5]], 2: [[.28, .28], [.72, .72]], 3: [[.28, .28], [.5, .5], [.72, .72]], 4: [[.28, .28], [.72, .28], [.28, .72], [.72, .72]], 5: [[.28, .28], [.72, .28], [.5, .5], [.28, .72], [.72, .72]], 6: [[.3, .24], [.7, .24], [.3, .5], [.7, .5], [.3, .76], [.7, .76]] };
function domSVG(a, b, o = {}) {
  const h = 30, id = 'g' + Math.random().toString(36).slice(2, 7), v = !!o.v, px = o.px || 60, back = o.back;
  const W = v ? h : h * 2, H = v ? h * 2 : h;
  const half = (n, k) => (DOM_PIPS[n] || []).map(([x, y]) => `<circle cx="${v ? x * h : k * h + x * h}" cy="${v ? k * h + y * h : y * h}" r="${h * .09}" fill="#1b1b2a"/>`).join('');
  return `<svg class="domsvg ${o.cls || ''}" viewBox="0 0 ${W} ${H}" width="${v ? px / 2 : px}" height="${v ? px : px / 2}"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${back ? '#3b4fd6' : '#fffdf5'}"/><stop offset="1" stop-color="${back ? '#1b2a8f' : '#e3d9bd'}"/></linearGradient></defs><rect x="1" y="1" width="${W - 2}" height="${H - 2}" rx="${h * .18}" fill="url(#${id})" stroke="${o.glow ? '#ffd54a' : '#0006'}" stroke-width="${o.glow ? 2.5 : 1.2}"/>${back ? `<circle cx="${W / 2}" cy="${H / 2}" r="${h * .18}" fill="#fff3"/>` : (v ? `<line x1="${h * .14}" y1="${h}" x2="${h * .86}" y2="${h}" stroke="#9a8f70" stroke-width="1.4"/>` : `<line x1="${h}" y1="${h * .14}" x2="${h}" y2="${h * .86}" stroke="#9a8f70" stroke-width="1.4"/>`) + half(a, 0) + half(b, 1)}</svg>`;
}
const domPips = hand => hand.reduce((a, t) => a + t[0] + t[1], 0);
Object.assign(G_DOM, {
  desc: 'Match the tile ends and play all your tiles first. Draw from the boneyard if you have no move. Fewest pips wins a blocked game.',
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null, hand = s.hands[seat], ends = domEnds(s);
    const sel = el.__sel != null && hand[el.__sel] ? el.__sel : null, can = hand.some(t => domPlayable(t, ends));
    const selT = sel != null ? hand[sel] : null, selL = selT && ends && (selT[0] === ends[0] || selT[1] === ends[0]), selR = selT && ends && (selT[0] === ends[1] || selT[1] === ends[1]), both = selL && selR && ends[0] !== ends[1];
    const chain = s.board.length ? s.board.map((t, i) => { const dbl = t[0] === t[1], hl = (i === 0 && selL) || (i === s.board.length - 1 && selR); const side = (i === 0 && selL) ? 'L' : (i === s.board.length - 1 && selR) ? 'R' : ''; return `<span class="dtile ${hl && both ? 'pick' : ''}" ${hl ? `data-side="${side}"` : ''}>${domSVG(t[0], t[1], { px: dbl ? 62 : 70, v: dbl })}</span>`; }).join('') : '<span class="mut">Play any tile to start the chain</span>';
    const opp = Array.from({ length: s.hands[1 - seat].length }, () => domSVG(0, 0, { back: true, px: 34 })).join('');
    el.innerHTML = `<div class="domfelt"><div class="domtopbar"><div class="dompl ${s.turn !== seat && s.winner == null ? 'act' : ''}"><span class="domav">🤖</span><b>${domPips(s.hands[1 - seat])}</b></div><div class="domoppt">${opp}</div><div class="domstock ${mine && !can && s.stock.length ? 'pulse' : ''}" id="dw">${domSVG(0, 0, { back: true, px: 56 })}<b>${s.stock.length}</b></div></div>
      <div class="domchain">${chain}</div>
      <div class="domhand2">${hand.map((t, i) => `<button class="dh ${mine && domPlayable(t, ends) ? 'ok' : ''} ${sel === i ? 'sel' : ''}" data-t="${i}">${domSVG(t[0], t[1], { px: 84 })}</button>`).join('')}</div>
      <div class="domtopbar"><div class="dompl ${mine ? 'act' : ''}"><span class="domav">🙂</span><b>${domPips(hand)}</b></div><div class="domstat">${s.winner != null ? '' : mine ? (can ? (both ? '👆 Tap a glowing end of the chain' : '👉 Tap a glowing tile') : (s.stock.length ? '📦 No move: tap the boneyard to draw' : '⏭ No move')) : '⏳ Opponent’s turn'}</div></div>
      ${mine && !can && !s.stock.length ? '<button class="btn full" id="ps">⏭ Pass</button>' : ''}</div>`;
    if (!mine) return;
    bindAll(el, '[data-t]', b => {
      const i = +b.dataset.t, t = hand[i]; if (!domPlayable(t, ends)) return;
      if (!ends) return send({ a: 'play', t: i, side: 'R' });
      const r = t[0] === ends[1] || t[1] === ends[1], l = t[0] === ends[0] || t[1] === ends[0];
      if (r && l && ends[0] !== ends[1]) { el.__sel = i; G_DOM.render(el, s, seat, send); } else send({ a: 'play', t: i, side: r ? 'R' : 'L' });
    });
    bindAll(el, '[data-side]', b => { if (el.__sel == null) return; const i = el.__sel; el.__sel = null; send({ a: 'play', t: i, side: b.dataset.side }); });
    const dw = $('#dw', el); if (dw) dw.onclick = () => { if (!can && s.stock.length) send({ a: 'draw' }); };
    const ps = $('#ps', el); if (ps) ps.onclick = () => send({ a: 'pass' });
  }
});


/* ================= BACKGAMMON (wooden board, glossy checkers) ================= */
const BGC = ['#e8374f', '#2f6fe0'];
function bgDie(n, used) { const h = 40; return `<svg viewBox="0 0 40 40" width="40" height="40" class="${used ? 'dieu' : ''}"><rect x="1.5" y="1.5" width="37" height="37" rx="8" fill="${used ? '#8a8a96' : '#fffdf5'}" stroke="#0006" stroke-width="1.5"/>${DOM_PIPS[n].map(([x, y]) => `<circle cx="${6 + x * 28}" cy="${6 + y * 28}" r="3.4" fill="#1b1b2a"/>`).join('')}</svg>`; }
Object.assign(G_BG, {
  botDelay: 1050,
  desc: 'Roll the dice, move your checkers home and bear them all off first. Hit single checkers to send them to the bar!',
  render(el, s, seat, send) {
    const mine = s.turn === seat && s.winner == null, mv = mine ? bgMoves(s, seat) : [];
    let sel = el.__sel; if (sel != null && !mv.some(m => m.from === sel)) sel = el.__sel = null;
    const dests = sel != null ? mv.filter(m => m.from === sel) : [], froms = new Set(mv.map(m => m.from));
    const top = seat === 0 ? [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23] : [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0], bot = seat === 0 ? [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0] : [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23];
    const colX = k => k < 6 ? 12 + k * 30 : 216 + (k - 6) * 30, TH = 150, B = 348, T = 12;
    let svg = `<defs><radialGradient id="ck0" cx=".35" cy=".3"><stop offset="0" stop-color="#ffb0bc"/><stop offset=".55" stop-color="${BGC[0]}"/><stop offset="1" stop-color="#8a1224"/></radialGradient><radialGradient id="ck1" cx=".35" cy=".3"><stop offset="0" stop-color="#a8c8ff"/><stop offset=".55" stop-color="${BGC[1]}"/><stop offset="1" stop-color="#14327a"/></radialGradient><linearGradient id="wd" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7a4a22"/><stop offset="1" stop-color="#4a2a12"/></linearGradient></defs>`;
    svg += `<rect x="0" y="0" width="432" height="360" rx="14" fill="url(#wd)"/><rect x="8" y="8" width="388" height="344" rx="6" fill="#2a1a10"/><rect x="192" y="8" width="24" height="344" fill="#5a3418"/><rect x="398" y="8" width="28" height="344" rx="4" fill="#3a2212"/>`;
    const tri = (idx, k, isTop) => { const x = colX(k), y0 = isTop ? T : B, y1 = isTop ? T + TH : B - TH, col = (k % 2) ? '#c9a066' : '#8a2f2f', isD = dests.some(m => m.to === idx); return `<polygon points="${x + 1},${y0} ${x + 29},${y0} ${x + 15},${y1}" fill="${col}"/>${isD ? `<polygon points="${x + 1},${y0} ${x + 29},${y0} ${x + 15},${y1}" fill="#5aff8a" opacity=".45"/><circle cx="${x + 15}" cy="${isTop ? T + 22 : B - 22}" r="8" fill="#5aff8a" stroke="#fff" stroke-width="2"/>` : ''}`; };
    top.forEach((idx, k) => { svg += tri(idx, k, true); }); bot.forEach((idx, k) => { svg += tri(idx, k, false); });
    const ck = (x, y, who, extra) => `<circle cx="${x}" cy="${y}" r="13" fill="url(#ck${who})" stroke="#0007" stroke-width="1.2" ${extra || ''}/><circle cx="${x}" cy="${y}" r="8.5" fill="none" stroke="#fff4" stroke-width="1.4"/>`;
    const stack = (idx, k, isTop) => {
      const n = s.pts[idx], c = Math.abs(n); if (!c) return ''; const who = n > 0 ? 0 : 1, x = colX(k) + 15; let o = '';
      for (let j = 0; j < Math.min(c, 5); j++) { const y = isTop ? T + 14 + j * 25 : B - 14 - j * 25, topc = j === Math.min(c, 5) - 1; o += ck(x, y, who, sel === idx && topc ? 'stroke="#ffd54a" stroke-width="3"' : (froms.has(idx) && topc && who === seat ? 'stroke="#5aff8a" stroke-width="3"' : '')); if (topc && c > 5) o += `<text x="${x}" y="${y + 5}" text-anchor="middle" font-size="14" font-weight="900" fill="#fff" stroke="#000" stroke-width="3" paint-order="stroke">${c}</text>`; }
      return o;
    };
    top.forEach((idx, k) => { svg += stack(idx, k, true); }); bot.forEach((idx, k) => { svg += stack(idx, k, false); });
    for (let j = 0; j < s.bar[1 - seat]; j++) svg += ck(204, 150 - j * 24, 1 - seat);
    for (let j = 0; j < s.bar[seat]; j++) svg += ck(204, 214 + j * 24, seat, sel === 'bar' ? 'stroke="#ffd54a" stroke-width="3"' : (froms.has('bar') ? 'stroke="#5aff8a" stroke-width="3"' : ''));
    for (let j = 0; j < s.off[seat]; j++) svg += `<rect x="402" y="${340 - j * 7}" width="20" height="5" rx="2" fill="url(#ck${seat})"/>`;
    for (let j = 0; j < s.off[1 - seat]; j++) svg += `<rect x="402" y="${14 + j * 7}" width="20" height="5" rx="2" fill="url(#ck${1 - seat})"/>`;
    if (dests.some(m => m.to === 'off')) svg += `<rect x="400" y="170" width="24" height="120" rx="6" fill="#5aff8a" opacity=".5" data-off="1"/>`;
    top.forEach((idx, k) => { svg += `<rect x="${colX(k)}" y="${T}" width="30" height="170" fill="transparent" data-p="${idx}"/>`; }); bot.forEach((idx, k) => { svg += `<rect x="${colX(k)}" y="${B - 170}" width="30" height="170" fill="transparent" data-p="${idx}"/>`; });
    const rem = s.d.slice(), all = s.rolled ? (s.rolled[0] === s.rolled[1] ? [s.rolled[0], s.rolled[0], s.rolled[0], s.rolled[0]] : s.rolled.slice()) : [];
    const left = all.map(d => { const i = rem.indexOf(d); if (i >= 0) { rem.splice(i, 1); return true; } return false; });
    const dbl = !!s.rolled && s.rolled[0] === s.rolled[1], nleft = s.d.length;
    let D = el.__bg3; if (!D) D = el.__bg3 = { rc: -1, layer: document.createElement('div'), dice: [dr3Dice({ size: 46 }), dr3Dice({ size: 46 })] };
    if (!D.layer.firstChild) { D.layer.className = 'dr3-bglayer'; D.dice.forEach(d => D.layer.appendChild(d)); }
    if (D.rc !== s.rc && s.rolled) {
      D.dice.forEach((d, k) => d.dr3roll(s.rolled[k], { dur: 880, delay: k * 110, sound: k === 0, dx: (k ? 1 : -1) * (14 + Math.random() * 26) }));
      D.rc = s.rc;
    } else if (s.rolled && !D.dice[0].classList.contains('dr3-rolling') && !D.dice[1].classList.contains('dr3-rolling')) D.dice.forEach((d, k) => d.dr3set(s.rolled[k]));
    D.dice.forEach((d, k) => { d.dr3used(dbl ? nleft === 0 : !left[k]); d.classList.toggle('dr3-gold', dbl && nleft > 0); });
    D.layer.style.display = s.rolled ? '' : 'none';
    const msg = s.winner != null ? '' : (dbl ? `<b class="dr3-dbl">DOUBLES ×4</b> ${[0, 1, 2, 3].map(k => `<i class="dr3-pipdot ${k < nleft ? 'on' : ''}"></i>`).join('')} ` : '') + (s.winner != null ? '' : mine ? 'Your move' : '⏳ Opponent’s move');
    el.innerHTML = `<div class="bgbar"><span style="color:${BGC[seat]}">● You</span> <span class="mut">off ${s.off[seat]} · bar ${s.bar[seat]}</span><span style="flex:1"></span><span class="mut">off ${s.off[1 - seat]} · bar ${s.bar[1 - seat]}</span> <span style="color:${BGC[1 - seat]}">● Opp</span></div><div class="dr3-bgwrap"><svg class="bgsvg" viewBox="0 0 432 360">${svg}</svg><span id="dr3ph"></span></div><div class="bgdice">${msg}</div>${mine && s.bar[seat] ? `<button class="btn ${sel === 'bar' ? '' : 'sec'} full" data-bar="1">🚧 Enter from the bar</button>` : ''}${dests.some(m => m.to === 'off') ? '<button class="btn full" id="off">🏁 Bear off</button>' : ''}`;
    $('#dr3ph', el).replaceWith(D.layer);
    if (!mine) return;
    bindAll(el, '[data-p]', b => {
      const i = +b.dataset.p, d = dests.find(m => m.to === i);
      if (d) { el.__sel = null; return send({ from: d.from, die: d.die }); }
      if (!s.bar[seat] && froms.has(i)) { el.__sel = i; G_BG.render(el, s, seat, send); }
    });
    const bb = $('[data-bar]', el); if (bb) bb.onclick = () => { const ds = mv.filter(m => m.from === 'bar'); if (ds.length === 1) send({ from: 'bar', die: ds[0].die }); else { el.__sel = 'bar'; G_BG.render(el, s, seat, send); } };
    const of = $('#off', el); if (of) of.onclick = () => { const d = dests.find(m => m.to === 'off'); el.__sel = null; send({ from: d.from, die: d.die }); };
    const ofr = $('[data-off]', el); if (ofr) ofr.onclick = () => { const d = dests.find(m => m.to === 'off'); el.__sel = null; send({ from: d.from, die: d.die }); };
  }
});


/* ================= SEA BATTLE (10x10, fleet placement, sonar, fire) ================= */
const SEN = 10, SSH = [5, 4, 3, 3, 2], SEA_NAMES = ['Carrier', 'Cruiser', 'Destroyer', 'Sub', 'Boat'];
const seaNb = i => { const r = (i / SEN) | 0, c = i % SEN, o = []; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { const rr = r + dr, cc = c + dc; if (rr >= 0 && rr < SEN && cc >= 0 && cc < SEN) o.push(rr * SEN + cc); } return o; };
function seaCells(r, c, len, h) { const o = []; for (let k = 0; k < len; k++) { const rr = r + (h ? 0 : k), cc = c + (h ? k : 0); if (rr >= SEN || cc >= SEN) return null; o.push(rr * SEN + cc); } return o; }
function seaCanPut(g, cells, id) { return cells && cells.every(i => seaNb(i).every(j => g[j] < 0 || g[j] === id)); }
function seaValid(g) {
  if (!Array.isArray(g) || g.length !== SEN * SEN) return false;
  for (let id = 0; id < SSH.length; id++) {
    const cs = []; g.forEach((v, i) => { if (v === id) cs.push(i); }); if (cs.length !== SSH[id]) return false;
    const r0 = (cs[0] / SEN) | 0, c0 = cs[0] % SEN, h = cs.length < 2 || ((cs[1] / SEN) | 0) === r0; const exp = seaCells(r0, c0, cs.length, h); if (!exp || exp.some((v, k) => v !== cs[k])) return false;
    if (cs.some(i => seaNb(i).some(j => g[j] >= 0 && g[j] !== id))) return false;
  }
  return g.every(v => v >= -1 && v < SSH.length);
}
function seaRandom() { for (let t = 0; t < 200; t++) { const g = Array(SEN * SEN).fill(-1); let ok = true; for (let id = 0; id < SSH.length && ok; id++) { ok = false; for (let k = 0; k < 300; k++) { const h = Math.random() < .5, cs = seaCells(Math.floor(Math.random() * SEN), Math.floor(Math.random() * SEN), SSH[id], h); if (seaCanPut(g, cs, id)) { cs.forEach(i => g[i] = id); ok = true; break; } } } if (ok) return g; } return null; }
const seaSunk2 = (ships, sh, id) => ships.every((v, i) => v !== id || sh[i] === 2);
function seaShipCells(g, id) { const o = []; g.forEach((v, i) => { if (v === id) o.push(i); }); return o; }
function seaDrawShip(c, cells, cs, ox, oy, col, alpha) {
  if (!cells.length) return; const r0 = Math.floor(cells[0] / SEN), c0 = cells[0] % SEN, horiz = cells.length < 2 || Math.floor(cells[1] / SEN) === r0, L = cells.length;
  c.save(); c.globalAlpha = alpha == null ? 1 : alpha; c.translate(ox + c0 * cs + (horiz ? L * cs / 2 : cs / 2), oy + r0 * cs + (horiz ? cs / 2 : L * cs / 2)); if (!horiz) c.rotate(Math.PI / 2);
  const w = L * cs - 4, h = cs * .66; c.fillStyle = shade(col, -.35); c.beginPath(); c.moveTo(-w / 2, 0); c.quadraticCurveTo(-w / 2 + 5, -h / 2, -w / 2 + h * .6, -h / 2); c.lineTo(w / 2 - h * .7, -h / 2); c.quadraticCurveTo(w / 2, 0, w / 2 - h * .7, h / 2); c.lineTo(-w / 2 + h * .6, h / 2); c.quadraticCurveTo(-w / 2 + 5, h / 2, -w / 2, 0); c.fill();
  c.fillStyle = col; c.fillRect(-w / 2 + h * .6, -h / 2 + 3, w - h * 1.4, h - 6); c.fillStyle = shade(col, .3); c.fillRect(-w / 6, -h / 4, w / 3, h / 2); c.fillStyle = '#ffffff55'; c.fillRect(-w / 2 + 8, -1, w - 20, 2); c.restore();
}
function seaGrid(c, x, y, cs, t) {
  const S = cs * SEN, g = c.createRadialGradient(x + S / 2, y + S / 2, 10, x + S / 2, y + S / 2, S * .75); g.addColorStop(0, '#0b3a4a'); g.addColorStop(1, '#041a24'); c.fillStyle = g; rr(c, x - 4, y - 4, S + 8, S + 8, 10); c.fill();
  c.strokeStyle = '#27e0ff2e'; c.lineWidth = 1; for (let i = 0; i <= SEN; i++) { c.beginPath(); c.moveTo(x + i * cs, y); c.lineTo(x + i * cs, y + S); c.moveTo(x, y + i * cs); c.lineTo(x + S, y + i * cs); c.stroke(); }
  if (t != null) { c.save(); c.beginPath(); c.rect(x, y, S, S); c.clip(); const a = t * 1.4, sw = c.createLinearGradient(x + S / 2, y + S / 2, x + S / 2 + Math.cos(a) * S, y + S / 2 + Math.sin(a) * S); sw.addColorStop(0, '#27e0ff55'); sw.addColorStop(1, '#27e0ff00'); c.fillStyle = sw; c.beginPath(); c.moveTo(x + S / 2, y + S / 2); c.arc(x + S / 2, y + S / 2, S, a - .35, a); c.closePath(); c.fill(); c.restore(); }
}
function seaMark(c, v, cx, cy, cs, age) {
  if (v === 1) { c.strokeStyle = '#cfeaff'; c.lineWidth = 2; c.beginPath(); c.arc(cx, cy, cs * .2, 0, 6.283); c.stroke(); c.globalAlpha = .45; c.beginPath(); c.arc(cx, cy, cs * .34, 0, 6.283); c.stroke(); c.globalAlpha = 1; }
  else if (v === 2) { const g = c.createRadialGradient(cx, cy, 1, cx, cy, cs * .42); g.addColorStop(0, '#fff3a0'); g.addColorStop(.4, '#ff8a2a'); g.addColorStop(1, '#c4141466'); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, cs * .42, 0, 6.283); c.fill(); c.strokeStyle = '#7a0a0a'; c.lineWidth = 2; c.beginPath(); c.moveTo(cx - cs * .16, cy - cs * .16); c.lineTo(cx + cs * .16, cy + cs * .16); c.moveTo(cx + cs * .16, cy - cs * .16); c.lineTo(cx - cs * .16, cy + cs * .16); c.stroke(); }
  if (age != null && age < .9) { c.strokeStyle = v === 2 ? '#ffb02e' : '#fff'; c.globalAlpha = 1 - age / .9; c.lineWidth = 3; c.beginPath(); c.arc(cx, cy, cs * (.3 + age * 1.2), 0, 6.283); c.stroke(); c.globalAlpha = 1; }
}
const G_SEA2 = {
  id: 'sea', name: 'Sea Battle', icon: '🚢', sym: ['🔴', '🔵'], simul: true,
  desc: 'Place your fleet (ships may not touch, even diagonally), then take turns firing. A hit gives you another shot!',
  init: () => ({ ph: 0, rdy: [0, 0], ships: [null, null], sh: [Array(100).fill(0), Array(100).fill(0)], turn: 0, winner: null, cnt: 0, last: null }),
  status: (s, seat) => s.winner != null ? '' : s.ph === 0 ? (s.rdy[seat] ? '⏳ Waiting for rival to place fleet' : '🚢 Place your fleet') : (s.turn === seat ? '🎯 Your turn' : '⏳ Enemy is aiming'),
  move(s, m, seat) {
    if (s.winner != null) return null;
    if (m.a === 'ready') { if (s.ph !== 0 || s.rdy[seat] || !seaValid(m.g)) return null; s.ships[seat] = m.g; s.rdy[seat] = 1; if (s.rdy[0] && s.rdy[1]) { s.ph = 1; s.turn = 0; } return s; }
    if (m.a !== 'fire' || s.ph !== 1 || s.turn !== seat) return null;
    const t = 1 - seat, i = m.i | 0; if (i < 0 || i > 99 || s.sh[t][i]) return null;
    const hit = s.ships[t][i] >= 0; s.sh[t][i] = hit ? 2 : 1; s.cnt++; s.last = { by: seat, i, hit };
    if (s.ships[t].every((v, k) => v < 0 || s.sh[t][k] === 2)) s.winner = seat; else if (!hit) s.turn = t;
    return s;
  },
  bot(s, seat) {
    if (s.winner != null) return null;
    if (s.ph === 0) return s.rdy[seat] ? null : { a: 'ready', g: seaRandom() };
    if (s.turn !== seat) return null;
    const t = 1 - seat, sh = s.sh[t], ships = s.ships[t], free = []; sh.forEach((v, i) => { if (!v) free.push(i); });
    const near = [], hits = []; sh.forEach((v, i) => { if (v === 2 && !seaSunk2(ships, sh, ships[i])) hits.push(i); });
    hits.forEach(i => { [[0, 1], [0, -1], [1, 0], [-1, 0]].forEach(([dr, dc]) => { const r = (i / SEN | 0) + dr, c = i % SEN + dc; if (r >= 0 && r < SEN && c >= 0 && c < SEN && !sh[r * SEN + c]) { const aligned = hits.length < 2 || hits.some(h => h !== i && ((h / SEN | 0) === (i / SEN | 0) ? dr === 0 : dc === 0)); near.push([r * SEN + c, aligned ? 2 : 1]); } }); });
    if (near.length) { const top = near.filter(n => n[1] === Math.max(...near.map(x => x[1]))); return { a: 'fire', i: pick(top)[0] }; }
    const par = free.filter(i => ((i / SEN | 0) + i % SEN) % 2 === 0); const pool = par.length ? par : free; return { a: 'fire', i: pick(pool) };
  },
  render(el, s, seat, send) {
    if (s.ph === 0) return seaPlaceUI(el, s, seat, send);
    let R = el.__sea;
    if (!R || el.__sg !== s.gid || el.__mode !== 1) {
      if (el.__stop) try { el.__stop(); } catch (e) { } el.innerHTML = ''; el.__sg = s.gid; el.__mode = 1;
      const { cv, c } = arena(el, 360, 582); const fb = document.createElement('button'); fb.className = 'btn full'; el.appendChild(fb);
      R = el.__sea = { s, seat, sel: -1, t: 0, cv, c, fb, seen: s.cnt, born: -9 };
      const upd = () => { const S = R.s, can = S.turn === R.seat && S.winner == null; fb.disabled = !(can && R.sel >= 0); fb.textContent = S.winner != null ? (S.winner === R.seat ? '🏆 You won!' : '💀 You lost') : can ? (R.sel >= 0 ? '🔥 FIRE at ' + 'ABCDEFGHIJ'[R.sel % SEN] + (Math.floor(R.sel / SEN) + 1) : 'Tap a square on the enemy sea') : '⏳ Enemy is aiming…'; };
      R.upd = upd;
      cv.addEventListener('pointerdown', e => { const p = ptr(cv, e), col = Math.floor((p.x - 30) / 30), row = Math.floor((p.y - 50) / 30); if (col < 0 || row < 0 || col >= SEN || row >= SEN) return; const i = row * SEN + col, S = R.s; if (S.turn !== R.seat || S.winner != null || S.sh[1 - R.seat][i]) return; R.sel = i; upd(); e.preventDefault(); });
      fb.onclick = () => { if (R.sel >= 0) { const i = R.sel; R.sel = -1; send({ a: 'fire', i }); } };
      R.stop = anim(dt => {
        R.t += dt; const S = R.s, sd = R.seat, tt = 1 - sd; if (S.cnt !== R.seen) { R.seen = S.cnt; R.born = R.t; }
        const age = R.t - R.born, last = S.last;
        const bg = c.createLinearGradient(0, 0, 0, 582); bg.addColorStop(0, '#05212e'); bg.addColorStop(1, '#020c12'); c.fillStyle = bg; c.fillRect(0, 0, 360, 582);
        c.fillStyle = '#27e0ff'; c.font = '900 13px Arial'; c.textAlign = 'center'; c.fillText('ENEMY WATERS · SONAR', 180, 18);
        const ships = S.ships[tt], sh = S.sh[tt]; seaGrid(c, 30, 50, 30, R.t);
        for (let i = 0; i < SEN; i++) { c.fillStyle = '#27e0ffaa'; c.font = '700 11px Arial'; c.textAlign = 'center'; c.fillText('ABCDEFGHIJ'[i], 30 + i * 30 + 15, 44); c.fillText(i + 1, 19, 50 + i * 30 + 19); }
        SSH.forEach((len, id) => { if (seaSunk2(ships, sh, id)) seaDrawShip(c, seaShipCells(ships, id), 30, 30, 50, '#a02a2a', .85); });
        for (let i = 0; i < 100; i++) { const v = sh[i]; if (v) seaMark(c, v, 30 + (i % SEN) * 30 + 15, 50 + Math.floor(i / SEN) * 30 + 15, 30, last && last.by === sd && last.i === i ? age : null); }
        if (R.sel >= 0) { const cx = 30 + (R.sel % SEN) * 30 + 15, cy = 50 + Math.floor(R.sel / SEN) * 30 + 15; c.strokeStyle = '#ffd54a'; c.lineWidth = 2.5; c.beginPath(); c.arc(cx, cy, 11 + Math.sin(R.t * 6) * 2, 0, 6.283); c.moveTo(cx - 17, cy); c.lineTo(cx - 7, cy); c.moveTo(cx + 7, cy); c.lineTo(cx + 17, cy); c.moveTo(cx, cy - 17); c.lineTo(cx, cy - 7); c.moveTo(cx, cy + 7); c.lineTo(cx, cy + 17); c.stroke(); }
        c.fillStyle = '#27e0ff'; c.font = '900 12px Arial'; c.textAlign = 'left'; c.fillText('YOUR FLEET', 20, 378);
        const ms = S.ships[sd], msh = S.sh[sd]; seaGrid(c, 20, 388, 16, null);
        SSH.forEach((len, id) => seaDrawShip(c, seaShipCells(ms, id), 16, 20, 388, seaSunk2(ms, msh, id) ? '#a02a2a' : '#7fa3c8'));
        for (let i = 0; i < 100; i++) { const v = msh[i]; if (v) seaMark(c, v, 20 + (i % SEN) * 16 + 8, 388 + Math.floor(i / SEN) * 16 + 8, 16, last && last.by === tt && last.i === i ? age : null); }
        c.fillStyle = '#27e0ff'; c.fillText('ENEMY FLEET', 214, 378);
        SSH.forEach((len, id) => { const dead = seaSunk2(ships, sh, id), y = 392 + id * 26; for (let k = 0; k < len; k++) { c.fillStyle = dead ? '#a02a2a' : '#7fa3c8'; rr(c, 214 + k * 14, y, 12, 12, 3); c.fill(); } c.fillStyle = dead ? '#ff6b6b' : '#9fc'; c.font = '700 10px Arial'; c.fillText(SEA_NAMES[id] + (dead ? ' ✖' : ''), 214 + 5 * 14 + 6, y + 10); });
        c.fillStyle = S.turn === sd && S.winner == null ? '#5aff8a' : '#ffd54a'; c.font = '900 14px Arial'; c.textAlign = 'center'; c.fillText(S.winner != null ? (S.winner === sd ? 'VICTORY!' : 'DEFEAT') : (S.turn === sd ? 'YOUR TURN' : 'ENEMY TURN'), 180, 574);
        R.upd();
      });
      el.__stop = R.stop;
    }
    R.s = s; R.seat = seat; R.upd();
  }
};
function seaPlaceUI(el, s, seat, send) {
  if (el.__stop) { try { el.__stop(); } catch (e) { } el.__stop = null; }
  if (el.__pg !== s.gid || el.__mode !== 0) { el.__pg = s.gid; el.__mode = 0; el.__sea = null; el.__pl = { g: Array(100).fill(-1), cur: 0, h: true }; }
  const P = el.__pl, done = s.rdy[seat], placed = id => P.g.includes(id), all = SSH.every((_, id) => placed(id));
  const cs = 32, ox = 20, oy = 8;
  const cell = i => { const v = P.g[i], r = (i / SEN) | 0, c = i % SEN; return `<div class="sbc ${v >= 0 ? 'ship' : ''}" data-i="${i}" style="left:${c * cs}px;top:${r * cs}px;width:${cs}px;height:${cs}px"></div>`; };
  el.innerHTML = `<div class="seaplace"><div class="seat">Place your fleet</div><div class="mut" style="text-align:center;font-size:12px">Ships can’t touch each other — not even diagonally</div>
    <div class="sbboard" style="width:${cs * SEN}px;height:${cs * SEN}px">${Array.from({ length: 100 }, (_, i) => cell(i)).join('')}</div>
    <div class="sbships">${SSH.map((l, id) => `<button class="sbchip ${P.cur === id ? 'on' : ''} ${placed(id) ? 'ok' : ''}" data-id="${id}" ${done ? 'disabled' : ''}>${SEA_NAMES[id]} <b>${'■'.repeat(l)}</b></button>`).join('')}</div>
    <div class="sbbtns"><button class="btn sec" id="sbr" ${done ? 'disabled' : ''}>🔄 ${P.h ? 'Horizontal' : 'Vertical'}</button><button class="btn sec" id="sbx" ${done ? 'disabled' : ''}>🎲 Random</button><button class="btn sec" id="sbc" ${done ? 'disabled' : ''}>🗑 Clear</button></div>
    <button class="btn full" id="sbok" ${done || !all ? 'disabled' : ''}>${done ? '⏳ Waiting for rival…' : all ? '✅ Ready — Start battle' : 'Place all 5 ships (tap the sea)'}</button></div>`;
  // colour ships via inline styles by id
  const cols = ['#7fa3c8', '#6fc2a0', '#c8a46f', '#b389d6', '#d68989'];
  $$('.sbc', el).forEach(d => { const v = P.g[+d.dataset.i]; if (v >= 0) d.style.background = cols[v]; });
  if (done) return;
  $$('[data-id]', el).forEach(b => b.onclick = () => { P.cur = +b.dataset.id; seaPlaceUI(el, s, seat, send); });
  $$('.sbc', el).forEach(d => d.onclick = () => {
    const i = +d.dataset.i, v = P.g[i];
    if (v >= 0) { P.g = P.g.map(x => x === v ? -1 : x); P.cur = v; return seaPlaceUI(el, s, seat, send); }
    const len = SSH[P.cur]; let r = (i / SEN) | 0, c = i % SEN; if (P.h) c = Math.min(c, SEN - len); else r = Math.min(r, SEN - len);
    const cells = seaCells(r, c, len, P.h), g = P.g.map(x => x === P.cur ? -1 : x);
    if (!seaCanPut(g, cells, P.cur)) { d.classList.add('bad'); return setTimeout(() => d.classList.remove('bad'), 300); }
    cells.forEach(k => g[k] = P.cur); P.g = g; const nx = SSH.findIndex((_, id) => !g.includes(id)); if (nx >= 0) P.cur = nx; seaPlaceUI(el, s, seat, send);
  });
  $('#sbr', el).onclick = () => { P.h = !P.h; seaPlaceUI(el, s, seat, send); };
  $('#sbx', el).onclick = () => { const g = seaRandom(); if (g) { P.g = g; seaPlaceUI(el, s, seat, send); } };
  $('#sbc', el).onclick = () => { P.g = Array(100).fill(-1); P.cur = 0; seaPlaceUI(el, s, seat, send); };
  $('#sbok', el).onclick = () => { if (seaValid(P.g)) send({ a: 'ready', g: P.g }); };
}
